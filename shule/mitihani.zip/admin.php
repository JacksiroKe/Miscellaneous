<?php

	require( "config.php" );
	session_start();
	$open = isset( $_GET['open'] ) ? $_GET['open'] : "";

	$content = array();
	$content['sitename'] = strlen(as_option('sitename')) ? as_option('sitename') : SITENAME;
	$adminid = isset( $_SESSION['loggedin_admin'] ) ? $_SESSION['loggedin_admin'] : "";
	$level = isset( $_SESSION['loggedin_level'] ) ? $_SESSION['loggedin_level'] : "";
	$adminame = isset( $_SESSION['loggedin_adminame'] ) ? $_SESSION['loggedin_adminame'] : "";
		
	if ($open == 'install') {
		errMissingTables();
		exit();
	}
	
	if ( $open != "signin" && $open != "signout" && $open != "register" && !$adminid ) {
		$open = 'signin';
	}

	switch ( $open ) {
		case 'signin':
			require( CORE . "admin.php" );
			$content['admin'] = new admin;
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array( 
						'handle' => array('label' => 'Username:', 'type' => 'text'),				
						'password' => array('label' => 'Password:', 'type' => 'password'),
					),
			
					'buttons' => array('signin' => array('label' => 'Login')),			
				);
			
			$content['title'] = "Login to Your Account";
			if ( isset( $_POST['signin'] ) ) {
				$adminid = admin::signinuser($_POST['handle'], md5($_POST['password']));
				if ($adminid) {
					header( "Location: admin.php" );
				} else {
					$content['errorMessage'] = "Incorrect username or password. Please try again.";
				}
			}
			break;

		case 'register':
			require( CORE . "admin.php" );
			$content['admin'] = new admin;			
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array( 
						'firstname' => array('label' => 'First Name:', 'type' => 'text', 'tags' => 'required '),
						'lastname' => array('label' => 'Last Name:', 'type' => 'text', 'tags' => 'required '),
						'sex' => array('label' => 'Sex:', 'type' => 'radio', 
							'options' => array(
								'male' => array('name' => 'Male', 'value' => 1),
								'female' => array('name' => 'Female', 'value' => 2),
								), 'value' => 1, 'tags' => 'required '),
						'mobile' => array('label' => 'Mobile:', 'type' => 'text', 'tags' => 'required '),
						'email' => array('label' => 'Email:', 'type' => 'email', 'tags' => 'required '),
						'handle' => array('label' => 'Username:', 'type' => 'text', 'tags' => 'required '),
						'password' => array('label' => 'Password:', 'type' => 'password', 'tags' => 'required '),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array('register' => array('label' => 'Register')),
				);
			
			$content['title'] = "Register as a admin";
			if ( isset( $_POST['register'] ) ) {
				$admin = new admin;
				$admin->storeFormValues( $_POST );
				$adminid = $admin->insert();
				if ($adminid) {
					$_SESSION['loggedin_level'] = $_POST['level'];
					$_SESSION['loggedin_admin'] = $adminid;
					header( "Location: admin.php" );
				} else {
					$content['errorMessage'] = "Unable to register you at the moment. Please try again later.";
				}
			}
			break;
		
		case 'class_new':
			require( CORE . "tclass.php" );
			$content['class'] = new tclass;			
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array(
						'title' => array('label' => 'Class Title:', 'type' => 'text', 'tags' => 'required '),
						'code' => array('label' => 'Class Code:', 'type' => 'text', 'tags' => 'required '),
					),
					
					'hidden' => array('admin' => 1),		
					'buttons' => array(
						'saveclose' => array('label' => 'Save & Close'),
						'saveadd' => array('label' => 'Save & Add'),
					),
				);
			
			$content['title'] = "Add a Class";
			if ( isset( $_POST['saveclose'] ) ) {
				$class = new tclass;
				$class->storeFormValues( $_POST );
				$classid = $class->insert();
				if ($classid) {
					header( "Location: admin.php?open=class_all" );
				} else {
					$content['errorMessage'] = "Unable to add a class at the moment. Please try again later.";
				}
			} else if ( isset( $_POST['saveadd'] ) ) {
				$class = new tclass;
				$class->storeFormValues( $_POST );
				$classid = $class->insert();
				if ($classid) {
					header( "Location: admin.php?open=class_new" );
				} else {
					$content['errorMessage'] = "Unable to add a class at the moment. Please try again later.";
				}
			}
			break;
			
		case 'class_view':
			require( CORE . "tclass.php" );
			$classid = $_GET["classid"];
			$class = tclass::getById( (int)$classid );
			$content['title'] = "Edit Class";
			$content['link'] = '<a href="admin.php?open=class_delete&&classid='.$classid.'" onclick="return confirm(\'Delete This Class? This action is irrevesible!\')" style="float:right;">DELETE CLASS</a>';	
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open.'&&classid='.$classid,
					'fields' => array(
						'title' => array('label' => 'Class Title:', 'type' => 'text', 'tags' => 'required ', 'value' => $class->title),
						'code' => array('label' => 'Class Code:', 'type' => 'text', 'tags' => 'required ', 'value' => $class->code),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
						'cancel' => array('label' => 'Cancel Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$class->storeFormValues( $_POST );
				$class->update();
				header( "Location: admin.php?open=class_view&&classid=".$classid."status=changesSaved" );
			} elseif ( isset( $_POST['cancel'] ) ) {
				header( "Location: admin.php?open=class_all" );
			} 
			break;
			
		case 'class_all':
			require( CORE . "tclass.php" );
			$adminid = $_SESSION["loggedin_admin"];
			$dbitems = tclass::getList( $adminid );
			$listitems = array();
			foreach ( $dbitems as $dbitem ) {
				$listitems[$dbitem->classid] = array($dbitem->title, $dbitem->code);
			}
			
			$content['title'] = "Classes (".count($dbitems).")";
			$content['page'] = array(
					'type' => 'table',
					'headers' => array( 'title', 'code' ),
					'items' => $listitems,
					'onclick' => 'open=class_view&&classid=',
				);
			$content['link'] = '<a href="admin.php?open=class_new" style="float:right">Add a Class</a>';
			
			break;
		
		case 'subject_new':
			require( CORE . "subject.php" );
			$content['subject'] = new subject;			
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array(
						'title' => array('label' => 'Subject Title:', 'type' => 'text', 'tags' => 'required '),
						'code' => array('label' => 'Subject Code:', 'type' => 'text', 'tags' => 'required '),
					),
					
					'hidden' => array('admin' => 1),		
					'buttons' => array(
						'saveclose' => array('label' => 'Save & Close'),
						'saveadd' => array('label' => 'Save & Add'),
					),
				);
			
			$content['title'] = "Add a Subject";
			if ( isset( $_POST['saveclose'] ) ) {
				$subject = new subject;
				$subject->storeFormValues( $_POST );
				$subjectid = $subject->insert();
				if ($subjectid) {
					header( "Location: admin.php?open=subject_all" );
				} else {
					$content['errorMessage'] = "Unable to add a subject at the moment. Please try again later.";
				}
			} else if ( isset( $_POST['saveadd'] ) ) {
				$subject = new subject;
				$subject->storeFormValues( $_POST );
				$subjectid = $subject->insert();
				if ($subjectid) {
					header( "Location: admin.php?open=subject_new" );
				} else {
					$content['errorMessage'] = "Unable to add a subject at the moment. Please try again later.";
				}
			}
			break;
			
		case 'subject_view':
			require( CORE . "subject.php" );
			$subjectid = $_GET["subjectid"];
			$subject = subject::getById( (int)$subjectid );
			$content['title'] = "Edit Subject";
			$content['link'] = '<a href="admin.php?open=subject_delete&&subjectid='.$subjectid.'" onclick="return confirm(\'Delete This Subject? This action is irrevesible!\')" style="float:right;">DELETE SUBJECT</a>';	
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open.'&&subjectid='.$subjectid,
					'fields' => array(
						'title' => array('label' => 'Subject Title:', 'type' => 'text', 'tags' => 'required ', 'value' => $subject->title),
						'code' => array('label' => 'Subject Code:', 'type' => 'text', 'tags' => 'required ', 'value' => $subject->code),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
						'cancel' => array('label' => 'Cancel Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$subject->storeFormValues( $_POST );
				$subject->update();
				header( "Location: admin.php?open=subject_view&&subjectid=".$subjectid."status=changesSaved" );
			} elseif ( isset( $_POST['cancel'] ) ) {
				header( "Location: admin.php?open=subject_all" );
			} 
			break;
			
		case 'subject_all':
			require( CORE . "subject.php" );
			$adminid = $_SESSION["loggedin_admin"];
			$dbitems = subject::getList( $adminid );
			$listitems = array();
			foreach ( $dbitems as $dbitem ) {
				$listitems[$dbitem->subjectid] = array($dbitem->title, $dbitem->code);
			}
			
			$content['title'] = "Subject (".count($listitems).")";
			$content['page'] = array(
					'type' => 'table',
					'headers' => array( 'title', 'code' ),
					'items' => $listitems,
					'onclick' => 'open=subject_view&&subjectid=',
				);
			$content['link'] = '<a href="admin.php?open=subject_new" style="float:right">Add a Subject</a>';
			
			break;
		
		case 'student_new':
			require( CORE . "student.php" );
			$content['student'] = new student;			
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array(
						'fullname' => array('label' => 'Full Name:', 'type' => 'text', 'tags' => 'required '),
						'email' => array('label' => 'Email Address:', 'type' => 'text', 'tags' => 'required '),
						'mobile' => array('label' => 'Mobile Number:', 'type' => 'text', 'tags' => 'required '),
						'address' => array('label' => 'Physical Address:', 'type' => 'textarea', 'tags' => 'required '),
						'password' => array('label' => 'Password:', 'type' => 'password', 'tags' => 'required '),
					),
					
					'hidden' => array('admin' => 1),		
					'buttons' => array(
						'saveclose' => array('label' => 'Save & Close'),
						'saveadd' => array('label' => 'Save & Add'),
					),
				);
			
			$content['title'] = "Add a Student";
			if ( isset( $_POST['saveclose'] ) ) {
				$student = new student;
				$student->storeFormValues( $_POST );
				$studentid = $student->insert();
				if ($studentid) {
					header( "Location: admin.php?open=student_all" );
				} else {
					$content['errorMessage'] = "Unable to add a student at the moment. Please try again later.";
				}
			} else if ( isset( $_POST['saveadd'] ) ) {
				$student = new student;
				$student->storeFormValues( $_POST );
				$studentid = $student->insert();
				if ($studentid) {
					header( "Location: admin.php?open=student_new" );
				} else {
					$content['errorMessage'] = "Unable to add a student at the moment. Please try again later.";
				}
			}
			break;
		
		case 'student_view':
			require( CORE . "student.php" );
			$studentid = $_GET["studentid"];
			$student = student::getById( (int)$studentid );
			$content['title'] = "Edit Student";
			$content['link'] = '<a href="admin.php?open=student_delete&&studentid='.$studentid.'" onclick="return confirm(\'Delete This Student? This action is irrevesible!\')" style="float:right;">DELETE SUBJECT</a>';	
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open.'&&studentid='.$studentid,
					'fields' => array(
						'fullname' => array('label' => 'Full Name:', 'type' => 'text', 'tags' => 'required ', 'value' => $student->fullname),
						'code' => array('label' => 'Student Code/Number:', 'type' => 'text', 'tags' => 'required ', 'value' => $student->email),
						'mobile' => array('label' => 'Mobile Number:', 'type' => 'text', 'tags' => 'required ', 'value' => $student->mobile),
						'address' => array('label' => 'Physical Address:', 'type' => 'text', 'tags' => 'required ', 'value' => $student->address),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
						'cancel' => array('label' => 'Cancel Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$student->storeFormValues( $_POST );
				$student->update();
				header( "Location: admin.php?open=student_view&&studentid=".$studentid."status=changesSaved" );
			} elseif ( isset( $_POST['cancel'] ) ) {
				header( "Location: admin.php?open=student_all" );
			} 
			break;
			
		case 'student_all':
			require( CORE . "student.php" );
			$adminid = $_SESSION["loggedin_admin"];
			$dbitems = student::getList( $adminid );
			$listitems = array();
			foreach ( $dbitems as $dbitem ) {
				$listitems[$dbitem->studentid] = array($dbitem->firstname . " ".$dbitem->lastname, $dbitem->email, $dbitem->mobile, $dbitem->address);
			}
			
			$content['title'] = "Student (".count($listitems).")";
			$content['page'] = array(
					'type' => 'table',
					'headers' => array( 'fullname', 'email', 'mobile', 'address' ),
					'items' => $listitems,
					'onclick' => 'open=student_view&&studentid=',
				);
			$content['link'] = '<a href="admin.php?open=student_new" style="float:right">Add a Student</a>';
			
			break;
				
		case 'account':
			require( CORE . "admin.php" );
			$content['admin'] = admin::getById( (int)$_SESSION["loggedin_admin"] );
			$content['title'] = $content['admin']->firstname . ' ' .$content['admin']->lastname.
			' '.($content['admin']->sex == 1 ? '(M)' : '(F)' );
			break;
			
		case 'signout';
			unset( $_SESSION['loggedin_level'] );
			unset( $_SESSION['loggedin_adminame'] );
			unset( $_SESSION['loggedin_admin'] );
			header( "Location: admin.php" );
			break;
				
		case 'database';
			errMissingTables();
			break;
		 	
		case 'admin_all':
			require( CORE . "admin.php" );
			$admins = admin::getList(5);
			$listitems = array();
			foreach ( $admins as $admin ) {
				$listitems[] = array($admin->firstname. ' ' . $admin->lastname, $admin->handle, ($admin->sex ==1) ? 'M' : 'F', $admin->mobile, $admin->email);
			}
			
			$content['title'] = "Administrators";
			$content['page'] = array(
					'type' => 'table',
					'headers' => array( 'Name', 'username', 'sex', 'mobile phone', 'email'), 
					'items' => $listitems,
				);
			break;
			
		case 'settings':
			$content['title'] = "Your Site Preferences";
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array( 
						'sitename' => array('label' => 'Site Name:', 'type' => 'text', 'tags' => 'required ', 'value' => $content['sitename']),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$sitename = $_POST['sitename'];
				as_update_option('sitename', $sitename);
				
				$filename = "config.php";
				$lines = file($filename, FILE_IGNORE_NEW_LINES );
				$lines[12] = '	define( "SITENAME", "'.$sitename.'"  );';
				file_put_contents($filename, implode("\n", $lines));
		
				header( "Location: admin.php?pg=settings&&status=changesSaved" );
			} 
			break;
		 
		case 'test_new':
			require( CORE . "test.php" );
			$content['test'] = new test;			
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array(
						'title' => array('label' => 'Title:', 'type' => 'text', 'tags' => 'required '),
						'questions' => array('label' => 'Number of Questions:', 'type' => 'number', 'tags' => 'min="2" max="50" required ', 'value' => 1),
					),
					
					'hidden' => array('admin' => 1),		
					'buttons' => array(
						'testnew' => array('label' => 'Save this Test'),
					),
				);
			
			$content['title'] = "Add a Test";
			$content['calendarScript'] = '<script type="text/javascript">
	window.onload = function(){
		new JsDatePick({
			useMode:2,
			target:"dateField1", "dateField2"
		});
	};
</script>';
			if ( isset( $_POST['testnew'] ) ) {
				$test = new test;
				$test->storeFormValues( $_POST );
				$testid = $test->insert();
				if ($testid) {
					header( "Location: admin.php?open=tests_all" );
				} else {
					$content['errorMessage'] = "Unable to add a test at the moment. Please try again later.";
				}
			}
			break;
				
		case 'test_view':
			require( CORE . "test.php" );
			require( CORE . "question.php" );
			$testid = $_GET["testid"];
			$adminid = $_SESSION["loggedin_admin"];
			$test = test::getById( (int)$testid );
			
			$questions = question::getList($testid);
			$listitems = array();
			$i=0;
			foreach ( $questions as $question ) {
				$listitems[$question->questionid] = array(($i+1).' .', $question->title);
				$i++;
			}
			
			$content['title'] = $test->title;
			$content['link'] = '<a href="admin.php?open=test_edit&&testid='.$testid.'" style="float:right;">EDIT TEST</a>';
			$content['page'] = array(
					'type' => 'viewer',
					'subitems' => array(
						'Questions' => $test->questions, 'Attempts' => $test->attempts),
					'lists' => array(
						'headers' => array( 'NO', 'Question'), 
						'items' => $listitems,
					),
				);
			if ( $i != $test->questions)
				$content['page']['lists']['title'] = '<a href="admin.php?open=question_new&&testid='.$testid.'&&count='.$test->questions.'">Add/Edit Questions</a>';	
						
			break;
			
		case 'test_edit':
			require( CORE . "test.php" );
			$testid = $_GET["testid"];
			$test = test::getById( (int)$testid );
			$content['title'] = "Edit Test";
			$content['link'] = '<a href="admin.php?open=test_delete&&testid='.$testid.'" onclick="return confirm(\'Delete This Test? This action is irrevesible!\')" style="float:right;">DELETE TEST</a>';	
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open.'&&testid='.$testid,
					'fields' => array(
						'title' => array('label' => 'Title:', 'type' => 'text', 'tags' => 'required ', 'value' => $test->title),
						'salary' => array('label' => 'Salary:', 'type' => 'text', 'tags' => 'required ', 'value' => $test->salary),
						'company' => array('label' => 'Company:', 'type' => 'text', 'tags' => 'required ', 'value' => $test->company),
						'requirements' => array('label' => 'Requirements:', 'type' => 'textarea', 'tags' => 'required ', 'value' => $test->requirements),
						'skills' => array('label' => 'Skills:', 'type' => 'textarea', 'tags' => 'required ', 'value' => $test->skills),
						'description' => array('label' => 'Description:', 'type' => 'textarea', 'tags' => 'required ', 'value' => $test->description),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
						'cancel' => array('label' => 'Cancel Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$test->storeFormValues( $_POST );
				$test->update();
				header( "Location: admin.php?open=test_view&&testid=".$testid."status=changesSaved" );
			} elseif ( isset( $_POST['cancel'] ) ) {
				header( "Location: admin.php?open=test_view&&testid=".$testid );
			} 
			break;
		
		case 'question_new':
			require( CORE . "question.php" );
			$content['question'] = new question;
			$count = $_GET['count'];
			$testid = $_GET['testid'];
			$questions = question::countQuestions( $testid );
			$request = 'admin.php?open=question_new&&testid='.$testid.'&&count='.$count;			
				
			if ($questions != $count) {
				$content['page'] = array(
						'type' => 'form',
						'action' => $request,
						'fields' => array(
							'title' => array('label' => 'Your Question goes here:', 'type' => 'textarea', 'tags' => 'required '),
							'optiona' => array('label' => 'Option A:', 'type' => 'text', 'tags' => 'required '),
							'optionb' => array('label' => 'Option B:', 'type' => 'text', 'tags' => 'required '),
							'optionc' => array('label' => 'Option C:', 'type' => 'text', 'tags' => 'required '),
							'optiond' => array('label' => 'Option D:', 'type' => 'text', 'tags' => 'required '),
							'answer' => array('label' => 'Correct Answer', 'type' => 'select', 'tags' => 'required ', 
								'options' => array('1' => 'Option A', '2' => 'Option B', '3' => 'Option C', '4' => 'Option D' ) ),
						),
						
						'hidden' => array( 'admin' => 1, 'testid' => $testid ),		
						'buttons' => array(
							'savequiz' => array('label' => 'Save Question'),
						),
					);
				
				$content['title'] = "Add Question ".($questions + 1)." out of ".$count;
				if ( isset( $_POST['savequiz'] ) ) {
					$question = new question;
					$question->storeFormValues( $_POST );
					$questionid = $question->insert();
					if ($questionid) {
						$questions = question::countQuestions( $testid );
						if ( $questions == $count ) header( "Location: admin.php?open=test_view&&testid=".$testid );
						else header( "Location: ".$request );
					} else {
						$content['errorMessage'] = "Unable to add a question at the moment. Please try again later.";
					}
				} 
			}
			break;
				
		default: 
			require( CORE . "test.php" );
			$tests = test::getList();
			$listitems = array();
			foreach ( $tests as $test ) {
				$listitems[$test->testid] = array($test->title, $test->questions, $test->created, $test->attempts);
			}
			
			$content['title'] = "Available Tests";
			$content['link'] = '<a href="admin.php?open=test_new" style="float:right">New Test</a>';
			$content['page'] = array(
				'type' => 'table',
				'headers' => array( 'title', 'questions', 'created', 'attempts' ), 
				'items' => $listitems,
				'onclick' => 'open=test_view&&testid=',
			);
			break;
	}
	
	require ( CORE . "page_admin.php" );