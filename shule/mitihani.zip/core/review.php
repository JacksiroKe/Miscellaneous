<?php

	class review
	{ 
		public $reviewid = null;
		public $studentid = null;
		public $testid = null;
		public $title = null;
		public $optiona = null;
		public $optionb = null;
		public $optionc = null;
		public $optiond = null;
		public $true_answer = null;
		public $set_answer = null;
		public $marks = null;
		public $created = null;
		public $updated = null;

		public function __construct( $data=array() ) 
		{
			if ( isset( $data['reviewid'] ) ) $this->reviewid = (int) $data['reviewid'];
			if ( isset( $data['studentid'] ) ) $this->studentid =  (int) $data['studentid'];
			if ( isset( $data['testid'] ) ) $this->testid =  (int) $data['testid'];
			if ( isset( $data['title'] ) ) $this->title = $data['title'];
			if ( isset( $data['optiona'] ) ) $this->optiona = $data['optiona'];
			if ( isset( $data['optionb'] ) ) $this->optionb = $data['optionb'];
			if ( isset( $data['optionc'] ) ) $this->optionc = $data['optionc'];
			if ( isset( $data['optiond'] ) ) $this->optiond = $data['optiond'];
			if ( isset( $data['true_answer'] ) ) $this->true_answer = (int) $data['true_answer'];
			if ( isset( $data['set_answer'] ) ) $this->set_answer = (int) $data['set_answer'];
			if ( isset( $data['created'] ) ) $this->created = (int) $data['created'];
			if ( isset( $data['updated'] ) ) $this->updated = (int) $data['updated'];
		}

		public function storeFormValues ( $params ) 
		{
			$this->__construct( $params );

			if ( isset($params['created']) ) {
				$created = explode ( '-', $params['created'] );

				if ( count($created) == 3 ) {
					list ( $y, $m, $d ) = $created;
					$this->created = mktime ( 0, 0, 0, $m, $d, $y );
				}
			}
		}

		public static function getById( $reviewid ) 
		{
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "SELECT *, UNIX_TIMESTAMP(created) AS created FROM reviews WHERE reviewid = :reviewid";
			$st = $conn->prepare( $sql );
			$st->bindValue( ":reviewid", $reviewid, PDO::PARAM_INT );
			$st->execute();
			$row = $st->fetch();
			$conn = null;
			if ( $row ) return new review( $row );
		}
		
		public static function countQuestions( $testid ) 
		{
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "SELECT SQL_CALC_FOUND_ROWS *, UNIX_TIMESTAMP(created) AS created FROM reviews WHERE testid=:testid";

			$st = $conn->prepare( $sql );
			$st->bindValue( ":testid", $testid, PDO::PARAM_INT );
			$st->execute();
			
			$sql = "SELECT FOUND_ROWS() AS totalRows";
			$totalRows = $conn->query( $sql )->fetch();
			$conn = null;
			return $totalRows[0];
		}

		public static function getList( $testid ) 
		{
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "SELECT * FROM reviews WHERE testid=:testid ORDER BY created DESC";

			$st = $conn->prepare( $sql );
			$st->bindValue( ":testid", $testid, PDO::PARAM_INT );
			$st->execute();
			$list = array();

			while ( $row = $st->fetch() ) {
				$review = new review( $row );
				$list[] = $review;
			}

			$conn = null;
			return $list;
		}

		public function insert() 
		{
			if ( !is_null( $this->reviewid ) ) trigger_error ( "review::insert(): Attempt to insert an review object that already has its ID property set (to $this->reviewid).", E_USER_ERROR );

			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "INSERT INTO reviews ( studentid, testid, title, optiona, optionb, optionc, optiond, true_answer, set_answer, created ) VALUES ( :studentid, :testid, :title, :optiona, :optionb, :optionc, :optiond, :true_answer, :set_answer, :created)";
			$st = $conn->prepare ( $sql );
			$st->bindValue( ":studentid", $this->studentid, PDO::PARAM_STR );
			$st->bindValue( ":testid", $this->testid, PDO::PARAM_STR );
			$st->bindValue( ":title", $this->title, PDO::PARAM_STR );
			$st->bindValue( ":optiona", $this->optiona, PDO::PARAM_STR );
			$st->bindValue( ":optionb", $this->optionb, PDO::PARAM_STR );
			$st->bindValue( ":optionc", $this->optionc, PDO::PARAM_STR );
			$st->bindValue( ":optiond", $this->optiond, PDO::PARAM_STR );
			$st->bindValue( ":true_answer", $this->true_answer, PDO::PARAM_STR );
			$st->bindValue( ":set_answer", $this->set_answer, PDO::PARAM_STR );
			$st->bindValue( ":created", date('Y-m-d H:i:s'), PDO::PARAM_INT );
			$st->execute();
			$this->reviewid = $conn->lastInsertId();
			$conn = null;
			return $this->reviewid;
		}

		public function studentsCount($oldcount, $reviewid) 
		{
			if ( is_null( $this->reviewid ) ) trigger_error ( "review::update(): Attempt to update an review object that does not have its ID property set.", E_USER_ERROR );
		   
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "UPDATE reviews SET students=:students, updated=:updated WHERE reviewid = :reviewid";
			$st = $conn->prepare ( $sql );
			$st->bindValue( ":students", $oldcount + 1, PDO::PARAM_INT );
			$st->bindValue( ":reviewid", $reviewid, PDO::PARAM_INT );
			$st->bindValue( ":updated", date('Y-m-d H:i:s'), PDO::PARAM_INT );
			$st->execute();
			$conn = null;
		}

		public function update() 
		{
			if ( is_null( $this->reviewid ) ) trigger_error ( "review::update(): Attempt to update an review object that does not have its ID property set.", E_USER_ERROR );
		   
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "UPDATE reviews SET testid=:testid, title=:title, optiona=:optiona, optionb=:optionb, optionc=:optionc, optiond=:optiond, answer=:answer, updated=:updated WHERE reviewid = :reviewid";
			$st = $conn->prepare ( $sql );
			$st->bindValue( ":testid", $this->testid, PDO::PARAM_STR );
			$st->bindValue( ":title", $this->title, PDO::PARAM_STR );
			$st->bindValue( ":optiona", $this->optiona, PDO::PARAM_STR );
			$st->bindValue( ":optionb", $this->optionb, PDO::PARAM_STR );
			$st->bindValue( ":optionc", $this->optionc, PDO::PARAM_STR );
			$st->bindValue( ":optiond", $this->optiond, PDO::PARAM_STR );
			$st->bindValue( ":answer", $this->answer, PDO::PARAM_STR );
			$st->bindValue( ":updated", date('Y-m-d H:i:s'), PDO::PARAM_INT );
			$st->bindValue( ":reviewid", $this->reviewid, PDO::PARAM_INT );
			$st->execute();
			$conn = null;
		}

		public function delete() 
		{

			if ( is_null( $this->reviewid ) ) trigger_error ( "review::delete(): Attempt to delete an review object that does not have its ID property set.", E_USER_ERROR );

			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$st = $conn->prepare ( "DELETE FROM reviews WHERE reviewid = :reviewid LIMIT 1" );
			$st->bindValue( ":reviewid", $this->reviewid, PDO::PARAM_INT );
			$st->execute();
			$conn = null;
		}

	}
