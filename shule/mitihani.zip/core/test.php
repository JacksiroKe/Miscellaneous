<?php

	class test
	{ 
		public $testid = null;
		public $title = null;
		public $questions = null;
		public $attempts = null;
		public $created = null;
		public $updated = null;

		public function __construct( $data=array() ) 
		{
			if ( isset( $data['testid'] ) ) $this->testid = (int) $data['testid'];
			if ( isset( $data['title'] ) ) $this->title =  $data['title'];
			if ( isset( $data['questions'] ) ) $this->questions = (int) $data['questions'];
			if ( isset( $data['attempts'] ) ) $this->attempts = (int) $data['attempts'];
			if ( isset( $data['created'] ) ) $this->created = $data['created'];
			if ( isset( $data['updated'] ) ) $this->updated = $data['updated'];
		}

		public function storeFormValues ( $params ) 
		{
			$this->__construct( $params );

			if ( isset($params['created']) ) {
				$created = explode ( '-', $params['created'] );

				if ( count($created) == 3 ) {
					list ( $y, $m, $d ) = $created;
					$this->created = mktime ( 0, 0, 0, $m, $d, $y );
				}
			}
		}

		public static function getById( $testid ) 
		{
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "SELECT *, UNIX_TIMESTAMP(created) AS created FROM tests WHERE testid = :testid";
			$st = $conn->prepare( $sql );
			$st->bindValue( ":testid", $testid, PDO::PARAM_INT );
			$st->execute();
			$row = $st->fetch();
			$conn = null;
			if ( $row ) return new test( $row );
		}

		public static function students( $testid ) 
		{
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "SELECT students FROM tests WHERE testid = :testid";
			$st = $conn->prepare( $sql );
			$st->bindValue( ":testid", $testid, PDO::PARAM_INT );
			$st->execute();
			$row = $st->fetch();
			$conn = null;
			if ( $row ) return $row['students'];
			else return 0;
		}

		public static function getList() 
		{
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "SELECT * FROM tests ORDER BY testid DESC";

			$st = $conn->prepare( $sql );
			$st->execute();
			$list = array();

			while ( $row = $st->fetch() ) {
				$test = new test( $row );
				$list[] = $test;
			}

			$conn = null;
			return $list;
		}

		public static function searchThis( $search ) 
		{
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "SELECT * FROM tests
			WHERE title LIKE '%".$search."%' ORDER BY created DESC";

			$st = $conn->prepare( $sql );
			$st->execute();
			$list = array();

			while ( $row = $st->fetch() ) {
				$test = new test( $row );
				$list[] = $test;
			}

			$conn = null;
			return $list;
		}

		public function insert() 
		{
			if ( !is_null( $this->testid ) ) trigger_error ( "test::insert(): Attempt to insert an test object that already has its ID property set (to $this->testid).", E_USER_ERROR );

			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "INSERT INTO tests ( title, questions, created ) VALUES ( :title, :questions, :created)";
			$st = $conn->prepare ( $sql );
			$st->bindValue( ":title", $this->title, PDO::PARAM_STR );
			$st->bindValue( ":questions", $this->questions, PDO::PARAM_STR );
			$st->bindValue( ":created", date('Y-m-d H:i:s'), PDO::PARAM_INT );
			$st->execute();
			$this->testid = $conn->lastInsertId();
			$conn = null;
			return $this->testid;
		}

		public function studentsCount($oldcount, $testid) 
		{
			if ( is_null( $this->testid ) ) trigger_error ( "test::update(): Attempt to update an test object that does not have its ID property set.", E_USER_ERROR );
		   
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "UPDATE tests SET students=:students, updated=:updated WHERE testid = :testid";
			$st = $conn->prepare ( $sql );
			$st->bindValue( ":students", $oldcount + 1, PDO::PARAM_INT );
			$st->bindValue( ":testid", $testid, PDO::PARAM_INT );
			$st->bindValue( ":updated", date('Y-m-d H:i:s'), PDO::PARAM_INT );
			$st->execute();
			$conn = null;
		}

		public function update() 
		{
			if ( is_null( $this->testid ) ) trigger_error ( "test::update(): Attempt to update an test object that does not have its ID property set.", E_USER_ERROR );
		   
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "UPDATE tests SET title=:title, questions=:questions, updated=:updated WHERE testid = :testid";
			$st = $conn->prepare ( $sql );
			$st->bindValue( ":title", $this->title, PDO::PARAM_STR );
			$st->bindValue( ":questions", $this->questions, PDO::PARAM_STR );
			$st->bindValue( ":attempts", $this->attempts, PDO::PARAM_STR );
			$st->bindValue( ":updated", date('Y-m-d H:i:s'), PDO::PARAM_INT );
			$st->bindValue( ":testid", $this->testid, PDO::PARAM_INT );
			$st->execute();
			$conn = null;
		}

		public function delete() 
		{

			if ( is_null( $this->testid ) ) trigger_error ( "test::delete(): Attempt to delete an test object that does not have its ID property set.", E_USER_ERROR );

			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$st = $conn->prepare ( "DELETE FROM tests WHERE testid = :testid LIMIT 1" );
			$st->bindValue( ":testid", $this->testid, PDO::PARAM_INT );
			$st->execute();
			$conn = null;
		}

	}
