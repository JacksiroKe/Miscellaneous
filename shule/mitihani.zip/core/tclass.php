<?php

	class tclass
	{ 
		public $classid = null;
		public $title = null;
		public $code = null;
		public $created = null;
		public $updated = null;

		public function __construct( $data=array() ) 
		{
			if ( isset( $data['classid'] ) ) $this->classid = (int) $data['classid'];
			if ( isset( $data['title'] ) ) $this->title =  $data['title'];
			if ( isset( $data['code'] ) ) $this->code = $data['code'];
			if ( isset( $data['created'] ) ) $this->created = (int) $data['created'];
			if ( isset( $data['updated'] ) ) $this->updated = (int) $data['updated'];
		}

		public function storeFormValues ( $params ) 
		{
			$this->__construct( $params );

			if ( isset($params['created']) ) {
				$created = explode ( '-', $params['created'] );

				if ( count($created) == 3 ) {
					list ( $y, $m, $d ) = $created;
					$this->created = mktime ( 0, 0, 0, $m, $d, $y );
				}
			}
		}

		public static function getById( $classid ) 
		{
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "SELECT *, UNIX_TIMESTAMP(created) AS created FROM classes WHERE classid = :classid";
			$st = $conn->prepare( $sql );
			$st->bindValue( ":classid", $classid, PDO::PARAM_INT );
			$st->execute();
			$row = $st->fetch();
			$conn = null;
			if ( $row ) return new tclass( $row );
		}

		public static function getList() 
		{
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "SELECT * FROM classes
			ORDER BY created DESC";

			$st = $conn->prepare( $sql );
			$st->execute();
			$list = array();

			while ( $row = $st->fetch() ) {
				$tclass = new tclass( $row );
				$list[] = $tclass;
			}

			$sql = "SELECT FOUND_ROWS() AS totalRows";
			$totalRows = $conn->query( $sql )->fetch();
			$conn = null;
			return $list;
		}

		public function insert() 
		{
			if ( !is_null( $this->classid ) ) trigger_error ( "tclass::insert(): Attempt to insert an tclass object that already has its ID property set (to $this->classid).", E_USER_ERROR );

			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "INSERT INTO classes ( title, code, created ) VALUES ( :title, :code, :created)";
			$st = $conn->prepare ( $sql );
			$st->bindValue( ":title", $this->title, PDO::PARAM_STR );
			$st->bindValue( ":code", $this->code, PDO::PARAM_STR );
			$st->bindValue( ":created", date('Y-m-d H:i:s'), PDO::PARAM_INT );
			$st->execute();
			$this->classid = $conn->lastInsertId();
			$conn = null;
			return $this->classid;
		}

		public function update() 
		{
			if ( is_null( $this->classid ) ) trigger_error ( "tclass::update(): Attempt to update an tclass object that does not have its ID property set.", E_USER_ERROR );
		   
			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$sql = "UPDATE classes SET title=:title, code=:code, updated=:updated WHERE classid = :classid";
			$st = $conn->prepare ( $sql );
			$st->bindValue( ":title", $this->title, PDO::PARAM_STR );
			$st->bindValue( ":code", $this->code, PDO::PARAM_STR );
			$st->bindValue( ":updated", date('Y-m-d H:i:s'), PDO::PARAM_INT );
			$st->bindValue( ":classid", $this->classid, PDO::PARAM_INT );
			$st->execute();
			$conn = null;
		}

		public function delete() 
		{

			if ( is_null( $this->classid ) ) trigger_error ( "tclass::delete(): Attempt to delete an tclass object that does not have its ID property set.", E_USER_ERROR );

			$conn = new PDO( DB_DSN, DB_USER, DB_PASS );
			$st = $conn->prepare ( "DELETE FROM classes WHERE classid = :classid LIMIT 1" );
			$st->bindValue( ":classid", $this->classid, PDO::PARAM_INT );
			$st->execute();
			$conn = null;
		}

	}
