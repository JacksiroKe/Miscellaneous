<?php

	require( "config.php" );
	session_start();
	$open = isset( $_GET['open'] ) ? $_GET['open'] : "";

	$content = array();
	$content['sitename'] = strlen(as_option('sitename')) ? as_option('sitename') : SITENAME;
	$adminid = isset( $_SESSION['loggedin_admin'] ) ? $_SESSION['loggedin_admin'] : "";
	$level = isset( $_SESSION['loggedin_level'] ) ? $_SESSION['loggedin_level'] : "";
	$adminame = isset( $_SESSION['loggedin_adminame'] ) ? $_SESSION['loggedin_adminame'] : "";
		
	if ($open == 'install') {
		errMissingTables();
		exit();
	}
	
	if ( $open != "signin" && $open != "signout" && $open != "register" && !$adminid ) {
		$open = 'signin';
	}

	switch ( $open ) {
		case 'signin':
			require( CORE . "admin.php" );
			$content['admin'] = new admin;
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array( 
						'handle' => array('label' => 'Username:', 'type' => 'text'),				
						'password' => array('label' => 'Password:', 'type' => 'password'),
					),
			
					'buttons' => array('signin' => array('label' => 'Login')),			
				);
			
			$content['title'] = "Login to Your Account";
			if ( isset( $_POST['signin'] ) ) {
				$adminid = admin::signinuser($_POST['handle'], md5($_POST['password']));
				if ($adminid) {
					header( "Location: admin.php" );
				} else {
					$content['errorMessage'] = "Incorrect username or password. Please try again.";
				}
			}
			break;

		case 'register':
			require( CORE . "admin.php" );
			$content['admin'] = new admin;			
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array( 
						'firstname' => array('label' => 'First Name:', 'type' => 'text', 'tags' => 'required '),
						'lastname' => array('label' => 'Last Name:', 'type' => 'text', 'tags' => 'required '),
						'sex' => array('label' => 'Sex:', 'type' => 'radio', 
							'options' => array(
								'male' => array('name' => 'Male', 'value' => 1),
								'female' => array('name' => 'Female', 'value' => 2),
								), 'value' => 1, 'tags' => 'required '),
						'mobile' => array('label' => 'Mobile:', 'type' => 'text', 'tags' => 'required '),
						'email' => array('label' => 'Email:', 'type' => 'email', 'tags' => 'required '),
						'handle' => array('label' => 'Username:', 'type' => 'text', 'tags' => 'required '),
						'password' => array('label' => 'Password:', 'type' => 'password', 'tags' => 'required '),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array('register' => array('label' => 'Register')),
				);
			
			$content['title'] = "Register as a admin";
			if ( isset( $_POST['register'] ) ) {
				$admin = new admin;
				$admin->storeFormValues( $_POST );
				$adminid = $admin->insert();
				if ($adminid) {
					$_SESSION['loggedin_level'] = $_POST['level'];
					$_SESSION['loggedin_admin'] = $adminid;
					header( "Location: admin.php" );
				} else {
					$content['errorMessage'] = "Unable to register you at the moment. Please try again later.";
				}
			}
			break;
		
		case 'class_new':
			require( CORE . "room.php" );
			$content['class'] = new room;			
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array(
						'title' => array('label' => 'Room Title:', 'type' => 'text', 'tags' => 'required '),
						'code' => array('label' => 'Room Code:', 'type' => 'text', 'tags' => 'required '),
					),
					
					'hidden' => array('admin' => 1),		
					'buttons' => array(
						'saveclose' => array('label' => 'Save & Close'),
						'saveadd' => array('label' => 'Save & Add'),
					),
				);
			
			$content['title'] = "Add a Room";
			if ( isset( $_POST['saveclose'] ) ) {
				$class = new room;
				$class->storeFormValues( $_POST );
				$roomid = $class->insert();
				if ($roomid) {
					header( "Location: admin.php?open=room_all" );
				} else {
					$content['errorMessage'] = "Unable to add a class at the moment. Please try again later.";
				}
			} else if ( isset( $_POST['saveadd'] ) ) {
				$class = new room;
				$class->storeFormValues( $_POST );
				$roomid = $class->insert();
				if ($roomid) {
					header( "Location: admin.php?open=class_new" );
				} else {
					$content['errorMessage'] = "Unable to add a class at the moment. Please try again later.";
				}
			}
			break;
			
		case 'class_view':
			require( CORE . "room.php" );
			$roomid = $_GET["roomid"];
			$class = room::getById( (int)$roomid );
			$content['title'] = "Edit Room";
			$content['link'] = '<a href="admin.php?open=class_delete&&roomid='.$roomid.'" onclick="return confirm(\'Delete This Room? This action is irrevesible!\')" style="float:right;">DELETE CLASS</a>';	
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open.'&&roomid='.$roomid,
					'fields' => array(
						'title' => array('label' => 'Room Title:', 'type' => 'text', 'tags' => 'required ', 'value' => $class->title),
						'code' => array('label' => 'Room Code:', 'type' => 'text', 'tags' => 'required ', 'value' => $class->code),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
						'cancel' => array('label' => 'Cancel Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$class->storeFormValues( $_POST );
				$class->update();
				header( "Location: admin.php?open=class_view&&roomid=".$roomid."status=changesSaved" );
			} elseif ( isset( $_POST['cancel'] ) ) {
				header( "Location: admin.php?open=room_all" );
			} 
			break;
			
		case 'room_all':
			require( CORE . "room.php" );
			$adminid = $_SESSION["loggedin_admin"];
			$dbitems = room::getList( $adminid );
			$listitems = array();
			foreach ( $dbitems as $dbitem ) {
				$listitems[$dbitem->roomid] = array($dbitem->title, $dbitem->code);
			}
			
			$content['title'] = "Rooms (".count($dbitems).")";
			$content['page'] = array(
					'type' => 'table',
					'headers' => array( 'title', 'code' ),
					'items' => $listitems,
					'onclick' => 'open=class_view&&roomid=',
				);
			$content['link'] = '<a href="admin.php?open=class_new" style="float:right">Add a Room</a>';
			
			break;
		
		case 'subject_new':
			require( CORE . "subject.php" );
			$content['subject'] = new subject;			
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array(
						'title' => array('label' => 'Subject Title:', 'type' => 'text', 'tags' => 'required '),
						'code' => array('label' => 'Subject Code:', 'type' => 'text', 'tags' => 'required '),
					),
					
					'hidden' => array('admin' => 1),		
					'buttons' => array(
						'saveclose' => array('label' => 'Save & Close'),
						'saveadd' => array('label' => 'Save & Add'),
					),
				);
			
			$content['title'] = "Add a Subject";
			if ( isset( $_POST['saveclose'] ) ) {
				$subject = new subject;
				$subject->storeFormValues( $_POST );
				$subjectid = $subject->insert();
				if ($subjectid) {
					header( "Location: admin.php?open=subject_all" );
				} else {
					$content['errorMessage'] = "Unable to add a subject at the moment. Please try again later.";
				}
			} else if ( isset( $_POST['saveadd'] ) ) {
				$subject = new subject;
				$subject->storeFormValues( $_POST );
				$subjectid = $subject->insert();
				if ($subjectid) {
					header( "Location: admin.php?open=subject_new" );
				} else {
					$content['errorMessage'] = "Unable to add a subject at the moment. Please try again later.";
				}
			}
			break;
			
		case 'subject_view':
			require( CORE . "subject.php" );
			$subjectid = $_GET["subjectid"];
			$subject = subject::getById( (int)$subjectid );
			$content['title'] = "Edit Subject";
			$content['link'] = '<a href="admin.php?open=subject_delete&&subjectid='.$subjectid.'" onclick="return confirm(\'Delete This Subject? This action is irrevesible!\')" style="float:right;">DELETE SUBJECT</a>';	
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open.'&&subjectid='.$subjectid,
					'fields' => array(
						'title' => array('label' => 'Subject Title:', 'type' => 'text', 'tags' => 'required ', 'value' => $subject->title),
						'code' => array('label' => 'Subject Code:', 'type' => 'text', 'tags' => 'required ', 'value' => $subject->code),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
						'cancel' => array('label' => 'Cancel Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$subject->storeFormValues( $_POST );
				$subject->update();
				header( "Location: admin.php?open=subject_view&&subjectid=".$subjectid."status=changesSaved" );
			} elseif ( isset( $_POST['cancel'] ) ) {
				header( "Location: admin.php?open=subject_all" );
			} 
			break;
			
		case 'subject_all':
			require( CORE . "subject.php" );
			$adminid = $_SESSION["loggedin_admin"];
			$dbitems = subject::getList( $adminid );
			$listitems = array();
			foreach ( $dbitems as $dbitem ) {
				$listitems[$dbitem->subjectid] = array($dbitem->title, $dbitem->code);
			}
			
			$content['title'] = "Subject (".count($listitems).")";
			$content['page'] = array(
					'type' => 'table',
					'headers' => array( 'title', 'code' ),
					'items' => $listitems,
					'onclick' => 'open=subject_view&&subjectid=',
				);
			$content['link'] = '<a href="admin.php?open=subject_new" style="float:right">Add a Subject</a>';
			
			break;
		
		case 'client_new':
			require( CORE . "client.php" );
			$content['client'] = new client;			
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array(
						'fullname' => array('label' => 'Full Name:', 'type' => 'text', 'tags' => 'required '),
						'email' => array('label' => 'Email Address:', 'type' => 'text', 'tags' => 'required '),
						'mobile' => array('label' => 'Mobile Number:', 'type' => 'text', 'tags' => 'required '),
						'address' => array('label' => 'Physical Address:', 'type' => 'textarea', 'tags' => 'required '),
						'password' => array('label' => 'Password:', 'type' => 'password', 'tags' => 'required '),
					),
					
					'hidden' => array('admin' => 1),		
					'buttons' => array(
						'saveclose' => array('label' => 'Save & Close'),
						'saveadd' => array('label' => 'Save & Add'),
					),
				);
			
			$content['title'] = "Add a Client";
			if ( isset( $_POST['saveclose'] ) ) {
				$client = new client;
				$client->storeFormValues( $_POST );
				$clientid = $client->insert();
				if ($clientid) {
					header( "Location: admin.php?open=client_all" );
				} else {
					$content['errorMessage'] = "Unable to add a client at the moment. Please try again later.";
				}
			} else if ( isset( $_POST['saveadd'] ) ) {
				$client = new client;
				$client->storeFormValues( $_POST );
				$clientid = $client->insert();
				if ($clientid) {
					header( "Location: admin.php?open=client_new" );
				} else {
					$content['errorMessage'] = "Unable to add a client at the moment. Please try again later.";
				}
			}
			break;
		
		case 'client_view':
			require( CORE . "client.php" );
			$clientid = $_GET["clientid"];
			$client = client::getById( (int)$clientid );
			$content['title'] = "Edit Client";
			$content['link'] = '<a href="admin.php?open=client_delete&&clientid='.$clientid.'" onclick="return confirm(\'Delete This Client? This action is irrevesible!\')" style="float:right;">DELETE SUBJECT</a>';	
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open.'&&clientid='.$clientid,
					'fields' => array(
						'fullname' => array('label' => 'Full Name:', 'type' => 'text', 'tags' => 'required ', 'value' => $client->fullname),
						'code' => array('label' => 'Client Code/Number:', 'type' => 'text', 'tags' => 'required ', 'value' => $client->email),
						'mobile' => array('label' => 'Mobile Number:', 'type' => 'text', 'tags' => 'required ', 'value' => $client->mobile),
						'address' => array('label' => 'Physical Address:', 'type' => 'text', 'tags' => 'required ', 'value' => $client->address),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
						'cancel' => array('label' => 'Cancel Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$client->storeFormValues( $_POST );
				$client->update();
				header( "Location: admin.php?open=client_view&&clientid=".$clientid."status=changesSaved" );
			} elseif ( isset( $_POST['cancel'] ) ) {
				header( "Location: admin.php?open=client_all" );
			} 
			break;
			
		case 'client_all':
			require( CORE . "client.php" );
			$adminid = $_SESSION["loggedin_admin"];
			$dbitems = client::getList( $adminid );
			$listitems = array();
			foreach ( $dbitems as $dbitem ) {
				$listitems[$dbitem->clientid] = array($dbitem->firstname . " ".$dbitem->lastname, $dbitem->email, $dbitem->mobile, $dbitem->address);
			}
			
			$content['title'] = "Client (".count($listitems).")";
			$content['page'] = array(
					'type' => 'table',
					'headers' => array( 'fullname', 'email', 'mobile', 'address' ),
					'items' => $listitems,
					'onclick' => 'open=client_view&&clientid=',
				);
			$content['link'] = '<a href="admin.php?open=client_new" style="float:right">Add a Client</a>';
			
			break;
				
		case 'account':
			require( CORE . "admin.php" );
			$content['admin'] = admin::getById( (int)$_SESSION["loggedin_admin"] );
			$content['title'] = $content['admin']->firstname . ' ' .$content['admin']->lastname.
			' '.($content['admin']->sex == 1 ? '(M)' : '(F)' );
			break;
			
		case 'signout';
			unset( $_SESSION['loggedin_level'] );
			unset( $_SESSION['loggedin_adminame'] );
			unset( $_SESSION['loggedin_admin'] );
			header( "Location: admin.php" );
			break;
				
		case 'database';
			errMissingTables();
			break;
		 	
		case 'admin_all':
			require( CORE . "admin.php" );
			$admins = admin::getList(5);
			$listitems = array();
			foreach ( $admins as $admin ) {
				$listitems[] = array($admin->firstname. ' ' . $admin->lastname, $admin->handle, ($admin->sex ==1) ? 'M' : 'F', $admin->mobile, $admin->email);
			}
			
			$content['title'] = "Administrators";
			$content['page'] = array(
					'type' => 'table',
					'headers' => array( 'Name', 'username', 'sex', 'mobile phone', 'email'), 
					'items' => $listitems,
				);
			break;
			
		case 'settings':
			$content['title'] = "Your Site Preferences";
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array( 
						'sitename' => array('label' => 'Site Name:', 'type' => 'text', 'tags' => 'required ', 'value' => $content['sitename']),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$sitename = $_POST['sitename'];
				as_update_option('sitename', $sitename);
				
				$filename = "config.php";
				$lines = file($filename, FILE_IGNORE_NEW_LINES );
				$lines[12] = '	define( "SITENAME", "'.$sitename.'"  );';
				file_put_contents($filename, implode("\n", $lines));
		
				header( "Location: admin.php?pg=settings&&status=changesSaved" );
			} 
			break;
		 
		case 'booking_new':
			require( CORE . "booking.php" );
			$content['booking'] = new booking;			
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open,
					'fields' => array(
						'title' => array('label' => 'Title:', 'type' => 'text', 'tags' => 'required '),
						'clientid' => array('label' => 'Number of Questions:', 'type' => 'number', 'tags' => 'min="2" max="50" required ', 'value' => 1),
					),
					
					'hidden' => array('admin' => 1),		
					'buttons' => array(
						'bookingnew' => array('label' => 'Save this Booking'),
					),
				);
			
			$content['title'] = "Add a Booking";
			$content['calendarScript'] = '<script type="text/javascript">
	window.onload = function(){
		new JsDatePick({
			useMode:2,
			target:"dateField1", "dateField2"
		});
	};
</script>';
			if ( isset( $_POST['bookingnew'] ) ) {
				$booking = new booking;
				$booking->storeFormValues( $_POST );
				$bookingid = $booking->insert();
				if ($bookingid) {
					header( "Location: admin.php?open=bookings_all" );
				} else {
					$content['errorMessage'] = "Unable to add a booking at the moment. Please try again later.";
				}
			}
			break;
				
		case 'booking_view':
			require( CORE . "booking.php" );
			require( CORE . "question.php" );
			$bookingid = $_GET["bookingid"];
			$adminid = $_SESSION["loggedin_admin"];
			$booking = booking::getById( (int)$bookingid );
			
			$clientid = question::getList($bookingid);
			$listitems = array();
			$i=0;
			foreach ( $clientid as $question ) {
				$listitems[$question->questionid] = array(($i+1).' .', $question->title);
				$i++;
			}
			
			$content['title'] = $booking->title;
			$content['link'] = '<a href="admin.php?open=booking_edit&&bookingid='.$bookingid.'" style="float:right;">EDIT TEST</a>';
			$content['page'] = array(
					'type' => 'viewer',
					'subitems' => array(
						'Questions' => $booking->clientid, 'Attempts' => $booking->roomid),
					'lists' => array(
						'headers' => array( 'NO', 'Question'), 
						'items' => $listitems,
					),
				);
			if ( $i != $booking->clientid)
				$content['page']['lists']['title'] = '<a href="admin.php?open=question_new&&bookingid='.$bookingid.'&&count='.$booking->clientid.'">Add/Edit Questions</a>';	
						
			break;
			
		case 'booking_edit':
			require( CORE . "booking.php" );
			$bookingid = $_GET["bookingid"];
			$booking = booking::getById( (int)$bookingid );
			$content['title'] = "Edit Booking";
			$content['link'] = '<a href="admin.php?open=booking_delete&&bookingid='.$bookingid.'" onclick="return confirm(\'Delete This Booking? This action is irrevesible!\')" style="float:right;">DELETE TEST</a>';	
			$content['page'] = array(
					'type' => 'form',
					'action' => 'admin.php?open='.$open.'&&bookingid='.$bookingid,
					'fields' => array(
						'title' => array('label' => 'Title:', 'type' => 'text', 'tags' => 'required ', 'value' => $booking->title),
						'salary' => array('label' => 'Salary:', 'type' => 'text', 'tags' => 'required ', 'value' => $booking->salary),
						'company' => array('label' => 'Company:', 'type' => 'text', 'tags' => 'required ', 'value' => $booking->company),
						'requirements' => array('label' => 'Requirements:', 'type' => 'textarea', 'tags' => 'required ', 'value' => $booking->requirements),
						'skills' => array('label' => 'Skills:', 'type' => 'textarea', 'tags' => 'required ', 'value' => $booking->skills),
						'price' => array('label' => 'Description:', 'type' => 'textarea', 'tags' => 'required ', 'value' => $booking->price),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
						'cancel' => array('label' => 'Cancel Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$booking->storeFormValues( $_POST );
				$booking->update();
				header( "Location: admin.php?open=booking_view&&bookingid=".$bookingid."status=changesSaved" );
			} elseif ( isset( $_POST['cancel'] ) ) {
				header( "Location: admin.php?open=booking_view&&bookingid=".$bookingid );
			} 
			break;
		
		case 'question_new':
			require( CORE . "question.php" );
			$content['question'] = new question;
			$count = $_GET['count'];
			$bookingid = $_GET['bookingid'];
			$clientid = question::countQuestions( $bookingid );
			$request = 'admin.php?open=question_new&&bookingid='.$bookingid.'&&count='.$count;			
				
			if ($clientid != $count) {
				$content['page'] = array(
						'type' => 'form',
						'action' => $request,
						'fields' => array(
							'title' => array('label' => 'Your Question goes here:', 'type' => 'textarea', 'tags' => 'required '),
							'optiona' => array('label' => 'Option A:', 'type' => 'text', 'tags' => 'required '),
							'optionb' => array('label' => 'Option B:', 'type' => 'text', 'tags' => 'required '),
							'optionc' => array('label' => 'Option C:', 'type' => 'text', 'tags' => 'required '),
							'optiond' => array('label' => 'Option D:', 'type' => 'text', 'tags' => 'required '),
							'answer' => array('label' => 'Correct Answer', 'type' => 'select', 'tags' => 'required ', 
								'options' => array('1' => 'Option A', '2' => 'Option B', '3' => 'Option C', '4' => 'Option D' ) ),
						),
						
						'hidden' => array( 'admin' => 1, 'bookingid' => $bookingid ),		
						'buttons' => array(
							'savequiz' => array('label' => 'Save Question'),
						),
					);
				
				$content['title'] = "Add Question ".($clientid + 1)." out of ".$count;
				if ( isset( $_POST['savequiz'] ) ) {
					$question = new question;
					$question->storeFormValues( $_POST );
					$questionid = $question->insert();
					if ($questionid) {
						$clientid = question::countQuestions( $bookingid );
						if ( $clientid == $count ) header( "Location: admin.php?open=booking_view&&bookingid=".$bookingid );
						else header( "Location: ".$request );
					} else {
						$content['errorMessage'] = "Unable to add a question at the moment. Please try again later.";
					}
				} 
			}
			break;
				
		default: 
			require( CORE . "booking.php" );
			$bookings = booking::getList();
			$listitems = array();
			foreach ( $bookings as $booking ) {
				$listitems[$booking->bookingid] = array($booking->title, $booking->clientid, $booking->created, $booking->roomid);
			}
			
			$content['title'] = "Available Bookings";
			$content['link'] = '<a href="admin.php?open=booking_new" style="float:right">New Booking</a>';
			$content['page'] = array(
				'type' => 'table',
				'headers' => array( 'title', 'clientid', 'created', 'roomid' ), 
				'items' => $listitems,
				'onclick' => 'open=booking_view&&bookingid=',
			);
			break;
	}
	
	require ( CORE . "page_admin.php" );