			
            <div class="cleaner h20"></div>
            
        	<div class="cleaner"></div>
            
        </div>
        
        <div id="tooplate_main_bottom"></div>
                       
    </div> <!-- end of tooplate_wrapper -->
    
    <div id="tooplate_footer_wrapper">
        <div id="tooplate_footer">
            <center><?php echo $content['sitename'].' &copy; '.date('Y') ?>. All rights reserved.
			</center>
        </div>
    </div>
</div>
</body>
</html>