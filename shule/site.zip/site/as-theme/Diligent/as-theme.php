<?php

/*
	Theme Name: Diligent
	Theme Description: A handy theme for your Osam site that is a delight for the eyes
	Theme URI: http://jacksiro.github.io
	Theme Version: 1.0
	Theme Date: 2014-02-24
	Theme Author: Jack Siro
	Theme Author URI: http://jacksiro.github.io
	Theme Minimum AppSmata Version: 1.5
	
	Licence: Copyright © Jack SIro - All rights reserved	
*/

	class as_html_theme extends as_html_theme_base {
		
		// language strings and theme settings
		var $twitterUsername = 'fill-in-your-twitter-name';
		var $googlePlusLink = 'https://plus.google.com/';
		var $facebookLink = 'https://www.facebook.com/';
		var $facebookBoxEnabled = false; // or true
		
		var $writeNowLabel = 'write now - it\'s free';
		var $writeQuestionString = 'What do you like to know?';
		var $writeQbuttonLabel = 'Ask now';
		var $bestLabel = 'Best';
			
		var $sp_intromain = 'Get free help from experts';
		var $sp_introexp1 = 'Ask your article';
		var $sp_introexp2 = 'Ask for free and without registration';
		var $sp_introdisc1 = 'Discuss with members';
		var $sp_introdisc2 = 'Share your problem with experts and get help';
		var $sp_introprob1 = 'Problem solved';
		var $sp_introprob2 = 'Vote on answers and select the best one';


		
		// override subnavigation to place nav('sub') into sidepanel layer
		function nav_main_sub() {
			$this->nav('main');
		}
			
		/**
		 * Additional admin panel.
		 *
		 * @since Snow 1.4
		 */
		 
		 // ** Added Line Begin
		public function adminpanel($sub_navigation)
		{
			if ($this->template == 'admin') {
				$this->output('<div class="as-adminpanel" id="asm-adminpanel-mobile">');
				
				$this->output( '<div class="as-left-side-bar" id="sidebar" role="navigation">', '' );
				if ( count( $sub_navigation ) ) {

					$this->output( '<div class="navlist-group">', '' );

					foreach ( $sub_navigation as $key => $sub_navigation_item ) {
						$this->as_nav_side_bar_item( $sub_navigation_item );
					}
					$this->output( '</div>', '' );
				}
				$this->output( '</div>', '<!-- END of left-menu-->' );
				$this->output('</div>', '');
			}
		}

		/**
		 * Add navigation bar for the admin panel
		 *
		 */
		 
		public function as_nav_side_bar_item( $nav_item )
		{
			$class = ( !!@$nav_item['selected'] ) ? ' active' : '';
			$icon = ( !!@$nav_item['icon'] ) ? as_get_fa_icon( @$nav_item['icon'] ) : '';
			$this->output( '<a href="' . $nav_item['url'] . '" class="navlist-group-item ' . $class . '">' . $icon . $nav_item['label'] . '</a>' );
		}
		// ** Added Line End
		
		// override sidepanel
		function sidepanel()
		{
			// output css element (for background)
			$this->output('<div class="content-flow"><div class="content-wrapper">');
			
			// moved sub-nav to inner
			// ** Added Line Begin			
			if ($this->template != 'admin') $this->nav('sub');
			// ** Added Line End
		}

		// override main to output own html elements and more
		function main() {
			// output identifier for anonymous, needed for some JS plugins
			if(!as_is_logged_in()) {
				$this->output('<div id="isAnonym"></div>');
			}
			
			// default call
			as_html_theme_base::main();
		}

		// output embed css font
		function head_css() {
			$this->output('<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400&amp;subset=latin,latin-ext" type="text/css" />');
			$this->output('<style type="text/css">
.as-q-list .as-a-count-selected:after, .as-memberact-wrapper .as-a-count-selected:after,
.as-a-selection:after {
	content:"'.$this->bestLabel.'";
}
.as-a-item-selected>.as-a-selection:after {
	content:"";
}');				
			
			if ($this->template != 'admin') 
			$this->output('
.as-sidepanel { display: none !important;}
.as-main { width: 95% !important; }
.tt_title{ color:#000;text-transform:uppercase;text-align: center; } 
.tt_title pre { display: inline; }
.td-titles {font-weight: bold; color: #000; }
			');
			$this->output('</style>');

			// default
			as_html_theme_base::head_css();
		}

		// viewport for mobiles
		function head_metas() {
			as_html_theme_base::head_metas();
			$this->output('<meta name="viewport" content="width=device-width, initial-scale=1.0" >');
		}

		// add logo next to title
		/*
		function logo() {
			$this->output(
				'<div class="as-logo"><span style="font-size:13px;color:#EFEFEF;">Answers and articles</span><br />', 
				'<a href="#" class="as-logo-link">Forum Name <span class="ktlogo"></span></a>',
				'</div>'
			);
		}
		*/

		// override body_content
		function body_content()
		{
			$sub_navigation = @$this->content['navigation']['sub'];
			$this->body_prefix();
			$this->notices();
			
			$this->output('<div class="as-body-wrapper">', '');

			// flag for mobiles
			if(as_is_mobile_probably()) $this->output('<div id="agentIsMobile"></div>');
			
			$this->widgets('full', 'top');
			$this->header();
			$this->dashboard();

			$this->widgets('full', 'high');
			$this->sidepanel();
			// ** Added Line Begin
			$this->adminpanel($sub_navigation);
			// ** Added Line End
			$this->main();
			$this->widgets('full', 'low');
			$this->footer();
			$this->widgets('full', 'bottom');
			
			// close additional css-div
			$this->output('
						</div> <!-- content-wrapper -->
				</div> <!-- content-flow -->
			');  
			$this->output('</div> <!-- body-wrapper -->');

			$this->body_suffix();
		}

		// override for pagination articles on activity page
		function page_links() {
			$page_links=@$this->content['page_links'];
			
			if (!empty($page_links)) {
				$this->output('<div class="as-page-links">');
				
				$this->page_links_label(@$page_links['label']);
				$this->page_links_list(@$page_links['items']);
				$this->page_links_clear();
				
				$this->output('</div>');
			}
			// added pagination on qa page
			else if($this->template=='qa' && $this->request=='') {
				$pagesize = as_opt('page_size_qs');
				$i = 1;
				$this->output('<div class="as-page-links">');
				$this->output('
					<ul class="as-page-links-list" style="margin-top:10px;">
						<li CLASS="as-page-links-item">
							<a href="./articles?start=0" CLASS="as-page-link">1</a>
						</li>
						<li CLASS="as-page-links-item">
							<a href="./articles?start='.($i++*$pagesize).'" CLASS="as-page-link">2</a>
						</li>
						<li CLASS="as-page-links-item">
							<a href="./articles?start='.($i++*$pagesize).'" CLASS="as-page-link">3</a>
						</li>
						<li CLASS="as-page-links-item">
							<a href="./articles?start='.($i++*$pagesize).'" CLASS="as-page-link">4</a>
						</li>
						<li CLASS="as-page-links-item">
							<span class="as-page-ellipsis">…</span>
						</li>
					</ul>
				');
				$this->page_links_clear();
				$this->output('</div>');
			}
		}

		/* override to add custom CSS class in body tag */
		function body_tags() {
			$class='as-template-'.as_html($this->template);
			if($this->request=='rewards'){
				$class='as-template-page-rewards';
			}
			if (isset($this->content['departmentids']))
				foreach ($this->content['departmentids'] as $departmentid)
					$class.=' as-department-'.as_html($departmentid);
			
			$this->output('class="'.$class.' as-body-js-off"');
		}

		/* SHAREBOX */
		function q_view_buttons($q_view) {
			$shareUrl = as_q_path($this->content['q_view']['raw']['postid'], $this->content['q_view']['raw']['title'], true);
			$shareUrlKT = as_opt('site_url').$this->content['q_view']['raw']['postid'];
			$shareUrlEnc = urlencode($shareUrl);
			$this->output('
			<div class="sharebox">
				<a class="shlink tooltipS" href="'.$shareUrlKT.'"></a>
				<a class="shprint tooltipS" href="javascript:window.print();"></a>
				<a class="shfb tooltipS" href="https://www.facebook.com/sharer.php?u='.$shareUrlEnc.'"></a>
				<a class="shgp tooltipS" href="https://plus.google.com/share?url='.$shareUrlEnc.'"></a>
				<a class="shtw tooltipS" href="https://www.twitter.com/share?url='.$shareUrlEnc.'"></a>
			</div>');

			// default method call
			as_html_theme_base::q_view_buttons($q_view);
		}

		function footer() {
			$this->output('<div class="as-footer">');
			$this->nav('footer');
			$this->output('<a class="as-theme-notice" href="https://jacksiro.github.io/osam">Design by <u>Jack Siro</u></a>');
			$this->footer_clear();			
			// social buttons in footer
			$this->output('<a class="foot_tw" target="_blank" href="https://twitter.com/'.$this->twitterUsername.'"></a>
				<a class="foot_gp" target="_blank" href="'.$this->googlePlusLink.'"></a>
				<a class="foot_fb" target="_blank" href="'.$this->facebookLink.'"></a>
			');
			$this->output('</div> <!-- END as-footer -->', '');
		}
		
		function a_count($post) {
			// You can also use $post['answers_raw'] to get a raw integer count of answers
			$this->output_split(@$post['answers'], 'as-a-count', 'span', 'span',
				@$post['answer_selected'] ? 'as-a-count-selected' : (@$post['answers_raw'] ? null : 'as-a-count-zero'));
				
			// is votes show them on article list
			if(isset($post['vote_view']) && $this->template!='article') {
				$quvotes = $post['raw']['upvotes'];
				if($quvotes>0) {
					$this->output('<span class="quvotes">'.$post['raw']['upvotes'].'</span>');
				}
			}
		}

		// override to not display :after element for best answer button (relies on as-a-selection)
		function a_selection($post)
		{
			if( isset($post['select_tags']) || isset($post['unselect_tags']) || $post['selected'] || isset($post['select_text']) ) {
				$this->output('<div class="as-a-selection">');
				
				if (isset($post['select_tags']))
					$this->post_hover_button($post, 'select_tags', '', 'as-a-select');
				elseif (isset($post['unselect_tags']))
					$this->post_hover_button($post, 'unselect_tags', '', 'as-a-unselect');
				elseif ($post['selected'])
					$this->output('<div class="as-a-selected">&nbsp;</div>');
				
				if (isset($post['select_text']))
					$this->output('<div class="as-a-selected-text">'.@$post['select_text'].'</div>');
				
				$this->output('</div>');
			}
		}

	} // END
	

/*
	Omit PHP closing tag to help avoid accidental output
*/