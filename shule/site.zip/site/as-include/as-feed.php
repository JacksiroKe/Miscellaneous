<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Handles all requests to RSS feeds, first checking if they should be available


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../');
	exit;
}

@ini_set('display_errors', 0); // we don't want to show PHP errors to RSS readers

as_report_process_stage('init_feed');

require_once AS_INCLUDE_DIR . 'app/options.php';


// Functions used within this file

/**
 * Database failure handler function for RSS feeds - outputs HTTP and text errors
 * @param $type
 * @param int $errno
 * @param string $error
 * @param string $query
 */
function as_feed_db_fail_handler($type, $errno = null, $error = null, $query = null)
{
	header('HTTP/1.1 500 Internal Server Error');
	echo as_lang_html('main/general_error');
	as_exit('error');
}


/**
 * Common function called when a non-existent feed is requested - outputs HTTP and text errors
 */
function as_feed_not_found()
{
	header('HTTP/1.0 404 Not Found');
	echo as_lang_html('misc/feed_not_found');
	as_exit();
}


/**
 * Common function to load appropriate set of articles for requested feed, check department exists, and set up page title
 * @param array $departmentslugs
 * @param string $allkey
 * @param string $catkey
 * @param string $title
 * @param array $articleselectspec1
 * @param array $articleselectspec2
 * @param array $articleselectspec3
 * @param array $articleselectspec4
 * @return array
 */
function as_feed_load_ifdepartment($departmentslugs, $allkey, $catkey, &$title,
	$articleselectspec1 = null, $articleselectspec2 = null, $articleselectspec3 = null, $articleselectspec4 = null)
{
	$countslugs = @count($departmentslugs);

	list($articles1, $articles2, $articles3, $articles4, $departments, $departmentid) = as_db_select_with_pending(
		$articleselectspec1,
		$articleselectspec2,
		$articleselectspec3,
		$articleselectspec4,
		$countslugs ? as_db_department_nav_selectspec($departmentslugs, false) : null,
		$countslugs ? as_db_slugs_to_department_id_selectspec($departmentslugs) : null
	);

	if ($countslugs && !isset($departmentid))
		as_feed_not_found();

	if (isset($allkey))
		$title = (isset($departmentid) && isset($catkey)) ? as_lang_sub($catkey, $departments[$departmentid]['title']) : as_lang($allkey);

	return array_merge(
		is_array($articles1) ? $articles1 : array(),
		is_array($articles2) ? $articles2 : array(),
		is_array($articles3) ? $articles3 : array(),
		is_array($articles4) ? $articles4 : array()
	);
}


// Connect to database and get the type of feed and department requested (in some cases these are overridden later)

as_db_connect('as_feed_db_fail_handler');
as_initialize_postdb_plugins();

$requestlower = strtolower(as_request());
$foursuffix = substr($requestlower, -4);

if ($foursuffix == '.rss' || $foursuffix == '.xml') {
	$requestlower = substr($requestlower, 0, -4);
}

$requestlowerparts = explode('/', $requestlower);

$feedtype = @$requestlowerparts[1];
$feedparams = array_slice($requestlowerparts, 2);


// Choose which option needs to be checked to determine if this feed can be requested, and stop if no matches

$feedoption = null;
$departmentslugs = $feedparams;

switch ($feedtype) {
	case 'articles':
		$feedoption = 'feed_for_articles';
		break;

	case 'hot':
		$feedoption = 'feed_for_hot';
		if (!AS_ALLOW_UNINDEXED_QUERIES)
			$departmentslugs = null;
		break;

	case 'unanswered':
		$feedoption = 'feed_for_unanswered';
		if (!AS_ALLOW_UNINDEXED_QUERIES)
			$departmentslugs = null;
		break;

	case 'answers':
	case 'comments':
	case 'activity':
		$feedoption = 'feed_for_activity';
		break;

	case 'as':
		$feedoption = 'feed_for_qa';
		break;

	case 'tag':
		if (strlen(@$feedparams[0])) {
			$feedoption = 'feed_for_tag_qs';
			$departmentslugs = null;
		}
		break;

	case 'search':
		if (strlen(@$feedparams[0])) {
			$feedoption = 'feed_for_search';
			$departmentslugs = null;
		}
		break;
}

$countslugs = @count($departmentslugs);

if (!isset($feedoption))
	as_feed_not_found();


// Check that all the appropriate options are in place to allow this feed to be retrieved

if (!(as_opt($feedoption) && ($countslugs ? (as_using_departments() && as_opt('feed_per_department')) : true)))
	as_feed_not_found();


// Retrieve the appropriate articles and other information for this feed

require_once AS_INCLUDE_DIR . 'db/selects.php';

$sitetitle = as_opt('site_title');
$siteurl = as_opt('site_url');
$full = as_opt('feed_full_text');
$count = as_opt('feed_number_items');
$showurllinks = as_opt('show_url_links');

$linkrequest = $feedtype . ($countslugs ? ('/' . implode('/', $departmentslugs)) : '');
$linkparams = null;

switch ($feedtype) {
	case 'articles':
		$articles = as_feed_load_ifdepartment($departmentslugs, 'main/recent_qs_title', 'main/recent_qs_in_x', $title,
			as_db_qs_selectspec(null, 'created', 0, $departmentslugs, null, false, $full, $count)
		);
		break;

	case 'hot':
		$articles = as_feed_load_ifdepartment($departmentslugs, 'main/hot_qs_title', 'main/hot_qs_in_x', $title,
			as_db_qs_selectspec(null, 'hotness', 0, $departmentslugs, null, false, $full, $count)
		);
		break;

	case 'unanswered':
		$articles = as_feed_load_ifdepartment($departmentslugs, 'main/unanswered_qs_title', 'main/unanswered_qs_in_x', $title,
			as_db_unanswered_qs_selectspec(null, null, 0, $departmentslugs, false, $full, $count)
		);
		break;

	case 'answers':
		$articles = as_feed_load_ifdepartment($departmentslugs, 'main/recent_as_title', 'main/recent_as_in_x', $title,
			as_db_recent_a_qs_selectspec(null, 0, $departmentslugs, null, false, $full, $count)
		);
		break;

	case 'comments':
		$articles = as_feed_load_ifdepartment($departmentslugs, 'main/recent_cs_title', 'main/recent_cs_in_x', $title,
			as_db_recent_c_qs_selectspec(null, 0, $departmentslugs, null, false, $full, $count)
		);
		break;

	case 'as':
		$articles = as_feed_load_ifdepartment($departmentslugs, 'main/recent_qs_as_title', 'main/recent_qs_as_in_x', $title,
			as_db_qs_selectspec(null, 'created', 0, $departmentslugs, null, false, $full, $count),
			as_db_recent_a_qs_selectspec(null, 0, $departmentslugs, null, false, $full, $count)
		);
		break;

	case 'activity':
		$articles = as_feed_load_ifdepartment($departmentslugs, 'main/recent_activity_title', 'main/recent_activity_in_x', $title,
			as_db_qs_selectspec(null, 'created', 0, $departmentslugs, null, false, $full, $count),
			as_db_recent_a_qs_selectspec(null, 0, $departmentslugs, null, false, $full, $count),
			as_db_recent_c_qs_selectspec(null, 0, $departmentslugs, null, false, $full, $count),
			as_db_recent_edit_qs_selectspec(null, 0, $departmentslugs, null, true, $full, $count)
		);
		break;

	case 'tag':
		$tag = $feedparams[0];

		$articles = as_feed_load_ifdepartment(null, null, null, $title,
			as_db_tag_recent_qs_selectspec(null, $tag, 0, $full, $count)
		);

		$title = as_lang_sub('main/articles_tagged_x', $tag);
		$linkrequest = 'tag/' . $tag;
		break;

	case 'search':
		require_once AS_INCLUDE_DIR . 'app/search.php';

		$query = $feedparams[0];

		$results = as_get_search_results($query, 0, $count, null, true, $full);

		$title = as_lang_sub('main/results_for_x', $query);
		$linkrequest = 'search';
		$linkparams = array('q' => $query);

		$articles = array();

		foreach ($results as $result) {
			$setarray = array(
				'title' => $result['title'],
				'url' => $result['url'],
			);

			if (isset($result['article']))
				$articles[] = array_merge($result['article'], $setarray);
			elseif (isset($result['url']))
				$articles[] = $setarray;
		}
		break;
}


// Remove duplicate articles (perhaps referenced in an answer and a comment) and cut down to size

require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/updates.php';
require_once AS_INCLUDE_DIR . 'util/string.php';

if ($feedtype != 'search' && $feedtype != 'hot') // leave search results and hot articles sorted by relevance
	$articles = as_any_sort_and_dedupe($articles);

$articles = array_slice($articles, 0, $count);
$blockwordspreg = as_get_block_words_preg();


// Prepare the XML output

$lines = array();

$lines[] = '<?xml version="1.0" encoding="utf-8"?>';
$lines[] = '<rss version="2.0">';
$lines[] = '<channel>';

$lines[] = '<title>' . as_xml($sitetitle . ' - ' . $title) . '</title>';
$lines[] = '<link>' . as_xml(as_path($linkrequest, $linkparams, $siteurl)) . '</link>';
$lines[] = '<description>Powered by Osam</description>';

foreach ($articles as $article) {
	// Determine whether this is a article, answer or comment, and act accordingly
	$options = array('blockwordspreg' => @$blockwordspreg, 'showurllinks' => $showurllinks);

	$time = null;
	$htmlcontent = null;

	if (isset($article['opostid'])) {
		$time = $article['otime'];

		if ($full)
			$htmlcontent = as_viewer_html($article['ocontent'], $article['oformat'], $options);

	} elseif (isset($article['postid'])) {
		$time = $article['created'];

		if ($full)
			$htmlcontent = as_viewer_html($article['content'], $article['format'], $options);
	}

	if ($feedtype == 'search') {
		$titleprefix = '';
		$urlxml = as_xml($article['url']);

	} else {
		switch (@$article['obasetype'] . '-' . @$article['oupdatetype']) {
			case 'Q-':
			case '-':
				$langstring = null;
				break;

			case 'Q-' . AS_UPDATE_VISIBLE:
				$langstring = $article['hidden'] ? 'misc/feed_hidden_prefix' : 'misc/feed_reshown_prefix';
				break;

			case 'Q-' . AS_UPDATE_CLOSED:
				$langstring = isset($article['closedbyid']) ? 'misc/feed_closed_prefix' : 'misc/feed_reopened_prefix';
				break;

			case 'Q-' . AS_UPDATE_TAGS:
				$langstring = 'misc/feed_retagged_prefix';
				break;

			case 'Q-' . AS_UPDATE_DEPARTMENT:
				$langstring = 'misc/feed_recategorized_prefix';
				break;

			case 'A-':
				$langstring = 'misc/feed_a_prefix';
				break;

			case 'A-' . AS_UPDATE_SELECTED:
				$langstring = 'misc/feed_a_selected_prefix';
				break;

			case 'A-' . AS_UPDATE_VISIBLE:
				$langstring = $article['ohidden'] ? 'misc/feed_hidden_prefix' : 'misc/feed_a_reshown_prefix';
				break;

			case 'A-' . AS_UPDATE_CONTENT:
				$langstring = 'misc/feed_a_edited_prefix';
				break;

			case 'C-':
				$langstring = 'misc/feed_c_prefix';
				break;

			case 'C-' . AS_UPDATE_TYPE:
				$langstring = 'misc/feed_c_moved_prefix';
				break;

			case 'C-' . AS_UPDATE_VISIBLE:
				$langstring = $article['ohidden'] ? 'misc/feed_hidden_prefix' : 'misc/feed_c_reshown_prefix';
				break;

			case 'C-' . AS_UPDATE_CONTENT:
				$langstring = 'misc/feed_c_edited_prefix';
				break;

			case 'Q-' . AS_UPDATE_CONTENT:
			default:
				$langstring = 'misc/feed_edited_prefix';
				break;

		}

		$titleprefix = isset($langstring) ? as_lang($langstring) : '';

		$urlxml = as_xml(as_q_path($article['postid'], $article['title'], true, @$article['obasetype'], @$article['opostid']));
	}

	if (isset($blockwordspreg))
		$article['title'] = as_block_words_replace($article['title'], $blockwordspreg);

	// Build the inner XML structure for each item

	$lines[] = '<item>';
	$lines[] = '<title>' . as_xml($titleprefix . $article['title']) . '</title>';
	$lines[] = '<link>' . $urlxml . '</link>';

	if (isset($htmlcontent))
		$lines[] = '<description>' . as_xml($htmlcontent) . '</description>';

	if (isset($article['departmentname']))
		$lines[] = '<department>' . as_xml($article['departmentname']) . '</department>';

	$lines[] = '<guid isPermaLink="true">' . $urlxml . '</guid>';

	if (isset($time))
		$lines[] = '<pubDate>' . as_xml(gmdate('r', $time)) . '</pubDate>';

	$lines[] = '</item>';
}

$lines[] = '</channel>';
$lines[] = '</rss>';


// Disconnect here, once all output is ready to go

as_db_disconnect();


// Output the XML - and we're done!

header('Content-type: text/xml; charset=utf-8');
echo implode("\n", $lines);
