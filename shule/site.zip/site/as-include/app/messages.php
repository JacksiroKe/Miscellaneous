<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Handling private or public messages (wall posts)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


/**
 * Returns an HTML string describing the reason why member $frommemberid cannot post on the wall of $tomemberid who has
 * member flags $tomemberflags. If there is no such reason the function returns false.
 * @param $frommemberid
 * @param $tomemberid
 * @param $tomemberflags
 * @return bool|mixed|string
 */
function as_wall_error_html($frommemberid, $tomemberid, $tomemberflags)
{
	require_once AS_INCLUDE_DIR . 'app/limits.php';

	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	if (!AS_FINAL_EXTERNAL_MEMBERS && as_opt('allow_member_walls')) {
		if (($tomemberflags & AS_MEMBER_FLAGS_NO_WALL_POSTS) && !(isset($frommemberid) && $frommemberid == $tomemberid))
			return as_lang_html('profile/post_wall_blocked');

		else {
			switch (as_member_permit_error('permit_post_wall', AS_LIMIT_WALL_POSTS)) {
				case 'limit':
					return as_lang_html('profile/post_wall_limit');
					break;

				case 'login':
					return as_insert_login_links(as_lang_html('profile/post_wall_must_login'), as_request());
					break;

				case 'confirm':
					return as_insert_login_links(as_lang_html('profile/post_wall_must_confirm'), as_request());
					break;

				case 'approve':
					return strtr(as_lang_html('profile/post_wall_must_be_approved'), array(
						'^1' => '<a href="' . as_path_html('account') . '">',
						'^2' => '</a>',
					));
					break;

				case false:
					return false;
					break;
			}
		}
	}

	return as_lang_html('members/no_permission');
}


/**
 * Adds a post to the wall of member $tomemberid with handle $tohandle, containing $content in $format (e.g. '' for text or 'html')
 * The post is by member $memberid with handle $handle, and $cookieid is the member's current cookie (used for reporting the event).
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $tomemberid
 * @param $tohandle
 * @param $content
 * @param $format
 * @return mixed
 */
function as_wall_add_post($memberid, $handle, $cookieid, $tomemberid, $tohandle, $content, $format)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'app/format.php';
	require_once AS_INCLUDE_DIR . 'db/messages.php';

	$messageid = as_db_message_create($memberid, $tomemberid, $content, $format, true);
	as_db_member_recount_posts($tomemberid);

	as_report_event('u_wall_post', $memberid, $handle, $cookieid, array(
		'memberid' => $tomemberid,
		'handle' => $tohandle,
		'messageid' => $messageid,
		'content' => $content,
		'format' => $format,
		'fullname' => as_get_member_name($handle),
		'text' => as_viewer_text($content, $format),
	));

	return $messageid;
}


/**
 * Deletes the wall post described in $message (as obtained via as_db_recent_messages_selectspec()). The deletion was performed
 * by member $memberid with handle $handle, and $cookieid is the member's current cookie (all used for reporting the event).
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $message
 */
function as_wall_delete_post($memberid, $handle, $cookieid, $message)
{
	require_once AS_INCLUDE_DIR . 'db/messages.php';

	as_db_message_delete($message['messageid']);
	as_db_member_recount_posts($message['tomemberid']);

	as_report_event('u_wall_delete', $memberid, $handle, $cookieid, array(
		'messageid' => $message['messageid'],
		'oldmessage' => $message,
	));
}


/**
 * Return the list of messages in $membermessages (as obtained via as_db_recent_messages_selectspec()) with additional
 * fields indicating what actions can be performed on them by the current member. The messages were retrieved beginning
 * at offset $start in the database. Currently only 'deleteable' is relevant.
 * @param $membermessages
 * @param $start
 * @return mixed
 */
function as_wall_posts_add_rules($membermessages, $start)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	$memberid = as_get_logged_in_memberid();
	// reuse "Hiding or showing any post" and "Deleting hidden posts" permissions
	$memberdeleteall = !(as_member_permit_error('permit_hide_show') || as_member_permit_error('permit_delete_hidden'));
	$memberrecent = $start == 0 && isset($memberid); // Member can delete all of the recent messages they wrote on someone's wall...

	foreach ($membermessages as $key => $message) {
		if ($message['frommemberid'] != $memberid)
			$memberrecent = false; // ... until we come across one that they didn't write (which could be a reply)

		$membermessages[$key]['deleteable'] =
			$message['tomemberid'] == $memberid || // if it's this member's wall
			($memberrecent && $message['frommemberid'] == $memberid) || // if it's one the member wrote that no one replied to yet
			$memberdeleteall; // if the member has enough permissions  to delete from any wall
	}

	return $membermessages;
}


/**
 * Returns an element to add to $as_content['message_list']['messages'] for $message (as obtained via
 * as_db_recent_messages_selectspec() and then as_wall_posts_add_rules()).
 * @param $message
 * @return array
 */
function as_wall_post_view($message)
{
	require_once AS_INCLUDE_DIR . 'app/format.php';

	$options = as_message_html_defaults();

	$htmlfields = as_message_html_fields($message, $options);

	if ($message['deleteable']) {
		$htmlfields['form'] = array(
			'style' => 'light',

			'buttons' => array(
				'delete' => array(
					'tags' => 'name="m' . as_html($message['messageid']) . '_dodelete" onclick="return as_wall_post_click(' . as_js($message['messageid']) . ', this);"',
					'label' => as_lang_html('article/delete_button'),
					'popup' => as_lang_html('profile/delete_wall_post_popup'),
				),
			),
		);
	}

	return $htmlfields;
}


/**
 * Returns an element to add to $as_content['message_list']['messages'] with a link to view all wall posts
 * @param $handle
 * @param $start
 * @return array
 */
function as_wall_view_more_link($handle, $start)
{
	$url = as_path_html($handle . '/wall', array('start' => $start));
	return array(
		'content' => '<a href="' . $url . '">' . as_lang_html('profile/wall_view_more') . '</a>',
	);
}


/**
 * Hides the private message described in $message (as obtained via as_db_messages_inbox_selectspec() or as_db_messages_outbox_selectspec()).
 * If both sender and receiver have hidden the message, it gets deleted from the database.
 * Note: currently no event is reported here, so $handle/$cookieid are unused.
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $message
 * @param $box
 */
function as_pm_delete($memberid, $handle, $cookieid, $message, $box)
{
	require_once AS_INCLUDE_DIR . 'db/messages.php';

	as_db_message_member_hide($message['messageid'], $box);
	as_db_message_delete($message['messageid'], false);
}
