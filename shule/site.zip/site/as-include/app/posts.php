<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Higher-level functions to create and manipulate posts


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'as-db.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/post-create.php';
require_once AS_INCLUDE_DIR . 'app/post-update.php';
require_once AS_INCLUDE_DIR . 'app/members.php';
require_once AS_INCLUDE_DIR . 'util/string.php';

/*
	Return the name of an exam with the exam title, unit title, class title, paper code/title
	based on a paperid
*/
function as_exam_name($paper)
{
	return $paper['exam'] . ($paper['unit'] ? ' - ' . $paper['unit'] : '') . 
		($paper['code'] ? ' ' . $paper['code'] : '') . ($paper['class'] ? ' ' . $paper['class'] : '');
}

/**
 * Create a new post in the database, and return its postid.
 *
 * Set $type to 'Q' for a new article, 'A' for an answer, or 'C' for a comment. You can also use 'Q_QUEUED',
 * 'A_QUEUED' or 'C_QUEUED' to create a post which is queued for moderator approval. For articles, set $parentid to
 * the postid of the answer to which the article is related, or null if (as in most cases) the article is not related
 * to an answer. For answers, set $parentid to the postid of the article being answered. For comments, set $parentid
 * to the postid of the article or answer to which the comment relates. The $content and $format parameters go
 * together - if $format is '' then $content should be in plain UTF-8 text, and if $format is 'html' then $content
 * should be in UTF-8 HTML. Other values of $format may be allowed if an appropriate viewer module is installed. The
 * $title, $departmentid and $tags parameters are only relevant when creating a article - $tags can either be an array
 * of tags, or a string of tags separated by commas. The new post will be assigned to $memberid if it is not null,
 * otherwise it will be by a non-member. If $notify is true then the author will be sent notifications relating to the
 * post - either to $email if it is specified and valid, or to the current email address of $memberid if $email is '@'.
 * If you're creating a article, the $extravalue parameter will be set as the custom extra field, if not null. For all
 * post types you can specify the $name of the post's author, which is relevant if the $memberid is null.
 * @param $type
 * @param $parentid
 * @param $title
 * @param $content
 * @param string $format
 * @param $departmentid
 * @param $tags
 * @param $memberid
 * @param $notify
 * @param $email
 * @param $extravalue
 * @param $name
 * @return mixed
 */
function as_post_create($type, $parentid, $title, $content, $format = '', $departmentid = null, $tags = null, $memberid = null,
	$notify = null, $email = null, $extravalue = null, $name = null)
{
	$handle = as_memberid_to_handle($memberid);
	$text = as_post_content_to_text($content, $format);

	switch ($type) {
		case 'Q':
		case 'Q_QUEUED':
			$followanswer = isset($parentid) ? as_post_get_full($parentid, 'A') : null;
			$tagstring = as_post_tags_to_tagstring($tags);
			$postid = as_article_create($followanswer, $memberid, $handle, null, $title, $content, $format, $text, $tagstring,
				$notify, $email, $departmentid, $extravalue, $type == 'Q_QUEUED', $name);
			break;

		case 'A':
		case 'A_QUEUED':
			$article = as_post_get_full($parentid, 'Q');
			$postid = as_answer_create($memberid, $handle, null, $content, $format, $text, $notify, $email, $article, $type == 'A_QUEUED', $name);
			break;

		case 'C':
		case 'C_QUEUED':
			$parent = as_post_get_full($parentid, 'AS');
			$commentsfollows = as_db_single_select(as_db_full_child_posts_selectspec(null, $parentid));
			$article = as_post_parent_to_article($parent);
			$postid = as_comment_create($memberid, $handle, null, $content, $format, $text, $notify, $email, $article, $parent, $commentsfollows, $type == 'C_QUEUED', $name);
			break;

		default:
			as_fatal_error('Post type not recognized: ' . $type);
			break;
	}

	return $postid;
}


/**
 * Change the data stored for post $postid based on any of the $title, $content, $format, $tags, $notify, $email,
 * $extravalue and $name parameters passed which are not null. The meaning of these parameters is the same as for
 * as_post_create() above. Pass the identify of the member making this change in $bymemberid (or null for silent).
 * @param $postid
 * @param $title
 * @param $content
 * @param $format
 * @param $tags
 * @param $notify
 * @param $email
 * @param $bymemberid
 * @param $extravalue
 * @param $name
 */
function as_post_set_content($postid, $title, $content, $format = null, $tags = null, $notify = null, $email = null, $bymemberid = null, $extravalue = null, $name = null)
{
	$oldpost = as_post_get_full($postid, 'QAC');

	if (!isset($title))
		$title = $oldpost['title'];

	if (!isset($content))
		$content = $oldpost['content'];

	if (!isset($format))
		$format = $oldpost['format'];

	if (!isset($tags))
		$tags = as_tagstring_to_tags($oldpost['tags']);

	if (isset($notify) || isset($email))
		$setnotify = as_combine_notify_email($oldpost['memberid'], isset($notify) ? $notify : isset($oldpost['notify']),
			isset($email) ? $email : $oldpost['notify']);
	else
		$setnotify = $oldpost['notify'];

	$byhandle = as_memberid_to_handle($bymemberid);

	$text = as_post_content_to_text($content, $format);

	switch ($oldpost['basetype']) {
		case 'Q':
			$tagstring = as_post_tags_to_tagstring($tags);
			as_article_set_content($oldpost, $title, $content, $format, $text, $tagstring, $setnotify, $bymemberid, $byhandle, null, $extravalue, $name);
			break;

		case 'A':
			$article = as_post_get_full($oldpost['parentid'], 'Q');
			as_answer_set_content($oldpost, $content, $format, $text, $setnotify, $bymemberid, $byhandle, null, $article, $name);
			break;

		case 'C':
			$parent = as_post_get_full($oldpost['parentid'], 'AS');
			$article = as_post_parent_to_article($parent);
			as_comment_set_content($oldpost, $content, $format, $text, $setnotify, $bymemberid, $byhandle, null, $article, $parent, $name);
			break;
	}
}


/**
 * Change the department of $postid to $departmentid. The department of all related posts (shown together on the same
 * article page) will also be changed. Pass the identify of the member making this change in $bymemberid (or null for an
 * anonymous change).
 * @param $postid
 * @param $departmentid
 * @param $bymemberid
 */
function as_post_set_department($postid, $departmentid, $bymemberid = null)
{
	$oldpost = as_post_get_full($postid, 'QAC');

	if ($oldpost['basetype'] == 'Q') {
		$byhandle = as_memberid_to_handle($bymemberid);
		$answers = as_post_get_article_answers($postid);
		$commentsfollows = as_post_get_article_commentsfollows($postid);
		$closepost = as_post_get_article_closepost($postid);
		as_article_set_department($oldpost, $departmentid, $bymemberid, $byhandle, null, $answers, $commentsfollows, $closepost);

	} else
		as_post_set_department($oldpost['parentid'], $departmentid, $bymemberid); // keep looking until we find the parent article
}


/**
 * Set the selected best answer of $articleid to $answerid (or to none if $answerid is null). Pass the identify of the
 * member in $bymemberid (or null for an anonymous change).
 * @param $articleid
 * @param $answerid
 * @param $bymemberid
 */
function as_post_set_selchildid($articleid, $answerid, $bymemberid = null)
{
	$oldarticle = as_post_get_full($articleid, 'Q');
	$byhandle = as_memberid_to_handle($bymemberid);
	$answers = as_post_get_article_answers($articleid);

	if (isset($answerid) && !isset($answers[$answerid]))
		as_fatal_error('Answer ID could not be found: ' . $answerid);

	as_article_set_selchildid($bymemberid, $byhandle, null, $oldarticle, $answerid, $answers);
}


/**
 * Closed $articleid if $closed is true, otherwise reopen it. If $closed is true, pass either the $originalpostid of
 * the article that it is a duplicate of, or a $note to explain why it's closed. Pass the identify of the member in
 * $bymemberid (or null for an anonymous change).
 * @param $articleid
 * @param bool $closed
 * @param $originalpostid
 * @param $note
 * @param $bymemberid
 */
function as_post_set_closed($articleid, $closed = true, $originalpostid = null, $note = null, $bymemberid = null)
{
	$oldarticle = as_post_get_full($articleid, 'Q');
	$oldclosepost = as_post_get_article_closepost($articleid);
	$byhandle = as_memberid_to_handle($bymemberid);

	if ($closed) {
		if (isset($originalpostid))
			as_article_close_duplicate($oldarticle, $oldclosepost, $originalpostid, $bymemberid, $byhandle, null);
		elseif (isset($note))
			as_article_close_other($oldarticle, $oldclosepost, $note, $bymemberid, $byhandle, null);
		else
			as_fatal_error('Article must be closed as a duplicate or with a note');

	} else
		as_article_close_clear($oldarticle, $oldclosepost, $bymemberid, $byhandle, null);
}


/**
 * Hide $postid if $hidden is true, otherwise show the post. Pass the identify of the member making this change in
 * $bymemberid (or null for a silent change).
 * @deprecated Replaced by as_post_set_status.
 * @param $postid
 * @param bool $hidden
 * @param $bymemberid
 */
function as_post_set_hidden($postid, $hidden = true, $bymemberid = null)
{
	as_post_set_status($postid, $hidden ? AS_POST_STATUS_HIDDEN : AS_POST_STATUS_NORMAL, $bymemberid);
}


/**
 * Change the status of $postid to $status, which should be one of the AS_POST_STATUS_* constants defined in
 * /as-include/app/post-update.php. Pass the identify of the member making this change in $bymemberid (or null for a silent change).
 * @param $postid
 * @param $status
 * @param $bymemberid
 */
function as_post_set_status($postid, $status, $bymemberid = null)
{
	$oldpost = as_post_get_full($postid, 'QAC');
	$byhandle = as_memberid_to_handle($bymemberid);

	switch ($oldpost['basetype']) {
		case 'Q':
			$answers = as_post_get_article_answers($postid);
			$commentsfollows = as_post_get_article_commentsfollows($postid);
			$closepost = as_post_get_article_closepost($postid);
			as_article_set_status($oldpost, $status, $bymemberid, $byhandle, null, $answers, $commentsfollows, $closepost);
			break;

		case 'A':
			$article = as_post_get_full($oldpost['parentid'], 'Q');
			$commentsfollows = as_post_get_answer_commentsfollows($postid);
			as_answer_set_status($oldpost, $status, $bymemberid, $byhandle, null, $article, $commentsfollows);
			break;

		case 'C':
			$parent = as_post_get_full($oldpost['parentid'], 'AS');
			$article = as_post_parent_to_article($parent);
			as_comment_set_status($oldpost, $status, $bymemberid, $byhandle, null, $article, $parent);
			break;
	}
}


/**
 * Set the created date of $postid to $created, which is a unix timestamp.
 * @param $postid
 * @param $created
 */
function as_post_set_created($postid, $created)
{
	$oldpost = as_post_get_full($postid);

	as_db_post_set_created($postid, $created);

	switch ($oldpost['basetype']) {
		case 'Q':
			as_db_hotness_update($postid);
			break;

		case 'A':
			as_db_hotness_update($oldpost['parentid']);
			break;
	}
}


/**
 * Delete $postid from the database, hiding it first if appropriate.
 * @param $postid
 */
function as_post_delete($postid)
{
	$oldpost = as_post_get_full($postid, 'QAC');

	if (!$oldpost['hidden']) {
		as_post_set_status($postid, AS_POST_STATUS_HIDDEN, null);
		$oldpost = as_post_get_full($postid, 'QAC');
	}

	switch ($oldpost['basetype']) {
		case 'Q':
			$answers = as_post_get_article_answers($postid);
			$commentsfollows = as_post_get_article_commentsfollows($postid);
			$closepost = as_post_get_article_closepost($postid);

			if (count($answers) || count($commentsfollows))
				as_fatal_error('Could not delete article ID due to dependents: ' . $postid);

			as_article_delete($oldpost, null, null, null, $closepost);
			break;

		case 'A':
			$article = as_post_get_full($oldpost['parentid'], 'Q');
			$commentsfollows = as_post_get_answer_commentsfollows($postid);

			if (count($commentsfollows))
				as_fatal_error('Could not delete answer ID due to dependents: ' . $postid);

			as_answer_delete($oldpost, $article, null, null, null);
			break;

		case 'C':
			$parent = as_post_get_full($oldpost['parentid'], 'AS');
			$article = as_post_parent_to_article($parent);
			as_comment_delete($oldpost, $article, $parent, null, null, null);
			break;
	}
}


/**
 * Return the full information from the database for $postid in an array.
 * @param $postid
 * @param $requiredbasetypes
 * @return array|mixed
 */
function as_post_get_full($postid, $requiredbasetypes = null)
{
	$post = as_db_single_select(as_db_full_post_selectspec(null, $postid));

	if (!is_array($post))
		as_fatal_error('Post ID could not be found: ' . $postid);

	if (isset($requiredbasetypes) && !is_numeric(strpos($requiredbasetypes, $post['basetype'])))
		as_fatal_error('Post of wrong type: ' . $post['basetype']);

	return $post;
}


/**
 * Return the handle corresponding to $memberid, unless it is null in which case return null.
 *
 * @deprecated Deprecated from 1.7; use `as_memberid_to_handle($memberid)` instead.
 * @param $memberid
 * @return mixed|null
 */
function as_post_memberid_to_handle($memberid)
{
	return as_memberid_to_handle($memberid);
}


/**
 * Return the textual rendition of $content in $format (used for indexing).
 * @param $content
 * @param $format
 * @return string
 */
function as_post_content_to_text($content, $format)
{
	$viewer = as_load_viewer($content, $format);

	if (!isset($viewer))
		as_fatal_error('Content could not be parsed in format: ' . $format);

	return $viewer->get_text($content, $format, array());
}


/**
 * Return tagstring to store in the database based on $tags as an array or a comma-separated string.
 * @param $tags
 * @return mixed|string
 */
function as_post_tags_to_tagstring($tags)
{
	if (is_array($tags))
		$tags = implode(',', $tags);

	return as_tags_to_tagstring(array_unique(preg_split('/\s*,\s*/', as_strtolower(strtr($tags, '/', ' ')), -1, PREG_SPLIT_NO_EMPTY)));
}


/**
 * Return the full database records for all answers to article $articleid
 * @param $articleid
 * @return array
 */
function as_post_get_article_answers($articleid)
{
	$answers = array();

	$childposts = as_db_single_select(as_db_full_child_posts_selectspec(null, $articleid));

	foreach ($childposts as $postid => $post) {
		if ($post['basetype'] == 'A')
			$answers[$postid] = $post;
	}

	return $answers;
}


/**
 * Return the full database records for all comments or follow-on articles for article $articleid or its answers
 * @param $articleid
 * @return array
 */
function as_post_get_article_commentsfollows($articleid)
{
	$commentsfollows = array();

	list($childposts, $achildposts) = as_db_multi_select(array(
		as_db_full_child_posts_selectspec(null, $articleid),
		as_db_full_a_child_posts_selectspec(null, $articleid),
	));

	foreach ($childposts as $postid => $post) {
		if ($post['basetype'] == 'C')
			$commentsfollows[$postid] = $post;
	}

	foreach ($achildposts as $postid => $post) {
		if ($post['basetype'] == 'Q' || $post['basetype'] == 'C')
			$commentsfollows[$postid] = $post;
	}

	return $commentsfollows;
}


/**
 * Return the full database record for the post which closed $articleid, if there is any
 * @param $articleid
 * @return array|mixed
 */
function as_post_get_article_closepost($articleid)
{
	return as_db_single_select(as_db_post_close_post_selectspec($articleid));
}


/**
 * Return the full database records for all comments or follow-on articles for answer $answerid
 * @param $answerid
 * @return array
 */
function as_post_get_answer_commentsfollows($answerid)
{
	$commentsfollows = array();

	$childposts = as_db_single_select(as_db_full_child_posts_selectspec(null, $answerid));

	foreach ($childposts as $postid => $post) {
		if ($post['basetype'] == 'Q' || $post['basetype'] == 'C')
			$commentsfollows[$postid] = $post;
	}

	return $commentsfollows;
}


/**
 * Return $parent if it's the database record for a article, otherwise return the database record for its parent
 * @param $parent
 * @return array|mixed
 */
function as_post_parent_to_article($parent)
{
	if ($parent['basetype'] == 'Q')
		$article = $parent;
	else
		$article = as_post_get_full($parent['parentid'], 'Q');

	return $article;
}
