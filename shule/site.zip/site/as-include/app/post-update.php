<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Changing articles, answer and comments (application level)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'app/post-create.php';
require_once AS_INCLUDE_DIR . 'app/updates.php';
require_once AS_INCLUDE_DIR . 'db/post-create.php';
require_once AS_INCLUDE_DIR . 'db/post-update.php';
require_once AS_INCLUDE_DIR . 'db/points.php';
require_once AS_INCLUDE_DIR . 'db/hotness.php';

define('AS_POST_STATUS_NORMAL', 0);
define('AS_POST_STATUS_HIDDEN', 1);
define('AS_POST_STATUS_QUEUED', 2);


function as_timetable_update($timetableid, $memberid, $handle, $cookieid, $title, $content, $count, $duration, $slots, $groups, $teachers, $units, $lessons, $extravalue = null)
{
	require_once AS_INCLUDE_DIR . 'db/selects.php';
	as_db_timetable_update($timetableid, $title, $content, $count, $duration, $slots, $groups, $teachers, $lessons, $memberid, isset($memberid) ? null : $cookieid,
		as_remote_ip_address(), isset($extravalue) ? null : $extravalue);

	as_report_event('t_update', $memberid, $handle, $cookieid, array(
		'timetableid' => $timetableid,
		'title' => $title,
		'content' => $content,
		'fullname' => as_get_member_name($handle),
	));

	return $timetableid;
}


/**
 * Change the fields of a article (application level) to $title, $content, $format, $tagstring, $notify, $extravalue
 * and $name, then reindex based on $text. For backwards compatibility if $name is null then the name will not be
 * changed. Pass the article's database record before changes in $oldarticle and details of the member doing this in
 * $memberid, $handle and $cookieid. Set $remoderate to true if the article should be requeued for moderation if
 * modified. Set $silent to true to not mark the article as edited. Reports event as appropriate. See /as-include/app/posts.php
 * for a higher-level function which is easier to use.
 * @param $oldarticle
 * @param $title
 * @param $content
 * @param $format
 * @param $text
 * @param $tagstring
 * @param $notify
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $extravalue
 * @param $name
 * @param bool $remoderate
 * @param bool $silent
 */
function as_article_set_content($oldarticle, $title, $content, $format, $text, $tagstring, $notify, $memberid, $handle, $cookieid, $extravalue = null, $name = null, $remoderate = false, $silent = false)
{
	as_post_unindex($oldarticle['postid']);

	$wasqueued = ($oldarticle['type'] == 'Q_QUEUED');
	$titlechanged = strcmp($oldarticle['title'], $title) !== 0;
	$contentchanged = strcmp($oldarticle['content'], $content) !== 0 || strcmp($oldarticle['format'], $format) !== 0;
	$tagschanged = strcmp($oldarticle['tags'], $tagstring) !== 0;
	$setupdated = ($titlechanged || $contentchanged || $tagschanged) && (!$wasqueued) && !$silent;

	as_db_post_set_content($oldarticle['postid'], $title, $content, $format, $tagstring, $notify,
		$setupdated ? $memberid : null, $setupdated ? as_remote_ip_address() : null,
		($titlechanged || $contentchanged) ? AS_UPDATE_CONTENT : AS_UPDATE_TAGS, $name);

	if (isset($extravalue)) {
		require_once AS_INCLUDE_DIR . 'db/metas.php';
		as_db_postmeta_set($oldarticle['postid'], 'as_q_extra', $extravalue);
	}

	if ($setupdated && $remoderate) {
		require_once AS_INCLUDE_DIR . 'app/posts.php';

		$answers = as_post_get_article_answers($oldarticle['postid']);
		$commentsfollows = as_post_get_article_commentsfollows($oldarticle['postid']);
		$closepost = as_post_get_article_closepost($oldarticle['postid']);

		foreach ($answers as $answer)
			as_post_unindex($answer['postid']);

		foreach ($commentsfollows as $comment) {
			if ($comment['basetype'] == 'C')
				as_post_unindex($comment['postid']);
		}

		if (@$closepost['parentid'] == $oldarticle['postid'])
			as_post_unindex($closepost['postid']);

		as_db_post_set_type($oldarticle['postid'], 'Q_QUEUED');
		as_update_counts_for_q($oldarticle['postid']);
		as_db_queuedcount_update();
		as_db_points_update_ifmember($oldarticle['memberid'], array('qposts', 'aselects'));

		if ($oldarticle['flagcount'])
			as_db_flaggedcount_update();

	} elseif ($oldarticle['type'] == 'Q') { // not hidden or queued
		as_post_index($oldarticle['postid'], 'Q', $oldarticle['postid'], $oldarticle['parentid'], $title, $content, $format, $text, $tagstring, $oldarticle['departmentid']);
	}

	$eventparams = array(
		'postid' => $oldarticle['postid'],
		'title' => $title,
		'content' => $content,
		'format' => $format,
		'text' => $text,
		'tags' => $tagstring,
		'extra' => $extravalue,
		'name' => $name,
		'oldarticle' => $oldarticle,
		'fullname' => as_get_member_name($handle),
	);

	as_report_event('q_edit', $memberid, $handle, $cookieid, $eventparams + array(
		'silent' => $silent,
		'oldtitle' => $oldarticle['title'],
		'oldcontent' => $oldarticle['content'],
		'oldformat' => $oldarticle['format'],
		'oldtags' => $oldarticle['tags'],
		'titlechanged' => $titlechanged,
		'contentchanged' => $contentchanged,
		'tagschanged' => $tagschanged,
	));

	if ($setupdated && $remoderate)
		as_report_event('q_requeue', $memberid, $handle, $cookieid, $eventparams);
}


/**
 * Set the selected answer (application level) of $oldarticle to $selchildid. Pass details of the member doing this
 * in $memberid, $handle and $cookieid, and the database records for the selected and deselected answers in $answers.
 * Handles member points values and notifications.
 * See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $oldarticle
 * @param $selchildid
 * @param $answers
 */
function as_article_set_selchildid($memberid, $handle, $cookieid, $oldarticle, $selchildid, $answers)
{
	$oldselchildid = $oldarticle['selchildid'];

	as_db_post_set_selchildid($oldarticle['postid'], isset($selchildid) ? $selchildid : null, $memberid, as_remote_ip_address());
	as_db_points_update_ifmember($oldarticle['memberid'], 'aselects');
	as_db_unselqcount_update();

	if (isset($oldselchildid) && isset($answers[$oldselchildid])) {
		as_db_points_update_ifmember($answers[$oldselchildid]['memberid'], 'aselecteds');

		as_report_event('a_unselect', $memberid, $handle, $cookieid, array(
			'parentid' => $oldarticle['postid'],
			'parent' => $oldarticle,
			'postid' => $oldselchildid,
			'answer' => $answers[$oldselchildid],
			'fullname' => as_get_member_name($handle),
		));
	}

	if (isset($selchildid)) {
		as_db_points_update_ifmember($answers[$selchildid]['memberid'], 'aselecteds');

		as_report_event('a_select', $memberid, $handle, $cookieid, array(
			'parentid' => $oldarticle['postid'],
			'parent' => $oldarticle,
			'postid' => $selchildid,
			'answer' => $answers[$selchildid],
			'fullname' => as_get_member_name($handle),
		));
	}
}


/**
 * Reopen $oldarticle if it was closed. Pass details of the member doing this in $memberid, $handle and $cookieid, and the
 * $oldclosepost (to match $oldarticle['closedbyid']) if any.
 * See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $oldarticle
 * @param $oldclosepost
 * @param $memberid
 * @param $handle
 * @param $cookieid
 */
function as_article_close_clear($oldarticle, $oldclosepost, $memberid, $handle, $cookieid)
{
	if (isset($oldarticle['closedbyid'])) {
		as_db_post_set_closed($oldarticle['postid'], null, $memberid, as_remote_ip_address());

		if (isset($oldclosepost) && ($oldclosepost['parentid'] == $oldarticle['postid'])) {
			as_post_unindex($oldclosepost['postid']);
			as_db_post_delete($oldclosepost['postid']);
		}

		as_report_event('q_reopen', $memberid, $handle, $cookieid, array(
			'postid' => $oldarticle['postid'],
			'oldarticle' => $oldarticle,
			'fullname' => as_get_member_name($handle),
		));
	}
}


/**
 * Close $oldarticle as a duplicate of the article with id $originalpostid. Pass details of the member doing this in
 * $memberid, $handle and $cookieid, and the $oldclosepost (to match $oldarticle['closedbyid']) if any. See
 * /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $oldarticle
 * @param $oldclosepost
 * @param $originalpostid
 * @param $memberid
 * @param $handle
 * @param $cookieid
 */
function as_article_close_duplicate($oldarticle, $oldclosepost, $originalpostid, $memberid, $handle, $cookieid)
{
	as_article_close_clear($oldarticle, $oldclosepost, $memberid, $handle, $cookieid);

	as_db_post_set_closed($oldarticle['postid'], $originalpostid, $memberid, as_remote_ip_address());

	as_report_event('q_close', $memberid, $handle, $cookieid, array(
		'postid' => $oldarticle['postid'],
		'oldarticle' => $oldarticle,
		'reason' => 'duplicate',
		'originalid' => $originalpostid,
		'fullname' => as_get_member_name($handle),
	));
}


/**
 * Close $oldarticle with the reason given in $note. Pass details of the member doing this in $memberid, $handle and
 * $cookieid, and the $oldclosepost (to match $oldarticle['closedbyid']) if any.
 * See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $oldarticle
 * @param $oldclosepost
 * @param $note
 * @param $memberid
 * @param $handle
 * @param $cookieid
 */
function as_article_close_other($oldarticle, $oldclosepost, $note, $memberid, $handle, $cookieid)
{
	as_article_close_clear($oldarticle, $oldclosepost, $memberid, $handle, $cookieid);

	$postid = as_db_post_create('NOTE', $oldarticle['postid'], $memberid, isset($memberid) ? null : $cookieid,
		as_remote_ip_address(), null, $note, '', null, null, $oldarticle['departmentid']);

	as_db_posts_calc_department_path($postid);

	if ($oldarticle['type'] == 'Q')
		as_post_index($postid, 'NOTE', $oldarticle['postid'], $oldarticle['postid'], null, $note, '', $note, null, $oldarticle['departmentid']);

	as_db_post_set_closed($oldarticle['postid'], $postid, $memberid, as_remote_ip_address());

	as_report_event('q_close', $memberid, $handle, $cookieid, array(
		'postid' => $oldarticle['postid'],
		'oldarticle' => $oldarticle,
		'reason' => 'other',
		'note' => $note,
		'fullname' => as_get_member_name($handle),
	));
}


/**
 * Set $oldarticle to hidden if $hidden is true, visible/normal if otherwise. All other parameters are as for as_article_set_status(...)
 * @deprecated Replaced by as_article_set_status.
 * @param $oldarticle
 * @param $hidden
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $answers
 * @param $commentsfollows
 * @param $closepost
 */
function as_article_set_hidden($oldarticle, $hidden, $memberid, $handle, $cookieid, $answers, $commentsfollows, $closepost = null)
{
	as_article_set_status($oldarticle, $hidden ? AS_POST_STATUS_HIDDEN : AS_POST_STATUS_NORMAL, $memberid, $handle, $cookieid, $answers, $commentsfollows, $closepost);
}


/**
 * Set the status (application level) of $oldarticle to $status, one of the AS_POST_STATUS_* constants above. Pass
 * details of the member doing this in $memberid, $handle and $cookieid, the database records for all answers to the
 * article in $answers, the database records for all comments on the article or the article's answers in
 * $commentsfollows ($commentsfollows can also contain records for follow-on articles which are ignored), and
 * $closepost to match $oldarticle['closedbyid'] (if any). Handles indexing, member points, cached counts and event
 * reports. See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $oldarticle
 * @param $status
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $answers
 * @param $commentsfollows
 * @param $closepost
 */
function as_article_set_status($oldarticle, $status, $memberid, $handle, $cookieid, $answers, $commentsfollows, $closepost = null)
{
	require_once AS_INCLUDE_DIR . 'app/format.php';
	require_once AS_INCLUDE_DIR . 'app/updates.php';

	$washidden = ($oldarticle['type'] == 'Q_HIDDEN');
	$wasqueued = ($oldarticle['type'] == 'Q_QUEUED');
	$wasrequeued = $wasqueued && isset($oldarticle['updated']);

	as_post_unindex($oldarticle['postid']);

	foreach ($answers as $answer) {
		as_post_unindex($answer['postid']);
	}

	foreach ($commentsfollows as $comment) {
		if ($comment['basetype'] == 'C')
			as_post_unindex($comment['postid']);
	}

	if (@$closepost['parentid'] == $oldarticle['postid'])
		as_post_unindex($closepost['postid']);

	$setupdated = false;
	$event = null;

	if ($status == AS_POST_STATUS_QUEUED) {
		$newtype = 'Q_QUEUED';
		if (!$wasqueued)
			$event = 'q_requeue'; // same event whether it was hidden or shown before

	} elseif ($status == AS_POST_STATUS_HIDDEN) {
		$newtype = 'Q_HIDDEN';
		if (!$washidden) {
			$event = $wasqueued ? 'q_reject' : 'q_hide';
			if (!$wasqueued)
				$setupdated = true;
		}

	} elseif ($status == AS_POST_STATUS_NORMAL) {
		$newtype = 'Q';
		if ($wasqueued)
			$event = 'q_approve';
		elseif ($washidden) {
			$event = 'q_reshow';
			$setupdated = true;
		}

	} else
		as_fatal_error('Unknown status in as_article_set_status(): ' . $status);

	as_db_post_set_type($oldarticle['postid'], $newtype, $setupdated ? $memberid : null, $setupdated ? as_remote_ip_address() : null, AS_UPDATE_VISIBLE);

	if ($wasqueued && $status == AS_POST_STATUS_NORMAL && as_opt('moderate_update_time')) { // ... for approval of a post, can set time to now instead
		if ($wasrequeued) // reset edit time to now if there was one, since we're approving the edit...
			as_db_post_set_updated($oldarticle['postid'], null);

		else { // ... otherwise we're approving original created post
			as_db_post_set_created($oldarticle['postid'], null);
			as_db_hotness_update($oldarticle['postid']);
		}
	}

	as_update_counts_for_q($oldarticle['postid']);
	as_db_points_update_ifmember($oldarticle['memberid'], array('qposts', 'aselects'));

	if ($wasqueued || ($status == AS_POST_STATUS_QUEUED))
		as_db_queuedcount_update();

	if ($oldarticle['flagcount'])
		as_db_flaggedcount_update();

	if ($status == AS_POST_STATUS_NORMAL) {
		as_post_index($oldarticle['postid'], 'Q', $oldarticle['postid'], $oldarticle['parentid'], $oldarticle['title'], $oldarticle['content'],
			$oldarticle['format'], as_viewer_text($oldarticle['content'], $oldarticle['format']), $oldarticle['tags'], $oldarticle['departmentid']);

		foreach ($answers as $answer) {
			if ($answer['type'] == 'A') { // even if article visible, don't index hidden or queued answers
				as_post_index($answer['postid'], $answer['type'], $oldarticle['postid'], $answer['parentid'], null,
					$answer['content'], $answer['format'], as_viewer_text($answer['content'], $answer['format']), null, $answer['departmentid']);
			}
		}

		foreach ($commentsfollows as $comment) {
			if ($comment['type'] == 'C') {
				$answer = @$answers[$comment['parentid']];

				if (!isset($answer) || $answer['type'] == 'A') { // don't index comment if it or its parent is hidden
					as_post_index($comment['postid'], $comment['type'], $oldarticle['postid'], $comment['parentid'], null,
						$comment['content'], $comment['format'], as_viewer_text($comment['content'], $comment['format']), null, $comment['departmentid']);
				}
			}
		}

		if ($closepost['parentid'] == $oldarticle['postid']) {
			as_post_index($closepost['postid'], $closepost['type'], $oldarticle['postid'], $closepost['parentid'], null,
				$closepost['content'], $closepost['format'], as_viewer_text($closepost['content'], $closepost['format']), null, $closepost['departmentid']);
		}
	}

	$eventparams = array(
		'postid' => $oldarticle['postid'],
		'parentid' => $oldarticle['parentid'],
		'parent' => isset($oldarticle['parentid']) ? as_db_single_select(as_db_full_post_selectspec(null, $oldarticle['parentid'])) : null,
		'title' => $oldarticle['title'],
		'content' => $oldarticle['content'],
		'format' => $oldarticle['format'],
		'text' => as_viewer_text($oldarticle['content'], $oldarticle['format']),
		'tags' => $oldarticle['tags'],
		'departmentid' => $oldarticle['departmentid'],
		'name' => $oldarticle['name'],
	);

	if (isset($event)) {
		as_report_event($event, $memberid, $handle, $cookieid, $eventparams + array(
				'oldarticle' => $oldarticle,
				'fullname' => as_get_member_name($handle),
			));
	}

	if ($wasqueued && ($status == AS_POST_STATUS_NORMAL) && !$wasrequeued) {
		require_once AS_INCLUDE_DIR . 'db/selects.php';
		require_once AS_INCLUDE_DIR . 'util/string.php';

		as_report_event('q_post', $oldarticle['memberid'], $oldarticle['handle'], $oldarticle['cookieid'], $eventparams + array(
			'notify' => isset($oldarticle['notify']),
			'email' => as_email_validate($oldarticle['notify']) ? $oldarticle['notify'] : null,
			'delayed' => $oldarticle['created'],
			'fullname' => as_get_member_name($handle),
		));
	}
}


/**
 * Sets the department (application level) of $oldarticle to $departmentid. Pass details of the member doing this in
 * $memberid, $handle and $cookieid, the database records for all answers to the article in $answers, the database
 * records for all comments on the article or the article's answers in $commentsfollows ($commentsfollows can also
 * contain records for follow-on articles which are ignored), and $closepost to match $oldarticle['closedbyid'] (if any).
 * Set $silent to true to not mark the article as edited. Handles cached counts and event reports and will reset department
 * IDs and paths for all answers and comments. See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $oldarticle
 * @param $departmentid
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $answers
 * @param $commentsfollows
 * @param $closepost
 * @param bool $silent
 */
function as_article_set_department($oldarticle, $departmentid, $memberid, $handle, $cookieid, $answers, $commentsfollows, $closepost = null, $silent = false)
{
	$oldpath = as_db_post_get_department_path($oldarticle['postid']);

	as_db_post_set_department($oldarticle['postid'], $departmentid, $silent ? null : $memberid, $silent ? null : as_remote_ip_address());
	as_db_posts_calc_department_path($oldarticle['postid']);

	$newpath = as_db_post_get_department_path($oldarticle['postid']);

	as_db_department_path_qcount_update($oldpath);
	as_db_department_path_qcount_update($newpath);

	$otherpostids = array();
	foreach ($answers as $answer) {
		$otherpostids[] = $answer['postid'];
	}

	foreach ($commentsfollows as $comment) {
		if ($comment['basetype'] == 'C')
			$otherpostids[] = $comment['postid'];
	}

	if (@$closepost['parentid'] == $oldarticle['postid'])
		$otherpostids[] = $closepost['postid'];

	as_db_posts_set_department_path($otherpostids, $newpath);

	$searchmodules = as_load_modules_with('search', 'move_post');
	foreach ($searchmodules as $searchmodule) {
		$searchmodule->move_post($oldarticle['postid'], $departmentid);
		foreach ($otherpostids as $otherpostid) {
			$searchmodule->move_post($otherpostid, $departmentid);
		}
	}

	as_report_event('q_move', $memberid, $handle, $cookieid, array(
		'postid' => $oldarticle['postid'],
		'oldarticle' => $oldarticle,
		'departmentid' => $departmentid,
		'olddepartmentid' => $oldarticle['departmentid'],
		'fullname' => as_get_member_name($handle),
	));
}


/**
 * Permanently delete a article (application level) from the database. The article must not have any answers or
 * comments on it. Pass details of the member doing this in $memberid, $handle and $cookieid, and $closepost to match
 * $oldarticle['closedbyid'] (if any). Handles unindexing, votes, points, cached counts and event reports.
 * See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $oldarticle
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $oldclosepost
 */
function as_article_delete($oldarticle, $memberid, $handle, $cookieid, $oldclosepost = null)
{
	require_once AS_INCLUDE_DIR . 'db/votes.php';

	if ($oldarticle['type'] != 'Q_HIDDEN')
		as_fatal_error('Tried to delete a non-hidden article');

	$params = array(
		'postid' => $oldarticle['postid'],
		'oldarticle' => $oldarticle,
		'fullname' => as_get_member_name($handle),
	);

	as_report_event('q_delete_before', $memberid, $handle, $cookieid, $params);

	if (isset($oldclosepost) && ($oldclosepost['parentid'] == $oldarticle['postid'])) {
		as_db_post_set_closed($oldarticle['postid'], null); // for foreign key constraint
		as_post_unindex($oldclosepost['postid']);
		as_db_post_delete($oldclosepost['postid']);
	}

	$memberidvotes = as_db_membervote_post_get($oldarticle['postid']);
	$oldpath = as_db_post_get_department_path($oldarticle['postid']);

	as_post_unindex($oldarticle['postid']);
	as_db_post_delete($oldarticle['postid']); // also deletes any related voteds due to foreign key cascading
	as_update_counts_for_q(null);
	as_db_department_path_qcount_update($oldpath); // don't do inside as_update_counts_for_q() since post no longer exists
	as_db_points_update_ifmember($oldarticle['memberid'], array('qposts', 'aselects', 'qvoteds', 'upvoteds', 'downvoteds'));

	foreach ($memberidvotes as $votermemberid => $vote) {
		// could do this in one query like in as_db_members_recalc_points() but this will do for now - unlikely to be many votes
		as_db_points_update_ifmember($votermemberid, ($vote > 0) ? 'qupvotes' : 'qdownvotes');
	}

	as_report_event('q_delete', $memberid, $handle, $cookieid, $params);
}


/**
 * Set the author (application level) of $oldarticle to $memberid and also pass $handle and $cookieid
 * of member. Updates points and reports events as appropriate.
 * @param $oldarticle
 * @param $memberid
 * @param $handle
 * @param $cookieid
 */
function as_article_set_memberid($oldarticle, $memberid, $handle, $cookieid)
{
	require_once AS_INCLUDE_DIR . 'db/votes.php';

	$postid = $oldarticle['postid'];

	as_db_post_set_memberid($postid, $memberid);
	as_db_membervote_remove_own($postid);
	as_db_post_recount_votes($postid);

	as_db_points_update_ifmember($oldarticle['memberid'], array('qposts', 'aselects', 'qvoteds', 'upvoteds', 'downvoteds'));
	as_db_points_update_ifmember($memberid, array('qposts', 'aselects', 'qvoteds', 'qupvotes', 'qdownvotes', 'upvoteds', 'downvoteds'));

	as_report_event('q_claim', $memberid, $handle, $cookieid, array(
		'postid' => $postid,
		'oldarticle' => $oldarticle,
		'fullname' => as_get_member_name($handle),
	));
}


/**
 * Remove post $postid from our index and update appropriate word counts. Calls through to all search modules.
 * @param $postid
 */
function as_post_unindex($postid)
{
	global $as_post_indexing_suspended;

	if ($as_post_indexing_suspended > 0)
		return;

	// Send through to any search modules for unindexing

	$searchmodules = as_load_modules_with('search', 'unindex_post');
	foreach ($searchmodules as $searchmodule) {
		$searchmodule->unindex_post($postid);
	}
}


/**
 * Change the fields of an answer (application level) to $content, $format, $notify and $name, then reindex based on
 * $text. For backwards compatibility if $name is null then the name will not be changed. Pass the answer's database
 * record before changes in $oldanswer, the article's in $article, and details of the member doing this in $memberid,
 * $handle and $cookieid. Set $remoderate to true if the article should be requeued for moderation if modified. Set
 * $silent to true to not mark the article as edited. Handle indexing and event reports as appropriate. See
 * /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $oldanswer
 * @param $content
 * @param $format
 * @param $text
 * @param $notify
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $article
 * @param $name
 * @param bool $remoderate
 * @param bool $silent
 */
function as_answer_set_content($oldanswer, $content, $format, $text, $notify, $memberid, $handle, $cookieid, $article, $name = null, $remoderate = false, $silent = false)
{
	as_post_unindex($oldanswer['postid']);

	$wasqueued = ($oldanswer['type'] == 'A_QUEUED');
	$contentchanged = strcmp($oldanswer['content'], $content) || strcmp($oldanswer['format'], $format);
	$setupdated = $contentchanged && (!$wasqueued) && !$silent;

	as_db_post_set_content($oldanswer['postid'], $oldanswer['title'], $content, $format, $oldanswer['tags'], $notify,
		$setupdated ? $memberid : null, $setupdated ? as_remote_ip_address() : null, AS_UPDATE_CONTENT, $name);

	if ($setupdated && $remoderate) {
		require_once AS_INCLUDE_DIR . 'app/posts.php';

		$commentsfollows = as_post_get_answer_commentsfollows($oldanswer['postid']);

		foreach ($commentsfollows as $comment) {
			if ($comment['basetype'] == 'C' && $comment['parentid'] == $oldanswer['postid'])
				as_post_unindex($comment['postid']);
		}

		as_db_post_set_type($oldanswer['postid'], 'A_QUEUED');
		as_update_q_counts_for_a($article['postid']);
		as_db_queuedcount_update();
		as_db_points_update_ifmember($oldanswer['memberid'], array('aposts', 'aselecteds'));

		if ($oldanswer['flagcount'])
			as_db_flaggedcount_update();

	} elseif ($oldanswer['type'] == 'A' && $article['type'] == 'Q') { // don't index if article or answer are hidden/queued
		as_post_index($oldanswer['postid'], 'A', $article['postid'], $oldanswer['parentid'], null, $content, $format, $text, null, $oldanswer['departmentid']);
	}

	$eventparams = array(
		'postid' => $oldanswer['postid'],
		'parentid' => $oldanswer['parentid'],
		'parent' => $article,
		'content' => $content,
		'format' => $format,
		'text' => $text,
		'name' => $name,
		'oldanswer' => $oldanswer,
		'fullname' => as_get_member_name($handle),
	);

	as_report_event('a_edit', $memberid, $handle, $cookieid, $eventparams + array(
		'silent' => $silent,
		'oldcontent' => $oldanswer['content'],
		'oldformat' => $oldanswer['format'],
		'contentchanged' => $contentchanged,
	));

	if ($setupdated && $remoderate)
		as_report_event('a_requeue', $memberid, $handle, $cookieid, $eventparams);
}


/**
 * Set $oldanswer to hidden if $hidden is true, visible/normal if otherwise. All other parameters are as for as_answer_set_status(...)
 * @deprecated Replaced by as_answer_set_status.
 * @param $oldanswer
 * @param $hidden
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $article
 * @param $commentsfollows
 */
function as_answer_set_hidden($oldanswer, $hidden, $memberid, $handle, $cookieid, $article, $commentsfollows)
{
	as_answer_set_status($oldanswer, $hidden ? AS_POST_STATUS_HIDDEN : AS_POST_STATUS_NORMAL, $memberid, $handle, $cookieid, $article, $commentsfollows);
}


/**
 * Set the status (application level) of $oldanswer to $status, one of the AS_POST_STATUS_* constants above. Pass
 * details of the member doing this in $memberid, $handle and $cookieid, the database record for the article in $article,
 * and the database records for all comments on the answer in $commentsfollows ($commentsfollows can also contain other
 * records which are ignored). Handles indexing, member points, cached counts and event reports. See /as-include/app/posts.php for
 * a higher-level function which is easier to use.
 * @param $oldanswer
 * @param $status
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $article
 * @param $commentsfollows
 */
function as_answer_set_status($oldanswer, $status, $memberid, $handle, $cookieid, $article, $commentsfollows)
{
	require_once AS_INCLUDE_DIR . 'app/format.php';

	$washidden = ($oldanswer['type'] == 'A_HIDDEN');
	$wasqueued = ($oldanswer['type'] == 'A_QUEUED');
	$wasrequeued = $wasqueued && isset($oldanswer['updated']);

	as_post_unindex($oldanswer['postid']);

	foreach ($commentsfollows as $comment) {
		if ($comment['basetype'] == 'C' && $comment['parentid'] == $oldanswer['postid'])
			as_post_unindex($comment['postid']);
	}

	$setupdated = false;
	$event = null;

	if ($status == AS_POST_STATUS_QUEUED) {
		$newtype = 'A_QUEUED';
		if (!$wasqueued)
			$event = 'a_requeue'; // same event whether it was hidden or shown before

	} elseif ($status == AS_POST_STATUS_HIDDEN) {
		$newtype = 'A_HIDDEN';
		if (!$washidden) {
			$event = $wasqueued ? 'a_reject' : 'a_hide';
			if (!$wasqueued)
				$setupdated = true;
		}

		if ($article['selchildid'] == $oldanswer['postid']) { // remove selected answer
			as_article_set_selchildid(null, null, null, $article, null, array($oldanswer['postid'] => $oldanswer));
		}

	} elseif ($status == AS_POST_STATUS_NORMAL) {
		$newtype = 'A';
		if ($wasqueued)
			$event = 'a_approve';
		elseif ($washidden) {
			$event = 'a_reshow';
			$setupdated = true;
		}

	} else
		as_fatal_error('Unknown status in as_answer_set_status(): ' . $status);

	as_db_post_set_type($oldanswer['postid'], $newtype, $setupdated ? $memberid : null, $setupdated ? as_remote_ip_address() : null, AS_UPDATE_VISIBLE);

	if ($wasqueued && ($status == AS_POST_STATUS_NORMAL) && as_opt('moderate_update_time')) { // ... for approval of a post, can set time to now instead
		if ($wasrequeued)
			as_db_post_set_updated($oldanswer['postid'], null);
		else
			as_db_post_set_created($oldanswer['postid'], null);
	}

	as_update_q_counts_for_a($article['postid']);
	as_db_points_update_ifmember($oldanswer['memberid'], array('aposts', 'aselecteds'));

	if ($wasqueued || $status == AS_POST_STATUS_QUEUED)
		as_db_queuedcount_update();

	if ($oldanswer['flagcount'])
		as_db_flaggedcount_update();

	if ($article['type'] == 'Q' && $status == AS_POST_STATUS_NORMAL) { // even if answer visible, don't index if article is hidden or queued
		as_post_index($oldanswer['postid'], 'A', $article['postid'], $oldanswer['parentid'], null, $oldanswer['content'],
			$oldanswer['format'], as_viewer_text($oldanswer['content'], $oldanswer['format']), null, $oldanswer['departmentid']);

		foreach ($commentsfollows as $comment) {
			if ($comment['type'] == 'C' && $comment['parentid'] == $oldanswer['postid']) { // and don't index hidden/queued comments
				as_post_index($comment['postid'], $comment['type'], $article['postid'], $comment['parentid'], null, $comment['content'],
					$comment['format'], as_viewer_text($comment['content'], $comment['format']), null, $comment['departmentid']);
			}
		}
	}

	$eventparams = array(
		'postid' => $oldanswer['postid'],
		'parentid' => $oldanswer['parentid'],
		'parent' => $article,
		'content' => $oldanswer['content'],
		'format' => $oldanswer['format'],
		'text' => as_viewer_text($oldanswer['content'], $oldanswer['format']),
		'departmentid' => $oldanswer['departmentid'],
		'name' => $oldanswer['name'],
		'fullname' => as_get_member_name($handle),
	);

	if (isset($event)) {
		as_report_event($event, $memberid, $handle, $cookieid, $eventparams + array(
				'oldanswer' => $oldanswer,
			));
	}

	if ($wasqueued && ($status == AS_POST_STATUS_NORMAL) && !$wasrequeued) {
		require_once AS_INCLUDE_DIR . 'util/string.php';

		as_report_event('a_post', $oldanswer['memberid'], $oldanswer['handle'], $oldanswer['cookieid'], $eventparams + array(
			'notify' => isset($oldanswer['notify']),
			'email' => as_email_validate($oldanswer['notify']) ? $oldanswer['notify'] : null,
			'delayed' => $oldanswer['created'],
		));
	}
}


/**
 * Permanently delete an answer (application level) from the database. The answer must not have any comments or
 * follow-on articles. Pass the database record for the article in $article and details of the member doing this
 * in $memberid, $handle and $cookieid. Handles unindexing, votes, points, cached counts and event reports.
 * See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $oldanswer
 * @param $article
 * @param $memberid
 * @param $handle
 * @param $cookieid
 */
function as_answer_delete($oldanswer, $article, $memberid, $handle, $cookieid)
{
	require_once AS_INCLUDE_DIR . 'db/votes.php';

	if ($oldanswer['type'] != 'A_HIDDEN')
		as_fatal_error('Tried to delete a non-hidden answer');

	$memberidvotes = as_db_membervote_post_get($oldanswer['postid']);

	$params = array(
		'postid' => $oldanswer['postid'],
		'parentid' => $oldanswer['parentid'],
		'oldanswer' => $oldanswer,
		'fullname' => as_get_member_name($handle),
	);

	as_report_event('a_delete_before', $memberid, $handle, $cookieid, $params);

	as_post_unindex($oldanswer['postid']);
	as_db_post_delete($oldanswer['postid']); // also deletes any related voteds due to cascading

	if ($article['selchildid'] == $oldanswer['postid']) {
		as_db_post_set_selchildid($article['postid'], null);
		as_db_points_update_ifmember($article['memberid'], 'aselects');
		as_db_unselqcount_update();
	}

	as_update_q_counts_for_a($article['postid']);
	as_db_points_update_ifmember($oldanswer['memberid'], array('aposts', 'aselecteds', 'avoteds', 'upvoteds', 'downvoteds'));

	foreach ($memberidvotes as $votermemberid => $vote) {
		// could do this in one query like in as_db_members_recalc_points() but this will do for now - unlikely to be many votes
		as_db_points_update_ifmember($votermemberid, ($vote > 0) ? 'aupvotes' : 'adownvotes');
	}

	as_report_event('a_delete', $memberid, $handle, $cookieid, $params);
}


/**
 * Set the author (application level) of $oldanswer to $memberid and also pass $handle and $cookieid
 * of member. Updates points and reports events as appropriate.
 * @param $oldanswer
 * @param $memberid
 * @param $handle
 * @param $cookieid
 */
function as_answer_set_memberid($oldanswer, $memberid, $handle, $cookieid)
{
	require_once AS_INCLUDE_DIR . 'db/votes.php';

	$postid = $oldanswer['postid'];

	as_db_post_set_memberid($postid, $memberid);
	as_db_membervote_remove_own($postid);
	as_db_post_recount_votes($postid);

	as_db_points_update_ifmember($oldanswer['memberid'], array('aposts', 'aselecteds', 'avoteds', 'upvoteds', 'downvoteds'));
	as_db_points_update_ifmember($memberid, array('aposts', 'aselecteds', 'avoteds', 'aupvotes', 'adownvotes', 'upvoteds', 'downvoteds'));

	as_report_event('a_claim', $memberid, $handle, $cookieid, array(
		'postid' => $postid,
		'parentid' => $oldanswer['parentid'],
		'oldanswer' => $oldanswer,
		'fullname' => as_get_member_name($handle),
	));
}


/**
 * Change the fields of a comment (application level) to $content, $format, $notify and $name, then reindex based on
 * $text. For backwards compatibility if $name is null then the name will not be changed. Pass the comment's database
 * record before changes in $oldcomment, details of the member doing this in $memberid, $handle and $cookieid, the
 * antecedent article in $article and the answer's database record in $answer if this is a comment on an answer,
 * otherwise null. Set $remoderate to true if the article should be requeued for moderation if modified. Set $silent
 * to true to not mark the article as edited. Handles unindexing and event reports. See /as-include/app/posts.php for a
 * higher-level function which is easier to use.
 * @param $oldcomment
 * @param $content
 * @param $format
 * @param $text
 * @param $notify
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $article
 * @param $parent
 * @param $name
 * @param bool $remoderate
 * @param bool $silent
 */
function as_comment_set_content($oldcomment, $content, $format, $text, $notify, $memberid, $handle, $cookieid, $article, $parent, $name = null, $remoderate = false, $silent = false)
{
	if (!isset($parent))
		$parent = $article; // for backwards compatibility with old answer parameter

	as_post_unindex($oldcomment['postid']);

	$wasqueued = ($oldcomment['type'] == 'C_QUEUED');
	$contentchanged = strcmp($oldcomment['content'], $content) || strcmp($oldcomment['format'], $format);
	$setupdated = $contentchanged && (!$wasqueued) && !$silent;

	as_db_post_set_content($oldcomment['postid'], $oldcomment['title'], $content, $format, $oldcomment['tags'], $notify,
		$setupdated ? $memberid : null, $setupdated ? as_remote_ip_address() : null, AS_UPDATE_CONTENT, $name);

	if ($setupdated && $remoderate) {
		as_db_post_set_type($oldcomment['postid'], 'C_QUEUED');
		as_db_ccount_update();
		as_db_queuedcount_update();
		as_db_points_update_ifmember($oldcomment['memberid'], array('cposts'));

		if ($oldcomment['flagcount'])
			as_db_flaggedcount_update();

	} elseif ($oldcomment['type'] == 'C' && $article['type'] == 'Q' && ($parent['type'] == 'Q' || $parent['type'] == 'A')) { // all must be visible
		as_post_index($oldcomment['postid'], 'C', $article['postid'], $oldcomment['parentid'], null, $content, $format, $text, null, $oldcomment['departmentid']);
	}

	$eventparams = array(
		'postid' => $oldcomment['postid'],
		'parentid' => $oldcomment['parentid'],
		'parenttype' => $parent['basetype'],
		'parent' => $parent,
		'articleid' => $article['postid'],
		'article' => $article,
		'content' => $content,
		'format' => $format,
		'text' => $text,
		'name' => $name,
		'oldcomment' => $oldcomment,
		'fullname' => as_get_member_name($handle),
	);

	as_report_event('c_edit', $memberid, $handle, $cookieid, $eventparams + array(
		'silent' => $silent,
		'oldcontent' => $oldcomment['content'],
		'oldformat' => $oldcomment['format'],
		'contentchanged' => $contentchanged,
	));

	if ($setupdated && $remoderate)
		as_report_event('c_requeue', $memberid, $handle, $cookieid, $eventparams);
}


/**
 * Convert an answer to a comment (application level) and set its fields to $content, $format, $notify and $name. For
 * backwards compatibility if $name is null then the name will not be changed. Pass the answer's database record before
 * changes in $oldanswer, the new comment's $parentid to be, details of the member doing this in $memberid, $handle and
 * $cookieid, the antecedent article's record in $article, the records for all answers to that article in $answers,
 * and the records for all comments on the (old) answer and articles following from the (old) answer in
 * $commentsfollows ($commentsfollows can also contain other records which are ignored). Set $remoderate to true if the
 * article should be requeued for moderation if modified. Set $silent to true to not mark the article as edited.
 * Handles indexing (based on $text), member points, cached counts and event reports.
 * @param $oldanswer
 * @param $parentid
 * @param $content
 * @param $format
 * @param $text
 * @param $notify
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $article
 * @param $answers
 * @param $commentsfollows
 * @param $name
 * @param bool $remoderate
 * @param bool $silent
 */
function as_answer_to_comment($oldanswer, $parentid, $content, $format, $text, $notify, $memberid, $handle, $cookieid, $article, $answers, $commentsfollows, $name = null, $remoderate = false, $silent = false)
{
	require_once AS_INCLUDE_DIR . 'db/votes.php';

	$parent = isset($answers[$parentid]) ? $answers[$parentid] : $article;

	as_post_unindex($oldanswer['postid']);

	$wasqueued = ($oldanswer['type'] == 'A_QUEUED');
	$contentchanged = strcmp($oldanswer['content'], $content) || strcmp($oldanswer['format'], $format);
	$setupdated = $contentchanged && (!$wasqueued) && !$silent;

	if ($setupdated && $remoderate)
		$newtype = 'C_QUEUED';
	else
		$newtype = substr_replace($oldanswer['type'], 'C', 0, 1);

	as_db_post_set_type($oldanswer['postid'], $newtype, ($wasqueued || $silent) ? null : $memberid,
		($wasqueued || $silent) ? null : as_remote_ip_address(), AS_UPDATE_TYPE);
	as_db_post_set_parent($oldanswer['postid'], $parentid);
	as_db_post_set_content($oldanswer['postid'], $oldanswer['title'], $content, $format, $oldanswer['tags'], $notify,
		$setupdated ? $memberid : null, $setupdated ? as_remote_ip_address() : null, AS_UPDATE_CONTENT, $name);

	foreach ($commentsfollows as $commentfollow) {
		if ($commentfollow['parentid'] == $oldanswer['postid']) // do same thing for comments and follows
			as_db_post_set_parent($commentfollow['postid'], $parentid);
	}

	as_update_q_counts_for_a($article['postid']);
	as_db_ccount_update();
	as_db_points_update_ifmember($oldanswer['memberid'], array('aposts', 'aselecteds', 'cposts', 'avoteds', 'cvoteds'));

	$memberidvotes = as_db_membervote_post_get($oldanswer['postid']);
	foreach ($memberidvotes as $votermemberid => $vote) {
		// could do this in one query like in as_db_members_recalc_points() but this will do for now - unlikely to be many votes
		as_db_points_update_ifmember($votermemberid, ($vote > 0) ? 'aupvotes' : 'adownvotes');
	}

	if ($setupdated && $remoderate) {
		as_db_queuedcount_update();

		if ($oldanswer['flagcount'])
			as_db_flaggedcount_update();

	} elseif ($oldanswer['type'] == 'A' && $article['type'] == 'Q' && ($parent['type'] == 'Q' || $parent['type'] == 'A')) // only if all fully visible
		as_post_index($oldanswer['postid'], 'C', $article['postid'], $parentid, null, $content, $format, $text, null, $oldanswer['departmentid']);

	if ($article['selchildid'] == $oldanswer['postid']) { // remove selected answer
		as_article_set_selchildid(null, null, null, $article, null, array($oldanswer['postid'] => $oldanswer));
	}

	$eventparams = array(
		'postid' => $oldanswer['postid'],
		'parentid' => $parentid,
		'parenttype' => $parent['basetype'],
		'parent' => $parent,
		'articleid' => $article['postid'],
		'article' => $article,
		'content' => $content,
		'format' => $format,
		'text' => $text,
		'name' => $name,
		'oldanswer' => $oldanswer,
		'fullname' => as_get_member_name($handle),
	);

	as_report_event('a_to_c', $memberid, $handle, $cookieid, $eventparams + array(
		'silent' => $silent,
		'oldcontent' => $oldanswer['content'],
		'oldformat' => $oldanswer['format'],
		'contentchanged' => $contentchanged,
	));

	if ($setupdated && $remoderate) {
		// a-to-c conversion can be detected by presence of $event['oldanswer'] instead of $event['oldcomment']
		as_report_event('c_requeue', $memberid, $handle, $cookieid, $eventparams);
	}
}


/**
 * Set $oldcomment to hidden if $hidden is true, visible/normal if otherwise. All other parameters are as for as_comment_set_status(...)
 * @deprecated Replaced by as_comment_set_status.
 * @param $oldcomment
 * @param $hidden
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $article
 * @param $parent
 */
function as_comment_set_hidden($oldcomment, $hidden, $memberid, $handle, $cookieid, $article, $parent)
{
	as_comment_set_status($oldcomment, $hidden ? AS_POST_STATUS_HIDDEN : AS_POST_STATUS_NORMAL, $memberid, $handle, $cookieid, $article, $parent);
}


/**
 * Set the status (application level) of $oldcomment to $status, one of the AS_POST_STATUS_* constants above. Pass the
 * antecedent article's record in $article, details of the member doing this in $memberid, $handle and $cookieid, and the
 * answer's database record in $answer if this is a comment on an answer, otherwise null. Handles indexing, member
 * points, cached counts and event reports. See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $oldcomment
 * @param $status
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $article
 * @param $parent
 */
function as_comment_set_status($oldcomment, $status, $memberid, $handle, $cookieid, $article, $parent)
{
	require_once AS_INCLUDE_DIR . 'app/format.php';

	if (!isset($parent))
		$parent = $article; // for backwards compatibility with old answer parameter

	$washidden = ($oldcomment['type'] == 'C_HIDDEN');
	$wasqueued = ($oldcomment['type'] == 'C_QUEUED');
	$wasrequeued = $wasqueued && isset($oldcomment['updated']);

	as_post_unindex($oldcomment['postid']);

	$setupdated = false;
	$event = null;

	if ($status == AS_POST_STATUS_QUEUED) {
		$newtype = 'C_QUEUED';
		if (!$wasqueued)
			$event = 'c_requeue'; // same event whether it was hidden or shown before

	} elseif ($status == AS_POST_STATUS_HIDDEN) {
		$newtype = 'C_HIDDEN';
		if (!$washidden) {
			$event = $wasqueued ? 'c_reject' : 'c_hide';
			if (!$wasqueued)
				$setupdated = true;
		}

	} elseif ($status == AS_POST_STATUS_NORMAL) {
		$newtype = 'C';
		if ($wasqueued)
			$event = 'c_approve';
		elseif ($washidden) {
			$event = 'c_reshow';
			$setupdated = true;
		}

	} else
		as_fatal_error('Unknown status in as_comment_set_status(): ' . $status);

	as_db_post_set_type($oldcomment['postid'], $newtype, $setupdated ? $memberid : null, $setupdated ? as_remote_ip_address() : null, AS_UPDATE_VISIBLE);

	if ($wasqueued && ($status == AS_POST_STATUS_NORMAL) && as_opt('moderate_update_time')) { // ... for approval of a post, can set time to now instead
		if ($wasrequeued)
			as_db_post_set_updated($oldcomment['postid'], null);
		else
			as_db_post_set_created($oldcomment['postid'], null);
	}

	as_db_ccount_update();
	as_db_points_update_ifmember($oldcomment['memberid'], array('cposts'));

	if ($wasqueued || $status == AS_POST_STATUS_QUEUED)
		as_db_queuedcount_update();

	if ($oldcomment['flagcount'])
		as_db_flaggedcount_update();

	if ($article['type'] == 'Q' && ($parent['type'] == 'Q' || $parent['type'] == 'A') && $status == AS_POST_STATUS_NORMAL) {
		// only index if none of the things it depends on are hidden or queued
		as_post_index($oldcomment['postid'], 'C', $article['postid'], $oldcomment['parentid'], null, $oldcomment['content'],
			$oldcomment['format'], as_viewer_text($oldcomment['content'], $oldcomment['format']), null, $oldcomment['departmentid']);
	}

	$eventparams = array(
		'postid' => $oldcomment['postid'],
		'parentid' => $oldcomment['parentid'],
		'parenttype' => $parent['basetype'],
		'parent' => $parent,
		'articleid' => $article['postid'],
		'article' => $article,
		'content' => $oldcomment['content'],
		'format' => $oldcomment['format'],
		'text' => as_viewer_text($oldcomment['content'], $oldcomment['format']),
		'departmentid' => $oldcomment['departmentid'],
		'name' => $oldcomment['name'],
		'fullname' => as_get_member_name($handle),
	);

	if (isset($event)) {
		as_report_event($event, $memberid, $handle, $cookieid, $eventparams + array(
			'oldcomment' => $oldcomment,
		));
	}

	if ($wasqueued && $status == AS_POST_STATUS_NORMAL && !$wasrequeued) {
		require_once AS_INCLUDE_DIR . 'db/selects.php';
		require_once AS_INCLUDE_DIR . 'util/string.php';

		$commentsfollows = as_db_single_select(as_db_full_child_posts_selectspec(null, $oldcomment['parentid']));
		$thread = array();

		foreach ($commentsfollows as $comment) {
			if ($comment['type'] == 'C' && $comment['parentid'] == $parent['postid'])
				$thread[] = $comment;
		}

		as_report_event('c_post', $oldcomment['memberid'], $oldcomment['handle'], $oldcomment['cookieid'], $eventparams + array(
			'thread' => $thread,
			'notify' => isset($oldcomment['notify']),
			'fullname' => as_get_member_name($handle),
			'email' => as_email_validate($oldcomment['notify']) ? $oldcomment['notify'] : null,
			'delayed' => $oldcomment['created'],
		));
	}
}


/**
 * Permanently delete a comment in $oldcomment (application level) from the database. Pass the database article in $article
 * and the answer's database record in $answer if this is a comment on an answer, otherwise null. Pass details of the member
 * doing this in $memberid, $handle and $cookieid. Handles unindexing, points, cached counts and event reports.
 * See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $oldcomment
 * @param $article
 * @param $parent
 * @param $memberid
 * @param $handle
 * @param $cookieid
 */
function as_comment_delete($oldcomment, $article, $parent, $memberid, $handle, $cookieid)
{
	if (!isset($parent))
		$parent = $article; // for backwards compatibility with old answer parameter

	if ($oldcomment['type'] != 'C_HIDDEN')
		as_fatal_error('Tried to delete a non-hidden comment');

	$params = array(
		'postid' => $oldcomment['postid'],
		'parentid' => $oldcomment['parentid'],
		'oldcomment' => $oldcomment,
		'parenttype' => $parent['basetype'],
		'articleid' => $article['postid'],
		'fullname' => as_get_member_name($handle),
	);

	as_report_event('c_delete_before', $memberid, $handle, $cookieid, $params);

	as_post_unindex($oldcomment['postid']);
	as_db_post_delete($oldcomment['postid']);
	as_db_points_update_ifmember($oldcomment['memberid'], array('cposts'));
	as_db_ccount_update();

	as_report_event('c_delete', $memberid, $handle, $cookieid, $params);
}


/**
 * Set the author (application level) of $oldcomment to $memberid and also pass $handle and $cookieid
 * of member. Updates points and reports events as appropriate.
 * @param $oldcomment
 * @param $memberid
 * @param $handle
 * @param $cookieid
 */
function as_comment_set_memberid($oldcomment, $memberid, $handle, $cookieid)
{
	require_once AS_INCLUDE_DIR . 'db/votes.php';

	$postid = $oldcomment['postid'];

	as_db_post_set_memberid($postid, $memberid);
	as_db_membervote_remove_own($postid);
	as_db_post_recount_votes($postid);

	as_db_points_update_ifmember($oldcomment['memberid'], array('cposts'));
	as_db_points_update_ifmember($memberid, array('cposts'));

	as_report_event('c_claim', $memberid, $handle, $cookieid, array(
		'postid' => $postid,
		'parentid' => $oldcomment['parentid'],
		'oldcomment' => $oldcomment,
		'fullname' => as_get_member_name($handle),
	));
}
