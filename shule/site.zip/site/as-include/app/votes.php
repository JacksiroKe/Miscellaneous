<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Handling incoming votes (application level)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


/**
 * Check if $memberid can vote on $post, on the page $topage.
 * Return an HTML error to display if there was a problem, or false if it's OK.
 * @param $post
 * @param $vote
 * @param $memberid
 * @param $topage
 * @return bool|mixed|string
 */
function as_vote_error_html($post, $vote, $memberid, $topage)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	// The 'login', 'confirm', 'limit', 'memberblock' and 'ipblock' permission errors are reported to the member here.
	// Others ('approve', 'level') prevent the buttons being clickable in the first place, in as_get_vote_view(...)

	require_once AS_INCLUDE_DIR . 'app/members.php';
	require_once AS_INCLUDE_DIR . 'app/limits.php';

	if ($post['hidden']) {
		return as_lang_html('main/vote_disabled_hidden');
	}
	if ($post['queued']) {
		return as_lang_html('main/vote_disabled_queued');
	}

	switch($post['basetype'])
	{
		case 'Q':
			$allowVoting = as_opt('voting_on_qs');
			break;
		case 'A':
			$allowVoting = as_opt('voting_on_as');
			break;
		case 'C':
			$allowVoting = as_opt('voting_on_cs');
			break;
		default:
			$allowVoting = false;
			break;
	}

	if (!$allowVoting || (isset($post['memberid']) && isset($memberid) && $post['memberid'] == $memberid)) {
		// voting option should not have been presented (but could happen due to options change)
		return as_lang_html('main/vote_not_allowed');
	}

	$permiterror = as_member_post_permit_error(($post['basetype'] == 'Q') ? 'permit_vote_q' : 'permit_vote_a', $post, AS_LIMIT_VOTES);

	$errordownonly = !$permiterror && $vote < 0;
	if ($errordownonly) {
		$permiterror = as_member_post_permit_error('permit_vote_down', $post);
	}

	switch ($permiterror) {
		case false:
			return false;
			break;

		case 'login':
			return as_insert_login_links(as_lang_html('main/vote_must_login'), $topage);
			break;

		case 'confirm':
			return as_insert_login_links(as_lang_html($errordownonly ? 'main/vote_down_must_confirm' : 'main/vote_must_confirm'), $topage);
			break;

		case 'limit':
			return as_lang_html('main/vote_limit');
			break;

		default:
			return as_lang_html('members/no_permission');
			break;
	}
}


/**
 * Actually set (application level) the $vote (-1/0/1) by $memberid (with $handle and $cookieid) on $postid.
 * Handles member points, recounting and event reports as appropriate.
 * @param $post
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $vote
 * @return void
 */
function as_vote_set($post, $memberid, $handle, $cookieid, $vote)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'db/points.php';
	require_once AS_INCLUDE_DIR . 'db/hotness.php';
	require_once AS_INCLUDE_DIR . 'db/votes.php';
	require_once AS_INCLUDE_DIR . 'db/post-create.php';
	require_once AS_INCLUDE_DIR . 'app/limits.php';

	$vote = (int)min(1, max(-1, $vote));
	$oldvote = (int)as_db_membervote_get($post['postid'], $memberid);

	as_db_membervote_set($post['postid'], $memberid, $vote);
	as_db_post_recount_votes($post['postid']);

	if (!in_array($post['basetype'], array('Q', 'A', 'C'))) {
		return;
	}

	$prefix = strtolower($post['basetype']);

	if ($prefix === 'a') {
		as_db_post_acount_update($post['parentid']);
		as_db_unupaqcount_update();
	}

	$columns = array();

	if ($vote > 0 || $oldvote > 0) {
		$columns[] = $prefix . 'upvotes';
	}

	if ($vote < 0 || $oldvote < 0) {
		$columns[] = $prefix . 'downvotes';
	}

	as_db_points_update_ifmember($memberid, $columns);

	as_db_points_update_ifmember($post['memberid'], array($prefix . 'voteds', 'upvoteds', 'downvoteds'));

	if ($prefix === 'q') {
		as_db_hotness_update($post['postid']);
	}

	if ($vote < 0) {
		$event = $prefix . '_vote_down';
	} elseif ($vote > 0) {
		$event = $prefix . '_vote_up';
	} else {
		$event = $prefix . '_vote_nil';
	}

	as_report_event($event, $memberid, $handle, $cookieid, array(
		'postid' => $post['postid'],
		'memberid' => $post['memberid'],
		'vote' => $vote,
		'oldvote' => $oldvote,
	));
}


/**
 * Check if $memberid can flag $post, on the page $topage.
 * Return an HTML error to display if there was a problem, or false if it's OK.
 * @param $post
 * @param $memberid
 * @param $topage
 * @return bool|mixed|string
 */
function as_flag_error_html($post, $memberid, $topage)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	// The 'login', 'confirm', 'limit', 'memberblock' and 'ipblock' permission errors are reported to the member here.
	// Others ('approve', 'level') prevent the flag button being shown, in as_page_q_post_rules(...)

	require_once AS_INCLUDE_DIR . 'db/selects.php';
	require_once AS_INCLUDE_DIR . 'app/options.php';
	require_once AS_INCLUDE_DIR . 'app/members.php';
	require_once AS_INCLUDE_DIR . 'app/limits.php';

	if (is_array($post) && as_opt('flagging_of_posts') &&
		(!isset($post['memberid']) || !isset($memberid) || $post['memberid'] != $memberid)
	) {
		switch (as_member_post_permit_error('permit_flag', $post, AS_LIMIT_FLAGS)) {
			case 'login':
				return as_insert_login_links(as_lang_html('article/flag_must_login'), $topage);
				break;

			case 'confirm':
				return as_insert_login_links(as_lang_html('article/flag_must_confirm'), $topage);
				break;

			case 'limit':
				return as_lang_html('article/flag_limit');
				break;

			default:
				return as_lang_html('members/no_permission');
				break;

			case false:
				return false;
		}
	} else {
		return as_lang_html('article/flag_not_allowed'); // flagging option should not have been presented
	}
}


/**
 * Set (application level) a flag by $memberid (with $handle and $cookieid) on $oldpost which belongs to $article.
 * Handles recounting, admin notifications and event reports as appropriate.
 * Returns true if the post should now be hidden because it has accumulated enough flags.
 * @param $oldpost
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $article
 * @return bool
 */
function as_flag_set_tohide($oldpost, $memberid, $handle, $cookieid, $article)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'db/votes.php';
	require_once AS_INCLUDE_DIR . 'app/limits.php';
	require_once AS_INCLUDE_DIR . 'db/post-update.php';

	as_db_memberflag_set($oldpost['postid'], $memberid, true);
	as_db_post_recount_flags($oldpost['postid']);
	as_db_flaggedcount_update();

	switch ($oldpost['basetype']) {
		case 'Q':
			$event = 'q_flag';
			break;

		case 'A':
			$event = 'a_flag';
			break;

		case 'C':
			$event = 'c_flag';
			break;
	}

	$post = as_db_select_with_pending(as_db_full_post_selectspec(null, $oldpost['postid']));

	as_report_event($event, $memberid, $handle, $cookieid, array(
		'postid' => $oldpost['postid'],
		'oldpost' => $oldpost,
		'flagcount' => $post['flagcount'],
		'articleid' => $article['postid'],
		'article' => $article,
	));

	return $post['flagcount'] >= as_opt('flagging_hide_after') && !$post['hidden'];
}


/**
 * Clear (application level) a flag on $oldpost by $memberid (with $handle and $cookieid).
 * Handles recounting and event reports as appropriate.
 * @param $oldpost
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @return mixed
 */
function as_flag_clear($oldpost, $memberid, $handle, $cookieid)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'db/votes.php';
	require_once AS_INCLUDE_DIR . 'app/limits.php';
	require_once AS_INCLUDE_DIR . 'db/post-update.php';

	as_db_memberflag_set($oldpost['postid'], $memberid, false);
	as_db_post_recount_flags($oldpost['postid']);
	as_db_flaggedcount_update();

	switch ($oldpost['basetype']) {
		case 'Q':
			$event = 'q_unflag';
			break;

		case 'A':
			$event = 'a_unflag';
			break;

		case 'C':
			$event = 'c_unflag';
			break;
	}

	as_report_event($event, $memberid, $handle, $cookieid, array(
		'postid' => $oldpost['postid'],
		'oldpost' => $oldpost,
	));
}


/**
 * Clear (application level) all flags on $oldpost by $memberid (with $handle and $cookieid).
 * Handles recounting and event reports as appropriate.
 * @param $oldpost
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @return mixed
 */
function as_flags_clear_all($oldpost, $memberid, $handle, $cookieid)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'db/votes.php';
	require_once AS_INCLUDE_DIR . 'app/limits.php';
	require_once AS_INCLUDE_DIR . 'db/post-update.php';

	as_db_memberflags_clear_all($oldpost['postid']);
	as_db_post_recount_flags($oldpost['postid']);
	as_db_flaggedcount_update();

	switch ($oldpost['basetype']) {
		case 'Q':
			$event = 'q_clearflags';
			break;

		case 'A':
			$event = 'a_clearflags';
			break;

		case 'C':
			$event = 'c_clearflags';
			break;
	}

	as_report_event($event, $memberid, $handle, $cookieid, array(
		'postid' => $oldpost['postid'],
		'oldpost' => $oldpost,
	));
}
