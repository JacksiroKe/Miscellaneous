<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Server-side response to Ajax request to view table information


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

$headers = array();
$tablecontent = array();

$slots = as_array_filter( explode(',', as_post_text('txtslots')) );
$teachers = as_array_filter( explode(',', as_post_text('txteacher')) );
$groups = as_array_filter( explode(',', as_post_text('txtgroup')) );
$units = as_array_filter( explode(',', as_post_text('txtunit')) );
$count = as_array_filter( explode(',', as_post_text('txtcount')) );

function as_set_break($day, $id, $break, $grp_count, $data)
{
	$id = $day.'-'.$id;
	if (strpos($break, '#')) {
		
	} else return $id.'|';
}

function as_break_slots($slots, $day, $group, $groups, $grp_count, $data = '', $breaks = '')
{
	$items = count($slots) - 1;
	for ($i = 0; $i <= ($items - 1); $i++)
	{
		$breaks .= as_set_break( $day, $group.'-'.($i + 1), $slots[$i], $grp_count, $data);
	}
	$breaks .= as_set_break( $day, $group.'-'.($items + 1), $slots[$items], $grp_count, $data);
	return $breaks;
}

function as_lesson_slots($slots, $day, $group, $data = '', $lessons = '')
{
	$items = count($slots) - 1;
	for ($i = 0; $i <= ($items - 1); $i++)
	{
		$lessons .= (!strpos($slots[$i], '#')) ? $day.'-'.$group.'-'.($i + 1).'|' : '';
	}
	$lessons .= (!strpos($slots[$items], '#')) ? $day.'-'.$group.'-'.($items + 1).'|' : '';
	return $lessons;
}

function as_daily_slots($day, $slots, $groups, $teachers, $units, $periods = '')
{	
	$grp_count = count($groups);
	$timeslots = as_lesson_slots( $slots, $day, $grp_count );
	for ($g = 0; $g < $grp_count; $g++) {
		$grouparr = as_array_filter( explode('-', $groups[$g]) );
		if ($g == 0) {
			$periods .= as_break_slots($slots, $day, $grouparr[0], $groups, $grp_count);
		} else {
			$periods .= as_lesson_slots($slots, $day, $grouparr[0]);
		}
		$periods .= '|';
	}	
	return $periods;
}

$slot_count = count($slots) - 1;
if (!$groups) $groups = array('DC');

$tablecontent[] = as_daily_slots(1, $slots, $groups, $teachers, $units);
$tablecontent[] = as_daily_slots(2, $slots, $groups, $teachers, $units);
$tablecontent[] = as_daily_slots(3, $slots, $groups, $teachers, $units);
$tablecontent[] = as_daily_slots(4, $slots, $groups, $teachers, $units);
$tablecontent[] = as_daily_slots(5, $slots, $groups, $teachers, $units);

echo "AS_AJAX_RESPONSE\n1\n";
echo implode('', $tablecontent);
