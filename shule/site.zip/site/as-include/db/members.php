<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Database-level access to member management tables (if not using single sign-on)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


/**
 * Return the expected value for the passcheck column given the $password and password $salt
 * @param $password
 * @param $salt
 * @return mixed|string
 */
function as_db_calc_passcheck($password, $salt)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	return sha1(substr($salt, 0, 8) . $password . substr($salt, 8));
}


/**
 * Create a new member in the database with $email, $password, $handle, privilege $level, and $ip address
 * @param $email
 * @param $password
 * @param $handle
 * @param $level
 * @param $ip
 * @return mixed
 */
function as_db_member_create($grouped, $code, $firstname, $lastname, $sex, $country, $mobile, $email, $password, $handle, $level, $ip)
{
	require_once AS_INCLUDE_DIR . 'util/string.php';

	$ipHex = bin2hex(@inet_pton($ip));

	if (AS_PASSWORD_HASH) {
		as_db_query_sub(
			'INSERT INTO ^members (created, createip, grouped, code, firstname, lastname, sex, country, mobile, email, passhash, level, handle, loggedin, loginip) ' .
			'VALUES (NOW(), UNHEX($), $, $, $, $, $, $, $, $, $, #, $, NOW(), UNHEX($))',
			$ipHex, $grouped, $code, $firstname, $lastname, $sex, $country, $mobile, $email, isset($password) ? password_hash($password, PASSWORD_BCRYPT) : null, (int)$level, $handle, $ipHex
		);
	} else {
		$salt = isset($password) ? as_random_alphanum(16) : null;

		as_db_query_sub(
			'INSERT INTO ^members (created, createip, grouped, code, firstname, lastname, sex, country, mobile, email, passsalt, passcheck, level, handle, loggedin, loginip) ' .
			'VALUES (NOW(), UNHEX($), $, $, $, $, $, $, $, $, $, UNHEX($), #, $, NOW(), UNHEX($))',
			$ipHex, $grouped, $code, $firstname, $lastname, $sex, $country, $mobile, $email, $salt, isset($password) ? as_db_calc_passcheck($password, $salt) : null, (int)$level, $handle, $ipHex
		);
	}

	return as_db_last_insert_id();
}


/**
 * Delete member $memberid from the database, along with everything they have ever done (to the extent that it's possible)
 * @param $memberid
 */
function as_db_member_delete($memberid)
{
	as_db_query_sub('UPDATE ^posts SET lastmemberid=NULL WHERE lastmemberid=$', $memberid);
	as_db_query_sub('DELETE FROM ^memberpoints WHERE memberid=$', $memberid);
	as_db_query_sub('DELETE FROM ^blobs WHERE blobid=(SELECT avatarblobid FROM ^members WHERE memberid=$)', $memberid);
	as_db_query_sub('DELETE FROM ^members WHERE memberid=$', $memberid);

	// All the queries below should be superfluous due to foreign key constraints, but just in case the member switched to MyISAM.
	// Note also that private messages to/from that member are kept since we don't have all the keys we need to delete efficiently.

	as_db_query_sub('UPDATE ^posts SET memberid=NULL WHERE memberid=$', $memberid);
	as_db_query_sub('DELETE FROM ^memberlogins WHERE memberid=$', $memberid);
	as_db_query_sub('DELETE FROM ^memberprofile WHERE memberid=$', $memberid);
	as_db_query_sub('DELETE FROM ^memberfavorites WHERE memberid=$', $memberid);
	as_db_query_sub('DELETE FROM ^memberevents WHERE memberid=$', $memberid);
	as_db_query_sub('DELETE FROM ^membervotes WHERE memberid=$', $memberid);
	as_db_query_sub('DELETE FROM ^memberlimits WHERE memberid=$', $memberid);
}


/**
 * Return the ids of all members in the database which match $email (should be one or none)
 * @param $email
 * @return array
 */
function as_db_member_find_by_email($email)
{
	return as_db_read_all_values(as_db_query_sub(
		'SELECT memberid FROM ^members WHERE email=$',
		$email
	));
}


/**
 * Return the ids of all members in the database which match $handle (=username), should be one or none
 * @param $handle
 * @return array
 */
function as_db_member_find_by_handle($handle)
{
	return as_db_read_all_values(as_db_query_sub(
		'SELECT memberid FROM ^members WHERE handle=$',
		$handle
	));
}


/**
 * Return an array mapping each memberid in $memberids that can be found to that member's handle
 * @param $memberids
 * @return array
 */
function as_db_member_get_memberid_handles($memberids)
{
	if (count($memberids)) {
		return as_db_read_all_assoc(as_db_query_sub(
			'SELECT memberid, handle FROM ^members WHERE memberid IN (#)',
			$memberids
		), 'memberid', 'handle');
	}

	return array();
}


/**
 * Return an array mapping mapping each handle in $handle that can be found to that member's memberid
 * @param $handles
 * @return array
 */
function as_db_member_get_handle_memberids($handles)
{
	if (count($handles)) {
		return as_db_read_all_assoc(as_db_query_sub(
			'SELECT handle, memberid FROM ^members WHERE handle IN ($)',
			$handles
		), 'handle', 'memberid');
	}

	return array();
}


/**
 * Set $field of $memberid to $value in the database members table
 * @param $memberid
 * @param $field
 * @param $value
 */
function as_db_member_set($memberid, $field, $value)
{
	as_db_query_sub(
		'UPDATE ^members SET ' . as_db_escape_string($field) . '=$ WHERE memberid=$',
		$value, $memberid
	);
}


/**
 * Set the password of $memberid to $password, and reset their salt at the same time
 * @param $memberid
 * @param $password
 * @return mixed
 */
function as_db_member_set_password($memberid, $password)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'util/string.php';

	if (AS_PASSWORD_HASH) {
		as_db_query_sub(
			'UPDATE ^members SET passhash=$, passsalt=NULL, passcheck=NULL WHERE memberid=$',
			password_hash($password, PASSWORD_BCRYPT), $memberid
		);
	} else {
		$salt = as_random_alphanum(16);

		as_db_query_sub(
			'UPDATE ^members SET passsalt=$, passcheck=UNHEX($) WHERE memberid=$',
			$salt, as_db_calc_passcheck($password, $salt), $memberid
		);
	}
}


/**
 * Switch on the $flag bit of the flags column for $memberid if $set is true, or switch off otherwise
 * @param $memberid
 * @param $flag
 * @param $set
 */
function as_db_member_set_flag($memberid, $flag, $set)
{
	as_db_query_sub(
		'UPDATE ^members SET flags=flags' . ($set ? '|' : '&~') . '# WHERE memberid=$',
		$flag, $memberid
	);
}


/**
 * Return a random string to be used for a member's emailcode column
 */
function as_db_member_rand_emailcode()
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'util/string.php';

	return as_random_alphanum(8);
}


/**
 * Return a random string to be used for a member's sessioncode column (for browser session cookies)
 */
function as_db_member_rand_sessioncode()
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'util/string.php';

	return as_random_alphanum(8);
}


/**
 * Set a row in the database member profile table to store $value for $field for $memberid
 * @param $memberid
 * @param $field
 * @param $value
 */
function as_db_member_profile_set($memberid, $field, $value)
{
	as_db_query_sub(
		'INSERT INTO ^memberprofile (memberid, title, content) VALUES ($, $, $) ' .
		'ON DUPLICATE KEY UPDATE content = VALUES(content)',
		$memberid, $field, $value
	);
}


/**
 * Note in the database that $memberid just logged in from $ip address
 * @param $memberid
 * @param $ip
 */
function as_db_member_logged_in($memberid, $ip)
{
	as_db_query_sub(
		'UPDATE ^members SET loggedin=NOW(), loginip=UNHEX($) WHERE memberid=$',
		bin2hex(@inet_pton($ip)), $memberid
	);
}


/**
 * Note in the database that $memberid just performed a write operation from $ip address
 * @param $memberid
 * @param $ip
 */
function as_db_member_written($memberid, $ip)
{
	as_db_query_sub(
		'UPDATE ^members SET written=NOW(), writeip=UNHEX($) WHERE memberid=$',
		bin2hex(@inet_pton($ip)), $memberid
	);
}


/**
 * Add an external login in the database for $source and $identifier for member $memberid
 * @param $memberid
 * @param $source
 * @param $identifier
 */
function as_db_member_login_add($memberid, $source, $identifier)
{
	as_db_query_sub(
		'INSERT INTO ^memberlogins (memberid, source, identifier, identifiermd5) ' .
		'VALUES ($, $, $, UNHEX($))',
		$memberid, $source, $identifier, md5($identifier)
	);
}


/**
 * Return some information about the member with external login $source and $identifier in the database, if a match is found
 * @param $source
 * @param $identifier
 * @return array
 */
function as_db_member_login_find($source, $identifier)
{
	return as_db_read_all_assoc(as_db_query_sub(
		'SELECT ^memberlogins.memberid, handle, email FROM ^memberlogins LEFT JOIN ^members ON ^memberlogins.memberid=^members.memberid ' .
		'WHERE source=$ AND identifiermd5=UNHEX($) AND identifier=$',
		$source, md5($identifier), $identifier
	));
}


/**
 * Lock all tables if $sync is true, otherwise unlock them. Used to synchronize creation of external login mappings.
 * @param $sync
 */
function as_db_member_login_sync($sync)
{
	if ($sync) { // need to lock all tables since any could be used by a plugin's event module
		$tables = as_db_list_tables();

		$locks = array();
		foreach ($tables as $table)
			$locks[] = $table . ' WRITE';

		as_db_query_sub('LOCK TABLES ' . implode(', ', $locks));

	} else {
		as_db_query_sub('UNLOCK TABLES');
	}
}


/**
 * Reset the full set of context-specific (currently, per department) member levels for member $memberid to $memberlevels, where
 * $memberlevels is an array of arrays, the inner arrays containing items 'entitytype', 'entityid' and 'level'.
 * @param $memberid
 * @param $memberlevels
 */
function as_db_member_levels_set($memberid, $memberlevels)
{
	as_db_query_sub(
		'DELETE FROM ^memberlevels WHERE memberid=$',
		$memberid
	);

	foreach ($memberlevels as $memberlevel) {
		as_db_query_sub(
			'INSERT INTO ^memberlevels (memberid, entitytype, entityid, level) VALUES ($, $, #, #) ' .
			'ON DUPLICATE KEY UPDATE level = VALUES(level)',
			$memberid, $memberlevel['entitytype'], $memberlevel['entityid'], $memberlevel['level']
		);
	}
}


/**
 * Get the information required for sending a mailing to the next $count members with memberids greater than $lastmemberid
 * @param $lastmemberid
 * @param $count
 * @return array
 */
function as_db_members_get_mailing_next($lastmemberid, $count)
{
	return as_db_read_all_assoc(as_db_query_sub(
		'SELECT memberid, email, handle, emailcode, flags FROM ^members WHERE memberid># ORDER BY memberid LIMIT #',
		$lastmemberid, $count
	));
}


/**
 * Update the cached count of the number of members who are awaiting approval after registration
 */
function as_db_uapprovecount_update()
{
	if (as_should_update_counts() && !AS_FINAL_EXTERNAL_MEMBERS) {
		as_db_query_sub(
			"INSERT INTO ^options (title, content) " .
			"SELECT 'cache_uapprovecount', COUNT(*) FROM ^members " .
			"WHERE level < # AND NOT (flags & #) " .
			"ON DUPLICATE KEY UPDATE content = VALUES(content)",
			AS_MEMBER_LEVEL_APPROVED, AS_MEMBER_FLAGS_MEMBER_BLOCKED
		);
	}
}
