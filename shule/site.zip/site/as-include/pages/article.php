<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for article page (only viewing functionality here)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'app/cookies.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'util/sort.php';
require_once AS_INCLUDE_DIR . 'util/string.php';
require_once AS_INCLUDE_DIR . 'app/captcha.php';
require_once AS_INCLUDE_DIR . 'pages/article-view.php';
require_once AS_INCLUDE_DIR . 'app/updates.php';

$articleid = as_request_part(0);
$memberid = as_get_logged_in_memberid();
$cookieid = as_cookie_get();
$pagestate = as_get_state();


// Get information about this article

$cacheDriver = APS_Storage_CacheFactory::getCacheDriver();
$cacheKey = "article:$articleid";
$useCache = $memberid === null && $cacheDriver->isEnabled() && !as_is_http_post() && empty($pagestate);
$saveCache = false;

if ($useCache) {
	$articleData = $cacheDriver->get($cacheKey);
}

if (!isset($articleData)) {
	$articleData = as_db_select_with_pending(
		as_db_full_post_selectspec($memberid, $articleid),
		as_db_full_child_posts_selectspec($memberid, $articleid),
		as_db_full_a_child_posts_selectspec($memberid, $articleid),
		as_db_post_parent_q_selectspec($articleid),
		as_db_post_close_post_selectspec($articleid),
		as_db_post_duplicates_selectspec($articleid),
		as_db_post_meta_selectspec($articleid, 'as_q_extra'),
		as_db_department_nav_selectspec($articleid, true, true, true),
		isset($memberid) ? as_db_is_favorite_selectspec($memberid, AS_ENTITY_ARTICLE, $articleid) : null
	);

	// whether to save the cache (actioned below, after basic checks)
	$saveCache = $useCache;
}

list($article, $childposts, $achildposts, $parentarticle, $closepost, $duplicateposts, $extravalue, $departments, $favorite) = $articleData;


if ($article['basetype'] != 'Q') // don't allow direct viewing of other types of post
	$article = null;

if (isset($article)) {
	$q_request = as_q_request($articleid, $article['title']);

	if (trim($q_request, '/') !== trim(as_request(), '/')) {
		// redirect if the current URL is incorrect
		as_redirect($q_request);
	}

	$article['extra'] = $extravalue;

	$answers = as_page_q_load_as($article, $childposts);
	$commentsfollows = as_page_q_load_c_follows($article, $childposts, $achildposts, $duplicateposts);

	$article = $article + as_page_q_post_rules($article, null, null, $childposts + $duplicateposts); // array union

	if ($article['selchildid'] && (@$answers[$article['selchildid']]['type'] != 'A'))
		$article['selchildid'] = null; // if selected answer is hidden or somehow not there, consider it not selected

	foreach ($answers as $key => $answer) {
		$answers[$key] = $answer + as_page_q_post_rules($answer, $article, $answers, $achildposts);
		$answers[$key]['isselected'] = ($answer['postid'] == $article['selchildid']);
	}

	foreach ($commentsfollows as $key => $commentfollow) {
		$parent = ($commentfollow['parentid'] == $articleid) ? $article : @$answers[$commentfollow['parentid']];
		$commentsfollows[$key] = $commentfollow + as_page_q_post_rules($commentfollow, $parent, $commentsfollows, null);
	}
}

// Deal with article not found or not viewable, otherwise report the view event

if (!isset($article))
	return include AS_INCLUDE_DIR . 'as-page-not-found.php';

if (!$article['viewable']) {
	$as_content = as_content_prepare();

	if ($article['queued'])
		$as_content['error'] = as_lang_html('article/q_waiting_approval');
	elseif ($article['flagcount'] && !isset($article['lastmemberid']))
		$as_content['error'] = as_lang_html('article/q_hidden_flagged');
	elseif ($article['authorlast'])
		$as_content['error'] = as_lang_html('article/q_hidden_author');
	else
		$as_content['error'] = as_lang_html('article/q_hidden_other');

	$as_content['suggest_next'] = as_html_suggest_qs_tags(as_using_tags());

	return $as_content;
}

$permiterror = as_member_post_permit_error('permit_view_q_page', $article, null, false);

if ($permiterror && (as_is_human_probably() || !as_opt('allow_view_q_bots'))) {
	$as_content = as_content_prepare();
	$topage = as_q_request($articleid, $article['title']);

	switch ($permiterror) {
		case 'login':
			$as_content['error'] = as_insert_login_links(as_lang_html('main/view_q_must_login'), $topage);
			break;

		case 'confirm':
			$as_content['error'] = as_insert_login_links(as_lang_html('main/view_q_must_confirm'), $topage);
			break;

		case 'approve':
			$as_content['error'] = strtr(as_lang_html('main/view_q_must_be_approved'), array(
				'^1' => '<a href="' . as_path_html('account') . '">',
				'^2' => '</a>',
			));
			break;

		default:
			$as_content['error'] = as_lang_html('members/no_permission');
			break;
	}

	return $as_content;
}


// Save article data to cache (if older than configured limit)

if ($saveCache) {
	$articleAge = as_opt('db_time') - $article['created'];
	if ($articleAge > 86400 * as_opt('caching_q_start')) {
		$cacheDriver->set($cacheKey, $articleData, as_opt('caching_q_time'));
	}
}


// Determine if captchas will be required

$captchareason = as_member_captcha_reason(as_member_level_for_post($article));
$usecaptcha = ($captchareason != false);


// If we're responding to an HTTP POST, include file that handles all posting/editing/etc... logic
// This is in a separate file because it's a *lot* of logic, and will slow down ordinary page views

$pagestart = as_get_start();
$showid = as_get('show');
$pageerror = null;
$formtype = null;
$formpostid = null;
$jumptoanchor = null;
$commentsall = null;

if (substr($pagestate, 0, 13) == 'showcomments-') {
	$commentsall = substr($pagestate, 13);
	$pagestate = null;

} elseif (isset($showid)) {
	foreach ($commentsfollows as $comment) {
		if ($comment['postid'] == $showid) {
			$commentsall = $comment['parentid'];
			break;
		}
	}
}

if (as_is_http_post() || strlen($pagestate))
	require AS_INCLUDE_DIR . 'pages/article-post.php';

$formrequested = isset($formtype);

if (!$formrequested && $article['answerbutton']) {
	$immedoption = as_opt('show_a_form_immediate');

	if ($immedoption == 'always' || ($immedoption == 'if_no_as' && !$article['isbymember'] && !$article['acount']))
		$formtype = 'a_add'; // show answer form by default
}


// Get information on the members referenced

$membershtml = as_memberids_handles_html(array_merge(array($article), $answers, $commentsfollows), true);


// Prepare content for theme

$as_content = as_content_prepare(true, array_keys(as_department_path($departments, $article['departmentid'])));

if (isset($memberid) && !$formrequested)
	$as_content['favorite'] = as_favorite_form(AS_ENTITY_ARTICLE, $articleid, $favorite,
		as_lang($favorite ? 'article/remove_q_favorites' : 'article/add_q_favorites'));

if (isset($pageerror))
	$as_content['error'] = $pageerror; // might also show voting error set in as-index.php

elseif ($article['queued'])
	$as_content['error'] = $article['isbymember'] ? as_lang_html('article/q_your_waiting_approval') : as_lang_html('article/q_waiting_your_approval');

if ($article['hidden'])
	$as_content['hidden'] = true;

as_sort_by($commentsfollows, 'created');


// Prepare content for the article...

if ($formtype == 'q_edit') { // ...in edit mode
	$as_content['title'] = as_lang_html($article['editable'] ? 'article/edit_q_title' :
		(as_using_departments() ? 'article/recat_q_title' : 'article/retag_q_title'));
	$as_content['form_q_edit'] = as_page_q_edit_q_form($as_content, $article, @$qin, @$qerrors, $completetags, $departments);
	$as_content['q_view']['raw'] = $article;

} else { // ...in view mode
	$as_content['q_view'] = as_page_q_article_view($article, $parentarticle, $closepost, $membershtml, $formrequested);

	$as_content['title'] = $as_content['q_view']['title'];

	$as_content['description'] = as_html(as_shorten_string_line(as_viewer_text($article['content'], $article['format']), 150));

	$departmentkeyword = @$departments[$article['departmentid']]['title'];

	$as_content['keywords'] = as_html(implode(',', array_merge(
		(as_using_departments() && strlen($departmentkeyword)) ? array($departmentkeyword) : array(),
		as_tagstring_to_tags($article['tags'])
	))); // as far as I know, META keywords have zero effect on search rankings or listings, but many people have published for this
}

$microdata = as_opt('use_microdata');
if ($microdata) {
	$as_content['head_lines'][] = '<meta itemprop="name" content="' . as_html($as_content['q_view']['raw']['title']) . '">';
	$as_content['html_tags'] .= ' itemscope itemtype="http://schema.org/QAPage"';
	$as_content['main_tags'] = ' itemscope itemtype="http://schema.org/Article"';
}


// Prepare content for an answer being edited (if any) or to be added

if ($formtype == 'a_edit') {
	$as_content['a_form'] = as_page_q_edit_a_form($as_content, 'a' . $formpostid, $answers[$formpostid],
		$article, $answers, $commentsfollows, @$aeditin[$formpostid], @$aediterrors[$formpostid]);

	$as_content['a_form']['c_list'] = as_page_q_comment_follow_list($article, $answers[$formpostid],
		$commentsfollows, true, $membershtml, $formrequested, $formpostid);

	$jumptoanchor = 'a' . $formpostid;

} elseif ($formtype == 'a_add' || ($article['answerbutton'] && !$formrequested)) {
	$as_content['a_form'] = as_page_q_add_a_form($as_content, 'anew', $captchareason, $article, @$anewin, @$anewerrors, $formtype == 'a_add', $formrequested);

	if ($formrequested) {
		$jumptoanchor = 'anew';
	} elseif ($formtype == 'a_add') {
		$as_content['script_onloads'][] = array(
			"as_element_revealed=document.getElementById('anew');"
		);
	}
}


// Prepare content for comments on the article, plus add or edit comment forms

if ($formtype == 'q_close') {
	$as_content['q_view']['c_form'] = as_page_q_close_q_form($as_content, $article, 'close', @$closein, @$closeerrors);
	$jumptoanchor = 'close';

} elseif (($formtype == 'c_add' && $formpostid == $articleid) || ($article['commentbutton'] && !$formrequested)) { // ...to be added
	$as_content['q_view']['c_form'] = as_page_q_add_c_form($as_content, $article, $article, 'c' . $articleid,
		$captchareason, @$cnewin[$articleid], @$cnewerrors[$articleid], $formtype == 'c_add');

	if ($formtype == 'c_add' && $formpostid == $articleid) {
		$jumptoanchor = 'c' . $articleid;
		$commentsall = $articleid;
	}

} elseif ($formtype == 'c_edit' && @$commentsfollows[$formpostid]['parentid'] == $articleid) { // ...being edited
	$as_content['q_view']['c_form'] = as_page_q_edit_c_form($as_content, 'c' . $formpostid, $commentsfollows[$formpostid],
		@$ceditin[$formpostid], @$cediterrors[$formpostid]);

	$jumptoanchor = 'c' . $formpostid;
	$commentsall = $articleid;
}

$as_content['q_view']['c_list'] = as_page_q_comment_follow_list($article, $article, $commentsfollows,
	$commentsall == $articleid, $membershtml, $formrequested, $formpostid); // ...for viewing


// Prepare content for existing answers (could be added to by Ajax)

$as_content['a_list'] = array(
	'tags' => 'id="a_list"',
	'as' => array(),
);

// sort according to the site preferences

if (as_opt('sort_answers_by') == 'votes') {
	foreach ($answers as $answerid => $answer)
		$answers[$answerid]['sortvotes'] = $answer['downvotes'] - $answer['upvotes'];

	as_sort_by($answers, 'sortvotes', 'created');

} else {
	as_sort_by($answers, 'created');
}

// further changes to ordering to deal with queued, hidden and selected answers

$countfortitle = $article['acount'];
$nextposition = 10000;
$answerposition = array();

foreach ($answers as $answerid => $answer) {
	if ($answer['viewable']) {
		$position = $nextposition++;

		if ($answer['hidden'])
			$position += 10000;

		elseif ($answer['queued']) {
			$position -= 10000;
			$countfortitle++; // include these in displayed count

		} elseif ($answer['isselected'] && as_opt('show_selected_first'))
			$position -= 5000;

		$answerposition[$answerid] = $position;
	}
}

asort($answerposition, SORT_NUMERIC);

// extract IDs and prepare for pagination

$answerids = array_keys($answerposition);
$countforpages = count($answerids);
$pagesize = as_opt('page_size_q_as');

// see if we need to display a particular answer

if (isset($showid)) {
	if (isset($commentsfollows[$showid]))
		$showid = $commentsfollows[$showid]['parentid'];

	$position = array_search($showid, $answerids);

	if (is_numeric($position))
		$pagestart = floor($position / $pagesize) * $pagesize;
}

// set the canonical url based on possible pagination

$as_content['canonical'] = as_path_html(as_q_request($article['postid'], $article['title']),
	($pagestart > 0) ? array('start' => $pagestart) : null, as_opt('site_url'));

// build the actual answer list

$answerids = array_slice($answerids, $pagestart, $pagesize);

foreach ($answerids as $answerid) {
	$answer = $answers[$answerid];

	if (!($formtype == 'a_edit' && $formpostid == $answerid)) {
		$a_view = as_page_q_answer_view($article, $answer, $answer['isselected'], $membershtml, $formrequested);

		// Prepare content for comments on this answer, plus add or edit comment forms

		if (($formtype == 'c_add' && $formpostid == $answerid) || ($answer['commentbutton'] && !$formrequested)) { // ...to be added
			$a_view['c_form'] = as_page_q_add_c_form($as_content, $article, $answer, 'c' . $answerid,
				$captchareason, @$cnewin[$answerid], @$cnewerrors[$answerid], $formtype == 'c_add');

			if ($formtype == 'c_add' && $formpostid == $answerid) {
				$jumptoanchor = 'c' . $answerid;
				$commentsall = $answerid;
			}

		} elseif ($formtype == 'c_edit' && @$commentsfollows[$formpostid]['parentid'] == $answerid) { // ...being edited
			$a_view['c_form'] = as_page_q_edit_c_form($as_content, 'c' . $formpostid, $commentsfollows[$formpostid],
				@$ceditin[$formpostid], @$cediterrors[$formpostid]);

			$jumptoanchor = 'c' . $formpostid;
			$commentsall = $answerid;
		}

		$a_view['c_list'] = as_page_q_comment_follow_list($article, $answer, $commentsfollows,
			$commentsall == $answerid, $membershtml, $formrequested, $formpostid); // ...for viewing

		// Add the answer to the list

		$as_content['a_list']['as'][] = $a_view;
	}
}

if ($article['basetype'] == 'Q') {
	$as_content['a_list']['title_tags'] = 'id="a_list_title"';

	if ($countfortitle > 0) {
		$split = $countfortitle == 1
			? as_lang_html_sub_split('article/1_answer_title', '1', '1')
			: as_lang_html_sub_split('article/x_answers_title', $countfortitle);

		if ($microdata) {
			$split['data'] = '<span itemprop="answerCount">' . $split['data'] . '</span>';
		}
		$as_content['a_list']['title'] = $split['prefix'] . $split['data'] . $split['suffix'];
	} else
		$as_content['a_list']['title_tags'] .= ' style="display:none;" ';
}

if (!$formrequested) {
	$as_content['page_links'] = as_html_page_links(as_request(), $pagestart, $pagesize, $countforpages, as_opt('pages_prev_next'), array(), false, 'a_list_title');
}


// Some generally useful stuff

if (as_using_departments() && count($departments)) {
	$as_content['navigation']['cat'] = as_department_navigation($departments, $article['departmentid']);
}

if (isset($jumptoanchor)) {
	$as_content['script_onloads'][] = array(
		'as_scroll_page_to($("#"+' . as_js($jumptoanchor) . ').offset().top);'
	);
}

// Determine whether this request should be counted for page view statistics.
// The lastviewip check is now part of the hotness query in order to bypass caching.

if (as_opt('do_count_q_views') && !$formrequested && !as_is_http_post() && as_is_human_probably() &&
	(!$article['views'] || (
		// if it has more than zero views, then it must be different IP & member & cookieid from the creator
		(@inet_ntop($article['createip']) != as_remote_ip_address() || !isset($article['createip'])) &&
		($article['memberid'] != $memberid || !isset($article['memberid'])) &&
		($article['cookieid'] != $cookieid || !isset($article['cookieid']))
	))
) {
	$as_content['inc_views_postid'] = $articleid;
}


return $as_content;
