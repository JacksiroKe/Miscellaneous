<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for email confirmation page (can also request a new code)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

// Check we're not using single-sign on integration, that we're not already confirmed, and that we're not blocked

if (AS_FINAL_EXTERNAL_MEMBERS) {
	as_fatal_error('Member login is handled by external code');
}

// Check if we've been published to send a new link or have a successful email confirmation

// Fetch the handle from POST or GET
$handle = as_post_text('username');
if (!isset($handle)) {
	$handle = as_get('u');
}
$handle = trim($handle); // if $handle is null, trim returns an empty string

// Fetch the code from POST or GET
$code = as_post_text('code');
if (!isset($code)) {
	$code = as_get('c');
}
$code = trim($code); // if $code is null, trim returns an empty string

$loggedInMemberId = as_get_logged_in_memberid();
$emailConfirmationSent = false;
$memberConfirmed = false;

$pageError = null;

if (isset($loggedInMemberId) && as_clicked('dosendconfirm')) { // A logged in member requested to be sent a confirmation link
	if (!as_check_form_security_code('confirm', as_post_text('formcode'))) {
		$pageError = as_lang_html('misc/form_security_again');
	} else {
		// For as_send_new_confirm
		require_once AS_INCLUDE_DIR . 'app/members-edit.php';

		as_send_new_confirm($loggedInMemberId);
		$emailConfirmationSent = true;
	}
} elseif (strlen($code) > 0) { // If there is a code present in the URL
	// For as_db_select_with_pending, as_db_member_account_selectspec
	require_once AS_INCLUDE_DIR . 'db/selects.php';

	// For as_complete_confirm
	require_once AS_INCLUDE_DIR . 'app/members-edit.php';

	if (strlen($handle) > 0) { // If there is a handle present in the URL
		$memberInfo = as_db_select_with_pending(as_db_member_account_selectspec($handle, false));

		if (strtolower(trim($memberInfo['emailcode'])) == strtolower($code)) {
			as_complete_confirm($memberInfo['memberid'], $memberInfo['email'], $memberInfo['handle']);
			$memberConfirmed = true;
		}
	}

	if (!$memberConfirmed && isset($loggedInMemberId)) { // As a backup, also match code on URL against logged in member
		$memberInfo = as_db_select_with_pending(as_db_member_account_selectspec($loggedInMemberId, true));
		$flags = $memberInfo['flags'];

		if (($flags & AS_MEMBER_FLAGS_EMAIL_CONFIRMED) > 0 && ($flags & AS_MEMBER_FLAGS_MUST_CONFIRM) == 0) {
			$memberConfirmed = true; // if they confirmed before, just show message as if it happened now
		} elseif (strtolower(trim($memberInfo['emailcode'])) == strtolower($code)) {
			as_complete_confirm($memberInfo['memberid'], $memberInfo['email'], $memberInfo['handle']);
			$memberConfirmed = true;
		}
	}
}

// Prepare content for theme

$as_content = as_content_prepare();

$as_content['title'] = as_lang_html('members/confirm_title');
$as_content['error'] = $pageError;

if ($emailConfirmationSent) {
	$as_content['success'] = as_lang_html('members/confirm_emailed');

	$email = as_get_logged_in_email();
	$handle = as_get_logged_in_handle();

	$as_content['form'] = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',

		'style' => 'tall',

		'fields' => array(
			'email' => array(
				'label' => as_lang_html('members/email_label'),
				'value' => as_html($email) . strtr(as_lang_html('members/change_email_link'), array(
						'^1' => '<a href="' . as_path_html('account') . '">',
						'^2' => '</a>',
					)),
				'type' => 'static',
			),
			'code' => array(
				'label' => as_lang_html('members/email_code_label'),
				'tags' => 'name="code" id="code"',
				'value' => isset($code) ? as_html($code) : null,
				'note' => as_lang_html('members/email_code_emailed') . ' - ' .
					'<a href="' . as_path_html('confirm') . '">' . as_lang_html('members/email_code_another') . '</a>',
			),
		),

		'buttons' => array(
			'confirm' => array( // This button does not actually need a name attribute
				'label' => as_lang_html('members/confirm_button'),
			),
		),

		'hidden' => array(
			'formcode' => as_get_form_security_code('confirm'),
			'username' => as_html($handle),
		),
	);

	$as_content['focusid'] = 'code';
} elseif ($memberConfirmed) {
	$as_content['success'] = as_lang_html('members/confirm_complete');

	if (!isset($loggedInMemberId)) {
		$as_content['suggest_next'] = strtr(
			as_lang_html('members/log_in_to_access'),
			array(
				'^1' => '<a href="' . as_path_html('login', array('e' => $handle)) . '">',
				'^2' => '</a>',
			)
		);
	}
} elseif (isset($loggedInMemberId)) { // if logged in, allow sending a fresh link
	require_once AS_INCLUDE_DIR . 'util/string.php';

	if (strlen($code) > 0) {
		$as_content['error'] = as_lang_html('members/confirm_wrong_resend');
	}

	$email = as_get_logged_in_email();

	$as_content['form'] = array(
		'tags' => 'method="post" action="' . as_path_html('confirm') . '"',

		'style' => 'tall',

		'fields' => array(
			'email' => array(
				'label' => as_lang_html('members/email_label'),
				'value' => as_html($email) . strtr(as_lang_html('members/change_email_link'), array(
						'^1' => '<a href="' . as_path_html('account') . '">',
						'^2' => '</a>',
					)),
				'type' => 'static',
			),
		),

		'buttons' => array(
			'send' => array(
				'tags' => 'name="dosendconfirm"',
				'label' => as_lang_html('members/send_confirm_button'),
			),
		),

		'hidden' => array(
			'formcode' => as_get_form_security_code('confirm'),
		),
	);

	if (!as_email_validate($email)) {
		$as_content['error'] = as_lang_html('members/email_invalid');
		unset($as_content['form']['buttons']['send']);
	}
} else { // Member is not logged in
	$as_content['error'] = as_insert_login_links(as_lang_html('members/confirm_wrong_log_in'), 'confirm');
}

return $as_content;
