<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for member page showing all member's articles


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';


// $handle, $memberhtml are already set by /as-include/page/member.php - also $memberid if using external member integration

$start = as_get_start();

// Find the articles for this member
$loginmemberid = as_get_logged_in_memberid();
$identifier = AS_FINAL_EXTERNAL_MEMBERS ? $memberid : $handle;

list($memberaccount, $memberpoints, $articles) = as_db_select_with_pending(
	AS_FINAL_EXTERNAL_MEMBERS ? null : as_db_member_account_selectspec($handle, false),
	as_db_member_points_selectspec($identifier),
	as_db_member_recent_qs_selectspec($loginmemberid, $identifier, as_opt_if_loaded('page_size_qs'), $start)
);

if (!AS_FINAL_EXTERNAL_MEMBERS && !is_array($memberaccount)) // check the member exists
	return include AS_INCLUDE_DIR . 'as-page-not-found.php';


// Get information on member articles

$pagesize = as_opt('page_size_qs');
$count = (int)@$memberpoints['qposts'];
$articles = array_slice($articles, 0, $pagesize);
$membershtml = as_memberids_handles_html($articles, false);

$fullname = $memberaccount['firstname'] . ' '.$memberaccount['lastname'];

// Prepare content for theme

$as_content = as_content_prepare(true);

if (count($articles))
	$as_content['title'] = as_lang_html_sub('profile/articles_by_x', $fullname);
else
	$as_content['title'] = as_lang_html_sub('profile/no_articles_by_x', $fullname);


// Recent articles by this member

$as_content['q_list']['form'] = array(
	'tags' => 'method="post" action="' . as_self_html() . '"',

	'hidden' => array(
		'code' => as_get_form_security_code('vote'),
	),
);

$as_content['q_list']['qs'] = array();

$htmldefaults = as_post_html_defaults('Q');
$htmldefaults['whoview'] = false;
$htmldefaults['avatarsize'] = 0;

foreach ($articles as $article) {
	$as_content['q_list']['qs'][] = as_post_html_fields($article, $loginmemberid, as_cookie_get(),
		$membershtml, null, as_post_html_options($article, $htmldefaults));
}

$as_content['page_links'] = as_html_page_links(as_request(), $start, $pagesize, $count, as_opt('pages_prev_next'));


// Sub menu for navigation in member pages

$ismymember = isset($loginmemberid) && $loginmemberid == (AS_FINAL_EXTERNAL_MEMBERS ? $memberid : $memberaccount['memberid']);
$as_content['navigation']['sub'] = as_member_sub_navigation($handle, 'articles', $ismymember);


return $as_content;
