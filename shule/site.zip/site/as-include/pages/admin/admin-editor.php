<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	File: as-include/as-page-admin-editor.php
	Description: Added this file for loading html editor


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

	if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
		header('Location: ../');
		exit;
	}

	require_once AS_INCLUDE_DIR.'db/recalc.php';
	require_once AS_INCLUDE_DIR.'app/admin.php';
	require_once AS_INCLUDE_DIR.'db/admin.php';


//	Check admin privileges (do late to allow one DB query)

	if (!as_admin_check_privileges($as_content))
		return $as_content;
	$saved=false;		
	
	$errors = array();
	$securityexpired = false;

	$formokhtml = null;
	
	$item = as_get('item');
	$checkboxtodisplay = null;
	
	if (isset($item)) {
		$showoptions = array('show_' . $item, $item);	
		$checkboxtodisplay = array(
			'logo_url' => 'option_logo_show',
			'logo_width' => 'option_logo_show',
			'logo_height' => 'option_logo_show',
			'custom_sidebar' => 'option_show_custom_sidebar',
			'custom_sidepanel' => 'option_show_custom_sidepanel',
			'custom_header' => 'option_show_custom_header',
			'custom_footer' => 'option_show_custom_footer',
			'custom_in_head' => 'option_show_custom_in_head',
			'custom_home_heading' => 'option_show_custom_home',
			'custom_home_content' => 'option_show_custom_home',
			'home_description' => 'option_show_home_description',
		);
		
		if (as_clicked('doresetoptions')) {
			if (!as_check_form_security_code('admin/layout', as_post_text('code')))
				$securityexpired = true;

			else {
				as_reset_options($getoptions);
				$formokhtml = as_lang_html('admin/options_reset');
			}
		} elseif (as_clicked('dosaveoptions')) {		
			foreach ($getoptions as $optionname) {
				$optionvalue = as_post_text('option_' . $optionname);
				if (
						(@$optiontype[$optionname] == 'number') ||
						(@$optiontype[$optionname] == 'checkbox') ||
						((@$optiontype[$optionname] == 'number-blank') && strlen($optionvalue))
				)
					$optionvalue = (int) $optionvalue;
					
				as_set_option($optionname, $optionvalue);
			}

			$formokhtml = as_lang_html('admin/options_saved');
		}
		
		$getoptions = array();
		foreach ($showoptions as $optionname)
			if (strlen($optionname) && (strpos($optionname, '/') === false)) // empties represent spacers in forms
				$getoptions[] = $optionname;
		
	//	Get the information to display
		$options = as_get_options($getoptions);

		$as_content=as_content_prepare();

		$as_content['title']=as_lang_html('admin/admin_title').' ::  Editor';
		$as_content['error']=as_admin_page_error();	
		
		$in=array();	
		$editorname=isset($in['editor']) ? $in['editor'] : as_opt('editor_for_qs');
		$editor=as_load_editor(@$in['content'], @$in['format'], $editorname);
		
		$field = as_editor_load_field($editor, $as_content, @$in['content'], 
				@$in['format'], $item, 12, false);
		
		$as_content['script_rel'][] = 'as-content/as-admin.js?'.AS_VERSION;

		$as_content['form'] = array(
			'ok' => $formokhtml,

			'tags' => 'method="post" action="'.as_self_html().'" name="admin_form" onsubmit="document.forms.admin_form.has_js.value=1; return true;"',

			'style' => 'tall',

			'fields' => array(
				array(
					'id' => 'custom_home_content',
					'type' => 'textarea',
					'label' => as_lang_html('options/show_'.$item),
					'value' => as_opt($item),
					'tags' => 'name="'.$item.'" id="'.$item.'"',
					'rows' => 12,
					'error' => as_html(@$errors[$item]),
				),	
				
			),

			'buttons' => array(
				'save' => array(
					'tags' => 'id="dosaveoptions"',
					'label' => as_lang_html('admin/save_options_button'),
				),

				'reset' => array(
					'tags' => 'name="doresetoptions" onclick="return confirm('.as_js(as_lang_html('admin/reset_options_confirm')).');"',
					'label' => as_lang_html('admin/reset_options_button'),
				),
			),

			'hidden' => array(
				'dosaveoptions' => '1', // for IE
				'has_js' => '0',
				'code' => as_get_form_security_code('admin/layouteditor'),
			),
		);

	}
	
	$as_content['navigation']['sub']=as_admin_sub_navigation();


	return $as_content;


/*
	Omit PHP closing tag to help avoid accidental output
*/
