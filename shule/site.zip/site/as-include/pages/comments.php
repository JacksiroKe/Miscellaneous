<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for page listing recent comments on articles


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/q-list.php';

$departmentslugs = as_request_parts(1);
$countslugs = count($departmentslugs);
$memberid = as_get_logged_in_memberid();


// Get list of comments with related articles, plus department information

list($articles, $departments, $departmentid) = as_db_select_with_pending(
	as_db_recent_c_qs_selectspec($memberid, 0, $departmentslugs),
	as_db_department_nav_selectspec($departmentslugs, false, false, true),
	$countslugs ? as_db_slugs_to_department_id_selectspec($departmentslugs) : null
);

if ($countslugs) {
	if (!isset($departmentid))
		return include AS_INCLUDE_DIR . 'as-page-not-found.php';

	$departmenttitlehtml = as_html($departments[$departmentid]['title']);
	$sometitle = as_lang_html_sub('main/recent_cs_in_x', $departmenttitlehtml);
	$nonetitle = as_lang_html_sub('main/no_comments_in_x', $departmenttitlehtml);

} else {
	$sometitle = as_lang_html('main/recent_cs_title');
	$nonetitle = as_lang_html('main/no_comments_found');
}


// Prepare and return content for theme

return as_q_list_page_content(
	as_any_sort_and_dedupe($articles), // articles
	as_opt('page_size_activity'), // articles per page
	0, // start offset
	null, // total count (null to hide page links)
	$sometitle, // title if some articles
	$nonetitle, // title if no articles
	$departments, // departments for navigation
	$departmentid, // selected department id
	false, // show article counts in department navigation
	'comments/', // prefix for links in department navigation
	as_opt('feed_for_activity') ? 'comments' : null, // prefix for RSS feed paths (null to hide)
	as_html_suggest_qs_tags(as_using_tags(), as_department_path_request($departments, $departmentid)) // suggest what to do next
);
