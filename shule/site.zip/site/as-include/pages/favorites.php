<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for page listing member's favorites


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/favorites.php';


// Check that we're logged in

$memberid = as_get_logged_in_memberid();

if (!isset($memberid))
	as_redirect('login');


// Get lists of favorites for this member

$pagesize_qs = as_opt('page_size_qs');
$pagesize_members = as_opt('page_size_members');
$pagesize_tags = as_opt('page_size_tags');

list($numQs, $articles, $numMembers, $members, $numTags, $tags, $departments) = as_db_select_with_pending(
	as_db_selectspec_count(as_db_member_favorite_qs_selectspec($memberid)),
	as_db_member_favorite_qs_selectspec($memberid, $pagesize_qs),

	AS_FINAL_EXTERNAL_MEMBERS ? null : as_db_selectspec_count(as_db_member_favorite_members_selectspec($memberid)),
	AS_FINAL_EXTERNAL_MEMBERS ? null : as_db_member_favorite_members_selectspec($memberid, $pagesize_members),

	as_db_selectspec_count(as_db_member_favorite_tags_selectspec($memberid)),
	as_db_member_favorite_tags_selectspec($memberid, $pagesize_tags),

	as_db_member_favorite_departments_selectspec($memberid)
);

$membershtml = as_memberids_handles_html(AS_FINAL_EXTERNAL_MEMBERS ? $articles : array_merge($articles, $members));


// Prepare and return content for theme

$as_content = as_content_prepare(true);

$as_content['title'] = as_lang_html('misc/my_favorites_title');


// Favorite articles

$as_content['q_list'] = as_favorite_q_list_view($articles, $membershtml);
$as_content['q_list']['title'] = count($articles) ? as_lang_html('main/nav_qs') : as_lang_html('misc/no_favorite_qs');
if ($numQs['count'] > count($articles)) {
	$url = as_path_html('favorites/articles', array('start' => $pagesize_qs));
	$as_content['q_list']['footer'] = '<p class="as-link-next"><a href="' . $url . '">' . as_lang_html('misc/more_favorite_qs') . '</a></p>';
}


// Favorite members

if (!AS_FINAL_EXTERNAL_MEMBERS) {
	$as_content['ranking_members'] = as_favorite_members_view($members, $membershtml);
	$as_content['ranking_members']['title'] = count($members) ? as_lang_html('main/nav_members') : as_lang_html('misc/no_favorite_members');
	if ($numMembers['count'] > count($members)) {
		$url = as_path_html('favorites/members', array('start' => $pagesize_members));
		$as_content['ranking_members']['footer'] = '<p class="as-link-next"><a href="' . $url . '">' . as_lang_html('misc/more_favorite_members') . '</a></p>';
	}
}


// Favorite tags

if (as_using_tags()) {
	$as_content['ranking_tags'] = as_favorite_tags_view($tags);
	$as_content['ranking_tags']['title'] = count($tags) ? as_lang_html('main/nav_tags') : as_lang_html('misc/no_favorite_tags');
	if ($numTags['count'] > count($tags)) {
		$url = as_path_html('favorites/tags', array('start' => $pagesize_tags));
		$as_content['ranking_tags']['footer'] = '<p class="as-link-next"><a href="' . $url . '">' . as_lang_html('misc/more_favorite_tags') . '</a></p>';
	}
}


// Favorite departments (no pagination)

if (as_using_departments()) {
	$as_content['nav_list_departments'] = as_favorite_departments_view($departments);
	$as_content['nav_list_departments']['title'] = count($departments) ? as_lang_html('main/nav_departments') : as_lang_html('misc/no_favorite_departments');
}


// Sub navigation for account pages and suggestion

$as_content['suggest_next'] = as_lang_html_sub('misc/suggest_favorites_add', '<span class="as-favorite-image">&nbsp;</span>');

$as_content['navigation']['sub'] = as_member_sub_navigation(as_get_logged_in_handle(), 'favorites', true);


return $as_content;
