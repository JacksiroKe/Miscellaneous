<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for home page, Q&A listing page, custom pages and plugin pages


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';


// Determine whether path begins with as or not (article and answer listing can be accessed either way)

$requestparts = explode('/', as_request());
$explicitqa = (strtolower($requestparts[0]) == 'as');

if ($explicitqa) {
	$slugs = array_slice($requestparts, 1);
} elseif (strlen($requestparts[0])) {
	$slugs = $requestparts;
} else {
	$slugs = array();
}

$countslugs = count($slugs);


// Get list of articles, other bits of information that might be useful

$memberid = as_get_logged_in_memberid();

list($articles1, $articles2, $departments, $departmentid, $custompage) = as_db_select_with_pending(
	as_db_qs_selectspec($memberid, 'created', 0, $slugs, null, false, false, as_opt_if_loaded('page_size_activity')),
	as_db_recent_a_qs_selectspec($memberid, 0, $slugs),
	as_db_department_nav_selectspec($slugs, false, false, true),
	$countslugs ? as_db_slugs_to_department_id_selectspec($slugs) : null,
	($countslugs == 1 && !$explicitqa) ? as_db_page_full_selectspec($slugs[0], false) : null
);


// First, if this matches a custom page, return immediately with that page's content

if (isset($custompage) && !($custompage['flags'] & AS_PAGE_FLAGS_EXTERNAL)) {
	as_set_template('custom-' . $custompage['pageid']);

	$as_content = as_content_prepare();

	$level = as_get_logged_in_level();

	if (!as_permit_value_error($custompage['permit'], $memberid, $level, as_get_logged_in_flags()) || !isset($custompage['permit'])) {
		$as_content['title'] = as_html($custompage['heading']);
		$as_content['custom'] = $custompage['content'];

		if ($level >= AS_MEMBER_LEVEL_ADMIN) {
			$as_content['navigation']['sub'] = array(
				'admin/pages' => array(
					'label' => as_lang('admin/edit_custom_page'),
					'url' => as_path_html('admin/pages', array('edit' => $custompage['pageid'])),
				),
			);
		}

	} else {
		$as_content['error'] = as_lang_html('members/no_permission');
	}

	return $as_content;
}


// Then, see if we should redirect because the 'as' page is the same as the home page

if ($explicitqa && !as_is_http_post() && !as_has_custom_home()) {
	as_redirect(as_department_path_request($departments, $departmentid), $_GET);
}


// Then, if there's a slug that matches no department, check page modules provided by plugins

if (!$explicitqa && $countslugs && !isset($departmentid)) {
	$pagemodules = as_load_modules_with('page', 'match_request');
	$request = as_request();

	foreach ($pagemodules as $pagemodule) {
		if ($pagemodule->match_request($request)) {
			$tmpl = isset($custompage['pageid']) ? 'custom-' . $custompage['pageid'] : 'custom';
			as_set_template($tmpl);
			return $pagemodule->process_request($request);
		}
	}
}


// Then, check whether we are showing a custom home page

if (!$explicitqa && !$countslugs && as_opt('show_custom_home')) {
	as_set_template('custom');
	$as_content = as_content_prepare();
	$as_content['title'] = as_html(as_opt('custom_home_heading'));
	$as_content['custom'] = as_opt('custom_home_content');
	return $as_content;
}

as_set_template('as');
$as_content = as_content_prepare();
if (as_is_logged_in()) {
	$memberid = as_get_logged_in_memberid();
	$handle = as_get_logged_in_handle();
	$identifier = AS_FINAL_EXTERNAL_MEMBERS ? $memberid : $handle;

	list($memberaccount, $memberpoints, $memberlevels, $navdepartments, $memberrank) =
		as_db_select_with_pending(
			AS_FINAL_EXTERNAL_MEMBERS ? null : as_db_member_account_selectspec($handle, false),
			as_db_member_points_selectspec($identifier),
			as_db_member_levels_selectspec($identifier, AS_FINAL_EXTERNAL_MEMBERS, true),
			as_db_department_nav_selectspec(null, true),
			as_db_member_rank_selectspec($identifier)
		);

	// Check the member exists and work out what can and can't be set (if not using single sign-on)

	$errors = array();

	$loginlevel = as_get_logged_in_level();

	if (!AS_FINAL_EXTERNAL_MEMBERS) {
		$memberid = $memberaccount['memberid'];
		$fieldseditable = false;
		$maxlevelassign = null;

		$maxmemberlevel = $memberaccount['level'];
		foreach ($memberlevels as $memberlevel)
			$maxmemberlevel = max($maxmemberlevel, $memberlevel['level']);

		if (isset($memberid) && $memberid != $memberid &&
			($loginlevel >= AS_MEMBER_LEVEL_SUPER || $loginlevel > $maxmemberlevel) &&
			!as_member_permit_error()
		) { // can't change self - or someone on your level (or higher, obviously) unless you're a super admin

			if ($loginlevel >= AS_MEMBER_LEVEL_SUPER) $maxlevelassign = AS_MEMBER_LEVEL_SUPER;
			elseif ($loginlevel >= AS_MEMBER_LEVEL_ADMIN) $maxlevelassign = AS_MEMBER_LEVEL_MODERATOR;
			elseif ($loginlevel >= AS_MEMBER_LEVEL_MODERATOR) $maxlevelassign = AS_MEMBER_LEVEL_WRITER;

			if ($loginlevel >= AS_MEMBER_LEVEL_ADMIN) $fieldseditable = true;

			if (isset($maxlevelassign) && ($memberaccount['flags'] & AS_MEMBER_FLAGS_MEMBER_BLOCKED))
				$maxlevelassign = min($maxlevelassign, AS_MEMBER_LEVEL_EDITOR); 
		}
	}

	$pagesize = as_opt('page_size_qs');
	$count = (int)@$memberpoints['qposts'];	
	$memberaccount['name'] = as_get_member_name($handle, false);
	$memberaccount['memberid'] = $memberid;
	$memberaccount['points'] = (@$memberpoints['points'] == 1)
					? as_lang_html_sub('main/1_point', '1', '1')
					: as_lang_html_sub('main/x_points', as_html(as_format_number(@$memberpoints['points'])));

	if (isset($memberid) && $memberid != $memberaccount['memberid'] && !AS_FINAL_EXTERNAL_MEMBERS) {
		$favoritemap = as_get_favorite_non_qs_map();
		$favorite = @$favoritemap['member'][$memberaccount['memberid']];

		$as_content['favorite'] = as_favorite_form(AS_ENTITY_MEMBER, $memberaccount['memberid'], $favorite,
			as_lang_sub($favorite ? 'main/remove_x_favorites' : 'members/add_member_x_favorites', $handle));
	}


	// General information about the member, only available if we're using internal member management
	if (!AS_FINAL_EXTERNAL_MEMBERS) {
		$membertime = as_time_to_string(as_opt('db_time') - $memberaccount['created']);
		$joindate = as_when_to_html($memberaccount['created'], 0);
		$hasavatar = as_get_member_avatar_html($memberaccount['flags'], $memberaccount['email'], $memberaccount['handle'], $memberaccount['avatarblobid'], 30, 30, 30);
		$asavatar = '<img src="./as-media/member.png" width="30" height="30"/>';
		
		$memberaccount['avatar'] = $hasavatar ? $hasavatar  : $asavatar;
		$memberaccount['info']['country'] = as_lang_html('members/from_label').' '.$memberaccount['country'].' '.
			($memberaccount['sex'] == 1 ? ' ('.as_lang('members/sex_male').')' : ' ('.as_lang('members/sex_female').')');
		$memberaccount['info']['since_when'] = as_lang_html('members/member_for').' '.as_html($membertime . ' (' . as_lang_sub('main/since_x', $joindate['data']) . ')');
		
		// Show email address only if we're an administrator
		if ($loginlevel >= AS_MEMBER_LEVEL_ADMIN && !as_member_permit_error()) {
			$doconfirms = as_opt('confirm_member_emails') && $memberaccount['level'] < AS_MEMBER_LEVEL_WRITER;
			$isconfirmed = ($memberaccount['flags'] & AS_MEMBER_FLAGS_EMAIL_CONFIRMED) > 0;
			$htmlemail = as_html(isset($inemail) ? $inemail : $memberaccount['email']);

			$as_content['dashboard']['fields']['email'] = array(
				'type' => 'static',
				'label' => as_lang_html('members/email_label'),
				'tags' => 'name="email"',
				'error' => as_html(@$errors['email']),
				'note' => ($doconfirms ? (as_lang_html($isconfirmed ? 'members/email_confirmed' : 'members/email_not_confirmed') . ' ') : ''),
				'id' => 'email',
			);
		}

		// Show IP addresses and times for last login or write - only if we're a moderator or higher
		if ($loginlevel >= AS_MEMBER_LEVEL_MODERATOR && !as_member_permit_error()) {
			$as_content['dashboard']['fields']['lastlogin'] = array(
				'type' => 'static',
				'label' => as_lang_html('members/last_login_label'),
				'value' =>
					strtr(as_lang_html('members/x_ago_from_y'), array(
						'^1' => as_time_to_string(as_opt('db_time') - $memberaccount['loggedin']),
						'^2' => as_ip_anchor_html(@inet_ntop($memberaccount['loginip'])),
					)),
				'id' => 'lastlogin',
			);

			if (isset($memberaccount['written'])) {
				$as_content['dashboard']['fields']['lastwrite'] = array(
					'type' => 'static',
					'label' => as_lang_html('members/last_write_label'),
					'value' =>
						strtr(as_lang_html('members/x_ago_from_y'), array(
							'^1' => as_time_to_string(as_opt('db_time') - $memberaccount['written']),
							'^2' => as_ip_anchor_html(@inet_ntop($memberaccount['writeip'])),
						)),
					'id' => 'lastwrite',
				);
			} else {
				unset($as_content['dashboard']['fields']['lastwrite']);
			}
		}
	}
	
	function home_app($name, $url = null, $img = null)
	{
		return '<a href="' . ((isset($url)) ? as_path_html($url) : as_path_html($name)) . 
			'"><div class="home_app"><div class="app_img" style="background: url(' . 
			(isset($img) ? $img : as_path_html('as-media/post.jpg')).
			'); background-size: cover; background-repeat: no-repeat; background-position: center center;"></div><span class="app_title">'.as_lang_html('main/nav_'.$name).'</span></div></a>';
	}
	
	$homehtml = '<div class="apps_wrapper">';
	$homehtml .= home_app('departments');
	$homehtml .= home_app('units', 'departments/units');
	$homehtml .= home_app('staffroom');
	$homehtml .= home_app('registry');
	$homehtml .= home_app('groups', 'registry/groups');
	$homehtml .= home_app('examinations');
	$homehtml .= home_app('timetables');
	$homehtml .= home_app('transcripts');
	$homehtml .= home_app('finance');
	$homehtml .= home_app('members');
	$homehtml .= '</div>';
	
	
	$as_content['title'] = as_lang('main/dashboard');
	$as_content['member'] = $memberaccount;
	$as_content['custom'] = $homehtml;
}

return $as_content;
