<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: External member functions for WordPress integration


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


function as_get_mysql_member_column_type()
{
	return 'BIGINT UNSIGNED';
}


function as_get_login_links($relative_url_prefix, $redirect_back_to_url)
{
	return array(
		'login' => wp_login_url(as_opt('site_url') . $redirect_back_to_url),
		'register' => function_exists('wp_registration_url') ? wp_registration_url() : site_url('wp-login.php?action=register'),
		'logout' => strtr(wp_logout_url(), array('&amp;' => '&')),
	);
}


function as_get_logged_in_member()
{
	$wordpressmember = wp_get_current_member();

	if ($wordpressmember->ID == 0)
		return null;

	else {
		if (current_member_can('administrator'))
			$level = AS_MEMBER_LEVEL_ADMIN;
		elseif (current_member_can('editor'))
			$level = AS_MEMBER_LEVEL_EDITOR;
		elseif (current_member_can('contributor'))
			$level = AS_MEMBER_LEVEL_WRITER;
		else
			$level = AS_MEMBER_LEVEL_BASIC;

		return array(
			'memberid' => $wordpressmember->ID,
			'publicusername' => $wordpressmember->member_nicename,
			'email' => $wordpressmember->member_email,
			'level' => $level,
		);
	}
}


function as_get_member_email($memberid)
{
	$member = get_memberdata($memberid);

	return @$member->member_email;
}


function as_get_memberids_from_public($publicusernames)
{
	global $wpdb;

	if (count($publicusernames))
		return as_db_read_all_assoc(as_db_query_sub(
			'SELECT member_nicename, ID FROM ' . $wpdb->base_prefix . 'members WHERE member_nicename IN ($)',
			$publicusernames
		), 'member_nicename', 'ID');
	else
		return array();
}


function as_get_public_from_memberids($memberids)
{
	global $wpdb, $as_cache_wp_member_emails;

	if (count($memberids)) {
		$memberidtopublic = array();
		$as_cache_wp_member_emails = array();

		$memberfields = as_db_read_all_assoc(as_db_query_sub(
			'SELECT ID, member_nicename, member_email FROM ' . $wpdb->base_prefix . 'members WHERE ID IN (#)',
			$memberids
		), 'ID');

		foreach ($memberfields as $id => $fields) {
			$memberidtopublic[$id] = $fields['member_nicename'];
			$as_cache_wp_member_emails[$id] = $fields['member_email'];
		}

		return $memberidtopublic;

	} else
		return array();
}


function as_get_logged_in_member_html($logged_in_member, $relative_url_prefix)
{
	$publicusername = $logged_in_member['publicusername'];

	return '<a href="' . as_path_html($publicusername) . '" class="as-member-link">' . htmlspecialchars($publicusername) . '</a>';
}


function as_get_members_html($memberids, $should_include_link, $relative_url_prefix)
{
	$memberidtopublic = as_get_public_from_memberids($memberids);

	$membershtml = array();

	foreach ($memberids as $memberid) {
		$publicusername = $memberidtopublic[$memberid];

		$membershtml[$memberid] = htmlspecialchars($publicusername);

		if ($should_include_link)
			$membershtml[$memberid] = '<a href="' . as_path_html($publicusername) . '" class="as-member-link">' . $membershtml[$memberid] . '</a>';
	}

	return $membershtml;
}


function as_avatar_html_from_memberid($memberid, $size, $padding)
{
	require_once AS_INCLUDE_DIR . 'app/format.php';

	global $as_cache_wp_member_emails;

	if (isset($as_cache_wp_member_emails[$memberid]))
		return as_get_gravatar_html($as_cache_wp_member_emails[$memberid], $size);

	return null;
}


function as_member_report_action($memberid, $action)
{
}
