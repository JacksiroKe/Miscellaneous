<?php
require_once AS_INCLUDE_DIR.'app/format.php';
require_once AS_INCLUDE_DIR.'app/options.php';

class AppFormatTest extends PHPUnit_Framework_TestCase
{
	/**
	 * Test basic number formatting (no compact numbers)
	 */
	public function test__as_format_number()
	{
		// set options/lang cache to bypass database
		global $as_options_cache, $as_phrases_full;
		$as_options_cache['show_compact_numbers'] = '0';

		$as_phrases_full['main']['_decimal_point'] = '.';
		$as_phrases_full['main']['_thousands_separator'] = ',';

		$this->assertSame('5.5', as_format_number(5.452, 1));
		$this->assertSame('5', as_format_number(5.452, 0));
		$this->assertSame('5', as_format_number(4.5, 0));
		$this->assertSame('9,123', as_format_number(9123, 0));
		$this->assertSame('9,123.0', as_format_number(9123, 1));

		// not shortened unless 'show_compact_numbers' is true
		$this->assertSame('5.0', as_format_number(5, 1, true));
		$this->assertSame('5.5', as_format_number(5.452, 1, true));
		$this->assertSame('5', as_format_number(5.452, 0, true));
		$this->assertSame('9,123', as_format_number(9123, 0, true));
		$this->assertSame('123,456,789', as_format_number(123456789, 0, true));

		// change separators
		$as_phrases_full['main']['_decimal_point'] = ',';
		$as_phrases_full['main']['_thousands_separator'] = '.';

		$this->assertSame('5,5', as_format_number(5.452, 1));
		$this->assertSame('5', as_format_number(5.452, 0));
		$this->assertSame('9.123', as_format_number(9123, 0));
		$this->assertSame('9.123,0', as_format_number(9123, 1));
	}

	/**
	 * Test number formatting including compact numbers (e.g. 1.3k)
	 */
	public function test__as_format_number__compact()
	{
		// set options/lang cache to bypass database
		global $as_options_cache, $as_phrases_full;
		$as_options_cache['show_compact_numbers'] = '1';

		$as_phrases_full['main']['_decimal_point'] = '.';
		$as_phrases_full['main']['_thousands_separator'] = ',';
		$as_phrases_full['main']['_thousands_suffix'] = 'k';
		$as_phrases_full['main']['_millions_suffix'] = 'm';

		// $decimal parameter ignored when 'show_compact_numbers' is true
		$this->assertSame('5.5', as_format_number(5.452, 0, true));
		$this->assertSame('5.5', as_format_number(5.452, 1, true));
		$this->assertSame('5', as_format_number(5, 1, true));

		$this->assertSame('9.1k', as_format_number(9123, 0, true));
		$this->assertSame('9.1k', as_format_number(9123, 1, true));
		$this->assertSame('9k', as_format_number(9040, 0, true));
		$this->assertSame('9k', as_format_number(9040, 1, true));
		$this->assertSame('9.1k', as_format_number(9050, 0, true));

		$this->assertSame('123m', as_format_number(123456789, 0, true));
		$this->assertSame('23.5m', as_format_number(23456789, 1, true));
		$this->assertSame('123m', as_format_number(123456789, 1, true));
		$this->assertSame('235m', as_format_number(234567891, 1, true));
		$this->assertSame('1,223m', as_format_number(1223456789, 0, true));

		$this->assertSame('9,000', as_format_number(9000, 0, false));
		$this->assertSame('912.3', as_format_number(912.3, 1, false));
		$this->assertSame('123,456,789', as_format_number(123456789, 0, false));

		// change separators and compact suffixes
		$as_phrases_full['main']['_decimal_point'] = ',';
		$as_phrases_full['main']['_thousands_separator'] = '.';
		$as_phrases_full['main']['_thousands_suffix'] = 'th';
		$as_phrases_full['main']['_millions_suffix'] = 'mi';

		$this->assertSame('9,1th', as_format_number(9123, 0, true));
		$this->assertSame('123mi', as_format_number(123456789, 0, true));
	}
}
