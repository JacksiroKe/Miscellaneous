<?php
require_once AS_INCLUDE_DIR.'app/members.php';

class AppMembersTest extends PHPUnit_Framework_TestCase
{
	/**
	 * Test logic of permissions function.
	 * Member level values: AS_MEMBER_LEVEL_* in app/members.php [BASIC..SUPER]
	 * Permission values: AS_PERMIT_* in app/options.php [ALL..SUPERS]
	 * Member flag values: AS_MEMBER_FLAGS_* in app/members.php
	 */
	public function test__as_permit_value_error()
	{
		// set options cache to bypass database
		global $as_options_cache;
		$as_options_cache['confirm_member_emails'] = '1';
		$as_options_cache['moderate_members'] = '0';

		$memberFlags = AS_MEMBER_FLAGS_EMAIL_CONFIRMED;
		$blockedFlags = AS_MEMBER_FLAGS_EMAIL_CONFIRMED | AS_MEMBER_FLAGS_MEMBER_BLOCKED;

		// Admin trying to do Super stuff
		$error = as_permit_value_error(AS_PERMIT_SUPERS, 1, AS_MEMBER_LEVEL_ADMIN, $memberFlags);
		$this->assertSame('level', $error);

		// Admin trying to do Admin stuff
		$error = as_permit_value_error(AS_PERMIT_ADMINS, 1, AS_MEMBER_LEVEL_ADMIN, $memberFlags);
		$this->assertSame(false, $error);

		// Admin trying to do Editor stuff
		$error = as_permit_value_error(AS_PERMIT_EDITORS, 1, AS_MEMBER_LEVEL_ADMIN, $memberFlags);
		$this->assertSame(false, $error);

		// Writer trying to do Moderator stuff
		$error = as_permit_value_error(AS_PERMIT_MODERATORS, 1, AS_MEMBER_LEVEL_WRITER, $memberFlags);
		$this->assertSame('level', $error);

		// Unconfirmed Member trying to do Confirmed stuff
		$error = as_permit_value_error(AS_PERMIT_CONFIRMED, 1, AS_MEMBER_LEVEL_BASIC, 0);
		$this->assertSame('confirm', $error);

		// Blocked Member trying to do anything
		$error = as_permit_value_error(AS_PERMIT_ALL, 1, AS_MEMBER_LEVEL_BASIC, $blockedFlags);
		$this->assertSame('memberblock', $error);

		// Logged Out Member trying to do Member stuff
		$error = as_permit_value_error(AS_PERMIT_MEMBERS, null, null, 0);
		$this->assertSame('login', $error);

		// Logged Out Member trying to do Moderator stuff
		$error = as_permit_value_error(AS_PERMIT_MODERATORS, null, null, 0);
		$this->assertSame('login', $error);
	}
}
