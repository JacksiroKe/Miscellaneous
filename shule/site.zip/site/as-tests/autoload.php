<?php
// currently, all APS code depends on as-base

global $as_options_cache;

// Needed in order to avoid accessing the database while including the as-base.php file
$as_options_cache['enabled_plugins'] = '';

$as_autoconnect = false;
require_once __DIR__.'/../as-include/as-base.php';
