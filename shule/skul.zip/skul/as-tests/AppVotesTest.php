<?php
require_once AS_INCLUDE_DIR.'app/votes.php';
require_once AS_INCLUDE_DIR.'app/options.php';

class AppVotesTest extends PHPUnit_Framework_TestCase
{
	private $voteviewOpts = array(
		'voting_on_qs' => 1,
		'voting_on_as' => 1,
		'voting_on_cs' => 1,
		// 'voting_on_q_page_only' => 1,
		// 'votes_separated' => 0,
		'permit_vote_q' => AS_PERMIT_MEMBERS,
		'permit_vote_a' => AS_PERMIT_MEMBERS,
		'permit_vote_c' => AS_PERMIT_MEMBERS,
		'permit_vote_down' => AS_PERMIT_MEMBERS,
	);

	private $mockArticle = array(
		'postid' => 16349,
		'departmentid' => '',
		'type' => 'Q',
		'basetype' => 'Q',
		'hidden' => 0,
		'queued' => 0,
		'acount' => 13,
		'selchildid' => '',
		'closedbyid' => '',
		'upvotes' => 1,
		'downvotes' => 0,
		'netvotes' => 1,
		'views' => 20,
		'hotness' => 33319100000,
		'flagcount' => 0,
		'title' => 'To be or not to be?',
		'tags' => 'article,answer',
		'created' => 1344623702,
		'name' => '',
		'departmentname' => '',
		'departmentbackpath' => '',
		'departmentids' => '',
		'membervote' => 1,
		'memberflag' => 0,
		'memberfavoriteq' => '0',
		'content' => 'That is the article.',
		'notify' => '',
		'updated' => 1409375832,
		'updatetype' => 'E',
		'format' => '',
		'lastmemberid' => 21981,
		'lastip' => '',
		'parentid' => '',
		'lastviewip' => '',
		'memberid' => 1,
		'cookieid' => '',
		'createip' => '',
		'points' => 140,
		'flags' => 0,
		'level' => 0,
		'email' => '21981@example.com',
		'handle' => 'ArticleWriteer',
		'avatarblobid' => '',
		'avatarwidth' => '',
		'avatarheight' => '',
		'lasthandle' => 'ArticleWriteer',
	);

	private $mockMember = array(
		'memberid' => 1,
		'passsalt' => null,
		'passcheck' => null,
		'passhash' => 'passhash',
		'email' => 'email',
		'level' => 120,
		'emailcode' => '',
		'handle' => 'admin',
		'created' => '',
		'sessioncode' => '',
		'sessionsource' => null,
		'flags' => 265,
		'loggedin' => '',
		'loginip' => '',
		'written' => '',
		'writeip' => '',
		'avatarblobid' => '',
		'avatarwidth' => '',
		'avatarheight' => '',
		'points' => 100,
		'wallposts' => 6,
	);


	/**
	 * Test voteview where upvotes/downvotes are combined
	 */
	public function test__as_vote_error_html()
	{
		// set options/lang/member cache to bypass database
		global $as_options_cache, $as_curr_ip_blocked, $as_cached_logged_in_member, $as_phrases_full;
		$as_options_cache = array_merge($as_options_cache, $this->voteviewOpts);
		$as_curr_ip_blocked = false;
		$as_cached_logged_in_member = $this->mockMember;

		$as_phrases_full['main']['vote_not_allowed'] = 'Voting on this is not allowed';
		$as_phrases_full['main']['vote_disabled_hidden'] = 'You cannot vote on hidden posts';

		$topage = '123/to-be-or-not-to-be';

		$this->assertSame($as_phrases_full['main']['vote_not_allowed'], as_vote_error_html($this->mockArticle, 1, 1, $topage));

		$hiddenQ = $this->mockArticle;
		$hiddenQ['hidden'] = 1;
		$this->assertSame($as_phrases_full['main']['vote_disabled_hidden'], as_vote_error_html($hiddenQ, 1, 17, $topage));

		// can't test more right now due to as_member_limits_remaining() call from as_member_permit_error()
	}
}
