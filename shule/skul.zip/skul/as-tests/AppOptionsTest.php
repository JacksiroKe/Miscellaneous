<?php
require_once AS_INCLUDE_DIR.'app/format.php';
require_once AS_INCLUDE_DIR.'app/options.php';

class AppOptionsTest extends PHPUnit_Framework_TestCase
{
	private $voteviewOpts = array(
		'voting_on_qs' => 1,
		'voting_on_as' => 1,
		'voting_on_cs' => 1,
		'voting_on_q_page_only' => 1,
		'votes_separated' => 0,
		'permit_vote_q' => AS_PERMIT_MEMBERS,
		'permit_vote_a' => AS_PERMIT_MEMBERS,
		'permit_vote_c' => AS_PERMIT_MEMBERS,
		'permit_vote_down' => AS_PERMIT_MEMBERS,
	);

	private $mockMember = array(
		'memberid' => '1',
		'passsalt' => null,
		'passcheck' => null,
		'passhash' => 'passhash',
		'email' => 'email',
		'level' => '120',
		'emailcode' => '',
		'handle' => 'admin',
		'created' => '',
		'sessioncode' => '',
		'sessionsource' => null,
		'flags' => '265',
		'loggedin' => '',
		'loginip' => '',
		'written' => '',
		'writeip' => '',
		'avatarblobid' => '',
		'avatarwidth' => '',
		'avatarheight' => '',
		'points' => '100',
		'wallposts' => '6',
	);

	/**
	 * Test voteview where upvotes/downvotes are combined
	 */
	public function test__as_get_vote_view__net()
	{
		// set options/member cache to bypass database
		global $as_options_cache, $as_curr_ip_blocked, $as_cached_logged_in_member;
		$as_options_cache = array_merge($as_options_cache, $this->voteviewOpts);
		$as_curr_ip_blocked = false;
		$as_cached_logged_in_member = $this->mockMember;


		$this->assertSame('net', as_get_vote_view('Q', true));
		$this->assertSame('net-disabled-page', as_get_vote_view('Q', false));
		$this->assertSame('net-disabled-page', as_get_vote_view('Q', true, false));
		$this->assertSame('net-disabled-page', as_get_vote_view('Q', false, false));

		$this->assertSame('net', as_get_vote_view('A', true));
		$this->assertSame('net', as_get_vote_view('A', false));
		$this->assertSame('net-disabled-page', as_get_vote_view('A', true, false));
		$this->assertSame('net-disabled-page', as_get_vote_view('A', false, false));

		$this->assertSame('net', as_get_vote_view('C', true));
		$this->assertSame('net', as_get_vote_view('C', false));


		$as_options_cache['voting_on_qs'] = 0;
		$as_options_cache['voting_on_as'] = 0;
		$as_options_cache['voting_on_cs'] = 0;
		$this->assertSame(false, as_get_vote_view('Q', true));
		$this->assertSame(false, as_get_vote_view('A', true));
		$this->assertSame(false, as_get_vote_view('C', true));
	}

	/**
	 * Test voteview where upvotes/downvotes are separated
	 */
	public function test__as_get_vote_view__updown()
	{
		// set options/member cache to bypass database
		global $as_options_cache, $as_curr_ip_blocked, $as_cached_logged_in_member;
		$as_options_cache = array_merge($as_options_cache, $this->voteviewOpts, array('votes_separated' => 1));
		$as_curr_ip_blocked = false;
		$as_cached_logged_in_member = $this->mockMember;

		$this->assertSame('updown', as_get_vote_view('Q', true));
		$this->assertSame('updown-disabled-page', as_get_vote_view('Q', false));
		$this->assertSame('updown-disabled-page', as_get_vote_view('Q', true, false));
		$this->assertSame('updown-disabled-page', as_get_vote_view('Q', false, false));

		$this->assertSame('updown', as_get_vote_view('A', true));
		$this->assertSame('updown', as_get_vote_view('A', false));
		$this->assertSame('updown-disabled-page', as_get_vote_view('A', true, false));
		$this->assertSame('updown-disabled-page', as_get_vote_view('A', false, false));

		$this->assertSame('updown', as_get_vote_view('C', true));
		$this->assertSame('updown', as_get_vote_view('C', false));

		$as_options_cache['voting_on_qs'] = 0;
		$as_options_cache['voting_on_as'] = 0;
		$as_options_cache['voting_on_cs'] = 0;
		$this->assertSame(false, as_get_vote_view('Q', true));
		$this->assertSame(false, as_get_vote_view('A', true));
		$this->assertSame(false, as_get_vote_view('C', true));
	}
}
