<?php
// Stand-in config file for PHPUnit

define('AS_MYSQL_HOSTNAME', 'localhost');
define('AS_MYSQL_MEMBERNAME', '');
define('AS_MYSQL_PASSWORD', '');
define('AS_MYSQL_DATABASE', '');

define('AS_MYSQL_TABLE_PREFIX', 'as_');
define('AS_EXTERNAL_MEMBERS', false);
