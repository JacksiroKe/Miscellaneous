<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: More control for article page if it's submitted by HTTP POST


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'app/limits.php';
require_once AS_INCLUDE_DIR . 'pages/article-submit.php';


$code = as_post_text('code');

// Process general cancel button

if (as_clicked('docancel'))
	as_page_q_refresh($pagestart);


// Process incoming answer (or button)

if ($article['answerbutton']) {
	if (as_clicked('q_doanswer'))
		as_page_q_refresh($pagestart, 'answer');

	// The 'approve', 'login', 'confirm', 'limit', 'memberblock', 'ipblock' permission errors are reported to the member here
	// The other option ('level') prevents the answer button being shown, in as_page_q_post_rules(...)

	if (as_clicked('a_doadd') || $pagestate == 'answer') {
		switch (as_member_post_permit_error('permit_post_a', $article, AS_LIMIT_ANSWERS)) {
			case 'login':
				$pageerror = as_insert_login_links(as_lang_html('article/answer_must_login'), as_request());
				break;

			case 'confirm':
				$pageerror = as_insert_login_links(as_lang_html('article/answer_must_confirm'), as_request());
				break;

			case 'approve':
				$pageerror = strtr(as_lang_html('article/answer_must_be_approved'), array(
					'^1' => '<a href="' . as_path_html('account') . '">',
					'^2' => '</a>',
				));
				break;

			case 'limit':
				$pageerror = as_lang_html('article/answer_limit');
				break;

			default:
				$pageerror = as_lang_html('members/no_permission');
				break;

			case false:
				if (as_clicked('a_doadd')) {
					$answerid = as_page_q_add_a_submit($article, $answers, $usecaptcha, $anewin, $anewerrors);

					if (isset($answerid))
						as_page_q_refresh(0, null, 'A', $answerid);
					else
						$formtype = 'a_add'; // show form again

				} else
					$formtype = 'a_add'; // show form as if first time
				break;
		}
	}
}


// Process close buttons for article

if ($article['closeable']) {
	if (as_clicked('q_doclose'))
		as_page_q_refresh($pagestart, 'close');

	elseif (as_clicked('doclose') && as_page_q_permit_edit($article, 'permit_close_q', $pageerror)) {
		if (as_page_q_close_q_submit($article, $closepost, $closein, $closeerrors))
			as_page_q_refresh($pagestart);
		else
			$formtype = 'q_close'; // keep editing if an error

	} elseif ($pagestate == 'close' && as_page_q_permit_edit($article, 'permit_close_q', $pageerror))
		$formtype = 'q_close';
}


// Process any single click operations or delete button for article

if (as_page_q_single_click_q($article, $answers, $commentsfollows, $closepost, $pageerror))
	as_page_q_refresh($pagestart);

if (as_clicked('q_dodelete') && $article['deleteable'] && as_page_q_click_check_form_code($article, $pageerror)) {
	as_article_delete($article, $memberid, as_get_logged_in_handle(), $cookieid, $closepost);
	as_redirect(''); // redirect since article has gone
}


// Process edit or save button for article

if ($article['editbutton'] || $article['retagcatbutton']) {
	if (as_clicked('q_doedit'))
		as_page_q_refresh($pagestart, 'edit-' . $articleid);

	elseif (as_clicked('q_dosave') && as_page_q_permit_edit($article, 'permit_edit_q', $pageerror, 'permit_retag_cat')) {
		if (as_page_q_edit_q_submit($article, $answers, $commentsfollows, $closepost, $qin, $qerrors))
			as_redirect(as_q_request($articleid, $qin['title'])); // don't use refresh since URL may have changed
		else {
			$formtype = 'q_edit'; // keep editing if an error
			$pageerror = @$qerrors['page']; // for security code failure
		}

	} elseif ($pagestate == ('edit-' . $articleid) && as_page_q_permit_edit($article, 'permit_edit_q', $pageerror, 'permit_retag_cat'))
		$formtype = 'q_edit';

	if ($formtype == 'q_edit') { // get tags for auto-completion
		if (as_opt('do_complete_tags'))
			$completetags = array_keys(as_db_select_with_pending(as_db_popular_tags_selectspec(0, AS_DB_RETRIEVE_COMPLETE_TAGS)));
		else
			$completetags = array();
	}
}


// Process adding a comment to article (shows form or processes it)

if ($article['commentbutton']) {
	if (as_clicked('q_docomment'))
		as_page_q_refresh($pagestart, 'comment-' . $articleid, 'C', $articleid);

	if (as_clicked('c' . $articleid . '_doadd') || $pagestate == ('comment-' . $articleid))
		as_page_q_do_comment($article, $article, $commentsfollows, $pagestart, $usecaptcha, $cnewin, $cnewerrors, $formtype, $formpostid, $pageerror);
}


// Process clicked buttons for answers

foreach ($answers as $answerid => $answer) {
	$prefix = 'a' . $answerid . '_';

	if (as_page_q_single_click_a($answer, $article, $answers, $commentsfollows, true, $pageerror))
		as_page_q_refresh($pagestart, null, 'A', $answerid);

	if ($answer['editbutton']) {
		if (as_clicked($prefix . 'doedit'))
			as_page_q_refresh($pagestart, 'edit-' . $answerid);

		elseif (as_clicked($prefix . 'dosave') && as_page_q_permit_edit($answer, 'permit_edit_a', $pageerror)) {
			$editedtype = as_page_q_edit_a_submit($answer, $article, $answers, $commentsfollows, $aeditin[$answerid], $aediterrors[$answerid]);

			if (isset($editedtype))
				as_page_q_refresh($pagestart, null, $editedtype, $answerid);

			else {
				$formtype = 'a_edit';
				$formpostid = $answerid; // keep editing if an error
			}

		} elseif ($pagestate == ('edit-' . $answerid) && as_page_q_permit_edit($answer, 'permit_edit_a', $pageerror)) {
			$formtype = 'a_edit';
			$formpostid = $answerid;
		}
	}

	if ($answer['commentbutton']) {
		if (as_clicked($prefix . 'docomment'))
			as_page_q_refresh($pagestart, 'comment-' . $answerid, 'C', $answerid);

		if (as_clicked('c' . $answerid . '_doadd') || $pagestate == ('comment-' . $answerid))
			as_page_q_do_comment($article, $answer, $commentsfollows, $pagestart, $usecaptcha, $cnewin, $cnewerrors, $formtype, $formpostid, $pageerror);
	}

	if (as_clicked($prefix . 'dofollow')) {
		$params = array('follow' => $answerid);
		if (isset($article['departmentid']))
			$params['cat'] = $article['departmentid'];

		as_redirect('write', $params);
	}
}


// Process hide, show, delete, flag, unflag, edit or save button for comments

foreach ($commentsfollows as $commentid => $comment) {
	if ($comment['basetype'] == 'C') {
		$cparentid = $comment['parentid'];
		$commentparent = isset($answers[$cparentid]) ? $answers[$cparentid] : $article;
		$prefix = 'c' . $commentid . '_';

		if (as_page_q_single_click_c($comment, $article, $commentparent, $pageerror))
			as_page_q_refresh($pagestart, 'showcomments-' . $cparentid, $commentparent['basetype'], $cparentid);

		if ($comment['editbutton']) {
			if (as_clicked($prefix . 'doedit')) {
				if (as_page_q_permit_edit($comment, 'permit_edit_c', $pageerror)) // extra check here ensures error message is visible
					as_page_q_refresh($pagestart, 'edit-' . $commentid, 'C', $commentid);
			} elseif (as_clicked($prefix . 'dosave') && as_page_q_permit_edit($comment, 'permit_edit_c', $pageerror)) {
				if (as_page_q_edit_c_submit($comment, $article, $commentparent, $ceditin[$commentid], $cediterrors[$commentid]))
					as_page_q_refresh($pagestart, null, 'C', $commentid);
				else {
					$formtype = 'c_edit';
					$formpostid = $commentid; // keep editing if an error
				}
			} elseif ($pagestate == ('edit-' . $commentid) && as_page_q_permit_edit($comment, 'permit_edit_c', $pageerror)) {
				$formtype = 'c_edit';
				$formpostid = $commentid;
			}
		}
	}
}


// Functions used above - also see functions in /as-include/pages/article-submit.php (which are shared with Ajax)

/*
	Redirects back to the article page, with the specified parameters
*/
function as_page_q_refresh($start = 0, $state = null, $showtype = null, $showid = null)
{
	$params = array();

	if ($start > 0)
		$params['start'] = $start;
	if (isset($state))
		$params['state'] = $state;

	if (isset($showtype) && isset($showid)) {
		$anchor = as_anchor($showtype, $showid);
		$params['show'] = $showid;
	} else
		$anchor = null;

	as_redirect(as_request(), $params, null, null, $anchor);
}


/*
	Returns whether the editing operation (as specified by $permitoption or $permitoption2) on $post is permitted.
	If not, sets the $error variable appropriately
*/
function as_page_q_permit_edit($post, $permitoption, &$error, $permitoption2 = null)
{
	// The 'login', 'confirm', 'memberblock', 'ipblock' permission errors are reported to the member here
	// The other options ('approve', 'level') prevent the edit button being shown, in as_page_q_post_rules(...)

	$permiterror = as_member_post_permit_error($post['isbymember'] ? null : $permitoption, $post);
	// if it's by the member, this will only check whether they are blocked

	if ($permiterror && isset($permitoption2)) {
		$permiterror2 = as_member_post_permit_error($post['isbymember'] ? null : $permitoption2, $post);

		if ($permiterror == 'level' || $permiterror == 'approve' || !$permiterror2) // if it's a less strict error
			$permiterror = $permiterror2;
	}

	switch ($permiterror) {
		case 'login':
			$error = as_insert_login_links(as_lang_html('article/edit_must_login'), as_request());
			break;

		case 'confirm':
			$error = as_insert_login_links(as_lang_html('article/edit_must_confirm'), as_request());
			break;

		default:
			$error = as_lang_html('members/no_permission');
			break;

		case false:
			break;
	}

	return !$permiterror;
}


/*
	Returns a $as_content form for editing the article and sets up other parts of $as_content accordingly
*/
function as_page_q_edit_q_form(&$as_content, $article, $in, $errors, $completetags, $departments)
{
	$form = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',

		'style' => 'tall',

		'fields' => array(
			'title' => array(
				'type' => $article['editable'] ? 'text' : 'static',
				'label' => as_lang_html('article/q_title_label'),
				'tags' => 'name="q_title"',
				'value' => as_html(($article['editable'] && isset($in['title'])) ? $in['title'] : $article['title']),
				'error' => as_html(@$errors['title']),
			),

			'department' => array(
				'label' => as_lang_html('article/q_department_label'),
				'error' => as_html(@$errors['departmentid']),
			),

			'content' => array(
				'label' => as_lang_html('article/q_content_label'),
				'error' => as_html(@$errors['content']),
			),

			'extra' => array(
				'label' => as_html(as_opt('extra_field_prompt')),
				'tags' => 'name="q_extra"',
				'value' => as_html(isset($in['extra']) ? $in['extra'] : $article['extra']),
				'error' => as_html(@$errors['extra']),
			),

			'tags' => array(
				'error' => as_html(@$errors['tags']),
			),

		),

		'buttons' => array(
			'save' => array(
				'tags' => 'onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html('main/save_button'),
			),

			'cancel' => array(
				'tags' => 'name="docancel"',
				'label' => as_lang_html('main/cancel_button'),
			),
		),

		'hidden' => array(
			'q_dosave' => '1',
			'code' => as_get_form_security_code('edit-' . $article['postid']),
		),
	);

	if ($article['editable']) {
		$content = isset($in['content']) ? $in['content'] : $article['content'];
		$format = isset($in['format']) ? $in['format'] : $article['format'];

		$editorname = isset($in['editor']) ? $in['editor'] : as_opt('editor_for_qs');
		$editor = as_load_editor($content, $format, $editorname);

		$form['fields']['content'] = array_merge($form['fields']['content'],
			as_editor_load_field($editor, $as_content, $content, $format, 'q_content', 12, true));

		if (method_exists($editor, 'update_script'))
			$form['buttons']['save']['tags'] = 'onclick="as_show_waiting_after(this, false); ' . $editor->update_script('q_content') . '"';

		$form['hidden']['q_editor'] = as_html($editorname);

	} else
		unset($form['fields']['content']);

	if (as_using_departments() && count($departments) && $article['retagcatable']) {
		as_set_up_department_field($as_content, $form['fields']['department'], 'q_department', $departments,
			isset($in['departmentid']) ? $in['departmentid'] : $article['departmentid'],
			as_opt('allow_no_department') || !isset($article['departmentid']), as_opt('allow_no_sub_department'));
	} else {
		unset($form['fields']['department']);
	}

	if (!($article['editable'] && as_opt('extra_field_active')))
		unset($form['fields']['extra']);

	if (as_using_tags() && $article['retagcatable']) {
		as_set_up_tag_field($as_content, $form['fields']['tags'], 'q_tags', isset($in['tags']) ? $in['tags'] : as_tagstring_to_tags($article['tags']),
			array(), $completetags, as_opt('page_size_write_tags'));
	} else {
		unset($form['fields']['tags']);
	}

	if ($article['isbymember']) {
		if (!as_is_logged_in() && as_opt('allow_anonymous_naming'))
			as_set_up_name_field($as_content, $form['fields'], isset($in['name']) ? $in['name'] : @$article['name'], 'q_');

		as_set_up_notify_fields($as_content, $form['fields'], 'Q', as_get_logged_in_email(),
			isset($in['notify']) ? $in['notify'] : !empty($article['notify']),
			isset($in['email']) ? $in['email'] : @$article['notify'], @$errors['email'], 'q_');
	}

	if (!as_member_post_permit_error('permit_edit_silent', $article)) {
		$form['fields']['silent'] = array(
			'type' => 'checkbox',
			'label' => as_lang_html('article/save_silent_label'),
			'tags' => 'name="q_silent"',
			'value' => as_html(@$in['silent']),
		);
	}

	return $form;
}


/*
	Processes a POSTed form for editing the article and returns true if successful
*/
function as_page_q_edit_q_submit($article, $answers, $commentsfollows, $closepost, &$in, &$errors)
{
	$in = array();

	if ($article['editable']) {
		$in['title'] = as_get_post_title('q_title');
		as_get_post_content('q_editor', 'q_content', $in['editor'], $in['content'], $in['format'], $in['text']);
		$in['extra'] = as_opt('extra_field_active') ? as_post_text('q_extra') : null;
	}

	if ($article['retagcatable']) {
		if (as_using_tags())
			$in['tags'] = as_get_tags_field_value('q_tags');

		if (as_using_departments())
			$in['departmentid'] = as_get_department_field_value('q_department');
	}

	if (array_key_exists('departmentid', $in)) { // need to check if we can move it to that department, and if we need moderation
		$departments = as_db_select_with_pending(as_db_department_nav_selectspec($in['departmentid'], true));
		$departmentids = array_keys(as_department_path($departments, $in['departmentid']));
		$memberlevel = as_member_level_for_departments($departmentids);

	} else
		$memberlevel = null;

	if ($article['isbymember']) {
		$in['name'] = as_opt('allow_anonymous_naming') ? as_post_text('q_name') : null;
		$in['notify'] = as_post_text('q_notify') !== null;
		$in['email'] = as_post_text('q_email');
	}

	if (!as_member_post_permit_error('permit_edit_silent', $article))
		$in['silent'] = as_post_text('q_silent');

	// here the $in array only contains values for parts of the form that were displayed, so those are only ones checked by filters

	$errors = array();

	if (!as_check_form_security_code('edit-' . $article['postid'], as_post_text('code')))
		$errors['page'] = as_lang_html('misc/form_security_again');

	else {
		$in['queued'] = as_opt('moderate_edited_again') && as_member_moderation_reason($memberlevel);

		$filtermodules = as_load_modules_with('filter', 'filter_article');
		foreach ($filtermodules as $filtermodule) {
			$oldin = $in;
			$filtermodule->filter_article($in, $errors, $article);

			if ($article['editable'])
				as_update_post_text($in, $oldin);
		}

		if (array_key_exists('departmentid', $in) && strcmp($in['departmentid'], $article['departmentid'])) {
			if (as_member_permit_error('permit_post_q', null, $memberlevel))
				$errors['departmentid'] = as_lang_html('article/department_write_not_allowed');
		}

		if (empty($errors)) {
			$memberid = as_get_logged_in_memberid();
			$handle = as_get_logged_in_handle();
			$cookieid = as_cookie_get();

			// now we fill in the missing values in the $in array, so that we have everything we need for as_article_set_content()
			// we do things in this way to avoid any risk of a validation failure on elements the member can't see (e.g. due to admin setting changes)

			if (!$article['editable']) {
				$in['title'] = $article['title'];
				$in['content'] = $article['content'];
				$in['format'] = $article['format'];
				$in['text'] = as_viewer_text($in['content'], $in['format']);
				$in['extra'] = $article['extra'];
			}

			if (!isset($in['tags']))
				$in['tags'] = as_tagstring_to_tags($article['tags']);

			if (!array_key_exists('departmentid', $in))
				$in['departmentid'] = $article['departmentid'];

			if (!isset($in['silent']))
				$in['silent'] = false;

			$setnotify = $article['isbymember'] ? as_combine_notify_email($article['memberid'], $in['notify'], $in['email']) : $article['notify'];

			as_article_set_content($article, $in['title'], $in['content'], $in['format'], $in['text'], as_tags_to_tagstring($in['tags']),
				$setnotify, $memberid, $handle, $cookieid, $in['extra'], @$in['name'], $in['queued'], $in['silent']);

			if (as_using_departments() && strcmp($in['departmentid'], $article['departmentid'])) {
				as_article_set_department($article, $in['departmentid'], $memberid, $handle, $cookieid,
					$answers, $commentsfollows, $closepost, $in['silent']);
			}

			return true;
		}
	}

	return false;
}


/*
	Returns a $as_content form for closing the article and sets up other parts of $as_content accordingly
*/
function as_page_q_close_q_form(&$as_content, $article, $id, $in, $errors)
{
	$form = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',

		'id' => $id,

		'style' => 'tall',

		'title' => as_lang_html('article/close_form_title'),

		'fields' => array(
			'details' => array(
				'tags' => 'name="q_close_details" id="q_close_details"',
				'label' =>
					'<span id="close_label_other">' . as_lang_html('article/close_reason_title') . '</span>',
				'value' => @$in['details'],
				'error' => as_html(@$errors['details']),
			),
		),

		'buttons' => array(
			'close' => array(
				'tags' => 'onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html('article/close_form_button'),
			),

			'cancel' => array(
				'tags' => 'name="docancel"',
				'label' => as_lang_html('main/cancel_button'),
			),
		),

		'hidden' => array(
			'doclose' => '1',
			'code' => as_get_form_security_code('close-' . $article['postid']),
		),
	);

	$as_content['focusid'] = 'q_close_details';

	return $form;
}


/*
	Processes a POSTed form for closing the article and returns true if successful
*/
function as_page_q_close_q_submit($article, $closepost, &$in, &$errors)
{
	$in = array(
		'details' => trim(as_post_text('q_close_details')),
	);

	$memberid = as_get_logged_in_memberid();
	$handle = as_get_logged_in_handle();
	$cookieid = as_cookie_get();

	$sanitizedUrl = filter_var($in['details'], FILTER_SANITIZE_URL);
	$isduplicateurl = filter_var($sanitizedUrl, FILTER_VALIDATE_URL);

	if (!as_check_form_security_code('close-' . $article['postid'], as_post_text('code'))) {
		$errors['details'] = as_lang_html('misc/form_security_again');
	} elseif ($isduplicateurl) {
		// be liberal in what we accept, but there are two potential unlikely pitfalls here:
		// a) URLs could have a fixed numerical path, e.g. http://as.mysite.com/1/478/...
		// b) There could be a article title which is just a number, e.g. http://as.mysite.com/478/12345/...
		// so we check if more than one article could match, and if so, show an error

		$parts = preg_split('|[=/&]|', $sanitizedUrl, -1, PREG_SPLIT_NO_EMPTY);
		$keypostids = array();

		foreach ($parts as $part) {
			if (preg_match('/^[0-9]+$/', $part))
				$keypostids[$part] = true;
		}

		$articleids = as_db_posts_filter_q_postids(array_keys($keypostids));

		if (count($articleids) == 1 && $articleids[0] != $article['postid']) {
			as_article_close_duplicate($article, $closepost, $articleids[0], $memberid, $handle, $cookieid);
			return true;

		} else
			$errors['details'] = as_lang('article/close_duplicate_error');

	} else {
		if (strlen($in['details']) > 0) {
			as_article_close_other($article, $closepost, $in['details'], $memberid, $handle, $cookieid);
			return true;

		} else
			$errors['details'] = as_lang('main/field_required');
	}

	return false;
}


/*
	Returns a $as_content form for editing an answer and sets up other parts of $as_content accordingly
*/
function as_page_q_edit_a_form(&$as_content, $id, $answer, $article, $answers, $commentsfollows, $in, $errors)
{
	require_once AS_INCLUDE_DIR . 'util/string.php';

	$answerid = $answer['postid'];
	$prefix = 'a' . $answerid . '_';

	$content = isset($in['content']) ? $in['content'] : $answer['content'];
	$format = isset($in['format']) ? $in['format'] : $answer['format'];

	$editorname = isset($in['editor']) ? $in['editor'] : as_opt('editor_for_as');
	$editor = as_load_editor($content, $format, $editorname);

	$hascomments = false;
	foreach ($commentsfollows as $commentfollow) {
		if ($commentfollow['parentid'] == $answerid)
			$hascomments = true;
	}

	$form = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',

		'id' => $id,

		'title' => as_lang_html('article/edit_a_title'),

		'style' => 'tall',

		'fields' => array(
			'content' => array_merge(
				as_editor_load_field($editor, $as_content, $content, $format, $prefix . 'content', 12),
				array(
					'error' => as_html(@$errors['content']),
				)
			),
		),

		'buttons' => array(
			'save' => array(
				'tags' => 'onclick="as_show_waiting_after(this, false); ' .
					(method_exists($editor, 'update_script') ? $editor->update_script($prefix . 'content') : '') . '"',
				'label' => as_lang_html('main/save_button'),
			),

			'cancel' => array(
				'tags' => 'name="docancel"',
				'label' => as_lang_html('main/cancel_button'),
			),
		),

		'hidden' => array(
			$prefix . 'editor' => as_html($editorname),
			$prefix . 'dosave' => '1',
			$prefix . 'code' => as_get_form_security_code('edit-' . $answerid),
		),
	);

	// Show option to convert this answer to a comment, if appropriate

	$commentonoptions = array();

	$lastbeforeid = $article['postid']; // used to find last post created before this answer - this is default given
	$lastbeforetime = $article['created'];

	if ($article['commentable']) {
		$commentonoptions[$article['postid']] =
			as_lang_html('article/comment_on_q') . as_html(as_shorten_string_line($article['title'], 80));
	}

	foreach ($answers as $otheranswer) {
		if ($otheranswer['postid'] != $answerid && $otheranswer['created'] < $answer['created'] && $otheranswer['commentable'] && !$otheranswer['hidden']) {
			$commentonoptions[$otheranswer['postid']] =
				as_lang_html('article/comment_on_a') . as_html(as_shorten_string_line(as_viewer_text($otheranswer['content'], $otheranswer['format']), 80));

			if ($otheranswer['created'] > $lastbeforetime) {
				$lastbeforeid = $otheranswer['postid'];
				$lastbeforetime = $otheranswer['created'];
			}
		}
	}

	if (count($commentonoptions)) {
		$form['fields']['tocomment'] = array(
			'tags' => 'name="' . $prefix . 'dotoc" id="' . $prefix . 'dotoc"',
			'label' => '<span id="' . $prefix . 'toshown">' . as_lang_html('article/a_convert_to_c_on') . '</span>' .
				'<span id="' . $prefix . 'tohidden" style="display:none;">' . as_lang_html('article/a_convert_to_c') . '</span>',
			'type' => 'checkbox',
			'tight' => true,
		);

		$form['fields']['commenton'] = array(
			'tags' => 'name="' . $prefix . 'commenton"',
			'id' => $prefix . 'commenton',
			'type' => 'select',
			'note' => as_lang_html($hascomments ? 'article/a_convert_warn_cs' : 'article/a_convert_warn'),
			'options' => $commentonoptions,
			'value' => @$commentonoptions[$lastbeforeid],
		);

		as_set_display_rules($as_content, array(
			$prefix . 'commenton' => $prefix . 'dotoc',
			$prefix . 'toshown' => $prefix . 'dotoc',
			$prefix . 'tohidden' => '!' . $prefix . 'dotoc',
		));
	}

	// Show name and notification field if appropriate

	if ($answer['isbymember']) {
		if (!as_is_logged_in() && as_opt('allow_anonymous_naming'))
			as_set_up_name_field($as_content, $form['fields'], isset($in['name']) ? $in['name'] : @$answer['name'], $prefix);

		as_set_up_notify_fields($as_content, $form['fields'], 'A', as_get_logged_in_email(),
			isset($in['notify']) ? $in['notify'] : !empty($answer['notify']),
			isset($in['email']) ? $in['email'] : @$answer['notify'], @$errors['email'], $prefix);
	}

	if (!as_member_post_permit_error('permit_edit_silent', $answer)) {
		$form['fields']['silent'] = array(
			'type' => 'checkbox',
			'label' => as_lang_html('article/save_silent_label'),
			'tags' => 'name="' . $prefix . 'silent"',
			'value' => as_html(@$in['silent']),
		);
	}

	return $form;
}


/*
	Processes a POSTed form for editing an answer and returns the new type of the post if successful
*/
function as_page_q_edit_a_submit($answer, $article, $answers, $commentsfollows, &$in, &$errors)
{
	$answerid = $answer['postid'];
	$prefix = 'a' . $answerid . '_';

	$in = array(
		'dotoc' => as_post_text($prefix . 'dotoc'),
		'commenton' => as_post_text($prefix . 'commenton'),
	);

	if ($answer['isbymember']) {
		$in['name'] = as_opt('allow_anonymous_naming') ? as_post_text($prefix . 'name') : null;
		$in['notify'] = as_post_text($prefix . 'notify') !== null;
		$in['email'] = as_post_text($prefix . 'email');
	}

	if (!as_member_post_permit_error('permit_edit_silent', $answer))
		$in['silent'] = as_post_text($prefix . 'silent');

	as_get_post_content($prefix . 'editor', $prefix . 'content', $in['editor'], $in['content'], $in['format'], $in['text']);

	// here the $in array only contains values for parts of the form that were displayed, so those are only ones checked by filters

	$errors = array();

	if (!as_check_form_security_code('edit-' . $answerid, as_post_text($prefix . 'code')))
		$errors['content'] = as_lang_html('misc/form_security_again');

	else {
		$in['queued'] = as_opt('moderate_edited_again') && as_member_moderation_reason(as_member_level_for_post($answer));

		$filtermodules = as_load_modules_with('filter', 'filter_answer');
		foreach ($filtermodules as $filtermodule) {
			$oldin = $in;
			$filtermodule->filter_answer($in, $errors, $article, $answer);
			as_update_post_text($in, $oldin);
		}

		if (empty($errors)) {
			$memberid = as_get_logged_in_memberid();
			$handle = as_get_logged_in_handle();
			$cookieid = as_cookie_get();

			if (!isset($in['silent']))
				$in['silent'] = false;

			$setnotify = $answer['isbymember'] ? as_combine_notify_email($answer['memberid'], $in['notify'], $in['email']) : $answer['notify'];

			if ($in['dotoc'] && (
					(($in['commenton'] == $article['postid']) && $article['commentable']) ||
					(($in['commenton'] != $answerid) && @$answers[$in['commenton']]['commentable'])
				)
			) { // convert to a comment

				if (as_member_limits_remaining(AS_LIMIT_COMMENTS)) { // already checked 'permit_post_c'
					as_answer_to_comment($answer, $in['commenton'], $in['content'], $in['format'], $in['text'], $setnotify,
						$memberid, $handle, $cookieid, $article, $answers, $commentsfollows, @$in['name'], $in['queued'], $in['silent']);

					return 'C'; // to signify that redirect should be to the comment

				} else
					$errors['content'] = as_lang_html('article/comment_limit'); // not really best place for error, but it will do

			} else {
				as_answer_set_content($answer, $in['content'], $in['format'], $in['text'], $setnotify,
					$memberid, $handle, $cookieid, $article, @$in['name'], $in['queued'], $in['silent']);

				return 'A';
			}
		}
	}

	return null;
}


/*
	Processes a request to add a comment to $parent, with antecedent $article, checking for permissions errors
*/
function as_page_q_do_comment($article, $parent, $commentsfollows, $pagestart, $usecaptcha, &$cnewin, &$cnewerrors, &$formtype, &$formpostid, &$error)
{
	// The 'approve', 'login', 'confirm', 'memberblock', 'ipblock' permission errors are reported to the member here
	// The other option ('level') prevents the comment button being shown, in as_page_q_post_rules(...)

	$parentid = $parent['postid'];

	switch (as_member_post_permit_error('permit_post_c', $parent, AS_LIMIT_COMMENTS)) {
		case 'login':
			$error = as_insert_login_links(as_lang_html('article/comment_must_login'), as_request());
			break;

		case 'confirm':
			$error = as_insert_login_links(as_lang_html('article/comment_must_confirm'), as_request());
			break;

		case 'approve':
			$error = strtr(as_lang_html('article/comment_must_be_approved'), array(
				'^1' => '<a href="' . as_path_html('account') . '">',
				'^2' => '</a>',
			));
			break;

		case 'limit':
			$error = as_lang_html('article/comment_limit');
			break;

		default:
			$error = as_lang_html('members/no_permission');
			break;

		case false:
			if (as_clicked('c' . $parentid . '_doadd')) {
				$commentid = as_page_q_add_c_submit($article, $parent, $commentsfollows, $usecaptcha, $cnewin[$parentid], $cnewerrors[$parentid]);

				if (isset($commentid))
					as_page_q_refresh($pagestart, null, 'C', $commentid);

				else {
					$formtype = 'c_add';
					$formpostid = $parentid; // show form again
				}

			} else {
				$formtype = 'c_add';
				$formpostid = $parentid; // show form first time
			}
			break;
	}
}


/*
	Returns a $as_content form for editing a comment and sets up other parts of $as_content accordingly
*/
function as_page_q_edit_c_form(&$as_content, $id, $comment, $in, $errors)
{
	$commentid = $comment['postid'];
	$prefix = 'c' . $commentid . '_';

	$content = isset($in['content']) ? $in['content'] : $comment['content'];
	$format = isset($in['format']) ? $in['format'] : $comment['format'];

	$editorname = isset($in['editor']) ? $in['editor'] : as_opt('editor_for_cs');
	$editor = as_load_editor($content, $format, $editorname);

	$form = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',

		'id' => $id,

		'title' => as_lang_html('article/edit_c_title'),

		'style' => 'tall',

		'fields' => array(
			'content' => array_merge(
				as_editor_load_field($editor, $as_content, $content, $format, $prefix . 'content', 4, true),
				array(
					'error' => as_html(@$errors['content']),
				)
			),
		),

		'buttons' => array(
			'save' => array(
				'tags' => 'onclick="as_show_waiting_after(this, false); ' .
					(method_exists($editor, 'update_script') ? $editor->update_script($prefix . 'content') : '') . '"',
				'label' => as_lang_html('main/save_button'),
			),

			'cancel' => array(
				'tags' => 'name="docancel"',
				'label' => as_lang_html('main/cancel_button'),
			),
		),

		'hidden' => array(
			$prefix . 'editor' => as_html($editorname),
			$prefix . 'dosave' => '1',
			$prefix . 'code' => as_get_form_security_code('edit-' . $commentid),
		),
	);

	if ($comment['isbymember']) {
		if (!as_is_logged_in() && as_opt('allow_anonymous_naming'))
			as_set_up_name_field($as_content, $form['fields'], isset($in['name']) ? $in['name'] : @$comment['name'], $prefix);

		as_set_up_notify_fields($as_content, $form['fields'], 'C', as_get_logged_in_email(),
			isset($in['notify']) ? $in['notify'] : !empty($comment['notify']),
			isset($in['email']) ? $in['email'] : @$comment['notify'], @$errors['email'], $prefix);
	}

	if (!as_member_post_permit_error('permit_edit_silent', $comment)) {
		$form['fields']['silent'] = array(
			'type' => 'checkbox',
			'label' => as_lang_html('article/save_silent_label'),
			'tags' => 'name="' . $prefix . 'silent"',
			'value' => as_html(@$in['silent']),
		);
	}

	return $form;
}


/*
	Processes a POSTed form for editing a comment and returns true if successful
*/
function as_page_q_edit_c_submit($comment, $article, $parent, &$in, &$errors)
{
	$commentid = $comment['postid'];
	$prefix = 'c' . $commentid . '_';

	$in = array();

	if ($comment['isbymember']) {
		$in['name'] = as_opt('allow_anonymous_naming') ? as_post_text($prefix . 'name') : null;
		$in['notify'] = as_post_text($prefix . 'notify') !== null;
		$in['email'] = as_post_text($prefix . 'email');
	}

	if (!as_member_post_permit_error('permit_edit_silent', $comment))
		$in['silent'] = as_post_text($prefix . 'silent');

	as_get_post_content($prefix . 'editor', $prefix . 'content', $in['editor'], $in['content'], $in['format'], $in['text']);

	// here the $in array only contains values for parts of the form that were displayed, so those are only ones checked by filters

	$errors = array();

	if (!as_check_form_security_code('edit-' . $commentid, as_post_text($prefix . 'code')))
		$errors['content'] = as_lang_html('misc/form_security_again');

	else {
		$in['queued'] = as_opt('moderate_edited_again') && as_member_moderation_reason(as_member_level_for_post($comment));

		$filtermodules = as_load_modules_with('filter', 'filter_comment');
		foreach ($filtermodules as $filtermodule) {
			$oldin = $in;
			$filtermodule->filter_comment($in, $errors, $article, $parent, $comment);
			as_update_post_text($in, $oldin);
		}

		if (empty($errors)) {
			$memberid = as_get_logged_in_memberid();
			$handle = as_get_logged_in_handle();
			$cookieid = as_cookie_get();

			if (!isset($in['silent']))
				$in['silent'] = false;

			$setnotify = $comment['isbymember'] ? as_combine_notify_email($comment['memberid'], $in['notify'], $in['email']) : $comment['notify'];

			as_comment_set_content($comment, $in['content'], $in['format'], $in['text'], $setnotify,
				$memberid, $handle, $cookieid, $article, $parent, @$in['name'], $in['queued'], $in['silent']);

			return true;
		}
	}

	return false;
}
