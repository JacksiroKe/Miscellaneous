<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for page showing members who have been blocked


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/members.php';
require_once AS_INCLUDE_DIR . 'app/format.php';


// Check we're not using single-sign on integration

if (AS_FINAL_EXTERNAL_MEMBERS) {
	as_fatal_error('Member accounts are handled by external code');
}


// Get list of blocked members

$start = as_get_start();
$pagesize = as_opt('page_size_members');

$memberSpecCount = as_db_selectspec_count(as_db_members_with_flag_selectspec(AS_MEMBER_FLAGS_MEMBER_BLOCKED));
$memberSpec = as_db_members_with_flag_selectspec(AS_MEMBER_FLAGS_MEMBER_BLOCKED, $start, $pagesize);

list($numMembers, $members) = as_db_select_with_pending($memberSpecCount, $memberSpec);
$count = $numMembers['count'];


// Check we have permission to view this page (moderator or above)

if (as_get_logged_in_level() < AS_MEMBER_LEVEL_MODERATOR) {
	$as_content = as_content_prepare();
	$as_content['error'] = as_lang_html('members/no_permission');
	return $as_content;
}


// Get memberids and handles of retrieved members

$membershtml = as_memberids_handles_html($members);


// Prepare content for theme

$as_content = as_content_prepare();

$as_content['title'] = $count > 0 ? as_lang_html('members/blocked_members') : as_lang_html('members/no_blocked_members');

$as_content['ranking'] = array(
	'items' => array(),
	'rows' => ceil(count($members) / as_opt('columns_members')),
	'type' => 'members',
	'sort' => 'level',
);

foreach ($members as $member) {
	$as_content['ranking']['items'][] = array(
		'label' => $membershtml[$member['memberid']],
		'score' => as_html(as_member_level_string($member['level'])),
		'raw' => $member,
	);
}

$as_content['page_links'] = as_html_page_links(as_request(), $start, $pagesize, $count, as_opt('pages_prev_next'));

$as_content['navigation']['sub'] = as_members_sub_navigation();


return $as_content;
