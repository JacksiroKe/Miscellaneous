<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	File: as-include/pages/members-newest.php
	Description: Controller for newest members page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';

// Check we're not using single-sign on integration

if (AS_FINAL_EXTERNAL_MEMBERS) {
	as_fatal_error('Member accounts are handled by external code');
}


// Check we have permission to view this page (moderator or above)

if (as_member_permit_error('permit_view_new_members_page')) {
	$as_content = as_content_prepare();
	$as_content['error'] = as_lang_html('members/no_permission');
	return $as_content;
}


// Get list of all members

$start = as_get_start();
$members = as_db_select_with_pending(as_db_newest_members_selectspec($start, as_opt_if_loaded('page_size_members')));

$memberCount = as_opt('cache_memberpointscount');
$pageSize = as_opt('page_size_members');
$members = array_slice($members, 0, $pageSize);
$membersHtml = as_memberids_handles_html($members);

// Prepare content for theme

$as_content = as_content_prepare();

$as_content['title'] = as_lang_html('main/newest_members');

$as_content['ranking'] = array(
	'items' => array(),
	'rows' => ceil($pageSize / as_opt('columns_members')),
	'type' => 'members',
	'sort' => 'date',
);

if (!empty($members)) {
	foreach ($members as $member) {
		$avatarHtml = as_get_member_avatar_html($member['flags'], $member['email'], $member['handle'],
			$member['avatarblobid'], $member['avatarwidth'], $member['avatarheight'], as_opt('avatar_members_size'), true);

		$when = as_when_to_html($member['created'], 7);
		$as_content['ranking']['items'][] = array(
			'avatar' => $avatarHtml,
			'label' => $membersHtml[$member['memberid']],
			'score' => $when['data'],
			'raw' => $member,
		);
	}
} else {
	$as_content['title'] = as_lang_html('main/no_active_members');
}

$as_content['canonical'] = as_get_canonical();

$as_content['page_links'] = as_html_page_links(as_request(), $start, $pageSize, $memberCount, as_opt('pages_prev_next'));

$as_content['navigation']['sub'] = as_members_sub_navigation();


return $as_content;
