<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for member account page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/members.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/members.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'util/image.php';


// Check we're not using single-sign on integration, that we're logged in

if (AS_FINAL_EXTERNAL_MEMBERS)
	as_fatal_error('Member accounts are handled by external code');

$memberid = as_get_logged_in_memberid();

if (!isset($memberid))
	as_redirect('login');


// Get current information on member

list($memberaccount, $memberprofile, $memberpoints, $memberfields) = as_db_select_with_pending(
	as_db_member_account_selectspec($memberid, true),
	as_db_member_profile_selectspec($memberid, true),
	as_db_member_points_selectspec($memberid, true),
	as_db_memberfields_selectspec()
);

$changehandle = as_opt('allow_change_usernames') || (!$memberpoints['qposts'] && !$memberpoints['aposts'] && !$memberpoints['cposts']);
$doconfirms = as_opt('confirm_member_emails') && $memberaccount['level'] < AS_MEMBER_LEVEL_WRITER;
$isconfirmed = ($memberaccount['flags'] & AS_MEMBER_FLAGS_EMAIL_CONFIRMED) ? true : false;

$haspasswordold = isset($memberaccount['passsalt']) && isset($memberaccount['passcheck']);
if (AS_PASSWORD_HASH) {
	$haspassword = isset($memberaccount['passhash']);
} else {
	$haspassword = $haspasswordold;
}
$permit_error = as_member_permit_error();
$isblocked = $permit_error !== false;
$pending_confirmation = $doconfirms && $permit_error == 'confirm';

// Process profile if saved

// If the post_max_size is exceeded then the $_POST array is empty so no field processing can be done
if (as_post_limit_exceeded())
	$errors['avatar'] = as_lang('main/file_upload_limit_exceeded');
else {
	require_once AS_INCLUDE_DIR . 'app/members-edit.php';

	if (as_clicked('dosaveprofile') && !$isblocked) {
		$inhandle = $changehandle ? as_post_text('handle') : $memberaccount['handle'];
		$inemail = as_post_text('email');
		$inmessages = as_post_text('messages');
		$inwallposts = as_post_text('wall');
		$inmailings = as_post_text('mailings');
		$inavatar = as_post_text('avatar');

		$inprofile = array();
		foreach ($memberfields as $memberfield)
			$inprofile[$memberfield['fieldid']] = as_post_text('field_' . $memberfield['fieldid']);

		if (!as_check_form_security_code('account', as_post_text('code')))
			$errors['page'] = as_lang_html('misc/form_security_again');
		else {
			$errors = as_handle_email_filter($inhandle, $inemail, $memberaccount);

			if (!isset($errors['handle']))
				as_db_member_set($memberid, 'handle', $inhandle);

			if (!isset($errors['email']) && $inemail !== $memberaccount['email']) {
				as_db_member_set($memberid, 'email', $inemail);
				as_db_member_set_flag($memberid, AS_MEMBER_FLAGS_EMAIL_CONFIRMED, false);
				$isconfirmed = false;

				if ($doconfirms)
					as_send_new_confirm($memberid);
			}

			if (as_opt('allow_private_messages'))
				as_db_member_set_flag($memberid, AS_MEMBER_FLAGS_NO_MESSAGES, !$inmessages);

			if (as_opt('allow_member_walls'))
				as_db_member_set_flag($memberid, AS_MEMBER_FLAGS_NO_WALL_POSTS, !$inwallposts);

			if (as_opt('mailing_enabled'))
				as_db_member_set_flag($memberid, AS_MEMBER_FLAGS_NO_MAILINGS, !$inmailings);

			as_db_member_set_flag($memberid, AS_MEMBER_FLAGS_SHOW_AVATAR, ($inavatar == 'uploaded'));
			as_db_member_set_flag($memberid, AS_MEMBER_FLAGS_SHOW_GRAVATAR, ($inavatar == 'gravatar'));

			if (is_array(@$_FILES['file'])) {
				$avatarfileerror = $_FILES['file']['error'];

				// Note if $_FILES['file']['error'] === 1 then upload_max_filesize has been exceeded
				if ($avatarfileerror === 1)
					$errors['avatar'] = as_lang('main/file_upload_limit_exceeded');
				elseif ($avatarfileerror === 0 && $_FILES['file']['size'] > 0) {
					require_once AS_INCLUDE_DIR . 'app/limits.php';

					switch (as_member_permit_error(null, AS_LIMIT_UPLOADS)) {
						case 'limit':
							$errors['avatar'] = as_lang('main/upload_limit');
							break;

						default:
							$errors['avatar'] = as_lang('members/no_permission');
							break;

						case false:
							as_limits_increment($memberid, AS_LIMIT_UPLOADS);
							$toobig = as_image_file_too_big($_FILES['file']['tmp_name'], as_opt('avatar_store_size'));

							if ($toobig)
								$errors['avatar'] = as_lang_sub('main/image_too_big_x_pc', (int)($toobig * 100));
							elseif (!as_set_member_avatar($memberid, file_get_contents($_FILES['file']['tmp_name']), $memberaccount['avatarblobid']))
								$errors['avatar'] = as_lang_sub('main/image_not_read', implode(', ', as_gd_image_formats()));
							break;
					}
				}  // There shouldn't be any need to catch any other error
			}

			if (count($inprofile)) {
				$filtermodules = as_load_modules_with('filter', 'filter_profile');
				foreach ($filtermodules as $filtermodule)
					$filtermodule->filter_profile($inprofile, $errors, $memberaccount, $memberprofile);
			}

			foreach ($memberfields as $memberfield) {
				if (!isset($errors[$memberfield['fieldid']]))
					as_db_member_profile_set($memberid, $memberfield['title'], $inprofile[$memberfield['fieldid']]);
			}

			list($memberaccount, $memberprofile) = as_db_select_with_pending(
				as_db_member_account_selectspec($memberid, true), as_db_member_profile_selectspec($memberid, true)
			);

			as_report_event('u_save', $memberid, $memberaccount['handle'], as_cookie_get());

			if (empty($errors))
				as_redirect('account', array('state' => 'profile-saved'));

			as_logged_in_member_flush();
		}
	} elseif (as_clicked('dosaveprofile') && $pending_confirmation) {
		// only allow member to update email if they are not confirmed yet
		$inemail = as_post_text('email');

		if (!as_check_form_security_code('account', as_post_text('code')))
			$errors['page'] = as_lang_html('misc/form_security_again');

		else {
			$errors = as_handle_email_filter($memberaccount['handle'], $inemail, $memberaccount);

			if (!isset($errors['email']) && $inemail !== $memberaccount['email']) {
				as_db_member_set($memberid, 'email', $inemail);
				as_db_member_set_flag($memberid, AS_MEMBER_FLAGS_EMAIL_CONFIRMED, false);
				$isconfirmed = false;

				if ($doconfirms)
					as_send_new_confirm($memberid);
			}

			as_report_event('u_save', $memberid, $memberaccount['handle'], as_cookie_get());

			if (empty($errors))
				as_redirect('account', array('state' => 'profile-saved'));

			as_logged_in_member_flush();
		}
	}


	// Process change password if clicked

	if (as_clicked('dochangepassword')) {
		$inoldpassword = as_post_text('oldpassword');
		$innewpassword1 = as_post_text('newpassword1');
		$innewpassword2 = as_post_text('newpassword2');

		if (!as_check_form_security_code('password', as_post_text('code')))
			$errors['page'] = as_lang_html('misc/form_security_again');
		else {
			$errors = array();
			$legacyPassError = !hash_equals(strtolower($memberaccount['passcheck']), strtolower(as_db_calc_passcheck($inoldpassword, $memberaccount['passsalt'])));

			if (AS_PASSWORD_HASH) {
				$passError = !password_verify($inoldpassword, $memberaccount['passhash']);
				if (($haspasswordold && $legacyPassError) || (!$haspasswordold && $haspassword && $passError)) {
					$errors['oldpassword'] = as_lang('members/password_wrong');
				}
			} else {
				if ($haspassword && $legacyPassError) {
					$errors['oldpassword'] = as_lang('members/password_wrong');
				}
			}

			$memberaccount['password'] = $inoldpassword;
			$errors = $errors + as_password_validate($innewpassword1, $memberaccount); // array union

			if ($innewpassword1 != $innewpassword2)
				$errors['newpassword2'] = as_lang('members/password_mismatch');

			if (empty($errors)) {
				as_db_member_set_password($memberid, $innewpassword1);
				as_db_member_set($memberid, 'sessioncode', ''); // stop old 'Remember me' style logins from still working
				as_set_logged_in_member($memberid, $memberaccount['handle'], false, $memberaccount['sessionsource']); // reinstate this specific session

				as_report_event('u_password', $memberid, $memberaccount['handle'], as_cookie_get());

				as_redirect('account', array('state' => 'password-changed'));
			}
		}
	}
}

// Prepare content for theme

$as_content = as_content_prepare();

$as_content['title'] = as_lang_html('profile/my_account_title');
$as_content['error'] = @$errors['page'];

$as_content['form_profile'] = array(
	'tags' => 'enctype="multipart/form-data" method="post" action="' . as_self_html() . '"',

	'style' => 'wide',

	'fields' => array(
		'duration' => array(
			'type' => 'static',
			'label' => as_lang_html('members/member_for'),
			'value' => as_time_to_string(as_opt('db_time') - $memberaccount['created']),
		),

		'type' => array(
			'type' => 'static',
			'label' => as_lang_html('members/member_type'),
			'value' => as_html(as_member_level_string($memberaccount['level'])),
			'note' => $isblocked ? as_lang_html('members/member_blocked') : null,
		),

		'handle' => array(
			'label' => as_lang_html('members/handle_label'),
			'tags' => 'name="handle"',
			'value' => as_html(isset($inhandle) ? $inhandle : $memberaccount['handle']),
			'error' => as_html(@$errors['handle']),
			'type' => ($changehandle && !$isblocked) ? 'text' : 'static',
		),

		'email' => array(
			'label' => as_lang_html('members/email_label'),
			'tags' => 'name="email"',
			'value' => as_html(isset($inemail) ? $inemail : $memberaccount['email']),
			'error' => isset($errors['email']) ? as_html($errors['email']) :
				($pending_confirmation ? as_insert_login_links(as_lang_html('members/email_please_confirm')) : null),
			'type' => $pending_confirmation ? 'text' : ($isblocked ? 'static' : 'text'),
		),

		'messages' => array(
			'label' => as_lang_html('members/private_messages'),
			'tags' => 'name="messages"' . ($pending_confirmation ? ' disabled' : ''),
			'type' => 'checkbox',
			'value' => !($memberaccount['flags'] & AS_MEMBER_FLAGS_NO_MESSAGES),
			'note' => as_lang_html('members/private_messages_explanation'),
		),

		'wall' => array(
			'label' => as_lang_html('members/wall_posts'),
			'tags' => 'name="wall"' . ($pending_confirmation ? ' disabled' : ''),
			'type' => 'checkbox',
			'value' => !($memberaccount['flags'] & AS_MEMBER_FLAGS_NO_WALL_POSTS),
			'note' => as_lang_html('members/wall_posts_explanation'),
		),

		'mailings' => array(
			'label' => as_lang_html('members/mass_mailings'),
			'tags' => 'name="mailings"',
			'type' => 'checkbox',
			'value' => !($memberaccount['flags'] & AS_MEMBER_FLAGS_NO_MAILINGS),
			'note' => as_lang_html('members/mass_mailings_explanation'),
		),

		'avatar' => null, // for positioning
	),

	'buttons' => array(
		'save' => array(
			'tags' => 'onclick="as_show_waiting_after(this, false);"',
			'label' => as_lang_html('members/save_profile'),
		),
	),

	'hidden' => array(
		'dosaveprofile' => array(
			'tags' => 'name="dosaveprofile"',
			'value' => '1',
		),
		'code' => array(
			'tags' => 'name="code"',
			'value' => as_get_form_security_code('account'),
		),
	),
);

if (as_get_state() == 'profile-saved')
	$as_content['form_profile']['ok'] = as_lang_html('members/profile_saved');

if (!as_opt('allow_private_messages'))
	unset($as_content['form_profile']['fields']['messages']);

if (!as_opt('allow_member_walls'))
	unset($as_content['form_profile']['fields']['wall']);

if (!as_opt('mailing_enabled'))
	unset($as_content['form_profile']['fields']['mailings']);

if ($isblocked && !$pending_confirmation) {
	unset($as_content['form_profile']['buttons']['save']);
	$as_content['error'] = as_lang_html('members/no_permission');
}

// Avatar upload stuff

if (as_opt('avatar_allow_gravatar') || as_opt('avatar_allow_upload')) {
	$avataroptions = array();

	if (as_opt('avatar_default_show') && strlen(as_opt('avatar_default_blobid'))) {
		$avataroptions[''] = '<span style="margin:2px 0; display:inline-block;">' .
			as_get_avatar_blob_html(as_opt('avatar_default_blobid'), as_opt('avatar_default_width'), as_opt('avatar_default_height'), 32) .
			'</span> ' . as_lang_html('members/avatar_default');
	} else
		$avataroptions[''] = as_lang_html('members/avatar_none');

	$avatarvalue = $avataroptions[''];

	if (as_opt('avatar_allow_gravatar') && !$pending_confirmation) {
		$avataroptions['gravatar'] = '<span style="margin:2px 0; display:inline-block;">' .
			as_get_gravatar_html($memberaccount['email'], 32) . ' ' . strtr(as_lang_html('members/avatar_gravatar'), array(
				'^1' => '<a href="http://www.gravatar.com/" target="_blank">',
				'^2' => '</a>',
			)) . '</span>';

		if ($memberaccount['flags'] & AS_MEMBER_FLAGS_SHOW_GRAVATAR)
			$avatarvalue = $avataroptions['gravatar'];
	}

	if (as_has_gd_image() && as_opt('avatar_allow_upload') && !$pending_confirmation) {
		$avataroptions['uploaded'] = '<input name="file" type="file">';

		if (isset($memberaccount['avatarblobid']))
			$avataroptions['uploaded'] = '<span style="margin:2px 0; display:inline-block;">' .
				as_get_avatar_blob_html($memberaccount['avatarblobid'], $memberaccount['avatarwidth'], $memberaccount['avatarheight'], 32) .
				'</span>' . $avataroptions['uploaded'];

		if ($memberaccount['flags'] & AS_MEMBER_FLAGS_SHOW_AVATAR)
			$avatarvalue = $avataroptions['uploaded'];
	}

	$as_content['form_profile']['fields']['avatar'] = array(
		'type' => 'select-radio',
		'label' => as_lang_html('members/avatar_label'),
		'tags' => 'name="avatar"',
		'options' => $avataroptions,
		'value' => $avatarvalue,
		'error' => as_html(@$errors['avatar']),
	);

} else {
	unset($as_content['form_profile']['fields']['avatar']);
}


// Other profile fields

foreach ($memberfields as $memberfield) {
	$value = @$inprofile[$memberfield['fieldid']];
	if (!isset($value))
		$value = @$memberprofile[$memberfield['title']];

	$label = trim(as_member_memberfield_label($memberfield), ':');
	if (strlen($label))
		$label .= ':';

	$as_content['form_profile']['fields'][$memberfield['title']] = array(
		'label' => as_html($label),
		'tags' => 'name="field_' . $memberfield['fieldid'] . '"',
		'value' => as_html($value),
		'error' => as_html(@$errors[$memberfield['fieldid']]),
		'rows' => ($memberfield['flags'] & AS_FIELD_FLAGS_MULTI_LINE) ? 8 : null,
		'type' => $isblocked ? 'static' : 'text',
	);
}


// Raw information for plugin layers to access

$as_content['raw']['account'] = $memberaccount;
$as_content['raw']['profile'] = $memberprofile;
$as_content['raw']['points'] = $memberpoints;


// Change password form

$as_content['form_password'] = array(
	'tags' => 'method="post" action="' . as_self_html() . '"',

	'style' => 'wide',

	'title' => as_lang_html('members/change_password'),

	'fields' => array(
		'old' => array(
			'label' => as_lang_html('members/old_password'),
			'tags' => 'name="oldpassword"',
			'value' => as_html(@$inoldpassword),
			'type' => 'password',
			'error' => as_html(@$errors['oldpassword']),
		),

		'new_1' => array(
			'label' => as_lang_html('members/new_password_1'),
			'tags' => 'name="newpassword1"',
			'type' => 'password',
			'error' => as_html(@$errors['password']),
		),

		'new_2' => array(
			'label' => as_lang_html('members/new_password_2'),
			'tags' => 'name="newpassword2"',
			'type' => 'password',
			'error' => as_html(@$errors['newpassword2']),
		),
	),

	'buttons' => array(
		'change' => array(
			'label' => as_lang_html('members/change_password'),
		),
	),

	'hidden' => array(
		'dochangepassword' => array(
			'tags' => 'name="dochangepassword"',
			'value' => '1',
		),
		'code' => array(
			'tags' => 'name="code"',
			'value' => as_get_form_security_code('password'),
		),
	),
);

if (!$haspassword && !$haspasswordold) {
	$as_content['form_password']['fields']['old']['type'] = 'static';
	$as_content['form_password']['fields']['old']['value'] = as_lang_html('members/password_none');
}

if (as_get_state() == 'password-changed')
	$as_content['form_profile']['ok'] = as_lang_html('members/password_changed');


$as_content['navigation']['sub'] = as_member_sub_navigation($memberaccount['handle'], 'account', true);


return $as_content;
