<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for page listing recent articles without upvoted/selected/any answers


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/q-list.php';


// Get list of unanswered articles, allow per-department if AS_ALLOW_UNINDEXED_QUERIES set in as-config.php

if (AS_ALLOW_UNINDEXED_QUERIES)
	$departmentslugs = as_request_parts(1);
else
	$departmentslugs = null;

$countslugs = @count($departmentslugs);
$by = as_get('by');
$start = as_get_start();
$memberid = as_get_logged_in_memberid();

switch ($by) {
	case 'selected':
		$selectby = 'selchildid';
		break;

	case 'upvotes':
		$selectby = 'amaxvote';
		break;

	default:
		$selectby = 'acount';
		break;
}

list($articles, $departments, $departmentid) = as_db_select_with_pending(
	as_db_unanswered_qs_selectspec($memberid, $selectby, $start, $departmentslugs, false, false, as_opt_if_loaded('page_size_una_qs')),
	AS_ALLOW_UNINDEXED_QUERIES ? as_db_department_nav_selectspec($departmentslugs, false, false, true) : null,
	$countslugs ? as_db_slugs_to_department_id_selectspec($departmentslugs) : null
);

if ($countslugs) {
	if (!isset($departmentid))
		return include AS_INCLUDE_DIR . 'as-page-not-found.php';

	$departmenttitlehtml = as_html($departments[$departmentid]['title']);
}

$feedpathprefix = null;
$linkparams = array('by' => $by);

switch ($by) {
	case 'selected':
		if ($countslugs) {
			$sometitle = as_lang_html_sub('main/unselected_qs_in_x', $departmenttitlehtml);
			$nonetitle = as_lang_html_sub('main/no_una_articles_in_x', $departmenttitlehtml);

		} else {
			$sometitle = as_lang_html('main/unselected_qs_title');
			$nonetitle = as_lang_html('main/no_unselected_qs_found');
			$count = as_opt('cache_unselqcount');
		}
		break;

	case 'upvotes':
		if ($countslugs) {
			$sometitle = as_lang_html_sub('main/unupvoteda_qs_in_x', $departmenttitlehtml);
			$nonetitle = as_lang_html_sub('main/no_una_articles_in_x', $departmenttitlehtml);

		} else {
			$sometitle = as_lang_html('main/unupvoteda_qs_title');
			$nonetitle = as_lang_html('main/no_unupvoteda_qs_found');
			$count = as_opt('cache_unupaqcount');
		}
		break;

	default:
		$feedpathprefix = as_opt('feed_for_unanswered') ? 'unanswered' : null;
		$linkparams = array();

		if ($countslugs) {
			$sometitle = as_lang_html_sub('main/unanswered_qs_in_x', $departmenttitlehtml);
			$nonetitle = as_lang_html_sub('main/no_una_articles_in_x', $departmenttitlehtml);

		} else {
			$sometitle = as_lang_html('main/unanswered_qs_title');
			$nonetitle = as_lang_html('main/no_una_articles_found');
			$count = as_opt('cache_unaqcount');
		}
		break;
}


// Prepare and return content for theme

$as_content = as_q_list_page_content(
	$articles, // articles
	as_opt('page_size_una_qs'), // articles per page
	$start, // start offset
	@$count, // total count
	$sometitle, // title if some articles
	$nonetitle, // title if no articles
	AS_ALLOW_UNINDEXED_QUERIES ? $departments : array(), // departments for navigation (null if not shown on this page)
	AS_ALLOW_UNINDEXED_QUERIES ? $departmentid : null, // selected department id (null if not relevant)
	false, // show article counts in department navigation
	AS_ALLOW_UNINDEXED_QUERIES ? 'unanswered/' : null, // prefix for links in department navigation (null if no navigation)
	$feedpathprefix, // prefix for RSS feed paths (null to hide)
	as_html_suggest_qs_tags(as_using_tags()), // suggest what to do next
	$linkparams, // extra parameters for page links
	$linkparams // department nav params
);

$as_content['navigation']['sub'] = as_unanswered_sub_navigation($by, $departmentslugs);


return $as_content;
