<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for member profile page, including wall


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/limits.php';
require_once AS_INCLUDE_DIR . 'app/updates.php';


// $handle, $memberhtml are already set by /as-include/page/member.php - also $memberid if using external member integration


// Redirect to 'My Account' page if button clicked

if (as_clicked('doaccount')) as_redirect('account');

$start = as_get_start();
$state = as_get_state();
// Find the member profile and articles and answers for this handle


$loginmemberid = as_get_logged_in_memberid();
$identifier = AS_FINAL_EXTERNAL_MEMBERS ? $memberid : $handle;

list($memberaccount, $memberprofile, $memberfields, $membermessages, $memberpoints, $memberlevels, $navdepartments, $memberrank, $articles) =
	as_db_select_with_pending(
		AS_FINAL_EXTERNAL_MEMBERS ? null : as_db_member_account_selectspec($handle, false),
		AS_FINAL_EXTERNAL_MEMBERS ? null : as_db_member_profile_selectspec($handle, false),
		AS_FINAL_EXTERNAL_MEMBERS ? null : as_db_memberfields_selectspec(),
		AS_FINAL_EXTERNAL_MEMBERS ? null : as_db_recent_messages_selectspec(null, null, $handle, false, as_opt_if_loaded('page_size_wall')),
		as_db_member_points_selectspec($identifier),
		as_db_member_levels_selectspec($identifier, AS_FINAL_EXTERNAL_MEMBERS, true),
		as_db_department_nav_selectspec(null, true),
		as_db_member_rank_selectspec($identifier),
		as_db_member_recent_qs_selectspec($loginmemberid, $identifier, as_opt_if_loaded('page_size_qs'), $start)
	);

if (!AS_FINAL_EXTERNAL_MEMBERS && $handle !== as_get_logged_in_handle()) {
	foreach ($memberfields as $index => $memberfield) {
		if (isset($memberfield['permit']) && as_permit_value_error($memberfield['permit'], $loginmemberid, as_get_logged_in_level(), as_get_logged_in_flags()))
			unset($memberfields[$index]); // don't pay attention to member fields we're not allowed to view
	}
}


// Check the member exists and work out what can and can't be set (if not using single sign-on)

$errors = array();

$loginlevel = as_get_logged_in_level();

if (!AS_FINAL_EXTERNAL_MEMBERS) { // if we're using integrated member management, we can know and show more
	require_once AS_INCLUDE_DIR . 'app/messages.php';

	if (!is_array($memberpoints) && !is_array($memberaccount))
		return include AS_INCLUDE_DIR . 'as-page-not-found.php';

	$memberid = $memberaccount['memberid'];
	$fieldseditable = false;
	$maxlevelassign = null;

	$maxmemberlevel = $memberaccount['level'];
	foreach ($memberlevels as $memberlevel)
		$maxmemberlevel = max($maxmemberlevel, $memberlevel['level']);

	if (isset($loginmemberid) && $loginmemberid != $memberid &&
		($loginlevel >= AS_MEMBER_LEVEL_SUPER || $loginlevel > $maxmemberlevel) &&
		!as_member_permit_error()
	) { // can't change self - or someone on your level (or higher, obviously) unless you're a super admin

		if ($loginlevel >= AS_MEMBER_LEVEL_SUPER)
			$maxlevelassign = AS_MEMBER_LEVEL_SUPER;
		elseif ($loginlevel >= AS_MEMBER_LEVEL_ADMIN)
			$maxlevelassign = AS_MEMBER_LEVEL_MODERATOR;
		elseif ($loginlevel >= AS_MEMBER_LEVEL_MODERATOR)
			$maxlevelassign = AS_MEMBER_LEVEL_WRITER;

		if ($loginlevel >= AS_MEMBER_LEVEL_ADMIN)
			$fieldseditable = true;

		if (isset($maxlevelassign) && ($memberaccount['flags'] & AS_MEMBER_FLAGS_MEMBER_BLOCKED))
			$maxlevelassign = min($maxlevelassign, AS_MEMBER_LEVEL_EDITOR); // if blocked, can't promote too high
	}

	$approvebutton = isset($maxlevelassign)
		&& $memberaccount['level'] < AS_MEMBER_LEVEL_APPROVED
		&& $maxlevelassign >= AS_MEMBER_LEVEL_APPROVED
		&& !($memberaccount['flags'] & AS_MEMBER_FLAGS_MEMBER_BLOCKED)
		&& as_opt('moderate_members');
	$membereditbutton = $fieldseditable || isset($maxlevelassign);
	$memberediting = $membereditbutton && ($state == 'edit');

	$wallposterrorhtml = as_wall_error_html($loginmemberid, $memberaccount['memberid'], $memberaccount['flags']);

	// This code is similar but not identical to that in to qq-page-member-wall.php

	$membermessages = array_slice($membermessages, 0, as_opt('page_size_wall'));
	$membermessages = as_wall_posts_add_rules($membermessages, 0);

	foreach ($membermessages as $message) {
		if ($message['deleteable'] && as_clicked('m' . $message['messageid'] . '_dodelete')) {
			if (!as_check_form_security_code('wall-' . $memberaccount['handle'], as_post_text('code')))
				$errors['page'] = as_lang_html('misc/form_security_again');
			else {
				as_wall_delete_post($loginmemberid, as_get_logged_in_handle(), as_cookie_get(), $message);
				as_redirect(as_request(), null, null, null, 'wall');
			}
		}
	}
}

$pagesize = as_opt('page_size_qs');
$count = (int)@$memberpoints['qposts'];
$articles = array_slice($articles, 0, $pagesize);

// Process edit or save button for member, and other actions

if (!AS_FINAL_EXTERNAL_MEMBERS) {
	$reloadmember = false;

	if ($membereditbutton) {
		if (as_clicked('docancel')) {
			as_redirect(as_request());
		} elseif (as_clicked('doedit')) {
			as_redirect(as_request(), array('state' => 'edit'));
		} elseif (as_clicked('dosave')) {
			require_once AS_INCLUDE_DIR . 'app/members-edit.php';
			require_once AS_INCLUDE_DIR . 'db/members.php';

			$inemail = as_post_text('email');

			$inprofile = array();
			foreach ($memberfields as $memberfield)
				$inprofile[$memberfield['fieldid']] = as_post_text('field_' . $memberfield['fieldid']);

			if (!as_check_form_security_code('member-edit-' . $handle, as_post_text('code'))) {
				$errors['page'] = as_lang_html('misc/form_security_again');
				$memberediting = true;
			} else {
				if (as_post_text('removeavatar')) {
					as_db_member_set_flag($memberid, AS_MEMBER_FLAGS_SHOW_AVATAR, false);
					as_db_member_set_flag($memberid, AS_MEMBER_FLAGS_SHOW_GRAVATAR, false);

					if (isset($memberaccount['avatarblobid'])) {
						require_once AS_INCLUDE_DIR . 'app/blobs.php';

						as_db_member_set($memberid, 'avatarblobid', null);
						as_db_member_set($memberid, 'avatarwidth', null);
						as_db_member_set($memberid, 'avatarheight', null);
						as_delete_blob($memberaccount['avatarblobid']);
					}
				}

				if ($fieldseditable) {
					$filterhandle = $handle; // we're not filtering the handle...
					$errors = as_handle_email_filter($filterhandle, $inemail, $memberaccount);
					unset($errors['handle']); // ...and we don't care about any errors in it

					if (!isset($errors['email'])) {
						if ($inemail != $memberaccount['email']) {
							as_db_member_set($memberid, 'email', $inemail);
							as_db_member_set_flag($memberid, AS_MEMBER_FLAGS_EMAIL_CONFIRMED, false);
						}
					}

					if (count($inprofile)) {
						$filtermodules = as_load_modules_with('filter', 'filter_profile');
						foreach ($filtermodules as $filtermodule)
							$filtermodule->filter_profile($inprofile, $errors, $memberaccount, $memberprofile);
					}

					foreach ($memberfields as $memberfield) {
						if (!isset($errors[$memberfield['fieldid']]))
							as_db_member_profile_set($memberid, $memberfield['title'], $inprofile[$memberfield['fieldid']]);
					}

					if (count($errors))
						$memberediting = true;

					as_report_event('u_edit', $loginmemberid, as_get_logged_in_handle(), as_cookie_get(), array(
						'memberid' => $memberid,
						'handle' => $memberaccount['handle'],
					));
				}

				if (isset($maxlevelassign)) {
					$inlevel = min($maxlevelassign, (int)as_post_text('level')); // constrain based on maximum permitted to prevent simple browser-based attack
					if ($inlevel != $memberaccount['level']) {
						as_set_member_level($memberid, $memberaccount['handle'], $memberaccount['email'], $inlevel, $memberaccount['level']);
					}

					if (as_using_departments()) {
						$inmemberlevels = array();

						for ($index = 1; $index <= 999; $index++) {
							$inlevel = as_post_text('uc_' . $index . '_level');
							if (!isset($inlevel))
								break;

							$departmentid = as_get_department_field_value('uc_' . $index . '_cat');

							if (strlen($departmentid) && strlen($inlevel)) {
								$inmemberlevels[] = array(
									'entitytype' => AS_ENTITY_DEPARTMENT,
									'entityid' => $departmentid,
									'level' => min($maxlevelassign, (int)$inlevel),
								);
							}
						}

						as_db_member_levels_set($memberid, $inmemberlevels);
					}
				}

				if (empty($errors))
					as_redirect(as_request());

				list($memberaccount, $memberprofile, $memberlevels) = as_db_select_with_pending(
					as_db_member_account_selectspec($memberid, true),
					as_db_member_profile_selectspec($memberid, true),
					as_db_member_levels_selectspec($memberid, true, true)
				);
			}
		}
	}

	if (as_clicked('doapprove') || as_clicked('doblock') || as_clicked('dounblock') || as_clicked('dohideall') || as_clicked('dodelete')) {
		if (!as_check_form_security_code('member-' . $handle, as_post_text('code')))
			$errors['page'] = as_lang_html('misc/form_security_again');

		else {
			if ($approvebutton && as_clicked('doapprove')) {
				require_once AS_INCLUDE_DIR . 'app/members-edit.php';
				as_set_member_level($memberid, $memberaccount['handle'], AS_MEMBER_LEVEL_APPROVED, $memberaccount['level']);
				as_redirect(as_request());
			}

			if (isset($maxlevelassign) && ($maxmemberlevel < AS_MEMBER_LEVEL_MODERATOR)) {
				if (as_clicked('doblock')) {
					require_once AS_INCLUDE_DIR . 'app/members-edit.php';

					as_set_member_blocked($memberid, $memberaccount['handle'], true);
					as_redirect(as_request());
				}

				if (as_clicked('dounblock')) {
					require_once AS_INCLUDE_DIR . 'app/members-edit.php';

					as_set_member_blocked($memberid, $memberaccount['handle'], false);
					as_redirect(as_request());
				}

				if (as_clicked('dohideall') && !as_member_permit_error('permit_hide_show')) {
					require_once AS_INCLUDE_DIR . 'db/admin.php';
					require_once AS_INCLUDE_DIR . 'app/posts.php';

					$postids = as_db_get_member_visible_postids($memberid);

					foreach ($postids as $postid)
						as_post_set_status($postid, AS_POST_STATUS_HIDDEN, $loginmemberid);

					as_redirect(as_request());
				}

				if (as_clicked('dodelete') && ($loginlevel >= AS_MEMBER_LEVEL_ADMIN)) {
					require_once AS_INCLUDE_DIR . 'app/members-edit.php';

					as_delete_member($memberid);

					as_report_event('u_delete', $loginmemberid, as_get_logged_in_handle(), as_cookie_get(), array(
						'memberid' => $memberid,
						'handle' => $memberaccount['handle'],
					));

					as_redirect('members');
				}
			}
		}
	}


	if (as_clicked('dowallpost')) {
		$inmessage = as_post_text('message');

		if (!strlen($inmessage)) {
			$errors['message'] = as_lang('profile/post_wall_empty');
		} elseif (!as_check_form_security_code('wall-' . $memberaccount['handle'], as_post_text('code'))) {
			$errors['message'] = as_lang_html('misc/form_security_again');
		} elseif (!$wallposterrorhtml) {
			as_wall_add_post($loginmemberid, as_get_logged_in_handle(), as_cookie_get(), $memberid, $memberaccount['handle'], $inmessage, '');
			as_redirect(as_request(), null, null, null, 'wall');
		}
	}
}


// Process bonus setting button

if ($loginlevel >= AS_MEMBER_LEVEL_ADMIN && as_clicked('dosetbonus')) {
	require_once AS_INCLUDE_DIR . 'db/points.php';

	$inbonus = (int)as_post_text('bonus');

	if (!as_check_form_security_code('member-activity-' . $handle, as_post_text('code'))) {
		$errors['page'] = as_lang_html('misc/form_security_again');
	} else {
		as_db_points_set_bonus($memberid, $inbonus);
		as_db_points_update_ifmember($memberid, null);
		as_redirect(as_request(), null, null, null, 'activity');
	}
}


// Prepare content for theme

$as_content = as_content_prepare();
$memberaccount['member_name'] = as_html(as_get_member_name($memberhtml, false));
$as_content['title'] = $memberaccount['member_name'] . ' ('.$memberaccount['handle'].')';
$as_content['error'] = @$errors['page'];
$memberaccount['logedin_member'] = $loginmemberid;
$memberaccount['member_points'] = (@$memberpoints['points'] == 1)
				? as_lang_html_sub('main/1_point', '1', '1')
				: as_lang_html_sub('main/x_points', as_html(as_format_number(@$memberpoints['points'])));

if (isset($loginmemberid) && $loginmemberid != $memberaccount['memberid'] && !AS_FINAL_EXTERNAL_MEMBERS) {
	$favoritemap = as_get_favorite_non_qs_map();
	$favorite = @$favoritemap['member'][$memberaccount['memberid']];

	$as_content['favorite'] = as_favorite_form(AS_ENTITY_MEMBER, $memberaccount['memberid'], $favorite,
		as_lang_sub($favorite ? 'main/remove_x_favorites' : 'members/add_member_x_favorites', $handle));
}


// General information about the member, only available if we're using internal member management

if (!AS_FINAL_EXTERNAL_MEMBERS) {
	$membertime = as_time_to_string(as_opt('db_time') - $memberaccount['created']);
	$joindate = as_when_to_html($memberaccount['created'], 0);
	$hasavatar = as_get_member_avatar_html($memberaccount['flags'], $memberaccount['email'], $memberaccount['handle'], $memberaccount['avatarblobid'], $memberaccount['avatarwidth'], $memberaccount['avatarheight'], as_opt('avatar_profile_size'));
	$asavatar = '<img src="./as-media/member.png" width="200" height="200"/>';
	
	$memberaccount['member_avatar'] = $hasavatar ? $hasavatar  : $asavatar;
	$memberaccount['member_info']['country'] = as_lang_html('members/from_label').' '.$memberaccount['country'].' '.
		($memberaccount['sex'] == 1 ? ' ('.as_lang('members/sex_male').')' : ' ('.as_lang('members/sex_female').')');
	$memberaccount['member_info']['since_when'] = as_lang_html('members/member_for').' '.as_html($membertime . ' (' . as_lang_sub('main/since_x', $joindate['data']) . ')');

	$as_content['form_profile'] = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',

		'style' => 'wide',

		'fields' => array(
			'avatar' => array(
				'type' => 'image',
				'style' => 'tall',
				'label' => '',
				'html' => as_get_member_avatar_html($memberaccount['flags'], $memberaccount['email'], $memberaccount['handle'],
					$memberaccount['avatarblobid'], $memberaccount['avatarwidth'], $memberaccount['avatarheight'], as_opt('avatar_profile_size')),
				'id' => 'avatar',
			),

			'removeavatar' => null,

			'duration' => array(
				'type' => 'static',
				'label' => as_lang_html('members/member_for'),
				'value' => as_html($membertime . ' (' . as_lang_sub('main/since_x', $joindate['data']) . ')'),
				'id' => 'duration',
			),

			'level' => array(
				'type' => 'static',
				'label' => as_lang_html('members/member_type'),
				'tags' => 'name="level"',
				'value' => as_html(as_member_level_string($memberaccount['level'])),
				'note' => (($memberaccount['flags'] & AS_MEMBER_FLAGS_MEMBER_BLOCKED) && isset($maxlevelassign)) ? as_lang_html('members/member_blocked') : '',
				'id' => 'level',
			),
		),
	);

	$as_content['form_profile']['buttons'] = array();

	if (empty($as_content['form_profile']['fields']['avatar']['html']))
		unset($as_content['form_profile']['fields']['avatar']);


	// Private message link

	if (as_opt('allow_private_messages') && isset($loginmemberid) && $loginmemberid != $memberid && !($memberaccount['flags'] & AS_MEMBER_FLAGS_NO_MESSAGES) && !$memberediting) {
		$as_content['form_profile']['fields']['level']['value'] .= strtr(as_lang_html('profile/send_private_message'), array(
			'^1' => '<a href="' . as_path_html('message/' . $handle) . '">',
			'^2' => '</a>',
		));
		$memberaccount['private_message'] = strtr(as_lang_html('profile/send_private_message'), array(
			'^1' => '<a href="' . as_path_html('message/' . $handle) . '">',
			'^2' => '</a>',
		));
	}


	// Levels editing or viewing (add department-specific levels)

	if ($memberediting) {
		if (isset($maxlevelassign)) {
			$as_content['form_profile']['fields']['level']['type'] = 'select';

			$showlevels = array(AS_MEMBER_LEVEL_BASIC);
			if (as_opt('moderate_members'))
				$showlevels[] = AS_MEMBER_LEVEL_APPROVED;

			array_push($showlevels, AS_MEMBER_LEVEL_WRITER, AS_MEMBER_LEVEL_EDITOR, AS_MEMBER_LEVEL_MODERATOR, AS_MEMBER_LEVEL_ADMIN, AS_MEMBER_LEVEL_SUPER);

			$leveloptions = array();
			$catleveloptions = array('' => as_lang_html('members/department_level_none'));

			foreach ($showlevels as $showlevel) {
				if ($showlevel <= $maxlevelassign) {
					$leveloptions[$showlevel] = as_html(as_member_level_string($showlevel));
					if ($showlevel > AS_MEMBER_LEVEL_BASIC)
						$catleveloptions[$showlevel] = $leveloptions[$showlevel];
				}
			}

			$as_content['form_profile']['fields']['level']['options'] = $leveloptions;


			// Department-specific levels
			if (as_using_departments()) {
				$catleveladd = strlen(as_get('catleveladd')) > 0;

				if (!$catleveladd && !count($memberlevels)) {
					$as_content['form_profile']['fields']['level']['suffix'] = strtr(as_lang_html('members/department_level_add'), array(
						'^1' => '<a href="' . as_path_html(as_request(), array('state' => 'edit', 'catleveladd' => 1)) . '">',
						'^2' => '</a>',
					));
				} else {
					$as_content['form_profile']['fields']['level']['suffix'] = as_lang_html('members/level_in_general');
				}

				if ($catleveladd || count($memberlevels))
					$memberlevels[] = array('entitytype' => AS_ENTITY_DEPARTMENT);

				$index = 0;
				foreach ($memberlevels as $memberlevel) {
					if ($memberlevel['entitytype'] == AS_ENTITY_DEPARTMENT) {
						$index++;
						$id = 'ls_' . +$index;

						$as_content['form_profile']['fields']['uc_' . $index . '_level'] = array(
							'label' => as_lang_html('members/department_level_label'),
							'type' => 'select',
							'tags' => 'name="uc_' . $index . '_level" id="' . as_html($id) . '" onchange="this.as_prev=this.options[this.selectedIndex].value;"',
							'options' => $catleveloptions,
							'value' => isset($memberlevel['level']) ? as_html(as_member_level_string($memberlevel['level'])) : '',
							'suffix' => as_lang_html('members/department_level_in'),
						);

						$as_content['form_profile']['fields']['uc_' . $index . '_cat'] = array();

						if (isset($memberlevel['entityid']))
							$fieldnavdepartments = as_db_select_with_pending(as_db_department_nav_selectspec($memberlevel['entityid'], true));
						else
							$fieldnavdepartments = $navdepartments;

						as_set_up_department_field($as_content, $as_content['form_profile']['fields']['uc_' . $index . '_cat'],
							'uc_' . $index . '_cat', $fieldnavdepartments, @$memberlevel['entityid'], true, true);

						unset($as_content['form_profile']['fields']['uc_' . $index . '_cat']['note']);
					}
				}

				$as_content['script_lines'][] = array(
					"function as_update_department_levels()",
					"{",
					"\tglob=document.getElementById('level_select');",
					"\tif (!glob)",
					"\t\treturn;",
					"\tvar opts=glob.options;",
					"\tvar lev=parseInt(opts[glob.selectedIndex].value);",
					"\tfor (var i=1; i<9999; i++) {",
					"\t\tvar sel=document.getElementById('ls_'+i);",
					"\t\tif (!sel)",
					"\t\t\tbreak;",
					"\t\tsel.as_prev=sel.as_prev || sel.options[sel.selectedIndex].value;",
					"\t\tsel.options.length=1;", // just leaves "no upgrade" element
					"\t\tfor (var j=0; j<opts.length; j++)",
					"\t\t\tif (parseInt(opts[j].value)>lev)",
					"\t\t\t\tsel.options[sel.options.length]=new Option(opts[j].text, opts[j].value, false, (opts[j].value==sel.as_prev));",
					"\t}",
					"}",
				);

				$as_content['script_onloads'][] = array(
					"as_update_department_levels();",
				);

				$as_content['form_profile']['fields']['level']['tags'] .= ' id="level_select" onchange="as_update_department_levels();"';
			}
		}

	} else {
		foreach ($memberlevels as $memberlevel) {
			if ($memberlevel['entitytype'] == AS_ENTITY_DEPARTMENT && $memberlevel['level'] > $memberaccount['level']) {
				$as_content['form_profile']['fields']['level']['value'] .= '<br/>' .
					strtr(as_lang_html('members/level_for_department'), array(
						'^1' => as_html(as_member_level_string($memberlevel['level'])),
						'^2' => '<a href="' . as_path_html(implode('/', array_reverse(explode('/', $memberlevel['backpath'])))) . '">' . as_html($memberlevel['title']) . '</a>',
					));
			}
		}
	}


	// Show any extra privileges due to member's level or their points

	$showpermits = array();
	$permitoptions = as_get_permit_options();

	foreach ($permitoptions as $permitoption) {
		// if not available to approved and email confirmed members with no points, but yes available to the member, it's something special
		if (as_permit_error($permitoption, $memberid, AS_MEMBER_LEVEL_APPROVED, AS_MEMBER_FLAGS_EMAIL_CONFIRMED, 0) &&
			!as_permit_error($permitoption, $memberid, $memberaccount['level'], $memberaccount['flags'], $memberpoints['points'])
		) {
			if ($permitoption == 'permit_retag_cat')
				$showpermits[] = as_lang(as_using_departments() ? 'profile/permit_recat' : 'profile/permit_retag');
			else
				$showpermits[] = as_lang('profile/' . $permitoption); // then show it as an extra priviliege
		}
	}

	if (count($showpermits)) {
		$as_content['form_profile']['fields']['permits'] = array(
			'type' => 'static',
			'label' => as_lang_html('profile/extra_privileges'),
			'value' => as_html(implode("\n", $showpermits), true),
			'rows' => count($showpermits),
			'id' => 'permits',
		);
	}


	// Show email address only if we're an administrator

	if ($loginlevel >= AS_MEMBER_LEVEL_ADMIN && !as_member_permit_error()) {
		$doconfirms = as_opt('confirm_member_emails') && $memberaccount['level'] < AS_MEMBER_LEVEL_WRITER;
		$isconfirmed = ($memberaccount['flags'] & AS_MEMBER_FLAGS_EMAIL_CONFIRMED) > 0;
		$htmlemail = as_html(isset($inemail) ? $inemail : $memberaccount['email']);

		$as_content['form_profile']['fields']['email'] = array(
			'type' => $memberediting ? 'text' : 'static',
			'label' => as_lang_html('members/email_label'),
			'tags' => 'name="email"',
			'value' => $memberediting ? $htmlemail : ('<a href="mailto:' . $htmlemail . '">' . $htmlemail . '</a>'),
			'error' => as_html(@$errors['email']),
			'note' => ($doconfirms ? (as_lang_html($isconfirmed ? 'members/email_confirmed' : 'members/email_not_confirmed') . ' ') : '') .
				($memberediting ? '' : as_lang_html('members/only_shown_admins')),
			'id' => 'email',
		);
	}


	// Show IP addresses and times for last login or write - only if we're a moderator or higher

	if ($loginlevel >= AS_MEMBER_LEVEL_MODERATOR && !as_member_permit_error()) {
		$as_content['form_profile']['fields']['lastlogin'] = array(
			'type' => 'static',
			'label' => as_lang_html('members/last_login_label'),
			'value' =>
				strtr(as_lang_html('members/x_ago_from_y'), array(
					'^1' => as_time_to_string(as_opt('db_time') - $memberaccount['loggedin']),
					'^2' => as_ip_anchor_html(@inet_ntop($memberaccount['loginip'])),
				)),
			'note' => $memberediting ? null : as_lang_html('members/only_shown_moderators'),
			'id' => 'lastlogin',
		);

		if (isset($memberaccount['written'])) {
			$as_content['form_profile']['fields']['lastwrite'] = array(
				'type' => 'static',
				'label' => as_lang_html('members/last_write_label'),
				'value' =>
					strtr(as_lang_html('members/x_ago_from_y'), array(
						'^1' => as_time_to_string(as_opt('db_time') - $memberaccount['written']),
						'^2' => as_ip_anchor_html(@inet_ntop($memberaccount['writeip'])),
					)),
				'note' => $memberediting ? null : as_lang_html('members/only_shown_moderators'),
				'id' => 'lastwrite',
			);
		} else {
			unset($as_content['form_profile']['fields']['lastwrite']);
		}
	}


	// Show other profile fields

	$fieldsediting = $fieldseditable && $memberediting;

	foreach ($memberfields as $memberfield) {
		if (($memberfield['flags'] & AS_FIELD_FLAGS_LINK_URL) && !$fieldsediting) {
			$valuehtml = as_url_to_html_link(@$memberprofile[$memberfield['title']], as_opt('links_in_new_window'));
		} else {
			$value = @$inprofile[$memberfield['fieldid']];
			if (!isset($value))
				$value = @$memberprofile[$memberfield['title']];

			$valuehtml = as_html($value, (($memberfield['flags'] & AS_FIELD_FLAGS_MULTI_LINE) && !$fieldsediting));
		}

		$label = trim(as_member_memberfield_label($memberfield), ':');
		if (strlen($label))
			$label .= ':';

		$notehtml = null;
		if (isset($memberfield['permit']) && !$memberediting) {
			if ($memberfield['permit'] <= AS_PERMIT_ADMINS)
				$notehtml = as_lang_html('members/only_shown_admins');
			elseif ($memberfield['permit'] <= AS_PERMIT_MODERATORS)
				$notehtml = as_lang_html('members/only_shown_moderators');
			elseif ($memberfield['permit'] <= AS_PERMIT_EDITORS)
				$notehtml = as_lang_html('members/only_shown_editors');
			elseif ($memberfield['permit'] <= AS_PERMIT_WRITERS)
				$notehtml = as_lang_html('members/only_shown_writers');
		}

		$as_content['form_profile']['fields'][$memberfield['title']] = array(
			'type' => $fieldsediting ? 'text' : 'static',
			'label' => as_html($label),
			'tags' => 'name="field_' . $memberfield['fieldid'] . '"',
			'value' => $valuehtml,
			'error' => as_html(@$errors[$memberfield['fieldid']]),
			'note' => $notehtml,
			'rows' => ($memberfield['flags'] & AS_FIELD_FLAGS_MULTI_LINE) ? 8 : null,
			'id' => 'memberfield-' . $memberfield['fieldid'],
		);
	}


	// Edit form or button, if appropriate

	if ($memberediting) {
		if ((as_opt('avatar_allow_gravatar') && ($memberaccount['flags'] & AS_MEMBER_FLAGS_SHOW_GRAVATAR)) ||
			(as_opt('avatar_allow_upload') && ($memberaccount['flags'] & AS_MEMBER_FLAGS_SHOW_AVATAR) && isset($memberaccount['avatarblobid']))
		) {
			$as_content['form_profile']['fields']['removeavatar'] = array(
				'type' => 'checkbox',
				'label' => as_lang_html('members/remove_avatar'),
				'tags' => 'name="removeavatar"',
			);
		}

		$as_content['form_profile']['buttons'] = array(
			'save' => array(
				'tags' => 'onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html('members/save_member'),
			),

			'cancel' => array(
				'tags' => 'name="docancel"',
				'label' => as_lang_html('main/cancel_button'),
			),
		);

		$as_content['form_profile']['hidden'] = array(
			'dosave' => '1',
			'code' => as_get_form_security_code('member-edit-' . $handle),
		);

	} elseif ($membereditbutton) {
		if ($approvebutton) {
			$as_content['form_profile']['buttons']['approve'] = array(
				'tags' => 'name="doapprove"',
				'label' => as_lang_html('members/approve_member_button'),
			);
		}

		$as_content['form_profile']['buttons']['edit'] = array(
			'tags' => 'name="doedit"',
			'label' => as_lang_html('members/edit_member_button'),
		);

		if (isset($maxlevelassign) && $memberaccount['level'] < AS_MEMBER_LEVEL_MODERATOR) {
			if ($memberaccount['flags'] & AS_MEMBER_FLAGS_MEMBER_BLOCKED) {
				$as_content['form_profile']['buttons']['unblock'] = array(
					'tags' => 'name="dounblock"',
					'label' => as_lang_html('members/unblock_member_button'),
				);

				if (!as_member_permit_error('permit_hide_show')) {
					$as_content['form_profile']['buttons']['hideall'] = array(
						'tags' => 'name="dohideall" onclick="as_show_waiting_after(this, false);"',
						'label' => as_lang_html('members/hide_all_member_button'),
					);
				}

				if ($loginlevel >= AS_MEMBER_LEVEL_ADMIN) {
					$as_content['form_profile']['buttons']['delete'] = array(
						'tags' => 'name="dodelete" onclick="as_show_waiting_after(this, false);"',
						'label' => as_lang_html('members/delete_member_button'),
					);
				}

			} else {
				$as_content['form_profile']['buttons']['block'] = array(
					'tags' => 'name="doblock"',
					'label' => as_lang_html('members/block_member_button'),
				);
			}

			$as_content['form_profile']['hidden'] = array(
				'code' => as_get_form_security_code('member-' . $handle),
			);
		}

	} elseif (isset($loginmemberid) && ($loginmemberid == $memberid)) {
		$as_content['form_profile']['buttons'] = array(
			'account' => array(
				'tags' => 'name="doaccount"',
				'label' => as_lang_html('members/edit_profile'),
			),
		);
	}


	if (!is_array($as_content['form_profile']['fields']['removeavatar']))
		unset($as_content['form_profile']['fields']['removeavatar']);

	$as_content['raw']['account'] = $memberaccount; // for plugin layers to access
	$as_content['raw']['profile'] = $memberprofile;
}

/*
// Information about member activity, available also with single sign-on integration

$as_content['form_activity'] = array(
	'title' => '<span id="activity">' . as_lang_html_sub('profile/activity_by_x', $memberhtml) . '</span>',

	'style' => 'wide',

	'fields' => array(
		'bonus' => array(
			'label' => as_lang_html('profile/bonus_points'),
			'tags' => 'name="bonus"',
			'value' => as_html(isset($inbonus) ? $inbonus : $memberpoints['bonus']),
			'type' => 'number',
			'note' => as_lang_html('members/only_shown_admins'),
			'id' => 'bonus',
		),

		'points' => array(
			'type' => 'static',
			'label' => as_lang_html('profile/score'),
			'value' => (@$memberpoints['points'] == 1)
				? as_lang_html_sub('main/1_point', '<span class="as-uf-member-points">1</span>', '1')
				: as_lang_html_sub('main/x_points', '<span class="as-uf-member-points">' . as_html(as_format_number(@$memberpoints['points'])) . '</span>'),
			'id' => 'points',
		),

		'title' => array(
			'type' => 'static',
			'label' => as_lang_html('profile/title'),
			'value' => as_get_points_title_html(@$memberpoints['points'], as_get_points_to_titles()),
			'id' => 'title',
		),

		'articles' => array(
			'type' => 'static',
			'label' => as_lang_html('profile/articles'),
			'value' => '<span class="as-uf-member-q-posts">' . as_html(as_format_number(@$memberpoints['qposts'])) . '</span>',
			'id' => 'articles',
		),

		'answers' => array(
			'type' => 'static',
			'label' => as_lang_html('profile/answers'),
			'value' => '<span class="as-uf-member-a-posts">' . as_html(as_format_number(@$memberpoints['aposts'])) . '</span>',
			'id' => 'answers',
		),
	),
);

if ($loginlevel >= AS_MEMBER_LEVEL_ADMIN) {
	$as_content['form_activity']['tags'] = 'method="post" action="' . as_self_html() . '"';

	$as_content['form_activity']['buttons'] = array(
		'setbonus' => array(
			'tags' => 'name="dosetbonus"',
			'label' => as_lang_html('profile/set_bonus_button'),
		),
	);

	$as_content['form_activity']['hidden'] = array(
		'code' => as_get_form_security_code('member-activity-' . $handle),
	);

} else {
	unset($as_content['form_activity']['fields']['bonus']);
}

if (!isset($as_content['form_activity']['fields']['title']['value']))
	unset($as_content['form_activity']['fields']['title']);

if (as_opt('comment_on_qs') || as_opt('comment_on_as')) { // only show comment count if comments are enabled
	$as_content['form_activity']['fields']['comments'] = array(
		'type' => 'static',
		'label' => as_lang_html('profile/comments'),
		'value' => '<span class="as-uf-member-c-posts">' . as_html(as_format_number(@$memberpoints['cposts'])) . '</span>',
		'id' => 'comments',
	);
}

if (as_opt('voting_on_qs') || as_opt('voting_on_as')) { // only show vote record if voting is enabled
	$votedonvalue = '';

	if (as_opt('voting_on_qs')) {
		$qvotes = @$memberpoints['qupvotes'] + @$memberpoints['qdownvotes'];

		$innervalue = '<span class="as-uf-member-q-votes">' . as_format_number($qvotes) . '</span>';
		$votedonvalue .= ($qvotes == 1) ? as_lang_html_sub('main/1_article', $innervalue, '1')
			: as_lang_html_sub('main/x_articles', $innervalue);

		if (as_opt('voting_on_as'))
			$votedonvalue .= ', ';
	}

	if (as_opt('voting_on_as')) {
		$avotes = @$memberpoints['aupvotes'] + @$memberpoints['adownvotes'];

		$innervalue = '<span class="as-uf-member-a-votes">' . as_format_number($avotes) . '</span>';
		$votedonvalue .= ($avotes == 1) ? as_lang_html_sub('main/1_answer', $innervalue, '1')
			: as_lang_html_sub('main/x_answers', $innervalue);
	}

	$as_content['form_activity']['fields']['votedon'] = array(
		'type' => 'static',
		'label' => as_lang_html('profile/voted_on'),
		'value' => $votedonvalue,
		'id' => 'votedon',
	);

	$upvotes = @$memberpoints['qupvotes'] + @$memberpoints['aupvotes'];
	$innervalue = '<span class="as-uf-member-upvotes">' . as_format_number($upvotes) . '</span>';
	$votegavevalue = (($upvotes == 1) ? as_lang_html_sub('profile/1_up_vote', $innervalue, '1') : as_lang_html_sub('profile/x_up_votes', $innervalue)) . ', ';

	$downvotes = @$memberpoints['qdownvotes'] + @$memberpoints['adownvotes'];
	$innervalue = '<span class="as-uf-member-downvotes">' . as_format_number($downvotes) . '</span>';
	$votegavevalue .= ($downvotes == 1) ? as_lang_html_sub('profile/1_down_vote', $innervalue, '1') : as_lang_html_sub('profile/x_down_votes', $innervalue);

	$as_content['form_activity']['fields']['votegave'] = array(
		'type' => 'static',
		'label' => as_lang_html('profile/gave_out'),
		'value' => $votegavevalue,
		'id' => 'votegave',
	);

	$innervalue = '<span class="as-uf-member-upvoteds">' . as_format_number(@$memberpoints['upvoteds']) . '</span>';
	$votegotvalue = ((@$memberpoints['upvoteds'] == 1) ? as_lang_html_sub('profile/1_up_vote', $innervalue, '1')
			: as_lang_html_sub('profile/x_up_votes', $innervalue)) . ', ';

	$innervalue = '<span class="as-uf-member-downvoteds">' . as_format_number(@$memberpoints['downvoteds']) . '</span>';
	$votegotvalue .= (@$memberpoints['downvoteds'] == 1) ? as_lang_html_sub('profile/1_down_vote', $innervalue, '1')
		: as_lang_html_sub('profile/x_down_votes', $innervalue);

	$as_content['form_activity']['fields']['votegot'] = array(
		'type' => 'static',
		'label' => as_lang_html('profile/received'),
		'value' => $votegotvalue,
		'id' => 'votegot',
	);
}

if (@$memberpoints['points']) {
	$as_content['form_activity']['fields']['points']['value'] .=
		as_lang_html_sub('profile/ranked_x', '<span class="as-uf-member-rank">' . as_format_number($memberrank) . '</span>');
}

if (@$memberpoints['aselects']) {
	$as_content['form_activity']['fields']['articles']['value'] .= ($memberpoints['aselects'] == 1)
		? as_lang_html_sub('profile/1_with_best_chosen', '<span class="as-uf-member-q-selects">1</span>', '1')
		: as_lang_html_sub('profile/x_with_best_chosen', '<span class="as-uf-member-q-selects">' . as_format_number($memberpoints['aselects']) . '</span>');
}

if (@$memberpoints['aselecteds']) {
	$as_content['form_activity']['fields']['answers']['value'] .= ($memberpoints['aselecteds'] == 1)
		? as_lang_html_sub('profile/1_chosen_as_best', '<span class="as-uf-member-a-selecteds">1</span>', '1')
		: as_lang_html_sub('profile/x_chosen_as_best', '<span class="as-uf-member-a-selecteds">' . as_format_number($memberpoints['aselecteds']) . '</span>');
}


// For plugin layers to access
$as_content['raw']['memberid'] = $memberid;
$as_content['raw']['points'] = $memberpoints;
$as_content['raw']['rank'] = $memberrank;*/

/*
// Wall posts
if (!AS_FINAL_EXTERNAL_MEMBERS && as_opt('allow_member_walls')) {
	$as_content['message_list'] = array(
		'title' => '<span id="wall">' . as_lang_html_sub('profile/wall_for_x', $memberhtml) . '</span>',

		'tags' => 'id="wallmessages"',

		'form' => array(
			'tags' => 'name="wallpost" method="post" action="' . as_self_html() . '#wall"',
			'style' => 'tall',
			'hidden' => array(
				'as_click' => '', // for simulating clicks in Javascript
				'handle' => as_html($memberaccount['handle']),
				'start' => 0,
				'code' => as_get_form_security_code('wall-' . $memberaccount['handle']),
			),
		),

		'messages' => array(),
	);

	if ($wallposterrorhtml) {
		$as_content['message_list']['error'] = $wallposterrorhtml; // an error that means we are not allowed to post
	} else {
		$as_content['message_list']['form']['fields'] = array(
			'message' => array(
				'tags' => 'name="message" id="message"',
				'value' => as_html(@$inmessage, false),
				'rows' => 2,
				'error' => as_html(@$errors['message']),
			),
		);

		$as_content['message_list']['form']['buttons'] = array(
			'post' => array(
				'tags' => 'name="dowallpost" onclick="return as_submit_wall_post(this, true);"',
				'label' => as_lang_html('profile/post_wall_button'),
			),
		);
	}

	foreach ($membermessages as $message)
		$as_content['message_list']['messages'][] = as_wall_post_view($message);

	if ($memberaccount['wallposts'] > count($membermessages))
		$as_content['message_list']['messages'][] = as_wall_view_more_link($handle, count($membermessages));
}
*/


// Recent articles by this member
if ( $state != 'edit' ) {
	$as_content['profile_actions'] = array(
		'form_tags' => 'method="post" action="' . as_self_html() . '"',
		'form_hidden' => array('code' => as_get_form_security_code('member-edit-' . $handle)),
		'action_tags' => 'id="actionbtn"',
		'buttons' => $as_content['form_profile']['buttons'],
	);

	unset ($as_content['form_profile']);
	$as_content['profile_page'] = $memberaccount;
	
	$as_content['q_list']['form'] = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',

		'hidden' => array(
			'code' => as_get_form_security_code('like'),
		),
	);

	$as_content['list_posts']['wall'] = array();

	$htmldefaults = as_post_html_defaults('Q');
	$htmldefaults['whoview'] = false;
	$htmldefaults['avatarsize'] = 0;

	foreach ($articles as $article) {
		$as_content['list_posts']['wall'][] = as_post_html_fields($article, $loginmemberid, as_cookie_get(),
			$handle, null, as_post_html_options($article, $htmldefaults));
	}

	$as_content['page_links'] = as_html_page_links(as_request(), $start, $pagesize, $count, as_opt('pages_prev_next'));
}

// Sub menu for navigation in member pages

$ismymember = isset($loginmemberid) && $loginmemberid == (AS_FINAL_EXTERNAL_MEMBERS ? $memberid : $memberaccount['memberid']);
$as_content['navigation']['sub'] = as_member_sub_navigation($handle, 'profile', $ismymember);


return $as_content;
