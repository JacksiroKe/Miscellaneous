<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for page listing hot articles


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/q-list.php';


// Get list of hottest articles, allow per-department if AS_ALLOW_UNINDEXED_QUERIES set in as-config.php

$departmentslugs = AS_ALLOW_UNINDEXED_QUERIES ? as_request_parts(1) : null;
$countslugs = @count($departmentslugs);

$start = as_get_start();
$memberid = as_get_logged_in_memberid();

list($articles, $departments, $departmentid) = as_db_select_with_pending(
	as_db_qs_selectspec($memberid, 'hotness', $start, $departmentslugs, null, false, false, as_opt_if_loaded('page_size_hot_qs')),
	as_db_department_nav_selectspec($departmentslugs, false, false, true),
	$countslugs ? as_db_slugs_to_department_id_selectspec($departmentslugs) : null
);

if ($countslugs) {
	if (!isset($departmentid))
		return include AS_INCLUDE_DIR . 'as-page-not-found.php';

	$departmenttitlehtml = as_html($departments[$departmentid]['title']);
	$sometitle = as_lang_html_sub('main/hot_qs_in_x', $departmenttitlehtml);
	$nonetitle = as_lang_html_sub('main/no_articles_in_x', $departmenttitlehtml);

} else {
	$sometitle = as_lang_html('main/hot_qs_title');
	$nonetitle = as_lang_html('main/no_articles_found');
}


// Prepare and return content for theme

return as_q_list_page_content(
	$articles, // articles
	as_opt('page_size_hot_qs'), // articles per page
	$start, // start offset
	$countslugs ? $departments[$departmentid]['qcount'] : as_opt('cache_qcount'), // total count
	$sometitle, // title if some articles
	$nonetitle, // title if no articles
	AS_ALLOW_UNINDEXED_QUERIES ? $departments : array(), // departments for navigation
	$departmentid, // selected department id
	true, // show article counts in department navigation
	AS_ALLOW_UNINDEXED_QUERIES ? 'hot/' : null, // prefix for links in department navigation (null if no navigation)
	as_opt('feed_for_hot') ? 'hot' : null, // prefix for RSS feed paths (null to hide)
	as_html_suggest_write() // suggest what to do next
);
