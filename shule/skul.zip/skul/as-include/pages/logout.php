<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for logout page (not much to do)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


if (AS_FINAL_EXTERNAL_MEMBERS) {
	$request = as_request();
	$topath = as_get('to'); // lets member switch between login and register without losing destination page
	$memberlinks = as_get_login_links(as_path_to_root(), isset($topath) ? $topath : as_path($request, $_GET, ''));

	if (!empty($memberlinks['logout'])) {
		as_redirect_raw($memberlinks['logout']);
	}
	as_fatal_error('Member logout should be handled by external code');
}

if (as_is_logged_in()) {
	as_set_logged_in_member(null);
}

as_redirect(''); // back to home page
