<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for students page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/members.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';

// Prepare content for theme
$as_content = as_content_prepare();
$page = as_get('page');
$ingrouped = 'STUDENT';
$menuItems = array();

$menuItems['registry$'] = array(
	'label' => as_lang_html('members/recent_students'),
	'url' => as_path_html('registry'),
);

$menuItems['registry/groups'] = array(
	'label' => as_lang_html('main/nav_groups'),
	'url' => as_path_html('registry/classes'),
);

list($memberfields, $groups) = as_db_select_with_pending(
	as_db_memberfields_selectspec(),
	as_db_group_nav_selectspec(null, true, false, true)
);

//$groupoptions[] = as_lang_html('main/select_group_label');
foreach ($groups as $group)
	$groupoptions[$group['groupid']] = $group['title'] . ' - ' . $group['code'];
		
foreach ($memberfields as $index => $memberfield)
	if (!($memberfield['flags'] & AS_FIELD_FLAGS_ON_REGISTER)) unset($memberfields[$index]);

if (as_clicked('register')) as_redirect(as_request(), array('page' => 'register'));
else if (as_clicked('dosaveclose')) {
	require_once AS_INCLUDE_DIR . 'app/members-edit.php';
	$infirstname = as_post_text('firstname');
	$inlastname = as_post_text('lastname');
	$insex = as_post_text('sex');
	$incountry = 'Kenya';
	$ingroup = as_post_text('group');
	$inadmno = as_post_text('admno');
	$inmobile = as_post_text('mobile');
	$inemail = as_post_text('email');
	$inpassword = as_post_text('password');
	$inhandle = as_post_text('handle');
	$interms = (int)as_post_text('terms');

	$inprofile = array();
	foreach ($memberfields as $memberfield)
		$inprofile[$memberfield['fieldid']] = as_post_text('field_' . $memberfield['fieldid']);

	if (!as_check_form_security_code('registry-register', as_post_text('code'))) {
		$pageerror = as_lang_html('misc/form_security_again');
	} else {
		// core validation
		$errors = array_merge(
			as_handle_email_filter($inhandle, $inemail),
			as_password_validate($inpassword)
		);

		// filter module validation
		if (count($inprofile)) {
			$filtermodules = as_load_modules_with('filter', 'filter_profile');
			foreach ($filtermodules as $filtermodule)
				$filtermodule->filter_profile($inprofile, $errors, null, null);
		}

		if (empty($errors)) {
			$memberid = as_create_new_member($ingrouped, $inadmno, $infirstname, $inlastname, $insex, $incountry, $ingroup, $inmobile, $inemail, $inpassword, $inhandle);
			
			foreach ($memberfields as $memberfield)
				as_db_member_profile_set($memberid, $memberfield['title'], $inprofile[$memberfield['fieldid']]);
			as_redirect('registry');
		}
	}
}
else if (as_clicked('dosaveadd')) {
	require_once AS_INCLUDE_DIR . 'app/members-edit.php';
	$infirstname = as_post_text('firstname');
	$inlastname = as_post_text('lastname');
	$insex = as_post_text('sex');
	$incountry = 'Kenya';
	$ingroup = as_post_text('group');
	$inadmno = as_post_text('admno');
	$inmobile = as_post_text('mobile');
	$inemail = as_post_text('email');
	$inpassword = as_post_text('password');
	$inhandle = as_post_text('handle');
	$interms = (int)as_post_text('terms');

	$inprofile = array();
	foreach ($memberfields as $memberfield)
		$inprofile[$memberfield['fieldid']] = as_post_text('field_' . $memberfield['fieldid']);

	if (!as_check_form_security_code('registry-register', as_post_text('code'))) {
		$pageerror = as_lang_html('misc/form_security_again');
	} else {
		// core validation
		$errors = array_merge(
			as_handle_email_filter($inhandle, $inemail),
			as_password_validate($inpassword)
		);

		// filter module validation
		if (count($inprofile)) {
			$filtermodules = as_load_modules_with('filter', 'filter_profile');
			foreach ($filtermodules as $filtermodule)
				$filtermodule->filter_profile($inprofile, $errors, null, null);
		}

		if (empty($errors)) {
			$memberid = as_create_new_member($ingrouped, $inadmno, $infirstname, $inlastname, $insex, $incountry, $ingroup, $inmobile, $inemail, $inpassword, $inhandle);
			
			foreach ($memberfields as $memberfield)
				as_db_member_profile_set($memberid, $memberfield['title'], $inprofile[$memberfield['fieldid']]);
			//as_redirect('registry');
			as_redirect('registry', array('page' => 'register'));
		}
	}
}

$sexfield = array();
$sexfield['label'] = as_lang_html('members/sex_general_label');
as_optionfield_make_select($sexfield, array(
	'1' => as_lang_html('members/male'),
	'2' => as_lang_html('members/female'),
), as_html(@$insex), '1');

$sexfield['tags'] = 'name="sex" id="sex" dir="auto"';
$sexfield['type'] = 'select-radio';
$sexfield['htmlextra'] = '&nbsp;&nbsp;';
$sexfield['error'] = as_html(@$errors['sex']);

if ( $page == 'register' ) {	
	$as_content['title'] = as_lang_html('members/register_student_title');
	$as_content['form'] = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',
		'style' => 'wide',
		
		'fields' => array(
			'firstname' => array(
				'label' => as_lang_html('members/firstname_label'),
				'tags' => 'name="firstname" id="firstname" dir="auto"',
				'value' => as_html(@$infirstname),
				'error' => as_html(@$errors['firstname']),
			),
			
			'lastname' => array(
				'label' => as_lang_html('members/lastname_label'),
				'tags' => 'name="lastname" id="lastname" dir="auto"',
				'value' => as_html(@$inlastname),
				'error' => as_html(@$errors['lastname']),
			),

			'sex' => $sexfield,
			
			'group' => array(
				'label' => as_lang_html('main/group_label'),
				'tags' => 'name="group" id="group" dir="auto" onchange="as_group_change(this.value);"',
				'type' => 'select',
				'options' => $groupoptions,
				'error' => as_html(@$errors['group']),
			),
			
			'admno' => array(
				'label' => as_lang_html('members/admno_label'),
				'tags' => 'name="admno" id="admno" dir="auto"',
				'value' => as_html(@$inadmno),
				'error' => as_html(@$errors['admno']),
			),

			'mobile' => array(
				'label' => as_lang_html('members/mobile_label'),
				'tags' => 'name="mobile" id="mobile" dir="auto"',
				'value' => as_html(@$inmobile),
				'error' => as_html(@$errors['mobile']),
			),

			'email' => array(
				'label' => as_lang_html('members/email_label'),
				'tags' => 'name="email" id="email" dir="auto"',
				'value' => as_html(@$inemail),
				'error' => as_html(@$errors['email']),
			),
			
			'handle' => array(
				'label' => as_lang_html('members/handle_label'),
				'tags' => 'name="handle" id="handle" dir="auto"',
				'value' => as_html(@$inhandle),
				'error' => as_html(@$errors['handle']),
			),

			'password' => array(
				'type' => 'password',
				'label' => as_lang_html('members/password_label'),
				'tags' => 'name="password" id="password" dir="auto"',
				'value' => as_html(@$inpassword),
				'error' => as_html(@$errors['password']),
			),

		),
		'buttons' => array(
			'saveclose' => array(
				'tags' => 'name="dosaveclose" onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html('members/register_student_close_button'),
			),
			
			'saveadd' => array(
				'tags' => 'name="dosaveadd" onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html('members/register_student_add_button'),
			),
		),

		'hidden' => array(
			'doregister' => '1',
			'code' => as_get_form_security_code('registry-register'),
		),
	);

	// prepend custom message
	$custom = as_opt('show_custom_register') ? trim(as_opt('custom_register')) : '';
	if (strlen($custom)) {
		array_unshift($as_content['form']['fields'], array(
			'type' => 'custom',
			'note' => $custom,
		));
	}

	foreach ($memberfields as $memberfield) {
		$value = @$inprofile[$memberfield['fieldid']];
		
		$label = trim(as_member_memberfield_label($memberfield), ':');
		if (strlen($label)) $label .= ':';
		
		if ($memberfield['flags'] & AS_FIELD_FLAGS_CHECKBOX) {
			$as_content['form']['fields'][$memberfield['title']]=array(
				'label' => '',
				'checklabel' => as_html($label),
				'tags' => 'required name="field_'.$memberfield['fieldid'].'"',
				'type' => 'checkbox',
				'value' => isset($value) ? as_html($value) : '',
				'error' => as_html(@$errors[$memberfield['fieldid']]),
			);
		} elseif ($memberfield['flags'] & AS_FIELD_FLAGS_SELECT || $memberfield['flags'] & AS_FIELD_FLAGS_RADIO) {
			$options = as_string_to_array($memberfield['extra']);
			$as_content['form']['fields'][$memberfield['title']]=array(
				'label' => as_html($label),
				'tags' => 'required name="field_'.$memberfield['fieldid'].'"',
				'type' => $memberfield['flags'] & AS_FIELD_FLAGS_SELECT ? 'select' : 'select-radio',
				'options' => $options,
				'htmlextra' => '&nbsp;&nbsp;',
				'value' => isset($value) ? as_html(@$options[$value]) : '',
				'error' => as_html(@$errors[$memberfield['fieldid']]),
			);
		} else {
			$as_content['form']['fields'][$memberfield['title']]=array(
				'label' => as_html($label),
				'tags' => 'required name="field_'.$memberfield['fieldid'].'"',
				'value' => isset($value) ? as_html($value) : '',
				'error' => as_html(@$errors[$memberfield['fieldid']]),
				'rows' => ($memberfield['flags'] & AS_FIELD_FLAGS_MULTI_LINE) ? 8 : null,
			);
		}
	}

	$as_content['focusid'] = 'firstname';
} else {
	$as_content['script_src'][] = 'as-content/as-tables.js?'.AS_VERSION;
	
	// Get list of all students
	$start = as_get_start();
	$students = as_db_select_with_pending(as_db_list_members_selectspec($ingrouped, $start));

	$studentcount = as_opt('cache_memberpointscount');
	$pagesize = as_opt('page_size_members');
	$students = array_slice($students, 0, $pagesize);
	$studentshtml = as_memberids_handles_html($students);

	$as_content['title'] = as_lang_html('main/registry');

	$as_content['listing'] = array(
		'items' => array(),
		'checker' => '', 
		'headers' => array(
			as_lang('members/full_name'),
			'G', 
			as_lang('members/admno_no'), 
			as_lang('members/contacts'), 
			as_lang('options/label_group'), 
			as_lang('members/joined'),
			as_lang('members/last_activity'),
			),
		'select' => array(
				array('value' => 'approve', 'label' => as_lang('main/approve')),
				array('value' => 'suspend', 'label' => as_lang('main/suspend')),
				array('value' => 'delete', 'label' => as_lang('main/delete')),
			),
		'extras' => '<div style="float:right;"><input id="do_register" class="as-form-tall-button as-form-tall-button-save btn btn-default" type="submit" name="register" value="'.as_lang('members/new_student').'" /></div>',
	);
		
	if (count($students)) {
		foreach ($students as $studentid => $student) {
			$studentid = $student['memberid'];
			if (AS_FINAL_EXTERNAL_MEMBERS)
				$avatarhtml = as_get_external_avatar_html($studentid, as_opt('avatar_members_size'), true);
			else {
				$avatarhtml = as_get_member_avatar_html($student['flags'], $student['email'], $student['handle'],
					$student['avatarblobid'], $student['avatarwidth'], $student['avatarheight'], as_opt('avatar_members_size'), true);
			}
			$asavatar = '<img src="./as-media/member.png" width="30" height="30"/>';
			$group = as_db_find_value('code', 'groups', 'groupid', $student['groupid']);
			
			$as_content['listing']['items'][]['fields'] = array(
				'checkthis' => array( 'data' => '<label><input id="chk-item-'. $student['handle'] . '" class="chk-item" name="chk-item-checked[]" type="checkbox" value="'.$studentid. '">
				'. ( $avatarhtml ? $avatarhtml  : $asavatar ) . '</label>' ),
				'label' => array( 'data' => $studentshtml[$student['memberid']]), 
				'sex' => array( 'data' => (($student['sex'] == '1') ? 'M' : 'F' )),
				'number' => array( 'data' => $student['code']),
				'contacts' => array( 'data' => ( $student['mobile'] ? $student['mobile'].', ' : '' ) . 
					$student['email'] ),
				'group' => array( 'data' => $group ),
				'created' => array( 'data' => as_lang_html_sub('main/x_ago', 
					as_html(as_time_to_string(as_opt('db_time') - $student['created'])))),
					
				'lastactive' => array( 'data' => as_lang_html_sub('main/x_ago', 
					as_html(as_time_to_string(as_opt('db_time') - (isset($student['written']) ? $student['written'] : $student['loggedin'])
					)))),
			);			
		}
	} else $as_content['title'] = as_lang_html('main/no_students_found');
	
	$as_content['canonical'] = as_get_canonical();

	$as_content['page_links'] = as_html_page_links(as_request(), $start, $pagesize, $studentcount, as_opt('pages_prev_next'));
}

$as_content['navigation']['sub'] = $menuItems;
as_set_template('osam');

return $as_content;
