<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for member page showing all member wall posts


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/messages.php';


// Check we're not using single-sign on integration, which doesn't allow walls

if (AS_FINAL_EXTERNAL_MEMBERS)
	as_fatal_error('Member accounts are handled by external code');


// $handle, $memberhtml are already set by /as-include/page/member.php

$start = as_get_start();


// Find the articles for this member

list($memberaccount, $membermessages) = as_db_select_with_pending(
	as_db_member_account_selectspec($handle, false),
	as_db_recent_messages_selectspec(null, null, $handle, false, as_opt_if_loaded('page_size_wall'), $start)
);

if (!is_array($memberaccount)) // check the member exists
	return include AS_INCLUDE_DIR . 'as-page-not-found.php';


// Perform pagination

$pagesize = as_opt('page_size_wall');
$count = $memberaccount['wallposts'];
$loginmemberid = as_get_logged_in_memberid();

$membermessages = array_slice($membermessages, 0, $pagesize);
$membermessages = as_wall_posts_add_rules($membermessages, $start);


// Process deleting or adding a wall post (similar but not identical code to qq-page-member-profile.php)

$errors = array();

$wallposterrorhtml = as_wall_error_html($loginmemberid, $memberaccount['memberid'], $memberaccount['flags']);

foreach ($membermessages as $message) {
	if ($message['deleteable'] && as_clicked('m' . $message['messageid'] . '_dodelete')) {
		if (!as_check_form_security_code('wall-' . $memberaccount['handle'], as_post_text('code'))) {
			$errors['page'] = as_lang_html('misc/form_security_again');
		} else {
			as_wall_delete_post($loginmemberid, as_get_logged_in_handle(), as_cookie_get(), $message);
			as_redirect(as_request(), $_GET);
		}
	}
}

if (as_clicked('dowallpost')) {
	$inmessage = as_post_text('message');

	if (!strlen($inmessage)) {
		$errors['message'] = as_lang('profile/post_wall_empty');
	} elseif (!as_check_form_security_code('wall-' . $memberaccount['handle'], as_post_text('code'))) {
		$errors['message'] = as_lang_html('misc/form_security_again');
	} elseif (!$wallposterrorhtml) {
		as_wall_add_post($loginmemberid, as_get_logged_in_handle(), as_cookie_get(), $memberaccount['memberid'], $memberaccount['handle'], $inmessage, '');
		as_redirect(as_request());
	}
}


// Prepare content for theme

$as_content = as_content_prepare();

$as_content['title'] = as_lang_html_sub('profile/wall_for_x', $memberhtml);
$as_content['error'] = @$errors['page'];

$as_content['message_list'] = array(
	'tags' => 'id="wallmessages"',

	'form' => array(
		'tags' => 'name="wallpost" method="post" action="' . as_self_html() . '"',
		'style' => 'tall',
		'hidden' => array(
			'as_click' => '', // for simulating clicks in Javascript
			'handle' => as_html($memberaccount['handle']),
			'start' => as_html($start),
			'code' => as_get_form_security_code('wall-' . $memberaccount['handle']),
		),
	),

	'messages' => array(),
);

if ($start == 0) { // only allow posting on first page
	if ($wallposterrorhtml) {
		$as_content['message_list']['error'] = $wallposterrorhtml; // an error that means we are not allowed to post
	} else {
		$as_content['message_list']['form']['fields'] = array(
			'message' => array(
				'tags' => 'name="message" id="message"',
				'value' => as_html(@$inmessage, false),
				'rows' => 2,
				'error' => as_html(@$errors['message']),
			),
		);

		$as_content['message_list']['form']['buttons'] = array(
			'post' => array(
				'tags' => 'name="dowallpost" onclick="return as_submit_wall_post(this, false);"',
				'label' => as_lang_html('profile/post_wall_button'),
			),
		);
	}
}

foreach ($membermessages as $message) {
	$as_content['message_list']['messages'][] = as_wall_post_view($message);
}

$as_content['page_links'] = as_html_page_links(as_request(), $start, $pagesize, $count, as_opt('pages_prev_next'));


// Sub menu for navigation in member pages

$ismymember = isset($loginmemberid) && $loginmemberid == (AS_FINAL_EXTERNAL_MEMBERS ? $memberid : $memberaccount['memberid']);
$as_content['navigation']['sub'] = as_member_sub_navigation($handle, 'wall', $ismymember);


return $as_content;
