<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for admin page showing new members waiting for approval


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'app/admin.php';
require_once AS_INCLUDE_DIR . 'db/admin.php';


// Check we're not using single-sign on integration

if (AS_FINAL_EXTERNAL_MEMBERS)
	as_fatal_error('Member accounts are handled by external code');


// Find most flagged articles, answers, comments

$memberid = as_get_logged_in_memberid();

$members = as_db_get_unapproved_members(as_opt('page_size_members'));
$memberfields = as_db_select_with_pending(as_db_memberfields_selectspec());


// Check admin privileges (do late to allow one DB query)

if (as_get_logged_in_level() < AS_MEMBER_LEVEL_MODERATOR) {
	$as_content = as_content_prepare();
	$as_content['error'] = as_lang_html('members/no_permission');
	return $as_content;
}


// Check to see if any were approved or blocked here

$pageerror = as_admin_check_clicks();


// Prepare content for theme

$as_content = as_content_prepare();

$as_content['title'] = as_lang_html('admin/approve_members_title');
$as_content['error'] = isset($pageerror) ? $pageerror : as_admin_page_error();

$as_content['message_list'] = array(
	'form' => array(
		'tags' => 'method="post" action="' . as_self_html() . '"',

		'hidden' => array(
			'code' => as_get_form_security_code('admin/click'),
		),
	),

	'messages' => array(),
);


if (count($members)) {
	foreach ($members as $member) {
		$message = array();

		$message['tags'] = 'id="p' . as_html($member['memberid']) . '"'; // use p prefix for as_admin_click() in as-admin.js

		$message['content'] = as_lang_html('members/registered_label') . ' ' .
			strtr(as_lang_html('members/x_ago_from_y'), array(
				'^1' => as_time_to_string(as_opt('db_time') - $member['created']),
				'^2' => as_ip_anchor_html(@inet_ntop($member['createip'])),
			)) . '<br/>';

		$htmlemail = as_html($member['email']);

		$message['content'] .= as_lang_html('members/email_label') . ' <a href="mailto:' . $htmlemail . '">' . $htmlemail . '</a>';

		if (as_opt('confirm_member_emails')) {
			$message['content'] .= '<small> - ' . as_lang_html(($member['flags'] & AS_MEMBER_FLAGS_EMAIL_CONFIRMED) ? 'members/email_confirmed' : 'members/email_not_confirmed') . '</small>';
		}

		foreach ($memberfields as $memberfield) {
			if (strlen(@$member['profile'][$memberfield['title']]))
				$message['content'] .= '<br/>' . as_html($memberfield['content'] . ': ' . $member['profile'][$memberfield['title']]);
		}

		$message['meta_order'] = as_lang_html('main/meta_order');
		$message['who']['data'] = as_get_one_member_html($member['handle']);

		$message['form'] = array(
			'style' => 'light',

			'buttons' => array(
				'approve' => array(
					'tags' => 'name="admin_' . $member['memberid'] . '_memberapprove" onclick="return as_admin_click(this);"',
					'label' => as_lang_html('article/approve_button'),
					'popup' => as_lang_html('admin/approve_member_popup'),
				),

				'block' => array(
					'tags' => 'name="admin_' . $member['memberid'] . '_memberblock" onclick="return as_admin_click(this);"',
					'label' => as_lang_html('admin/block_button'),
					'popup' => as_lang_html('admin/block_member_popup'),
				),
			),
		);

		$as_content['message_list']['messages'][] = $message;
	}

} else
	$as_content['title'] = as_lang_html('admin/no_unapproved_found');


$as_content['navigation']['sub'] = as_admin_sub_navigation();
$as_content['script_rel'][] = 'as-content/as-admin.js?' . AS_VERSION;


return $as_content;
