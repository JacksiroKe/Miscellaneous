<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for page listing recent articles


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/q-list.php';

$departmentslugs = as_request_parts(1);
$countslugs = count($departmentslugs);

$sort = ($countslugs && !AS_ALLOW_UNINDEXED_QUERIES) ? null : as_get('sort');
$start = as_get_start();
$memberid = as_get_logged_in_memberid();


// Get list of articles, plus department information

switch ($sort) {
	case 'hot':
		$selectsort = 'hotness';
		break;

	case 'votes':
		$selectsort = 'netvotes';
		break;

	case 'answers':
		$selectsort = 'acount';
		break;

	case 'views':
		$selectsort = 'views';
		break;

	default:
		$selectsort = 'created';
		break;
}

list($articles, $departments, $departmentid) = as_db_select_with_pending(
	as_db_qs_selectspec($memberid, $selectsort, $start, $departmentslugs, null, false, false, as_opt_if_loaded('page_size_qs')),
	as_db_department_nav_selectspec($departmentslugs, false, false, true),
	$countslugs ? as_db_slugs_to_department_id_selectspec($departmentslugs) : null
);

if ($countslugs) {
	if (!isset($departmentid)) {
		return include AS_INCLUDE_DIR . 'as-page-not-found.php';
	}

	$departmenttitlehtml = as_html($departments[$departmentid]['title']);
	$nonetitle = as_lang_html_sub('main/no_articles_in_x', $departmenttitlehtml);

} else {
	$nonetitle = as_lang_html('main/no_articles_found');
}


$departmentpathprefix = AS_ALLOW_UNINDEXED_QUERIES ? 'articles/' : null; // this default is applied if sorted not by recent
$feedpathprefix = null;
$linkparams = array('sort' => $sort);

switch ($sort) {
	case 'hot':
		$sometitle = $countslugs ? as_lang_html_sub('main/hot_qs_in_x', $departmenttitlehtml) : as_lang_html('main/hot_qs_title');
		$feedpathprefix = as_opt('feed_for_hot') ? 'hot' : null;
		break;

	case 'votes':
		$sometitle = $countslugs ? as_lang_html_sub('main/voted_qs_in_x', $departmenttitlehtml) : as_lang_html('main/voted_qs_title');
		break;

	case 'answers':
		$sometitle = $countslugs ? as_lang_html_sub('main/answered_qs_in_x', $departmenttitlehtml) : as_lang_html('main/answered_qs_title');
		break;

	case 'views':
		$sometitle = $countslugs ? as_lang_html_sub('main/viewed_qs_in_x', $departmenttitlehtml) : as_lang_html('main/viewed_qs_title');
		break;

	default:
		$linkparams = array();
		$sometitle = $countslugs ? as_lang_html_sub('main/recent_qs_in_x', $departmenttitlehtml) : as_lang_html('main/recent_qs_title');
		$departmentpathprefix = 'articles/';
		$feedpathprefix = as_opt('feed_for_articles') ? 'articles' : null;
		break;
}


// Prepare and return content for theme

$as_content = as_q_list_page_content(
	$articles, // articles
	as_opt('page_size_qs'), // articles per page
	$start, // start offset
	$countslugs ? $departments[$departmentid]['qcount'] : as_opt('cache_qcount'), // total count
	$sometitle, // title if some articles
	$nonetitle, // title if no articles
	$departments, // departments for navigation
	$departmentid, // selected department id
	true, // show article counts in department navigation
	$departmentpathprefix, // prefix for links in department navigation
	$feedpathprefix, // prefix for RSS feed paths
	$countslugs ? as_html_suggest_qs_tags(as_using_tags()) : as_html_suggest_write($departmentid), // suggest what to do next
	$linkparams, // extra parameters for page links
	$linkparams // department nav params
);

if (AS_ALLOW_UNINDEXED_QUERIES || !$countslugs) {
	$as_content['navigation']['sub'] = as_qs_sub_navigation($sort, $departmentslugs);
}


return $as_content;
