<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for timetables page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/members.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';

$page = as_request_part(1);
$pagestate = as_get_state();
$as_content = as_content_prepare();
$memberid = as_get_logged_in_memberid();

list($groups, $teachers, $units) = as_db_select_with_pending(
	as_db_group_nav_selectspec(null, true, false, true),
	as_db_list_members_selectspec('TEACHER', 0),
	as_db_unit_nav_selectspec(null, true, false, true)
);

$in = array();
$menuItems = array();

$menuItems['timetables$'] = array(
	'label' => as_lang_html('main/recent_timetables'),
	'url' => as_path_html('timetables'),
);

$menuItems['timetables/drafts'] = array(
	'label' => as_lang_html('main/draft_timetables'),
	'url' => as_path_html('timetables/drafts'),
);

$menuItems['timetables/create'] = array(
	'label' => as_lang_html('main/new_item'),
	'url' => as_path_html('timetables/create'),
);

if (as_clicked('dosaveclose')) {
	require_once AS_INCLUDE_DIR.'app/post-create.php';
	
	$in['title'] = as_post_text('title');
	$in['content'] = as_post_text('content');
	$in['duration'] = as_post_text('duration');
	$in['count'] = as_post_text('count');
	$in['slots'] = as_get_tags_field_value('slots');
	$in['slots_raw'] = as_post_text('slots');
	
	$errors = array();
	
	if (!as_check_form_security_code('new-timetable', as_post_text('code'))) {
		$errors['page'] = as_lang_html('misc/form_security_again');
	} else {
		$filtermodules = as_load_modules_with('filter', 'filter_timetable');
		foreach ($filtermodules as $filtermodule) {
			$oldin = $in;
			$filtermodule->filter_timetable($in, $errors, null);
		}

		if (empty($errors)) {
			$cookieid = isset($memberid) ? as_cookie_get() : as_cookie_get_create(); // create a new cookie if necessary
			
			$timetableid = as_timetable_create($memberid, as_get_logged_in_handle(), as_get_logged_in_email(),$cookieid, $in['title'], $in['content'], $in['count'], $in['duration'], $in['slots_raw']);
			as_redirect('timetable/'.$timetableid);
		}
	}
}

if (as_clicked('dosaveadd')) {
	require_once AS_INCLUDE_DIR.'app/post-create.php';
	
	$in['title'] = as_post_text('title');
	$in['content'] = as_post_text('content');
	$in['duration'] = as_post_text('duration');
	$in['count'] = as_post_text('count');
	$in['slots'] = as_get_tags_field_value('slots');
	$in['slots_raw'] = as_post_text('slots');
	
	$errors = array();
	
	if (!as_check_form_security_code('new-timetable', as_post_text('code'))) {
		$errors['page'] = as_lang_html('misc/form_security_again');
	} else {
		$filtermodules = as_load_modules_with('filter', 'filter_timetable');
		foreach ($filtermodules as $filtermodule) {
			$oldin = $in;
			$filtermodule->filter_timetable($in, $errors, null);
		}

		if (empty($errors)) {
			$cookieid = isset($memberid) ? as_cookie_get() : as_cookie_get_create(); // create a new cookie if necessary
			
			$timetableid = as_timetable_create($memberid, as_get_logged_in_handle(), as_get_logged_in_email(),$cookieid, $in['title'], $in['content'], $in['count'], $in['duration'], $in['slots_raw']);
			as_redirect('timetables/create');
		}
	}
}

switch ($page) {
	case 'create':
		$as_content['title'] = as_lang_html('main/new_timetable');
		$classcodes = '<br>';
		foreach ($groups as $class) {
			$classcodes .= $class['title'] . ' - <b>' . $class['code'] . '</b>, ';
		}
		
		$teachershtml = as_memberids_handles_html($teachers);

		$teachercodes = '<br>';
		foreach ($teachers as $teacher) {
			$teachercodes .= $teachershtml[$teacher['memberid']] . ' (' . ($teacher['sex'] == '1' ? 'M' : 'F') . ') - <b>' . $teacher['code'] . '</b>, ';
		}
		
		$completeslots = array();
		$slotsfield = array(
			'error' => as_html(@$errors['slots']),
		);
	
		as_set_up_slot_field($as_content, $slotsfield, 'slots', isset($in['slots']) ? $in['slots'] : array(), array(), as_opt('do_complete_tags') ? array_keys($completeslots) : array(), as_opt('page_size_write_tags'));

		$as_content['form'] = array(
			'tags' => 'method="post" action="' . as_self_html() . '"',
			'style' => 'tall',
			
			'fields' => array(
				'title' => array(
					'label' => as_lang_html('main/timetable_name_label'),
					'tags' => 'name="title" id="title" dir="auto"',
					'value' => as_html(@$in['title']),
					'error' => as_html(@$errors['title']),
				),
				
				'content' => array(
					'label' => as_lang_html('main/timetable_content_label'),
					'tags' => 'name="content" id="content" dir="auto"',
					'value' => as_html(@$in['content']),
					'type' => 'textarea',
					'rows' => 2,
					'error' => as_html(@$errors['content']),
				),
				
				'duration' => array(
					'label' => as_lang_html('main/timetable_duration_label'),
					'suffix' => as_lang_html('options/minutes_suffix'),
					'tags' => 'name="duration" id="duration" dir="auto"',
					'value' => as_html(@$in['duration']),
					'type' => 'updown',
					'error' => as_html(@$errors['duration']),
				),
				
				'slots' => $slotsfield,
				
				'count' => array(
					'label' => as_lang_html('main/timetable_lessons_label'),
					'tags' => 'name="count" id="count" readonly dir="auto"',
					'value' => 0,
					'type' => 'number',
					'error' => as_html(@$errors['count']),
				),
				
				'tableview' => array(
					'type' => 'custom',
					'html' => '<span id="tableviewer"></span>'."\n".'<table id="lazydata" style="display:none;"><tr><td><img src="'.as_path_to_root().'as-media/cyclic.gif" /></td>'."\n".'<td><img src="'.as_path_to_root().'as-media/cyclic.gif" /></td>'."\n".'<td><img src="'.as_path_to_root().'as-media/cyclic.gif" /></td></tr></table>'."\n".'<center><h1 onclick="as_table_preview()" style="cursor:pointer;">Click to See Preview</h1></center>',
				),
						
			),
			'buttons' => array(
				'saveclose' => array(
					'tags' => 'name="dosaveclose" onclick="as_show_waiting_after(this, false);"',
					'label' => as_lang_html('main/save_view'),
				),
				
				'saveadd' => array(
					'tags' => 'name="dosaveadd" onclick="as_show_waiting_after(this, false);"',
					'label' => as_lang_html('main/save_add'),
				),
				
				'cancel' => array(
					'tags' => 'name="docancel"',
					'label' => as_lang_html('main/cancel_button'),
				),
			),

			'hidden' => array(
				'docreate' => '1',
				'code' => as_get_form_security_code('new-timetable'),
			),
		);

		$as_content['focusid'] = 'title';
		break;
	case 'drafts':
		$as_content['script_src'][] = '../as-content/as-tables.js?'.AS_VERSION;
		$as_content['title'] = as_lang_html('main/draft_timetables');

		$as_content['listing'] = array(
			'items' => array(),
			'checker' => '', 
			'headers' => array(
				as_lang('options/label_title'),
				as_lang('options/label_lessons'),
				as_lang('main/created'),
				as_lang('main/updated'),
			),
		);
			
		as_set_template('osam');
		$timetables = as_db_select_with_pending(as_db_list_timetables_selectspec('1'));
		if (count($timetables)) {
			foreach ($timetables as $timetableid => $timetable) {
				$timetableid = $timetable['timetableid'];
				$as_content['listing']['items'][] = array(
					'onclick' => ' title="Click on this item to edit or view" onclick="location=\''.as_path_html('timetable/'.$timetableid).'\'"',
					'fields' => array(
						'checkthis' => array( 'data' => '<label><input id="chk-item-'. $timetable['timetableid'] . '" class="chk-item" name="chk-item-checked[]" type="checkbox" value="'.$timetableid. '">
						'. $timetableid . '</label>' ),
						'label' => array( 'data' => $timetable['title']),
						'lessons' => array( 'data' => '0' ),
						'created' => array( 'data' => as_lang_html_sub('main/x_ago', 
							as_html(as_time_to_string(as_opt('db_time') - $timetable['created'])))),
						'updated' => array( 'data' => ($timetable['updated']) ? as_lang_html_sub('main/x_ago', 
							as_html(as_time_to_string(as_opt('db_time') - $timetable['updated']))) : ''),
					),
				);			
			}
		} else $as_content['title'] = as_lang_html('main/no_timetables');
		break;
	default:
		$as_content['script_src'][] = 'as-content/as-tables.js?'.AS_VERSION;
		$timetables = as_db_select_with_pending(as_db_list_timetables_selectspec('0'));

		$as_content['title'] = as_lang_html('main/timetable_title');

		$as_content['listing'] = array(
			'items' => array(),
			'checker' => '', 
			'headers' => array(
				as_lang('options/label_title'),
				as_lang('options/label_lessons'),
				as_lang('main/created'),
				as_lang('main/updated'),
			),
		);
			
		if (count($timetables)) {
			foreach ($timetables as $timetableid => $timetable) {
				$timetableid = $timetable['timetableid'];
				$as_content['listing']['items'][] = array(
					'onclick' => ' title="Click on this item to edit or view" onclick="location=\''.as_path_html('timetable/'.$timetableid).'\'"',
					'fields' => array(
						'checkthis' => array( 'data' => '<label><input id="chk-item-'. $timetable['timetableid'] . '" class="chk-item" name="chk-item-checked[]" type="checkbox" value="'.$timetableid. '">
						'. $timetableid . '</label>' ),
						'label' => array( 'data' => $timetable['title']),
						'lessons' => array( 'data' => '0' ),
						'created' => array( 'data' => as_lang_html_sub('main/x_ago', 
							as_html(as_time_to_string(as_opt('db_time') - $timetable['created'])))),
						'updated' => array( 'data' => ($timetable['updated']) ? as_lang_html_sub('main/x_ago', 
							as_html(as_time_to_string(as_opt('db_time') - $timetable['updated']))) : ''),
					),
				);		
			}
		} else $as_content['title'] = as_lang_html('main/no_timetables');
		break;
}

as_set_template('osam');
$as_content['navigation']['sub'] = $menuItems;

return $as_content;