<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for examinations page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/members.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/posts.php';

$page = as_request_part(1);
$pagestate = as_get_state();
$as_content = as_content_prepare();
$memberid = as_get_logged_in_memberid();

$in = array();
$menuItems = array();

$menuItems['examinations$'] = array(
	'label' => as_lang_html('main/current_examinations'),
	'url' => as_path_html('examinations'),
);

$menuItems['examinations/past'] = array(
	'label' => as_lang_html('main/past_examinations'),
	'url' => as_path_html('examinations/past'),
);

$menuItems['examinations/create'] = array(
	'label' => as_lang_html('main/new_examination'),
	'url' => as_path_html('examinations/create'),
);

if (as_clicked('docreate')) {
	require_once AS_INCLUDE_DIR.'app/post-create.php';
	
	$intitle = as_post_text('title');
	$incode = as_post_text('ecode');
	$incontent = as_post_text('content');
	$intestfrom = as_post_text('testfrom');
	$intestto = as_post_text('testfrom');
	
	$errors = array();	
	if (!as_check_form_security_code('new-examination', as_post_text('code'))) {
		$errors['page'] = as_lang_html('misc/form_security_again');
	} else {
		if (empty($errors)) {
			$cookieid = isset($memberid) ? as_cookie_get() : as_cookie_get_create();			
			$examid = as_examination_create($memberid, as_get_logged_in_handle(), as_get_logged_in_email(), $cookieid, $intitle, $incode, $incontent, $intestfrom, $intestto);			
			as_redirect('examinations/'.$examid);
		}
	}
}
						
if (as_clicked('dopaper')) {
	require_once AS_INCLUDE_DIR.'app/post-create.php';
	$inexamid = as_post_text('examid');
	$inclass = as_post_text('group');
	$inunit = as_post_text('unit');
	$intype = as_post_text('type');
	$intitle = as_post_text('title');
	$inscount = as_post_text('scount');
	$induration = as_post_text('duration');
	$inpapers = as_post_text('papers');
	
	$errors = array();	
	if (!as_check_form_security_code('new-paper', as_post_text('code'))) {
		$errors['page'] = as_lang_html('misc/form_security_again');
	} else {
		if (empty($errors)) {
			$cookieid = isset($memberid) ? as_cookie_get() : as_cookie_get_create();			
			$paperid = as_paper_create($memberid, as_get_logged_in_handle(), as_get_logged_in_email(), $cookieid, $inexamid, $inclass, $inunit, $intype, $intitle, $inscount, $induration, $inpapers);			
			as_redirect( 'examinations/' . $inexamid . '/paper/' . $paperid );
		}
	}
}

if (as_clicked('setclose')) {
	require_once AS_INCLUDE_DIR.'app/post-create.php';
	require_once AS_INCLUDE_DIR.'util/string.php';
	
	$in['paperid'] = as_post_text('paperid');
	$in['qcount'] = as_post_text('questions');
	$in['answera'] = as_post_text('answera');
	$in['answerb'] = as_post_text('answerb');
	$in['answerc'] = as_post_text('answerc');
	$in['answerd'] = as_post_text('answerd');
	$in['marks'] = as_post_text('marks');
	$in['answer'] = as_post_text('answer');
	as_get_post_content('editor', 'question', $in['editor'], $in['question'], $in['format'], $in['text']);

	$errors = array();
	if (!as_check_form_security_code('set-exam', as_post_text('code'))) {
		$errors['page'] = as_lang_html('misc/form_security_again');
	} else {
		if (empty($errors)) {
			$cookieid = isset($memberid) ? as_cookie_get() : as_cookie_get_create();
			$questionid = as_question_create($memberid, as_get_logged_in_handle(), as_get_logged_in_email(), $cookieid, $in['paperid'], $in['question'], $in['format'], $in['text'], $in['answera'], $in['answerb'], $in['answerc'], $in['answerd'], $in['marks'], $in['answer'], $in['qcount']);

			as_redirect( 'examinations/' . $page . '/paper/' . $in['paperid'] );
		}
	}
}

if (as_clicked('setadd')) {
	require_once AS_INCLUDE_DIR.'app/post-create.php';
	require_once AS_INCLUDE_DIR.'util/string.php';
	
	$in['paperid'] = as_post_text('paperid');
	$in['qcount'] = as_post_text('questions');
	$in['answera'] = as_post_text('answera');
	$in['answerb'] = as_post_text('answerb');
	$in['answerc'] = as_post_text('answerc');
	$in['answerd'] = as_post_text('answerd');
	$in['marks'] = as_post_text('marks');
	$in['answer'] = as_post_text('answer');
	as_get_post_content('editor', 'question', $in['editor'], $in['question'], $in['format'], $in['text']);

	$errors = array();
	if (!as_check_form_security_code('set-exam', as_post_text('code'))) {
		$errors['page'] = as_lang_html('misc/form_security_again');
	} else {
		if (empty($errors)) {
			$cookieid = isset($memberid) ? as_cookie_get() : as_cookie_get_create();
			$questionid = as_question_create($memberid, as_get_logged_in_handle(), as_get_logged_in_email(), $cookieid, $in['paperid'], $in['question'], $in['format'], $in['text'], $in['answera'], $in['answerb'], $in['answerc'], $in['answerd'], $in['marks'], $in['answer'], $in['qcount']);

			as_redirect( as_request() );
		}
	}
}

if (is_numeric($page)) {
	$examid = $page;	
	switch ( as_request_part(2) ) {
		case 'paper':
			$thispaper = as_request_part(3);
			if (is_numeric($thispaper)) {
				switch ( as_request_part(4) ) {
					case 'setexam':
						$paper = as_db_select_with_pending(as_db_examspapers_selectspec($memberid, $thispaper));
						if ($paper['qcount'] == 0) {
							$as_content['subtitle'] = as_lang('main/no_questions_found').' ' . as_lang_html_sub('main/questions_missing_x', $paper['qcount']);
						} else {
							if ($paper['qcount'] == $paper['scount'])
								$as_content['subtitle'] = as_lang_html_sub('main/questions_found_x', $paper['qcount']);
							else 
								$as_content['subtitle'] = as_lang_html_sub('main/questions_missing_x', 
							($paper['scount'] - $paper['qcount']));
						} 
						
						as_set_template('write');
						$as_content['title'] = as_lang_html_sub('main/set_exams_x', as_exam_name($paper));
						
						$editorname = isset($in['editor']) ? $in['editor'] : as_opt('editor_for_qs');
						$editor = as_load_editor(@$in['question'], @$in['format'], $editorname);

						$field = as_editor_load_field($editor, $as_content, @$in['question'], @$in['format'], 'question', 12, false);
						$field['label'] = as_lang_html('main/question_label');
						$field['style'] = 'tall';
						$field['error'] = as_html(@$errors['question']);

						$as_content['form'] = array(
							'tags' => 'method="post" action="' . as_self_html() . '"',
							'style' => 'wide',
							
							'fields' => array(
								
								'question' => $field,
								
								'answera' => array(
									'label' => as_lang_html('options/answer_a_label') . ':',
									'tags' => 'name="answera" id="answera" dir="auto"',
									'value' => as_html(@$inanswera),
									'type' => 'textarea',
									'rows' => 2,
									'error' => as_html(@$errors['answera']),
								),
								
								'answerb' => array(
									'label' => as_lang_html('options/answer_b_label') . ':',
									'tags' => 'name="answerb" id="answerb" dir="auto"',
									'value' => as_html(@$inanswerb),
									'type' => 'textarea',
									'rows' => 2,
									'error' => as_html(@$errors['answerb']),
								),
								
								'answerc' => array(
									'label' => as_lang_html('options/answer_c_label') . ':',
									'tags' => 'name="answerc" id="answerc" dir="auto"',
									'value' => as_html(@$inanswerc),
									'type' => 'textarea',
									'rows' => 2,
									'error' => as_html(@$errors['answerc']),
								),
								
								'answerd' => array(
									'label' => as_lang_html('options/answer_d_label') . ':',
									'tags' => 'name="answerd" id="answerd" dir="auto"',
									'value' => as_html(@$inanswerd),
									'type' => 'textarea',
									'rows' => 2,
									'error' => as_html(@$errors['answerd']),
								),
								
								'marks' => array(
									'label' => as_lang_html('options/label_marks') . ':',
									'tags' => 'name="marks" id="marks" dir="auto"',
									'value' => as_html(@$inmarks),
									'type' => 'number',
									'error' => as_html(@$errors['marks']),
								),
								
								'answer' => array(
									'label' => as_lang_html('options/label_answer'),
									'tags' => 'name="answer" id="answer" dir="auto"',
									'type' => 'select',
									'options' => array(
										'A' => as_lang('options/answer_a_label'),
										'B' => as_lang('options/answer_b_label'),
										'C' => as_lang('options/answer_c_label'),
										'D' => as_lang('options/answer_d_label'),
									),
									'value' => as_html(@$inanswer),
									'error' => as_html(@$errors['answer']),
								),
								
							),
							
							'buttons' => array(
								'setclose' => array(
									'tags' => 'onclick="as_show_waiting_after(this, false); '.
										(method_exists($editor, 'update_script') ? $editor->update_script('question') : '').'"',
									'label' => as_lang_html('main/new_question_close'),
								),
								'setadd' => array(
									'tags' => 'onclick="as_show_waiting_after(this, false); '.
										(method_exists($editor, 'update_script') ? $editor->update_script('question') : '').'"',
									'label' => as_lang_html('main/new_question_add'),
								),
							),

							'hidden' => array(
								'editor' => as_html($editorname),
								'code' => as_get_form_security_code('set-exam'),
								'questions' => $paper['qcount'],
								'paperid' => $paper['paperid'],
								'dosetexam' => '1',
								'dosetexam' => '1',
							),
						);
						
						$as_content['focusid'] = 'group';
						break;
						
					case 'editpaper':
						as_set_template('osam');
						$as_content['title'] = as_lang_html('main/edit_paper');
						$classoptions = array();
						$unitoptions = array();
						
						list($groups, $units) = as_db_select_with_pending(
							as_db_group_nav_selectspec(null, true), as_db_unit_nav_selectspec(null, true)
						);
						
						foreach ($groups as $group) $classoptions[$group['groupid']] = $group['title'];
						foreach ($units as $unit) $unitoptions[$unit['unitid']] = $unit['title'];
						
						$as_content['form'] = array(
							'tags' => 'method="post" action="' . as_self_html() . '"',
							'style' => 'wide',
							
							'fields' => array(
								'group' => array(
									'label' => as_lang_html('main/paper_group_label'),
									'tags' => 'name="group" id="group" dir="auto"',
									'type' => 'select',
									'options' => $classoptions,
									'value' => as_html(@$inclass),
									'error' => as_html(@$errors['group']),
								),
								
								'unit' => array(
									'label' => as_lang_html('main/paper_unit_label'),
									'tags' => 'name="unit" id="unit" dir="auto"',
									'type' => 'select',
									'options' => $unitoptions,
									'value' => as_html(@$inunit),
									'error' => as_html(@$errors['unit']),
								),
								
								'title' => array(
									'label' => as_lang_html('options/optional_title_label'),
									'tags' => 'name="title" id="title" dir="auto"',
									'value' => as_html(@$intitle),
									'error' => as_html(@$errors['title']),
								),
								
								'qcount' => array(
									'label' => as_lang_html('options/number_questions_label'),
									'tags' => 'name="qcount" id="qcount" dir="auto"',
									'value' => as_html(@$inqcount),
									'type' => 'number',
									'error' => as_html(@$errors['qcount']),
								),
								
								'duration' => array(
									'label' => as_lang_html('options/label_duration') . ':',
									'tags' => 'name="duration" id="duration" dir="auto"',
									'value' => as_html(@$induration),
									'type' => 'number',
									'suffix' => as_lang_html('options/minutes_suffix'),
									'error' => as_html(@$errors['duration']),
								),
								
							),
							'buttons' => array(
								'paper' => array(
									'tags' => 'onclick="as_show_waiting_after(this, false);"',
									'label' => as_lang_html('main/new_paper_button'),
								),
							),

							'hidden' => array(
								'dopaper' => '1',
								'code' => as_get_form_security_code('new-paper'),
							),
						);
						
						$as_content['focusid'] = 'group';
						break;
						
					default:
						list($paper, $questions) = as_db_select_with_pending(
							as_db_examspapers_selectspec($memberid, $thispaper),
							as_db_quizes_selectspec($memberid, 'created', $thispaper, null, false, false)
						);
						
						as_set_template('osam');
						$as_content['title'] = as_exam_name($paper);
						$as_content['script_src'][] = '../../../as-content/as-tables.js?'.AS_VERSION;
						
						$as_content['listing'] = array(
							'items' => array(),
							'checker' => '',
							'headers' => array(
								as_lang('options/label_question'),
								as_lang('options/label_answer'),
								as_lang('options/label_marks'),
								as_lang('main/created'),
								),
							'select' => array(
								'delete' => array('value' => 'delete', 'label' => as_lang('options/delete')),
								'suspend' => array('value' => 'suspend', 'label' => as_lang('options/suspend')),
								),
							'links' => array(
								'editpaper' => array('label' => as_lang('main/edit_paper'), 'url' => as_request().'/editpaper'),
								'setexam' => array('label' => as_lang('main/new_question'), 'url' => as_request().'/setexam'),
							),
						);
						
						if (count($questions)) {
							if ($paper['qcount'] == $paper['scount'])
								$as_content['subtitle'] = as_lang_html_sub('main/questions_found_x', $paper['qcount']);
							else $as_content['subtitle'] = as_lang_html_sub('main/questions_missing_x', ($paper['scount'] - $paper['qcount']));
						
							foreach ($questions as $question => $quiz) {
								$quizid = $quiz['quizid'];
								$body = strip_tags($quiz['question']);
								//$summary = substr($body, 0, strpos($body, ' ', 200));
								
								$as_content['listing']['items'][] = array(
									'onclick' => ' title="This question has a score of '.$quiz['score'].': '.$quiz['attempts'].' attempts, '.$quiz['skips'].' skips! Click to view" onclick="location=\''.as_path_html('examinations/questions/'.$quizid).'\'"',
									'fields' => array(
										'checkthis' => array( 'data' => '<label><input id="chk-item-'. $quizid . '" group="chk-item" name="chk-item-checked[]" type="checkbox" value="'.$quizid. '">
										'. $quizid . '</label>' ),
										'question' => array( 'data' => substr($body, 0, 100)),
										'answer' => array( 'data' => $quiz['answer']),
										'marks' => array( 'data' => $quiz['marks'] ),
										'created' => array( 'data' => as_lang_html_sub('main/x_ago', 
											as_html(as_time_to_string(as_opt('db_time') - $quiz['created'])))),
									),
								);		
							}
						} else 
							$as_content['subtitle'] = as_lang('main/no_questions_found'). ' ' . as_lang_html_sub('main/questions_missing_x', $paper['qcount']);
					break;
				}
			} else {
				switch ( $thispaper ) {
					case 'create':
						as_set_template('osam');
						$classoptions = array();
						$unitoptions = array();
						
						list($exam, $groups, $units) = as_db_select_with_pending(
							as_db_examinations_selectspec($memberid, $page),
							as_db_group_nav_selectspec(null, true), 
							as_db_unit_nav_selectspec(null, true)
						);
						$intitle = $exam['title'];
						$inscount = 5;
						$induration = 10;
						$as_content['title'] = as_lang_html('main/new_paper_for').' '.$intitle;
						
						foreach ($groups as $group) $classoptions[$group['groupid']] = $group['title'];
						foreach ($units as $unit) $unitoptions[$unit['unitid']] = $unit['title'];
						
						$papertype = array();
						$papertype['label'] = as_lang_html('main/paper_type');
						as_optionfield_make_select($papertype, array(
							'ONLINE' => as_lang_html('main/paper_online'),
							'OFFLINE' => as_lang_html('main/paper_offline'),
						), as_html(@$intype), 'ONLINE');
						$papertype['tags'] = 'name="type" id="type" dir="auto"';
						$papertype['type'] = 'select-radio';
						$papertype['error'] = as_html(@$errors['type']);

						$as_content['form'] = array(
							'tags' => 'method="post" action="' . as_self_html() . '"',
							'style' => 'wide',
							
							'fields' => array(
								'group' => array(
									'label' => as_lang_html('main/paper_group_label'),
									'tags' => 'name="group" id="group" dir="auto"',
									'type' => 'select',
									'options' => $classoptions,
									'value' => as_html(@$inclass),
									'error' => as_html(@$errors['group']),
								),
								
								'unit' => array(
									'label' => as_lang_html('main/paper_unit_label'),
									'tags' => 'name="unit" id="unit" dir="auto"',
									'type' => 'select',
									'options' => $unitoptions,
									'value' => as_html(@$inunit),
									'error' => as_html(@$errors['unit']),
								),
								
								'title' => array(
									'label' => as_lang_html('options/optional_title_label'),
									'tags' => 'name="title" id="title" dir="auto"',
									'value' => as_html(@$intitle),
									'error' => as_html(@$errors['title']),
								),
								
								'type' => $papertype,

								'scount' => array(
									'label' => as_lang_html('options/number_questions_label'),
									'tags' => 'name="scount" id="scount" dir="auto" min="5" max="100"',
									'value' => as_html(@$inscount),
									'type' => 'updown',
									'error' => as_html(@$errors['scount']),
								),
								
								'duration' => array(
									'label' => as_lang_html('options/label_duration') . ':',
									'tags' => 'name="duration" id="duration" dir="auto" min="10" max="500"',
									'value' => as_html(@$induration),
									'type' => 'updown',
									'suffix' => as_lang_html('options/minutes_suffix'),
									'error' => as_html(@$errors['duration']),
								),
								
							),
							'buttons' => array(
								'paper' => array(
									'tags' => 'onclick="as_show_waiting_after(this, false);"',
									'label' => as_lang_html('main/new_paper_button'),
								),
							),

							'hidden' => array(
								'dopaper' => '1',
								'examid' => $exam['examid'],
								'papers' => $exam['papers'],
								'code' => as_get_form_security_code('new-paper'),
							),
						);
						
						$as_content['focusid'] = 'group';
						break;
						
					case 'edit':
					
						break;
				}
			}
			break;

		default:
			list($examination, $epapers) = as_db_select_with_pending(
				as_db_examinations_selectspec($memberid, $examid),
				as_db_list_examspapers_selectspec($examid)
			);
		
			as_set_template('osam');
			$as_content['title'] = count($epapers) . ' ' . as_lang_html_sub('main/papers_in_x', $examination['title']);
			$as_content['script_src'][] = '../as-content/as-tables.js?'.AS_VERSION;
			$as_content['script'][] = '<script>
$(\'#exam_change\').change(funtion() {
	window.location.href = $(this).val();
});
</script>';
			
			$as_content['listing'] = array(
				'items' => array(),
				'checker' => '',
				'headers' => array(
					//as_lang('options/label_title'),
					as_lang('options/label_group'),
					as_lang('options/label_unit'),
					as_lang('options/label_qcount'),
					as_lang('options/label_duration'),
					//as_lang('options/label_attempts'),
					//as_lang('options/label_unfinished'),
					as_lang('options/label_score'),
					as_lang('main/created'),
					),
				'select' => array(
					'delete' => array('value' => 'delete', 'label' => as_lang('options/delete')),
					'suspend' => array('value' => 'suspend', 'label' => as_lang('options/suspend')),
					),
				'extras' => '<select class="as-form-select-button" id="exam_change">
					<option value="">' . as_lang('options/switch_exam') . '</option>
					<option value="http://localhost/osam/site/examinations">Exam 1</option>
					<option value="http://localhost/osam/site">Exam 2</option>
					</select>',
				'links' => array(
					'edit' => array('label' => as_lang('main/edit_exam'), 'url' => as_request().'/edit'),
					'paper' => array('label' => as_lang('main/new_paper'), 'url' => as_request().'/paper/create'),
				),
			);
			
			if (count($epapers)) {
				foreach ($epapers as $epaper => $paper) {
					$group = as_db_find_value('code', 'groups', 'groupid', $paper['groupid']);
					$unit = as_db_find_value('code', 'units', 'unitid', $paper['unitid']);
					$paperid = $paper['paperid'];
					$as_content['listing']['items'][] = array(
						'onclick' => ' title="Click on this item to edit or view" onclick="location=\''.as_path_html('examinations/paper/'.$paperid).'\'"',
						'fields' => array(
							'checkthis' => array( 'data' => '<label><input id="chk-item-'. $paper['paperid'] . '" class="chk-item" name="chk-item-checked[]" type="checkbox" value="'.$paperid. '"> '. $paperid . '</label>' ),
							'group' => array( 'data' => $group),
							'unit' => array( 'data' => $unit),
							'qcount' => array( 'data' => $paper['qcount'] ),
							'duration' => array( 'data' => $paper['duration'].' '.as_lang('options/minutes_suffix')),
							//'attempts' => array( 'data' => $paper['attempts'] ),
							//'unfinished' => array( 'data' => $paper['unfinished'] ),
							'score' => array( 'data' => $paper['score'] ),
							'created' => array( 'data' => as_lang_html_sub('main/x_ago', as_html(as_time_to_string(as_opt('db_time') - $paper['created'])))),
						),
					);		
				}
			} else $as_content['title'] = as_lang_html_sub('main/no_papers_in_x', $examination['title']);
		break;
	}
} elseif ( $page == 'create' ) {
	as_set_template('osam');
	$as_content['title'] = as_lang_html('main/new_examination');
	$as_content['script_src'][] = '../as-content/jsDatePick.full.1.1.js?'.AS_VERSION;
	$as_content['head_lines'][] = '<link rel="stylesheet" href="../as-content/jsDatePick.css?'.AS_VERSION.'">
<script type="text/javascript">
	window.onload = function(){
		new JsDatePick({ useMode:2, target:"testfrom" });
		new JsDatePick({ useMode:2, target:"testto" });
	};
</script>';
	//$as_content['script_onloads'][] = 'new JsDatePick({ useMode:2, target:"testfrom" });';
	//$as_content['script_onloads'][] = 'new JsDatePick({ useMode:2, target:"testto" });';
	
	$as_content['form'] = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',
		'style' => 'wide',
		
		'fields' => array(
			'title' => array(
				'label' => as_lang_html('main/examination_name_label'),
				'tags' => 'name="title" id="title" dir="auto"',
				'value' => as_html(@$intitle),
				'error' => as_html(@$errors['title']),
			),
			
			'ecode' => array(
				'label' => as_lang_html('main/examination_code_label'),
				'tags' => 'name="ecode" id="ecode" dir="auto"',
				'value' => as_html(@$incode),
				'error' => as_html(@$errors['ecode']),
			),
			
			'testfrom' => array(
				'label' => as_lang_html('main/examination_testfrom_label'),
				'tags' => 'name="testfrom" id="testfrom" size="16" readonly',
				'value' => as_html(@$intestfrom),
				'error' => as_html(@$errors['testfrom']),
			),
			
			'testto' => array(
				'label' => as_lang_html('main/examination_testto_label'),
				'tags' => 'name="testto" id="testto" size="16" readonly',
				'value' => as_html(@$intestto),
				'error' => as_html(@$errors['testto']),
			),
			
			'content' => array(
				'label' => as_lang_html('main/examination_content_label'),
				'tags' => 'name="content" id="content" dir="auto"',
				'value' => as_html(@$incontent),
				'style' => 'tall',
				'type' => 'textarea',
				'rows' => 2,
				'error' => as_html(@$errors['content']),
			),
			
		),
		'buttons' => array(
			'examination' => array(
				'tags' => 'onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html('main/new_examination_button'),
			),
		),

		'hidden' => array(
			'docreate' => '1',
			'code' => as_get_form_security_code('new-examination'),
		),
	);

	$as_content['focusid'] = 'title';
} elseif ( $page == 'past' ) {
	$as_content['script_src'][] = '../as-content/as-tables.js?'.AS_VERSION;
	$examinations = as_db_select_with_pending(as_db_list_examinations_selectspec(date('Y-m-d'), true));

	as_set_template('osam');
	$as_content['title'] = as_lang_html('main/past_examinations');

	$as_content['listing'] = array(
		'items' => array(),
		'checker' => '',
		'headers' => array(
			as_lang('options/label_title'),
			as_lang('options/label_papers'),
			as_lang('options/label_from'),
			as_lang('options/label_to'),
			as_lang('main/created'),
		),
	);
		
	if (count($examinations)) {
		foreach ($examinations as $examination => $exam) {
			$examid = $exam['examid'];
			$as_content['listing']['items'][] = array(
				'onclick' => ' title="Click on this item to edit or view" onclick="location=\''.as_path_html('examinations/'.$examid).'\'"',
				'fields' => array(
					'checkthis' => array( 'data' => '<label><input id="chk-item-'. $exam['examid'] . '" group="chk-item" name="chk-item-checked[]" type="checkbox" value="'.$examid. '">
					'. $examid . '</label>' ),
					'label' => array( 'data' => $exam['title']),
					'papers' => array( 'data' => $exam['papers'] ),
					'testfrom' => array( 'data' => $exam['testfrom'] ),
					'testto' => array( 'data' => $exam['testto'] ),
					'created' => array( 'data' => as_lang_html_sub('main/x_ago', 
						as_html(as_time_to_string(as_opt('db_time') - $exam['created'])))),
				),
			);		
		}
	} else $as_content['title'] = as_lang_html('main/no_past_examinations');
} else {
	$as_content['script_src'][] = 'as-content/as-tables.js?'.AS_VERSION;
	$examinations = as_db_select_with_pending(as_db_list_examinations_selectspec(date('Y-m-d'), false));

	as_set_template('osam');
	$as_content['title'] = as_lang_html('main/current_examinations');

	$as_content['listing'] = array(
		'items' => array(),
		'checker' => '',
		'headers' => array(
			as_lang('options/label_title'),
			as_lang('options/label_papers'),
			as_lang('options/label_from'),
			as_lang('options/label_to'),
			as_lang('main/created'),
		),
	);
		
	if (count($examinations)) {
		foreach ($examinations as $examination => $exam) {
			$examid = $exam['examid'];
			$as_content['listing']['items'][] = array(
				'onclick' => ' title="Click on this item to edit or view" onclick="location=\''.as_path_html('examinations/'.$examid).'\'"',
				'fields' => array(
					'checkthis' => array( 'data' => '<label><input id="chk-item-'. $exam['examid'] . '" group="chk-item" name="chk-item-checked[]" type="checkbox" value="'.$examid. '">
					'. $examid . '</label>' ),
					'label' => array( 'data' => $exam['title']),
					'papers' => array( 'data' => $exam['papers'] ),
					'testfrom' => array( 'data' => $exam['testfrom'] ),
					'testto' => array( 'data' => $exam['testto'] ),
					'created' => array( 'data' => as_lang_html_sub('main/x_ago', 
						as_html(as_time_to_string(as_opt('db_time') - $exam['created'])))),
				),
			);		
		}
	} else $as_content['title'] = as_lang_html('main/no_current_examinations');
}

$as_content['navigation']['sub'] = $menuItems;

return $as_content;
