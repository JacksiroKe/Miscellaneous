<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for unsubscribe page (unsubscribe link is sent in mass mailings)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/members.php';


// Check we're not using single-sign on integration

if (AS_FINAL_EXTERNAL_MEMBERS)
	as_fatal_error('Member login is handled by external code');


// Check the code and unsubscribe the member if appropriate

$unsubscribed = false;
$loginmemberid = as_get_logged_in_memberid();

$incode = trim(as_get('c')); // trim to prevent passing in blank values to match uninitiated DB rows
$inhandle = as_get('u');

if (!empty($inhandle)) { // match based on code and handle provided on URL
	$memberinfo = as_db_select_with_pending(as_db_member_account_selectspec($inhandle, false));

	if (strtolower(trim(@$memberinfo['emailcode'])) == strtolower($incode)) {
		as_db_member_set_flag($memberinfo['memberid'], AS_MEMBER_FLAGS_NO_MAILINGS, true);
		$unsubscribed = true;
	}
}

if (!$unsubscribed && isset($loginmemberid)) { // as a backup, also unsubscribe logged in member
	as_db_member_set_flag($loginmemberid, AS_MEMBER_FLAGS_NO_MAILINGS, true);
	$unsubscribed = true;
}


// Prepare content for theme

$as_content = as_content_prepare();

$as_content['title'] = as_lang_html('members/unsubscribe_title');

if ($unsubscribed) {
	$as_content['success'] = strtr(as_lang_html('members/unsubscribe_complete'), array(
		'^0' => as_html(as_opt('site_title')),
		'^1' => '<a href="' . as_path_html('account') . '">',
		'^2' => '</a>',
	));
} else {
	$as_content['error'] = as_insert_login_links(as_lang_html('members/unsubscribe_wrong_log_in'), 'unsubscribe');
}


return $as_content;
