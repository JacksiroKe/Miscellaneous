<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for login page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


if (as_is_logged_in()) {
	as_redirect('');
}

// Check we're not using APS's single-sign on integration and that we're not logged in
if (AS_FINAL_EXTERNAL_MEMBERS) {
	$request = as_request();
	$topath = as_get('to'); // lets member switch between login and register without losing destination page
	$memberlinks = as_get_login_links(as_path_to_root(), isset($topath) ? $topath : as_path($request, $_GET, ''));

	if (!empty($memberlinks['login'])) {
		as_redirect_raw($memberlinks['login']);
	}
	as_fatal_error('Member login should be handled by external code');
}


// Process submitted form after checking we haven't reached rate limit

$passwordsent = as_get('ps');
$emailexists = as_get('ee');

$inemailhandle = as_post_text('emailhandle');
$inpassword = as_post_text('password');
$inremember = as_post_text('remember');

if (as_clicked('dologin') && (strlen($inemailhandle) || strlen($inpassword))) {
	require_once AS_INCLUDE_DIR . 'app/limits.php';

	if (as_member_limits_remaining(AS_LIMIT_LOGINS)) {
		require_once AS_INCLUDE_DIR . 'db/members.php';
		require_once AS_INCLUDE_DIR . 'db/selects.php';

		if (!as_check_form_security_code('login', as_post_text('code'))) {
			$pageerror = as_lang_html('misc/form_security_again');
		}
		else {
			as_limits_increment(null, AS_LIMIT_LOGINS);

			$errors = array();

			if (as_opt('allow_login_email_only') || strpos($inemailhandle, '@') !== false) { // handles can't contain @ symbols
				$matchmembers = as_db_member_find_by_email($inemailhandle);
			} else {
				$matchmembers = as_db_member_find_by_handle($inemailhandle);
			}

			if (count($matchmembers) == 1) { // if matches more than one (should be impossible), don't log in
				$inmemberid = $matchmembers[0];
				$memberinfo = as_db_select_with_pending(as_db_member_account_selectspec($inmemberid, true));

				$legacyPassOk = hash_equals(strtolower($memberinfo['passcheck']), strtolower(as_db_calc_passcheck($inpassword, $memberinfo['passsalt'])));

				if (AS_PASSWORD_HASH) {
					$haspassword = isset($memberinfo['passhash']);
					$haspasswordold = isset($memberinfo['passsalt']) && isset($memberinfo['passcheck']);
					$passOk = password_verify($inpassword, $memberinfo['passhash']);

					if (($haspasswordold && $legacyPassOk) || ($haspassword && $passOk)) {
						// upgrade password or rehash, when options like the cost parameter changed
						if ($haspasswordold || password_needs_rehash($memberinfo['passhash'], PASSWORD_BCRYPT)) {
							as_db_member_set_password($inmemberid, $inpassword);
						}
					} else {
						$errors['password'] = as_lang('members/password_wrong');
					}
				} else {
					if (!$legacyPassOk) {
						$errors['password'] = as_lang('members/password_wrong');
					}
				}

				if (!isset($errors['password'])) {
					// login and redirect
					require_once AS_INCLUDE_DIR . 'app/members.php';
					as_set_logged_in_member($inmemberid, $memberinfo['handle'], !empty($inremember));

					$topath = as_get('to');

					if (isset($topath))
						as_redirect_raw(as_path_to_root() . $topath); // path already provided as URL fragment
					elseif ($passwordsent)
						as_redirect('account');
					else
						as_redirect('');
				}

			} else {
				$errors['emailhandle'] = as_lang('members/member_not_found');
			}
		}

	} else {
		$pageerror = as_lang('members/login_limit');
	}

} else {
	$inemailhandle = as_get('e');
}


// Prepare content for theme

$as_content = as_content_prepare();

$as_content['title'] = as_lang_html('members/login_title');

$as_content['error'] = @$pageerror;

if (empty($inemailhandle) || isset($errors['emailhandle']))
	$forgotpath = as_path('forgot');
else
	$forgotpath = as_path('forgot', array('e' => $inemailhandle));

$forgothtml = '<a href="' . as_html($forgotpath) . '">' . as_lang_html('members/forgot_link') . '</a>';

$as_content['form'] = array(
	'tags' => 'method="post" action="' . as_self_html() . '"',

	'style' => 'tall',

	'ok' => $passwordsent ? as_lang_html('members/password_sent') : ($emailexists ? as_lang_html('members/email_exists') : null),

	'fields' => array(
		'email_handle' => array(
			'label' => as_opt('allow_login_email_only') ? as_lang_html('members/email_label') : as_lang_html('members/email_handle_label'),
			'tags' => 'name="emailhandle" id="emailhandle" dir="auto"',
			'value' => as_html(@$inemailhandle),
			'error' => as_html(@$errors['emailhandle']),
		),

		'password' => array(
			'type' => 'password',
			'label' => as_lang_html('members/password_label'),
			'tags' => 'name="password" id="password" dir="auto"',
			'value' => as_html(@$inpassword),
			'error' => empty($errors['password']) ? '' : (as_html(@$errors['password']) . ' - ' . $forgothtml),
			'note' => $passwordsent ? as_lang_html('members/password_sent') : $forgothtml,
		),

		'remember' => array(
			'type' => 'checkbox',
			'label' => as_lang_html('members/remember_label'),
			'tags' => 'name="remember"',
			'value' => !empty($inremember),
		),
	),

	'buttons' => array(
		'login' => array(
			'label' => as_lang_html('members/login_button'),
		),
	),

	'hidden' => array(
		'dologin' => '1',
		'code' => as_get_form_security_code('login'),
	),
);

$loginmodules = as_load_modules_with('login', 'login_html');

foreach ($loginmodules as $module) {
	ob_start();
	$module->login_html(as_opt('site_url') . as_get('to'), 'login');
	$html = ob_get_clean();

	if (strlen($html))
		@$as_content['custom'] .= '<br>' . $html . '<br>';
}

$as_content['focusid'] = (isset($inemailhandle) && !isset($errors['emailhandle'])) ? 'password' : 'emailhandle';


return $as_content;
