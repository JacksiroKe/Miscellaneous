<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for units page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'app/admin.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'db/admin.php';
require_once AS_INCLUDE_DIR . 'db/post-create.php';
require_once AS_INCLUDE_DIR . 'app/format.php';

$menuItems = array();

$menuItems['departments$'] = array(
	'label' => as_lang_html('main/nav_departments'),
	'url' => as_path_html('departments'),
);

$menuItems['departments/units'] = array(
	'label' => as_lang_html('main/nav_units'),
	'url' => as_path_html('departments/units'),
);

// Get relevant list of units

$editunitid = as_post_text('edit');
if (!isset($editunitid))
	$editunitid = as_get('edit');
if (!isset($editunitid))
	$editunitid = as_get('addsub');

$units = as_db_select_with_pending(as_db_unit_nav_selectspec($editunitid, true, false, true));

// Work out the appropriate state for the page
$editunit = @$units[$editunitid];
if (as_get('edit') == '0') {
	 $editunit = array();
} else if (isset($editunit)) {
	$unitid = as_get('addsub');
	if (isset($unitid))
		$editunit = array('unitid' => $unitid);

} else {
	if (as_clicked('doaddunit')) $editunit = array();

	elseif (as_clicked('dosaveunit')) {
		$unitid = as_post_text('parent');
		$editunit = array('unitid' => strlen($unitid) ? $unitid : null);
	}
}

$setmissing = as_post_text('missing') || as_get('missing');

$setparent = !$setmissing && (as_post_text('setparent') || as_get('setparent')) && isset($editunit['unitid']);

$hassubunit = false;
foreach ($units as $unit) {
	if (!strcmp($unit['unitid'], $editunitid))
		$hassubunit = true;
}


// Process saving options

$savedoptions = false;
$securityexpired = false;

// Process saving an old or new unit

if (as_clicked('docancel')) {
	if ($setmissing || $setparent)
		as_redirect(as_request(), array('edit' => $editunit['unitid']));
	elseif (isset($editunit['unitid']))
		as_redirect(as_request());
	else
		as_redirect(as_request(), array('edit' => @$editunit['unitid']));

} elseif (as_clicked('dosetmissing')) {
	if (!as_check_form_security_code('departments-units', as_post_text('code')))
		$securityexpired = true;

	else {
		$inreassign = as_get_unit_field_value('reassign');
		as_db_unit_reassign($editunit['unitid'], $inreassign);
		as_redirect(as_request(), array('recalc' => 1, 'edit' => $editunit['unitid']));
	}

} 
elseif (as_clicked('dosaveclose')) {
	if (!as_check_form_security_code('departments-units', as_post_text('code'))) $securityexpired = true;

	elseif (as_post_text('dodelete')) {
		if (!$hassubunit) {
			$inreassign = as_get_unit_field_value('reassign');
			as_db_unit_reassign($editunit['unitid'], $inreassign);
			as_db_unit_delete($editunit['unitid']);
			as_redirect(as_request(), array('recalc' => 1, 'edit' => $editunit['unitid']));
		}

	} else {
		require_once AS_INCLUDE_DIR . 'util/string.php';

		$inname = as_post_text('name');
		$inshort = as_post_text('short');
		$incontent = as_post_text('content');
		$inunitid = $setparent ? as_get_unit_field_value('parent') : $editunit['unitid'];
		$inposition = as_post_text('position');
		$errors = array();

		// Check the parent ID

		$inunits = as_db_select_with_pending(as_db_unit_nav_selectspec($inunitid, true));
		
		// Verify the name is legitimate for that parent ID

		if (empty($inname))
			$errors['name'] = as_lang('main/field_required');
		elseif (as_strlen($inname) > AS_DB_MAX_CAT_PAGE_TITLE_LENGTH)
			$errors['name'] = as_lang_sub('main/max_length_x', AS_DB_MAX_CAT_PAGE_TITLE_LENGTH);
		elseif (empty($inshort))
			$errors['short'] = as_lang('main/field_required');
		else {
			foreach ($inunits as $unit) {
				if (!strcmp($unit['unitid'], $inunitid) &&
					strcmp($unit['unitid'], @$editunit['unitid']) &&
					as_strtolower($unit['title']) == as_strtolower($inname)
				) {
					$errors['name'] = as_lang('main/unit_already_used');
				}
			}
		}

		// Verify the slug is legitimate for that parent ID

		for ($attempt = 0; $attempt < 100; $attempt++) {
			switch ($attempt) {
				case 0:
					$inslug = as_post_text('slug');
					if (!isset($inslug))
						$inslug = implode('-', as_string_to_words($inname));
					break;

				case 1:
					$inslug = as_lang_sub('main/unit_default_slug', $inslug);
					break;

				default:
					$inslug = as_lang_sub('main/unit_default_slug', $attempt - 1);
					break;
			}

			$matchunitid = as_db_unit_slug_to_id($inunitid, $inslug); // query against DB since MySQL ignores accents, etc...

			if (!isset($inunitid))
				$matchpage = as_db_single_select(as_db_page_full_selectspec($inslug, false));
			else
				$matchpage = null;

			if (empty($inslug))
				$errors['slug'] = as_lang('main/field_required');
			elseif (as_strlen($inslug) > AS_DB_MAX_CAT_PAGE_TAGS_LENGTH)
				$errors['slug'] = as_lang_sub('main/max_length_x', AS_DB_MAX_CAT_PAGE_TAGS_LENGTH);
			elseif (preg_match('/[\\+\\/]/', $inslug))
				$errors['slug'] = as_lang_sub('main/slug_bad_chars', '+ /');
			elseif (!isset($inunitid) && as_admin_is_slug_reserved($inslug)) // only top level is a problem
				$errors['slug'] = as_lang('main/slug_reserved');
			elseif (isset($matchunitid) && strcmp($matchunitid, @$editunit['unitid']))
				$errors['slug'] = as_lang('main/unit_already_used');
			elseif (isset($matchpage))
				$errors['slug'] = as_lang('main/page_already_used');
			else
				unset($errors['slug']);

			if (isset($editunit['unitid']) || !isset($errors['slug'])) // don't try other options if editing existing unit
				break;
		}

		// Perform appropriate database action

		if (empty($errors)) {
			if (isset($editunit['unitid'])) { // changing existing unit
				as_db_unit_rename($editunit['unitid'], $inname, $inshort, $inslug);

				$recalc = false;

				as_db_unit_set_content($editunit['unitid'], $incontent);
				as_db_unit_set_position($editunit['unitid'], $inposition);

				as_redirect(as_request(), array('edit' => $editunit['unitid'], 'saved' => true, 'recalc' => (int)$recalc));

			} else { // creating a new one
				$unitid = as_db_unit_create($inunitid, $inname, $inshort, $inslug);

				as_db_unit_set_content($unitid, $incontent);

				if (isset($inposition))
					as_db_unit_set_position($unitid, $inposition);

				as_redirect(as_request(), array('edit' => $inunitid, 'added' => true));
			}
		}
	}
}

elseif (as_clicked('dosaveadd')) {
	if (!as_check_form_security_code('departments-units', as_post_text('code'))) $securityexpired = true;

	elseif (as_post_text('dodelete')) {
		if (!$hassubunit) {
			$inreassign = as_get_unit_field_value('reassign');
			as_db_unit_reassign($editunit['unitid'], $inreassign);
			as_db_unit_delete($editunit['unitid']);
			as_redirect(as_request(), array('recalc' => 1, 'edit' => $editunit['unitid']));
		}

	} else {
		require_once AS_INCLUDE_DIR . 'util/string.php';

		$inname = as_post_text('name');
		$inshort = as_post_text('short');
		$incontent = as_post_text('content');
		$inunitid = $setparent ? as_get_unit_field_value('parent') : $editunit['unitid'];
		$inposition = as_post_text('position');
		$errors = array();

		// Check the parent ID

		$inunits = as_db_select_with_pending(as_db_unit_nav_selectspec($inunitid, true));
		
		// Verify the name is legitimate for that parent ID

		if (empty($inname))
			$errors['name'] = as_lang('main/field_required');
		elseif (as_strlen($inname) > AS_DB_MAX_CAT_PAGE_TITLE_LENGTH)
			$errors['name'] = as_lang_sub('main/max_length_x', AS_DB_MAX_CAT_PAGE_TITLE_LENGTH);
		elseif (empty($inshort))
			$errors['short'] = as_lang('main/field_required');
		else {
			foreach ($inunits as $unit) {
				if (!strcmp($unit['unitid'], $inunitid) &&
					strcmp($unit['unitid'], @$editunit['unitid']) &&
					as_strtolower($unit['title']) == as_strtolower($inname)
				) {
					$errors['name'] = as_lang('main/unit_already_used');
				}
			}
		}

		// Verify the slug is legitimate for that parent ID

		for ($attempt = 0; $attempt < 100; $attempt++) {
			switch ($attempt) {
				case 0:
					$inslug = as_post_text('slug');
					if (!isset($inslug))
						$inslug = implode('-', as_string_to_words($inname));
					break;

				case 1:
					$inslug = as_lang_sub('main/unit_default_slug', $inslug);
					break;

				default:
					$inslug = as_lang_sub('main/unit_default_slug', $attempt - 1);
					break;
			}

			$matchunitid = as_db_unit_slug_to_id($inunitid, $inslug); // query against DB since MySQL ignores accents, etc...

			if (!isset($inunitid))
				$matchpage = as_db_single_select(as_db_page_full_selectspec($inslug, false));
			else
				$matchpage = null;

			if (empty($inslug))
				$errors['slug'] = as_lang('main/field_required');
			elseif (as_strlen($inslug) > AS_DB_MAX_CAT_PAGE_TAGS_LENGTH)
				$errors['slug'] = as_lang_sub('main/max_length_x', AS_DB_MAX_CAT_PAGE_TAGS_LENGTH);
			elseif (preg_match('/[\\+\\/]/', $inslug))
				$errors['slug'] = as_lang_sub('main/slug_bad_chars', '+ /');
			elseif (!isset($inunitid) && as_admin_is_slug_reserved($inslug)) // only top level is a problem
				$errors['slug'] = as_lang('main/slug_reserved');
			elseif (isset($matchunitid) && strcmp($matchunitid, @$editunit['unitid']))
				$errors['slug'] = as_lang('main/unit_already_used');
			elseif (isset($matchpage))
				$errors['slug'] = as_lang('main/page_already_used');
			else
				unset($errors['slug']);

			if (isset($editunit['unitid']) || !isset($errors['slug'])) // don't try other options if editing existing unit
				break;
		}

		// Perform appropriate database action

		if (empty($errors)) {
			if (isset($editunit['unitid'])) { // changing existing unit
				as_db_unit_rename($editunit['unitid'], $inname, $inshort, $inslug);

				$recalc = false;

				as_db_unit_set_content($editunit['unitid'], $incontent);
				as_db_unit_set_position($editunit['unitid'], $inposition);

				as_redirect(as_request(), array('edit' => $editunit['unitid'], 'saved' => true, 'recalc' => (int)$recalc));

			} else { // creating a new one
				$unitid = as_db_unit_create($inunitid, $inname, $inshort, $inslug);

				as_db_unit_set_content($unitid, $incontent);

				if (isset($inposition))
					as_db_unit_set_position($unitid, $inposition);

				as_redirect(as_request(), array('edit' => 0, 'added' => true));
				$editunit = array();
			}
		}
	}
}


// Prepare content for theme
$as_content = as_content_prepare();

$as_content['title'] = as_lang_html('main/nav_units');
$as_content['error'] = '';
$as_content['script_src'][] = '../as-content/as-tables.js?'.AS_VERSION;

if ($setmissing) {
	$as_content['form'] = array(
		'tags' => 'method="post" action="' . as_path_html(as_request()) . '"',

		'style' => 'tall',

		'fields' => array(
			'reassign' => array(
				'label' => isset($editunit)
					? as_lang_html_sub('main/unit_no_sub_to', as_html($editunit['title']))
					: as_lang_html('main/unit_none_to'),
				'loose' => true,
			),
		),

		'buttons' => array(
			'saveclose' => array(
				'tags' => 'name="dosaveclose" onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html(isset($editunit['unitid']) ? 'main/save_changes_close' : 'main/add_unit_close_button'),
			),
			
			'saveadd' => array(
				'tags' => 'name="dosaveadd" onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html(isset($editunit['unitid']) ? 'main/save_changes_only' : 'main/add_unit_more_button'),
			),

			'cancel' => array(
				'tags' => 'name="docancel"',
				'label' => as_lang_html('main/cancel_button'),
			),
		),

		'hidden' => array(
			'dosetmissing' => '1', // for IE
			'edit' => @$editunit['unitid'],
			'missing' => '1',
			'code' => as_get_form_security_code('departments-units'),
		),
	);

	as_set_up_unit_field($as_content, $as_content['form']['fields']['reassign'], 'reassign',
		$units, @$editunit['unitid'], as_opt('allow_no_unit'), as_opt('allow_no_sub_unit'));


} elseif (isset($editunit)) {
	$as_content['form'] = array(
		'tags' => 'method="post" action="' . as_path_html(as_request()) . '"',

		'style' => 'tall',

		'ok' => as_get('saved') ? as_lang_html('main/unit_saved') : (as_get('added') ? as_lang_html('main/unit_added') : null),

		'fields' => array(
			'name' => array(
				'id' => 'name_display',
				'tags' => 'name="name" id="name"',
				'label' => as_lang_html(count($units) ? 'main/unit_name' : 'main/unit_name_first'),
				'value' => as_html(isset($inname) ? $inname : @$editunit['title']),
				'error' => as_html(@$errors['name']),
			),
			
			'short' => array(
				'id' => 'code_display',
				'tags' => 'name="short" id="short"',
				'label' => as_lang_html('main/unit_short'),
				'value' => as_html(isset($inshort) ? $inshort : @$editunit['short']),
				'error' => as_html(@$errors['short']),
			),

			'delete' => array(),

			'reassign' => array(),

			'slug' => array(
				'id' => 'slug_display',
				'tags' => 'name="slug"',
				'label' => as_lang_html('main/unit_slug'),
				'value' => as_html(isset($inslug) ? $inslug : @$editunit['tags']),
				'error' => as_html(@$errors['slug']),
			),

			'content' => array(
				'id' => 'content_display',
				'tags' => 'name="content"',
				'label' => as_lang_html('main/unit_description'),
				'value' => as_html(isset($incontent) ? $incontent : @$editunit['content']),
				'error' => as_html(@$errors['content']),
				'rows' => 2,
			),
		),

		'buttons' => array(			
			'saveclose' => array(
				'tags' => 'name="dosaveclose" onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html(isset($editunit['unitid']) ? 'main/save_changes_close' : 'main/add_unit_close_button'),
			),
			
			'saveadd' => array(
				'tags' => 'name="dosaveadd" onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html(isset($editunit['unitid']) ? 'main/save_changes_only' : 'main/add_unit_more_button'),
			),
			
			'cancel' => array(
				'tags' => 'name="docancel"',
				'label' => as_lang_html('main/cancel_button'),
			),
		),

		'hidden' => array(
			//'dosaveunit' => '1', // for IE
			'edit' => @$editunit['unitid'],
			'parent' => @$editunit['unitid'],
			'setparent' => (int)$setparent,
			'code' => as_get_form_security_code('departments-units'),
		),
	);


	if ($setparent) {
		unset($as_content['form']['fields']['delete']);
		unset($as_content['form']['fields']['reassign']);
		unset($as_content['form']['fields']['content']);

		$as_content['form']['fields']['parent'] = array(
			'label' => as_lang_html('main/unit_parent'),
		);

		$childdepth = as_db_unit_child_depth($editunit['unitid']);

		as_set_up_unit_field($as_content, $as_content['form']['fields']['parent'], 'parent',
			isset($inunits) ? $inunits : $units, isset($inunitid) ? $inunitid : @$editunit['unitid'],
			true, true, AS_DEPARTMENT_DEPTH - 1 - $childdepth, @$editunit['unitid']);

		$as_content['form']['fields']['parent']['options'][''] = as_lang_html('main/unit_top_level');

		@$as_content['form']['fields']['parent']['note'] .= as_lang_html_sub('main/unit_max_depth_x', AS_DEPARTMENT_DEPTH);

	} elseif (isset($editunit['unitid'])) { // existing unit
		if ($hassubunit) {
			$as_content['form']['fields']['name']['note'] = as_lang_html('main/unit_no_delete_subs');
			unset($as_content['form']['fields']['delete']);
			unset($as_content['form']['fields']['reassign']);

		} else {
			$as_content['form']['fields']['delete'] = array(
				'tags' => 'name="dodelete" id="dodelete"',
				'label' =>
					'<span id="reassign_shown">' . as_lang_html('main/delete_unit_reassign') . '</span>' .
					'<span id="reassign_hidden" style="display:none;">' . as_lang_html('main/delete_unit') . '</span>',
				'value' => 0,
				'type' => 'checkbox',
			);

			$as_content['form']['fields']['reassign'] = array(
				'id' => 'reassign_display',
				'tags' => 'name="reassign"',
			);

			as_set_up_unit_field($as_content, $as_content['form']['fields']['reassign'], 'reassign',
				$units, $editunit['unitid'], true, true, null, $editunit['unitid']);
		}

		if ($hassubunit && !as_opt('allow_no_sub_unit')) {
			$nosubcount = as_db_count_unitid_qs($editunit['unitid']);
		}

		as_set_display_rules($as_content, array(
			'position_display' => '!dodelete',
			'slug_display' => '!dodelete',
			'content_display' => '!dodelete',
			'parent_display' => '!dodelete',
			'children_display' => '!dodelete',
			'reassign_display' => 'dodelete',
			'reassign_shown' => 'dodelete',
			'reassign_hidden' => '!dodelete',
		));

	} else { // new unit
		unset($as_content['form']['fields']['delete']);
		unset($as_content['form']['fields']['reassign']);
		unset($as_content['form']['fields']['slug']);

		$as_content['focusid'] = 'name';
	}

	if (!$setparent) {
		$pathhtml = as_department_path_html($units, @$editunit['unitid']);

		if (count($units)) {
			$as_content['form']['fields']['parent'] = array(
				'id' => 'parent_display',
				'label' => as_lang_html('main/unit_parent'),
				'type' => 'static',
				'value' => (strlen($pathhtml) ? $pathhtml : as_lang_html('main/unit_top_level')),
			);

			$as_content['form']['fields']['parent']['value'] =
				'<a href="' . as_path_html(as_request(), array('edit' => @$editunit['unitid'])) . '">' .
				$as_content['form']['fields']['parent']['value'] . '</a>';

			if (isset($editunit['unitid'])) {
				$as_content['form']['fields']['parent']['value'] .= ' - ' .
					'<a href="' . as_path_html(as_request(), array('edit' => $editunit['unitid'], 'setparent' => 1)) .
					'" style="white-space: nowrap;">' . as_lang_html('main/unit_move_parent') . '</a>';
			}
		}

		$positionoptions = array();

		$previous = null;
		$passedself = false;

		foreach ($units as $key => $unit) {
			if (!strcmp($unit['unitid'], @$editunit['unitid'])) {
				if (isset($previous))
					$positionhtml = as_lang_html_sub('admin/after_x', as_html($passedself ? $unit['title'] : $previous['title']));
				else
					$positionhtml = as_lang_html('admin/first');

				$positionoptions[$unit['position']] = $positionhtml;

				if (!strcmp($unit['unitid'], @$editunit['unitid']))
					$passedself = true;

				$previous = $unit;
			}
		}

		if (isset($editunit['position']))
			$positionvalue = $positionoptions[$editunit['position']];

		else {
			$positionvalue = isset($previous) ? as_lang_html_sub('admin/after_x', as_html($previous['title'])) : as_lang_html('admin/first');
			$positionoptions[1 + @max(array_keys($positionoptions))] = $positionvalue;
		}

		$as_content['form']['fields']['position'] = array(
			'id' => 'position_display',
			'tags' => 'name="position"',
			'label' => as_lang_html('admin/position'),
			'type' => 'select',
			'options' => $positionoptions,
			'value' => $positionvalue,
		);

		if (isset($editunit['unitid'])) {
			$catdepth = count(as_department_path($units, $editunit['unitid']));

			if ($catdepth < AS_DEPARTMENT_DEPTH) {
				$childrenhtml = '';

				foreach ($units as $unit) {
					if (!strcmp($unit['unitid'], $editunit['unitid'])) {
						$childrenhtml .= (strlen($childrenhtml) ? ', ' : '');
					}
				}

				if (!strlen($childrenhtml))
					$childrenhtml = as_lang_html('main/unit_no_subs');

				$childrenhtml .= ' - <a href="' . as_path_html(as_request(), array('addsub' => $editunit['unitid'])) .
					'" style="white-space: nowrap;"><b>' . as_lang_html('main/unit_add_sub') . '</b></a>';

				$as_content['form']['fields']['children'] = array(
					'id' => 'children_display',
					'label' => as_lang_html('main/unit_subs'),
					'type' => 'static',
					'value' => $childrenhtml,
				);
			} else {
				$as_content['form']['fields']['name']['note'] = as_lang_html_sub('main/unit_no_add_subs_x', AS_DEPARTMENT_DEPTH);
			}

		}
	}

} else {
	$as_content['listing'] = array(
		'items' => array(),
		'checker' => as_lang('options/label_code'),
		'headers' => array(
			as_lang('options/label_title'),
			as_lang('options/label_tags'), 
			as_lang('options/label_color')
		),
		'extras' => '<input name="doaddunit" value="'.as_lang_html('main/add_unit_button').'" title="" type="submit" class="as-form-tall-button as-form-tall-button-add">',
	);
	
	if (count($units)) {
		unset($as_content['form']['fields']['intro']);

		foreach ($units as $unit) {
			$as_content['listing']['items'][]['fields'] = array(
			'checkthis' => array( 'data' => '<label><input id="chk-item-'. $unit['tags'] . '" class="chk-item" name="chk-item-checked[]" type="checkbox" value="'.$unit['unitid']. '">'.$unit['code']. '</label>' ),
			'ctitle' => array( 'data' => '<a href="' . as_path_html('departments/units', array('edit' => $unit['unitid'])) . '">'.$unit['title'].'</a>'),
			'ctags' => array( 'data' => $unit['tags']),
			'color' => array( 'data' => $unit['color'])
			);	
		}	
	} else
		unset($as_content['form']['buttons']['save']);
}

if (as_get('recalc')) {
	$as_content['form']['ok'] = '<span id="recalc_ok">' . as_lang_html('main/recalc_units') . '</span>';
	$as_content['form']['hidden']['code_recalc'] = as_get_form_security_code('main/recalc');

	$as_content['script_rel'][] = 'as-content/as-admin.js?' . AS_VERSION;
	$as_content['script_var']['as_warning_recalc'] = as_lang('main/stop_recalc_warning');

	$as_content['script_onloads'][] = array(
		"as_recalc_click('dorecalcunits', document.getElementById('dosaveoptions'), null, 'recalc_ok');"
	);
}

$as_content['navigation']['sub'] = $menuItems;

return $as_content;