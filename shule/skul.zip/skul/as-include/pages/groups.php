<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for groups page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'app/admin.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'db/admin.php';
require_once AS_INCLUDE_DIR . 'db/post-create.php';
require_once AS_INCLUDE_DIR . 'app/format.php';

$menuItems = array();

$menuItems['registry$'] = array(
	'label' => as_lang_html('members/recent_students'),
	'url' => as_path_html('registry'),
);

$menuItems['registry/groups'] = array(
	'label' => as_lang_html('main/nav_groups'),
	'url' => as_path_html('registry/classes'),
);

// Get relevant list of groups

$editgroupid = as_post_text('edit');
if (!isset($editgroupid))
	$editgroupid = as_get('edit');
if (!isset($editgroupid))
	$editgroupid = as_get('addsub');

$groups = as_db_select_with_pending(as_db_group_nav_selectspec($editgroupid, true, false, true));

// Work out the appropriate state for the page
$editgroup = @$groups[$editgroupid];

if (isset($editgroup)) {
	$groupid = as_get('addsub');
	if (isset($groupid))
		$editgroup = array('groupid' => $groupid);

} else {
	if (as_clicked('doaddclass'))
		$editgroup = array();

	elseif (as_clicked('dosaveclass')) {
		$groupid = as_post_text('parent');
		$editgroup = array('groupid' => strlen($groupid) ? $groupid : null);
	}
}

$setmissing = as_post_text('missing') || as_get('missing');

$setparent = !$setmissing && (as_post_text('setparent') || as_get('setparent')) && isset($editgroup['groupid']);

$hassubclass = false;
foreach ($groups as $group) {
	if (!strcmp($group['groupid'], $editgroupid))
		$hassubclass = true;
}


// Process saving options

$savedoptions = false;
$securityexpired = false;

// Process saving an old or new class

if (as_clicked('docancel')) {
	if ($setmissing || $setparent)
		as_redirect(as_request(), array('edit' => $editgroup['groupid']));
	elseif (isset($editgroup['groupid']))
		as_redirect(as_request());
	else
		as_redirect(as_request(), array('edit' => @$editgroup['groupid']));

} elseif (as_clicked('dosetmissing')) {
	if (!as_check_form_security_code('registry-classes', as_post_text('code')))
		$securityexpired = true;

	else {
		$inreassign = as_get_group_field_value('reassign');
		as_db_group_reassign($editgroup['groupid'], $inreassign);
		as_redirect(as_request(), array('recalc' => 1, 'edit' => $editgroup['groupid']));
	}

} elseif (as_clicked('dosaveclass')) {
	if (!as_check_form_security_code('registry-classes', as_post_text('code')))
		$securityexpired = true;

	elseif (as_post_text('dodelete')) {
		if (!$hassubclass) {
			$inreassign = as_get_group_field_value('reassign');
			as_db_group_reassign($editgroup['groupid'], $inreassign);
			as_db_group_delete($editgroup['groupid']);
			as_redirect(as_request(), array('recalc' => 1, 'edit' => $editgroup['groupid']));
		}

	} else {
		require_once AS_INCLUDE_DIR . 'util/string.php';

		$inname = as_post_text('name');
		$inshort = as_post_text('short');
		$incontent = as_post_text('content');
		$ingroupid = $setparent ? as_get_group_field_value('parent') : $editgroup['groupid'];
		$inposition = as_post_text('position');
		$errors = array();

		// Check the parent ID

		$ingroups = as_db_select_with_pending(as_db_group_nav_selectspec($ingroupid, true));
		
		// Verify the name is legitimate for that parent ID

		if (empty($inname))
			$errors['name'] = as_lang('main/field_required');
		elseif (as_strlen($inname) > AS_DB_MAX_CAT_PAGE_TITLE_LENGTH)
			$errors['name'] = as_lang_sub('main/max_length_x', AS_DB_MAX_CAT_PAGE_TITLE_LENGTH);
		elseif (empty($inshort))
			$errors['short'] = as_lang('main/field_required');
		else {
			foreach ($ingroups as $group) {
				if (!strcmp($group['groupid'], $ingroupid) &&
					strcmp($group['groupid'], @$editgroup['groupid']) &&
					as_strtolower($group['title']) == as_strtolower($inname)
				) {
					$errors['name'] = as_lang('main/group_already_used');
				}
			}
		}

		// Verify the slug is legitimate for that parent ID

		for ($attempt = 0; $attempt < 100; $attempt++) {
			switch ($attempt) {
				case 0:
					$inslug = as_post_text('slug');
					if (!isset($inslug))
						$inslug = implode('-', as_string_to_words($inname));
					break;

				case 1:
					$inslug = as_lang_sub('main/group_default_slug', $inslug);
					break;

				default:
					$inslug = as_lang_sub('main/group_default_slug', $attempt - 1);
					break;
			}

			$matchgroupid = as_db_group_slug_to_id($ingroupid, $inslug); // query against DB since MySQL ignores accents, etc...

			if (!isset($ingroupid))
				$matchpage = as_db_single_select(as_db_page_full_selectspec($inslug, false));
			else
				$matchpage = null;

			if (empty($inslug))
				$errors['slug'] = as_lang('main/field_required');
			elseif (as_strlen($inslug) > AS_DB_MAX_CAT_PAGE_TAGS_LENGTH)
				$errors['slug'] = as_lang_sub('main/max_length_x', AS_DB_MAX_CAT_PAGE_TAGS_LENGTH);
			elseif (preg_match('/[\\+\\/]/', $inslug))
				$errors['slug'] = as_lang_sub('main/slug_bad_chars', '+ /');
			elseif (!isset($ingroupid) && as_admin_is_slug_reserved($inslug)) // only top level is a problem
				$errors['slug'] = as_lang('main/slug_reserved');
			elseif (isset($matchgroupid) && strcmp($matchgroupid, @$editgroup['groupid']))
				$errors['slug'] = as_lang('main/group_already_used');
			elseif (isset($matchpage))
				$errors['slug'] = as_lang('main/page_already_used');
			else
				unset($errors['slug']);

			if (isset($editgroup['groupid']) || !isset($errors['slug'])) // don't try other options if editing existing class
				break;
		}

		// Perform appropriate database action

		if (empty($errors)) {
			if (isset($editgroup['groupid'])) { // changing existing class
				as_db_group_rename($editgroup['groupid'], $inname, $inshort, $inslug);

				$recalc = false;

				as_db_group_set_content($editgroup['groupid'], $incontent);
				as_db_group_set_position($editgroup['groupid'], $inposition);

				as_redirect(as_request(), array('edit' => $editgroup['groupid'], 'saved' => true, 'recalc' => (int)$recalc));

			} else { // creating a new one
				$groupid = as_db_group_create($ingroupid, $inname, $inshort, $inslug);

				as_db_group_set_content($groupid, $incontent);

				if (isset($inposition))
					as_db_group_set_position($groupid, $inposition);

				as_redirect(as_request(), array('edit' => $ingroupid, 'added' => true));
			}
		}
	}
}


// Prepare content for theme
$as_content = as_content_prepare();

$as_content['title'] = as_lang_html('main/nav_groups');
$as_content['error'] = '';
$as_content['script_src'][] = '../as-content/as-tables.js?'.AS_VERSION;

if ($setmissing) {
	$as_content['form'] = array(
		'tags' => 'method="post" action="' . as_path_html(as_request()) . '"',

		'style' => 'tall',

		'fields' => array(
			'reassign' => array(
				'label' => isset($editgroup)
					? as_lang_html_sub('main/group_no_sub_to', as_html($editgroup['title']))
					: as_lang_html('main/group_none_to'),
				'loose' => true,
			),
		),

		'buttons' => array(
			'save' => array(
				'tags' => 'id="dosaveoptions"', // just used for as_recalc_click()
				'label' => as_lang_html('main/save_button'),
			),

			'cancel' => array(
				'tags' => 'name="docancel"',
				'label' => as_lang_html('main/cancel_button'),
			),
		),

		'hidden' => array(
			'dosetmissing' => '1', // for IE
			'edit' => @$editgroup['groupid'],
			'missing' => '1',
			'code' => as_get_form_security_code('registry-classes'),
		),
	);

	as_set_up_group_field($as_content, $as_content['form']['fields']['reassign'], 'reassign',
		$groups, @$editgroup['groupid'], as_opt('allow_no_group'), as_opt('allow_no_sub_group'));


} elseif (isset($editgroup)) {
	$as_content['form'] = array(
		'tags' => 'method="post" action="' . as_path_html(as_request()) . '"',

		'style' => 'tall',

		'ok' => as_get('saved') ? as_lang_html('main/group_saved') : (as_get('added') ? as_lang_html('main/group_added') : null),

		'fields' => array(
			'name' => array(
				'id' => 'name_display',
				'tags' => 'name="name" id="name"',
				'label' => as_lang_html(count($groups) ? 'main/group_name' : 'main/group_name_first'),
				'value' => as_html(isset($inname) ? $inname : @$editgroup['title']),
				'error' => as_html(@$errors['name']),
			),
			
			'short' => array(
				'id' => 'code_display',
				'tags' => 'name="short" id="short"',
				'label' => as_lang_html('main/group_short'),
				'value' => as_html(isset($inshort) ? $inshort : @$editgroup['short']),
				'error' => as_html(@$errors['short']),
			),

			'articles' => array(),

			'delete' => array(),

			'reassign' => array(),

			'slug' => array(
				'id' => 'slug_display',
				'tags' => 'name="slug"',
				'label' => as_lang_html('main/group_slug'),
				'value' => as_html(isset($inslug) ? $inslug : @$editgroup['tags']),
				'error' => as_html(@$errors['slug']),
			),

			'content' => array(
				'id' => 'content_display',
				'tags' => 'name="content"',
				'label' => as_lang_html('main/group_description'),
				'value' => as_html(isset($incontent) ? $incontent : @$editgroup['content']),
				'error' => as_html(@$errors['content']),
				'rows' => 2,
			),
		),

		'buttons' => array(
			'save' => array(
				'tags' => 'id="dosaveoptions"', // just used for as_recalc_click
				'label' => as_lang_html(isset($editgroup['groupid']) ? 'main/save_button' : 'main/add_group_button'),
			),

			'cancel' => array(
				'tags' => 'name="docancel"',
				'label' => as_lang_html('main/cancel_button'),
			),
		),

		'hidden' => array(
			'dosaveclass' => '1', // for IE
			'edit' => @$editgroup['groupid'],
			'parent' => @$editgroup['groupid'],
			'setparent' => (int)$setparent,
			'code' => as_get_form_security_code('registry-classes'),
		),
	);


	if ($setparent) {
		unset($as_content['form']['fields']['delete']);
		unset($as_content['form']['fields']['reassign']);
		unset($as_content['form']['fields']['articles']);
		unset($as_content['form']['fields']['content']);

		$as_content['form']['fields']['parent'] = array(
			'label' => as_lang_html('main/group_parent'),
		);

		$childdepth = as_db_group_child_depth($editgroup['groupid']);

		as_set_up_group_field($as_content, $as_content['form']['fields']['parent'], 'parent',
			isset($ingroups) ? $ingroups : $groups, isset($ingroupid) ? $ingroupid : @$editgroup['groupid'],
			true, true, AS_DEPARTMENT_DEPTH - 1 - $childdepth, @$editgroup['groupid']);

		$as_content['form']['fields']['parent']['options'][''] = as_lang_html('main/group_top_level');

		@$as_content['form']['fields']['parent']['note'] .= as_lang_html_sub('main/group_max_depth_x', AS_DEPARTMENT_DEPTH);

	} elseif (isset($editgroup['groupid'])) { // existing class
		if ($hassubclass) {
			$as_content['form']['fields']['name']['note'] = as_lang_html('main/group_no_delete_subs');
			unset($as_content['form']['fields']['delete']);
			unset($as_content['form']['fields']['reassign']);

		} else {
			$as_content['form']['fields']['delete'] = array(
				'tags' => 'name="dodelete" id="dodelete"',
				'label' =>
					'<span id="reassign_shown">' . as_lang_html('main/delete_group_reassign') . '</span>' .
					'<span id="reassign_hidden" style="display:none;">' . as_lang_html('main/delete_group') . '</span>',
				'value' => 0,
				'type' => 'checkbox',
			);

			$as_content['form']['fields']['reassign'] = array(
				'id' => 'reassign_display',
				'tags' => 'name="reassign"',
			);

			as_set_up_group_field($as_content, $as_content['form']['fields']['reassign'], 'reassign',
				$groups, $editgroup['groupid'], true, true, null, $editgroup['groupid']);
		}

		$as_content['form']['fields']['articles'] = array(
			'label' => as_lang_html('main/total_qs'),
			'type' => 'static',
			'value' => '<a href="' . as_path_html('articles/' . as_department_path_request($groups, $editgroup['groupid'])) . '">' .
				($editgroup['qcount'] == 1
					? as_lang_html_sub('main/1_article', '1', '1')
					: as_lang_html_sub('main/x_articles', as_format_number($editgroup['qcount']))
				) . '</a>',
		);

		if ($hassubclass && !as_opt('allow_no_sub_group')) {
			$nosubcount = as_db_count_groupid_qs($editgroup['groupid']);

			if ($nosubcount) {
				$as_content['form']['fields']['articles']['error'] =
					strtr(as_lang_html('main/group_no_sub_error'), array(
						'^q' => as_format_number($nosubcount),
						'^1' => '<a href="' . as_path_html(as_request(), array('edit' => $editgroup['groupid'], 'missing' => 1)) . '">',
						'^2' => '</a>',
					));
			}
		}

		as_set_display_rules($as_content, array(
			'position_display' => '!dodelete',
			'slug_display' => '!dodelete',
			'content_display' => '!dodelete',
			'parent_display' => '!dodelete',
			'children_display' => '!dodelete',
			'reassign_display' => 'dodelete',
			'reassign_shown' => 'dodelete',
			'reassign_hidden' => '!dodelete',
		));

	} else { // new class
		unset($as_content['form']['fields']['delete']);
		unset($as_content['form']['fields']['reassign']);
		unset($as_content['form']['fields']['slug']);
		unset($as_content['form']['fields']['articles']);

		$as_content['focusid'] = 'name';
	}

	if (!$setparent) {
		$pathhtml = as_department_path_html($groups, @$editgroup['groupid']);

		if (count($groups)) {
			$as_content['form']['fields']['parent'] = array(
				'id' => 'parent_display',
				'label' => as_lang_html('main/group_parent'),
				'type' => 'static',
				'value' => (strlen($pathhtml) ? $pathhtml : as_lang_html('main/group_top_level')),
			);

			$as_content['form']['fields']['parent']['value'] =
				'<a href="' . as_path_html(as_request(), array('edit' => @$editgroup['groupid'])) . '">' .
				$as_content['form']['fields']['parent']['value'] . '</a>';

			if (isset($editgroup['groupid'])) {
				$as_content['form']['fields']['parent']['value'] .= ' - ' .
					'<a href="' . as_path_html(as_request(), array('edit' => $editgroup['groupid'], 'setparent' => 1)) .
					'" style="white-space: nowrap;">' . as_lang_html('main/group_move_parent') . '</a>';
			}
		}

		$positionoptions = array();

		$previous = null;
		$passedself = false;

		foreach ($groups as $key => $group) {
			if (!strcmp($group['groupid'], @$editgroup['groupid'])) {
				if (isset($previous))
					$positionhtml = as_lang_html_sub('admin/after_x', as_html($passedself ? $group['title'] : $previous['title']));
				else
					$positionhtml = as_lang_html('admin/first');

				$positionoptions[$group['position']] = $positionhtml;

				if (!strcmp($group['groupid'], @$editgroup['groupid']))
					$passedself = true;

				$previous = $group;
			}
		}

		if (isset($editgroup['position']))
			$positionvalue = $positionoptions[$editgroup['position']];

		else {
			$positionvalue = isset($previous) ? as_lang_html_sub('admin/after_x', as_html($previous['title'])) : as_lang_html('admin/first');
			$positionoptions[1 + @max(array_keys($positionoptions))] = $positionvalue;
		}

		$as_content['form']['fields']['position'] = array(
			'id' => 'position_display',
			'tags' => 'name="position"',
			'label' => as_lang_html('admin/position'),
			'type' => 'select',
			'options' => $positionoptions,
			'value' => $positionvalue,
		);

		if (isset($editgroup['groupid'])) {
			$catdepth = count(as_department_path($groups, $editgroup['groupid']));

			if ($catdepth < AS_DEPARTMENT_DEPTH) {
				$childrenhtml = '';

				foreach ($groups as $group) {
					if (!strcmp($group['groupid'], $editgroup['groupid'])) {
						$childrenhtml .= (strlen($childrenhtml) ? ', ' : '') .
							'<a href="' . as_path_html(as_request(), array('edit' => $group['groupid'])) . '">' . as_html($group['title']) . '</a>' .
							' (' . $group['qcount'] . ')';
					}
				}

				if (!strlen($childrenhtml))
					$childrenhtml = as_lang_html('main/group_no_subs');

				$childrenhtml .= ' - <a href="' . as_path_html(as_request(), array('addsub' => $editgroup['groupid'])) .
					'" style="white-space: nowrap;"><b>' . as_lang_html('main/group_add_sub') . '</b></a>';

				$as_content['form']['fields']['children'] = array(
					'id' => 'children_display',
					'label' => as_lang_html('main/group_subs'),
					'type' => 'static',
					'value' => $childrenhtml,
				);
			} else {
				$as_content['form']['fields']['name']['note'] = as_lang_html_sub('main/group_no_add_subs_x', AS_DEPARTMENT_DEPTH);
			}

		}
	}

} else {
	$as_content['listing'] = array(
		'items' => array(),
		'checker' => '', 
		'headers' => array(
			'<span style="float:right">NO.</span>',		
			as_lang('options/label_title'), 			
			as_lang('options/label_code'), 
			as_lang('options/label_tags'), 
			as_lang('options/label_students'),'', 
			),
		'extras' => '<input name="doaddclass" value="'.as_lang_html('main/add_group_button').'" title="" type="submit" class="as-form-tall-button as-form-tall-button-add">',
	);
	
	if (count($groups)) {
		unset($as_content['form']['fields']['intro']);
		$item = 1;
		foreach ($groups as $group) {
			$as_content['listing']['items'][]['fields'] = array(
			'checkthis' => array( 'data' => '<label><input id="chk-item-'. $group['tags'] . '" class="chk-item" name="chk-item-checked[]" type="checkbox" value="'.$group['groupid']. '"></label>' ),
			'rowid' => array( 'data' => '<span style="float:right">'.$item.'. </span>' ),
			'ctitle' => array( 'data' => '<a href="' . as_path_html('registry/classes', array('edit' => $group['groupid'])) . '">'.$group['title'].'</a>'),
			'ccode' => array( 'data' => $group['code']),
			'ctags' => array( 'data' => $group['tags']),
			'ccount' => array( 'data' => as_format_number($group['scount']) ),
			'checki' => array( 'data' => ''),
			);
			$item++;
		}	
	} else
		unset($as_content['form']['buttons']['save']);
}

if (as_get('recalc')) {
	$as_content['form']['ok'] = '<span id="recalc_ok">' . as_lang_html('main/recalc_groups') . '</span>';
	$as_content['form']['hidden']['code_recalc'] = as_get_form_security_code('main/recalc');

	$as_content['script_rel'][] = 'as-content/as-admin.js?' . AS_VERSION;
	$as_content['script_var']['as_warning_recalc'] = as_lang('main/stop_recalc_warning');

	$as_content['script_onloads'][] = array(
		"as_recalc_click('dorecalcgroups', document.getElementById('dosaveoptions'), null, 'recalc_ok');"
	);
}

$as_content['navigation']['sub'] = $menuItems;

return $as_content;