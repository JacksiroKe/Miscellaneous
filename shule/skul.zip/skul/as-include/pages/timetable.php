<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for managing a timetable item


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/members.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/post-update.php';

$timetableid = as_request_part(1);
$actionpage = as_request_part(2);
$pagestate = as_get_state();
$as_content = as_content_prepare();
$memberid = as_get_logged_in_memberid();

list($timetable, $groups, $teachers, $units) = as_db_select_with_pending(
	as_db_timetable_selectspec($memberid, $timetableid),
	as_db_group_nav_selectspec(null, true, false, true),
	as_db_list_members_selectspec('TEACHER', 0),
	as_db_unit_nav_selectspec(null, true, false, true)
);

$menuItems = array();

$menuItems['timetable$'] = array(
	'label' => as_lang_html('options/table_view'),
	'url' => as_path_html('timetable/'.$timetableid),
	//'selected_on' => array('timetable$', 'view/'),
);

$menuItems['timetable/update'] = array(
	'label' => as_lang_html('options/table_update'),
	'url' => as_path_html('timetable/'.$timetableid.'/update'),
);
	
$menuItems['timetable/lessons'] = array(
	'label' => as_lang_html('options/table_lessons'),
	'url' => as_path_html('timetable/'.$timetableid.'/lessons'),
);

if ($timetable['state'] == 1)
	$menuItems['timetable/publish'] = array(
	'label' => as_lang_html('options/table_publish'),
	'url' => as_path_html('timetable/'.$timetableid.'/publish'),
);
else $menuItems['timetable/unpublish'] = array(
	'label' => as_lang_html('options/table_unpublish'),
	'url' => as_path_html('timetable/'.$timetableid.'/unpublish'),
);
		
$menuItems['timetable/delete'] = array(
	'label' => as_lang_html('options/table_delete'),
	'url' => as_path_html('timetable/'.$timetableid.'/delete'),
);

if (as_clicked('dosaveclose')) {
	require_once AS_INCLUDE_DIR.'app/post-create.php';
	
	$intitle = as_post_text('title');
	$incontent = as_post_text('content');
	$inlessons = as_post_text('lessons');
	$incount = as_post_text('count');
	$induration = as_post_text('duration');
	$inslots = as_post_text('slots');
	$ingroups = as_post_text('groups');
	$inteachers = as_post_text('teachers');
	
	$errors = array();
	
	if (!as_check_form_security_code('update-timetable', as_post_text('code'))) {
		$errors['page'] = as_lang_html('misc/form_security_again');
	} else {
		if (empty($errors)) {
			$cookieid = isset($memberid) ? as_cookie_get() : as_cookie_get_create(); // create a new cookie if necessary
			
			as_timetable_update($timetableid, $memberid, as_get_logged_in_handle(), $cookieid, $intitle, $incontent, $incount, $induration, $inslots, $ingroups, $inteachers, $inlessons);
			as_redirect('timetable/'.$timetableid);
		}
	}
}

if (as_clicked('dosaveonly')) {
	require_once AS_INCLUDE_DIR.'app/post-create.php';
	
	$intitle = as_post_text('title');
	$incontent = as_post_text('content');
	$inlessons = as_post_text('lessons');
	$incount = as_post_text('count');
	$induration = as_post_text('duration');
	$inslots = as_post_text('slots');
	$ingroups = as_post_text('groups');
	$inteachers = as_post_text('teachers');
	
	$errors = array();
	
	if (!as_check_form_security_code('update-timetable', as_post_text('code'))) {
		$errors['page'] = as_lang_html('misc/form_security_again');
	} else {
		if (empty($errors)) {
			$cookieid = isset($memberid) ? as_cookie_get() : as_cookie_get_create(); // create a new cookie if necessary
			
			as_timetable_update($timetableid, $memberid, as_get_logged_in_handle(), $cookieid, $intitle, $incontent, $incount, $induration, $inslots, $ingroups, $inteachers, $inlessons);
			as_redirect('timetable/'.$timetableid.'/update');
		}
	}
}

switch ($actionpage){
	case 'publish':
		$as_content['title'] = as_lang_html('options/table_publish') . ' :: ' . $timetable['title'];

		break;
	
	case 'update':
		$as_content['title'] = as_lang_html('options/table_update') . ' :: ' . $timetable['title'
		$groupcodes = '<br>';
		foreach ($groups as $group) {
			$groupcodes .= $group['title'] . ' - <b>' . $group['code'] . '</b>, ';
		}
		
		$teachershtml = as_memberids_handles_html($teachers);

		$teachercodes = '<br>';
		foreach ($teachers as $teacher) {
			$teachercodes .= $teachershtml[$teacher['memberid']] . ' (' . ($teacher['sex'] == '1' ? 'M' : 'F') . ') - <b>' . $teacher['code'] . '</b>, ';
		}
		
		$as_content['form'] = array(
			'tags' => 'method="post" action="' . as_self_html() . '"',
			'style' => 'wide',
			
			'fields' => array(
				'title' => array(
					'label' => as_lang_html('main/timetable_name_label'),
					'tags' => 'name="title" id="title" dir="auto"',
					'value' => as_html(@$timetable['title']),
					'error' => as_html(@$errors['title']),
				),
				
				'content' => array(
					'label' => as_lang_html('main/timetable_content_label'),
					'tags' => 'name="content" id="content" dir="auto"',
					'value' => as_html(@$timetable['content']),
					'style' => 'tall',
					'type' => 'textarea',
					'rows' => 2,
					'error' => as_html(@$errors['content']),
				),
				
				'lessons' => array(
					'label' => 'Lessons',
					'tags' => 'name="lessons" id="lessons" dir="auto"',
					'value' => as_html(@$timetable['lessons']),
					'style' => 'tall',
					'type' => 'textarea',
					'rows' => 5,
					'error' => as_html(@$errors['lessons']),
				),
				
				'duration' => array(
					'label' => as_lang_html('main/timetable_duration_label'),
					'suffix' => as_lang_html('options/minutes_suffix'),
					'tags' => 'name="duration" id="duration" dir="auto"',
					'value' => as_html(@$timetable['duration']),
					'type' => 'number',
					'error' => as_html(@$errors['duration']),
				),
				
				'slots' => array(
					'label' => as_lang('main/timetable_slots_label'),
					'tags' => 'name="slots" id="slots" dir="auto"',
					'value' => as_html(@$timetable['slots']),
					'style' => 'tall',
					'type' => 'textarea',
					'rows' => 4,
					'error' => as_html(@$errors['slots']),
					'note' => as_lang('main/timetable_slots_note'),
				),
				
				'tableview' => array(
					'type' => 'custom',
					'style' => 'tall',
					'html' => '<span id="tableviewer"></span>'."\n".'<table id="lazydata" style="display:none;"><tr><td><img src="'.as_path_to_root().'as-media/cyclic.gif" /></td>'."\n".'<td><img src="'.as_path_to_root().'as-media/cyclic.gif" /></td>'."\n".'<td><img src="'.as_path_to_root().'as-media/cyclic.gif" /></td></tr></table>'."\n".'<h1 onclick="as_table_preview()" style="cursor:pointer;">Click to See Preview</h1>',
				),

			),
			'buttons' => array(
				'saveclose' => array(
					'tags' => 'name="dosaveclose" onclick="as_show_waiting_after(this, false);"',
					'label' => as_lang_html('main/save_changes_close'),
				),
				
				'saveonly' => array(
					'tags' => 'name="dosaveonly" onclick="as_show_waiting_after(this, false);"',
					'label' => as_lang_html('main/save_changes_only'),
				),
				
				'cancel' => array(
					'tags' => 'name="docancel"',
					'label' => as_lang_html('main/cancel_button'),
				),
			),

			'hidden' => array(
				'code' => as_get_form_security_code('update-timetable'),
			),
		);
		
		$as_content['focusid'] = 'title';
		break;

	case 'unpublish':
		$as_content['title'] = as_lang_html('options/table_unpublish') . ' :: ' . $timetable['title'];

		break;
	
	case 'delete':
		$as_content['title'] = as_lang_html('options/table_delete') . ' :: ' . $timetable['title'];

		break;
	case 'lessons':
		$as_content['title'] = as_lang_html('options/table_lessons') . ' :: ' . $timetable['title'];
		
		$teacheroptions = array(as_lang_html('main/select_teacher_label'));
		$groupoptions = array(as_lang_html('main/select_group_label'));
		$unitoptions = array(as_lang_html('main/select_unit_label'));
		
		$teachershtml = as_memberids_handles_html($teachers);

		$teachercodes = $groupcodes = $unitcodes = '<br>';
		foreach ($teachers as $teacher) {
			$teachercodes .= $teachershtml[$teacher['memberid']] . ' (' . ($teacher['sex'] == '1' ? 'M' : 'F') . ') - <b>' . $teacher['code'] . '</b>, ';
			$teacheroptions[$teacher['memberid'] . ' - ' . $teacher['code'] . ' - ' . $teacher['firstname'] . ' ' . $teacher['lastname']] = $teacher['firstname'] . ' ' . $teacher['lastname'] . ' (' . ($teacher['sex'] == '1' ? 'M' : 'F') . ') - ' . $teacher['code'];
		}
		
		foreach ($groups as $group) {
			$groupcodes .= $group['title'] . ' - <b>' . $group['code'] . '</b>, ';
			$groupoptions[$group['groupid'] . ' - ' . $group['code'] . ' - ' . $group['title']] = $group['title'] . ' - ' . $group['code'];
		}
		
		foreach ($units as $unit) {
			$unitcodes .= $unit['title'] . ' - <b>' . $unit['code'] . '</b>, ';
			$unitoptions[$unit['unitid'] . ' - ' . $unit['code'] . ' - ' . $unit['title']] = $unit['title'] . ' - ' . $unit['code'];
		}
		
		$as_content['timetable'] = array(
			'tags' => 'method="post" action="' . as_self_html() . '"',
			'style' => 'tall',
			'tstyle' => 'long',
			'loader' => 'big',
			
			'html' => array(
				'groups' => '<input id="groups" type="hidden" value="'.as_html(@$timetable['groups']).'"/>',
				'teachers' => '<input id="teachers" type="hidden" value="'.as_html(@$timetable['teachers']).'"/>',
				'units' => '<input id="units" type="hidden" value="'.as_html(@$timetable['units']).'"/>',
				'slots' => '<input id="slots" type="hidden" value="'.as_html(@$timetable['slots']).'"/>',
			),
			
			'html2' => array(
				'updater' => '<span class="as-form-tall-button" onclick="as_table_view();">Update</span>',
				'refresher' => '<span class="as-form-tall-button" onclick="as_lesson_fix('.$timetableid.');">Refresh</span>',
			),
			
			'fields' => array(
				'group' => array(
					'label' => '',
					'tags' => 'name="group" id="group" dir="auto" onchange="as_group_change(this.value);"',
					'type' => 'select',
					'options' => $groupoptions,
					'error' => as_html(@$errors['group']),
				),
				
				'unit' => array(
					'label' => '',
					'tags' => 'name="unit" id="unit" dir="auto" onchange="as_unit_change(this.value);"',
					'type' => 'select',
					'options' => $unitoptions,
					'error' => as_html(@$errors['unit']),
				),
				
				'teacher' => array(
					'label' => '',
					'tags' => 'name="teacher" id="teacher" dir="auto" onchange="as_teacher_change(this.value);"',
					'type' => 'select',
					'options' => $teacheroptions,
					'error' => as_html(@$errors['teacher']),
				),
				
				'count' => array(
					'label' => '',
					'tags' => 'name="count" id="count" min="1" max="20" dir="auto"',
					'suffix' => as_lang_html('options/lessons_suffix'),
					'value' => 5,
					'type' => 'updown',
					'error' => as_html(@$errors['count']),
				),
				
			),
			
			'buttons' => array(
				'saveclose' => array(
					'tags' => 'name="dosaveclose" onclick="as_show_waiting_after(this, false);"',
					'label' => as_lang_html('main/save_changes_close'),
				),
				
				'cancel' => array(
					'tags' => 'name="docancel"',
					'label' => as_lang_html('main/cancel_button'),
				),
			),

			'hidden' => array(
				'docreate' => '1',
				'code' => as_get_form_security_code('update-timetable'),
			),
		);
		$as_content['script_onloads'][] = 'as_table_view();';
		$as_content['script_lines'][] = array(
			"function as_teacher_change(newteacher)",
			"{",
			"	var txtteacher = document.getElementById('teachers');",
			"	txtteacher.value = txtteacher.value + ',' + newteacher;",
			"}",
			"function as_group_change(newgroup)",
			"{",
			"	var txtgroup = document.getElementById('groups');",
			"	txtgroup.value = txtgroup.value + ',' + newgroup;",
			"}",
			"function as_unit_change(newunit)",
			"{",
			"	var txtunit = document.getElementById('units');",
			"	txtunit.value = txtunit.value + ',' + newunit;",
			"}",
		);
		break;
		
	default:
		$as_content['title'] = $timetable['title'] . ' ('.(as_lang_html( ($timetable['state'] == 1) ? 'main/state_draft' : '')) . ')';
				
		$as_content['timetable'] = array(
			'style' => 'long',
			'tstyle' => null,
			'loader' => 'big',
			
			'html' => array(
				'teachers' => '<input id="teachers" type="hidden" value="'.as_html(@$timetable['teachers']).'"/>',
				'groups' => '<input id="groups" type="hidden" value="'.as_html(@$timetable['groups']).'"/>',
				'units' => '<input id="units" type="hidden" value="'.as_html(@$timetable['units']).'"/>',
				'slots' => '<input id="slots" type="hidden" value="'.as_html(@$timetable['slots']).'"/>',
			),
		);
		$as_content['script_onloads'][] = 'as_table_view();';
		break;
}

as_set_template('osam');
$as_content['navigation']['sub'] = $menuItems;

return $as_content;
