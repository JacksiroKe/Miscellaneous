<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for write a article page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


require_once AS_INCLUDE_DIR.'app/format.php';
require_once AS_INCLUDE_DIR.'app/limits.php';
require_once AS_INCLUDE_DIR.'db/selects.php';
require_once AS_INCLUDE_DIR.'util/sort.php';


// Check whether this is a follow-on article and get some info we need from the database

$in = array();

$followpostid = as_get('follow');
$in['departmentid'] = as_clicked('dowrite') ? as_get_department_field_value('department') : as_get('cat');
$memberid = as_get_logged_in_memberid();

list($departments, $followanswer, $completetags) = as_db_select_with_pending(
	as_db_department_nav_selectspec($in['departmentid'], true),
	isset($followpostid) ? as_db_full_post_selectspec($memberid, $followpostid) : null,
	as_db_popular_tags_selectspec(0, AS_DB_RETRIEVE_COMPLETE_TAGS)
);

if (!isset($departments[$in['departmentid']])) {
	$in['departmentid'] = null;
}

if (@$followanswer['basetype'] != 'A') {
	$followanswer = null;
}


// Check for permission error

$permiterror = as_member_maximum_permit_error('permit_post_q', AS_LIMIT_ARTICLES);

if ($permiterror) {
	$as_content = as_content_prepare();

	// The 'approve', 'login', 'confirm', 'limit', 'memberblock', 'ipblock' permission errors are reported to the member here
	// The other option ('level') prevents the menu option being shown, in as_content_prepare(...)

	switch ($permiterror) {
		case 'login':
			$as_content['error'] = as_insert_login_links(as_lang_html('article/write_must_login'), as_request(), isset($followpostid) ? array('follow' => $followpostid) : null);
			break;

		case 'confirm':
			$as_content['error'] = as_insert_login_links(as_lang_html('article/write_must_confirm'), as_request(), isset($followpostid) ? array('follow' => $followpostid) : null);
			break;

		case 'limit':
			$as_content['error'] = as_lang_html('article/write_limit');
			break;

		case 'approve':
			$as_content['error'] = strtr(as_lang_html('article/write_must_be_approved'), array(
				'^1' => '<a href="' . as_path_html('account') . '">',
				'^2' => '</a>',
			));
			break;

		default:
			$as_content['error'] = as_lang_html('members/no_permission');
			break;
	}

	return $as_content;
}


// Process input

$captchareason = as_member_captcha_reason();

$in['title'] = as_get_post_title('title'); // allow title and tags to be posted by an external form
$in['extra'] = as_opt('extra_field_active') ? as_post_text('extra') : null;

if (as_using_tags()) {
	$in['tags'] = as_get_tags_field_value('tags');
}

if (as_clicked('dowrite')) {
	require_once AS_INCLUDE_DIR.'app/post-create.php';
	require_once AS_INCLUDE_DIR.'util/string.php';

	$departmentids = array_keys(as_department_path($departments, @$in['departmentid']));
	$memberlevel = as_member_level_for_departments($departmentids);

	$in['name'] = as_opt('allow_anonymous_naming') ? as_post_text('name') : null;
	$in['notify'] = strlen(as_post_text('notify')) > 0;
	$in['email'] = as_post_text('email');
	$in['queued'] = as_member_moderation_reason($memberlevel) !== false;

	as_get_post_content('editor', 'content', $in['editor'], $in['content'], $in['format'], $in['text']);

	$errors = array();

	if (!as_check_form_security_code('write', as_post_text('code'))) {
		$errors['page'] = as_lang_html('misc/form_security_again');
	}
	else {
		$filtermodules = as_load_modules_with('filter', 'filter_article');
		foreach ($filtermodules as $filtermodule) {
			$oldin = $in;
			$filtermodule->filter_article($in, $errors, null);
			as_update_post_text($in, $oldin);
		}

		if (as_using_departments() && count($departments) && (!as_opt('allow_no_department')) && !isset($in['departmentid'])) {
			// check this here because we need to know count($departments)
			$errors['departmentid'] = as_lang_html('article/department_required');
		}
		elseif (as_member_permit_error('permit_post_q', null, $memberlevel)) {
			$errors['departmentid'] = as_lang_html('article/department_write_not_allowed');
		}

		if ($captchareason) {
			require_once AS_INCLUDE_DIR.'app/captcha.php';
			as_captcha_validate_post($errors);
		}

		if (empty($errors)) {
			// check if the article is already posted
			$testTitleWords = implode(' ', as_string_to_words($in['title']));
			$testContentWords = implode(' ', as_string_to_words($in['content']));
			$recentArticles = as_db_select_with_pending(as_db_qs_selectspec(null, 'created', 0, null, null, false, true, 5));

			foreach ($recentArticles as $article) {
				if (!$article['hidden']) {
					$qTitleWords = implode(' ', as_string_to_words($article['title']));
					$qContentWords = implode(' ', as_string_to_words($article['content']));

					if ($qTitleWords == $testTitleWords && $qContentWords == $testContentWords) {
						$errors['page'] = as_lang_html('article/duplicate_content');
						break;
					}
				}
			}
		}

		if (empty($errors)) {
			$cookieid = isset($memberid) ? as_cookie_get() : as_cookie_get_create(); // create a new cookie if necessary

			$articleid = as_article_create($followanswer, $memberid, as_get_logged_in_handle(), $cookieid,
				$in['title'], $in['content'], $in['format'], $in['text'], isset($in['tags']) ? as_tags_to_tagstring($in['tags']) : '',
				$in['notify'], $in['email'], $in['departmentid'], $in['extra'], $in['queued'], $in['name']);

			as_redirect(as_q_request($articleid, $in['title'])); // our work is done here
		}
	}
}


// Prepare content for theme

$as_content = as_content_prepare(false, array_keys(as_department_path($departments, @$in['departmentid'])));

$as_content['title'] = as_lang_html(isset($followanswer) ? 'article/write_follow_title' : 'article/write_title');
$as_content['error'] = @$errors['page'];

$editorname = isset($in['editor']) ? $in['editor'] : as_opt('editor_for_qs');
$editor = as_load_editor(@$in['content'], @$in['format'], $editorname);

$field = as_editor_load_field($editor, $as_content, @$in['content'], @$in['format'], 'content', 12, false);
$field['label'] = as_lang_html('article/q_content_label');
$field['error'] = as_html(@$errors['content']);

$custom = as_opt('show_custom_write') ? trim(as_opt('custom_write')) : '';

$as_content['form'] = array(
	'tags' => 'name="write" method="post" action="'.as_self_html().'"',

	'style' => 'tall',

	'fields' => array(
		'custom' => array(
			'type' => 'custom',
			'note' => $custom,
		),

		'title' => array(
			'label' => as_lang_html('article/q_title_label'),
			'tags' => 'name="title" id="title" autocomplete="off"',
			'value' => as_html(@$in['title']),
			'error' => as_html(@$errors['title']),
		),

		'similar' => array(
			'type' => 'custom',
			'html' => '<span id="similar"></span>',
		),

		'content' => $field,
	),

	'buttons' => array(
		'write' => array(
			'tags' => 'onclick="as_show_waiting_after(this, false); '.
				(method_exists($editor, 'update_script') ? $editor->update_script('content') : '').'"',
			'label' => as_lang_html('article/write_button'),
		),
	),

	'hidden' => array(
		'editor' => as_html($editorname),
		'code' => as_get_form_security_code('write'),
		'dowrite' => '1',
	),
);

if (!strlen($custom)) {
	unset($as_content['form']['fields']['custom']);
}

if (as_opt('do_write_check_qs') || as_opt('do_example_tags')) {
	$as_content['form']['fields']['title']['tags'] .= ' onchange="as_title_change(this.value);"';

	if (strlen(@$in['title'])) {
		$as_content['script_onloads'][] = 'as_title_change('.as_js($in['title']).');';
	}
}

if (isset($followanswer)) {
	$viewer = as_load_viewer($followanswer['content'], $followanswer['format']);

	$field = array(
		'type' => 'static',
		'label' => as_lang_html('article/write_follow_from_a'),
		'value' => $viewer->get_html($followanswer['content'], $followanswer['format'], array('blockwordspreg' => as_get_block_words_preg())),
	);

	as_array_insert($as_content['form']['fields'], 'title', array('follows' => $field));
}

if (as_using_departments() && count($departments)) {
	$field = array(
		'label' => as_lang_html('article/q_department_label'),
		'error' => as_html(@$errors['departmentid']),
	);

	as_set_up_department_field($as_content, $field, 'department', $departments, $in['departmentid'], true, as_opt('allow_no_sub_department'));

	if (!as_opt('allow_no_department')) // don't auto-select a department even though one is required
		$field['options'][''] = '';

	as_array_insert($as_content['form']['fields'], 'content', array('department' => $field));
}

if (as_opt('extra_field_active')) {
	$field = array(
		'label' => as_html(as_opt('extra_field_prompt')),
		'tags' => 'name="extra"',
		'value' => as_html(@$in['extra']),
		'error' => as_html(@$errors['extra']),
	);

	as_array_insert($as_content['form']['fields'], null, array('extra' => $field));
}

if (as_using_tags()) {
	$field = array(
		'error' => as_html(@$errors['tags']),
	);

	as_set_up_tag_field($as_content, $field, 'tags', isset($in['tags']) ? $in['tags'] : array(), array(),
		as_opt('do_complete_tags') ? array_keys($completetags) : array(), as_opt('page_size_write_tags'));

	as_array_insert($as_content['form']['fields'], null, array('tags' => $field));
}

if (!isset($memberid) && as_opt('allow_anonymous_naming')) {
	as_set_up_name_field($as_content, $as_content['form']['fields'], @$in['name']);
}

as_set_up_notify_fields($as_content, $as_content['form']['fields'], 'Q', as_get_logged_in_email(),
	isset($in['notify']) ? $in['notify'] : as_opt('notify_members_default'), @$in['email'], @$errors['email']);

if ($captchareason) {
	require_once AS_INCLUDE_DIR.'app/captcha.php';
	as_set_up_captcha_field($as_content, $as_content['form']['fields'], @$errors, as_captcha_reason_note($captchareason));
}

$as_content['focusid'] = 'title';


return $as_content;
