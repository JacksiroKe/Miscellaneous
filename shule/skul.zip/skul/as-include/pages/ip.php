<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for page showing recent activity for an IP address


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'app/format.php';


$ip = as_request_part(1); // picked up from as-page.php
if (filter_var($ip, FILTER_VALIDATE_IP) === false)
	return include AS_INCLUDE_DIR . 'as-page-not-found.php';


// Find recently (hidden, queued or not) articles, answers, comments and edits for this IP

$memberid = as_get_logged_in_memberid();

list($qs, $qs_queued, $qs_hidden, $a_qs, $a_queued_qs, $a_hidden_qs, $c_qs, $c_queued_qs, $c_hidden_qs, $edit_qs) =
	as_db_select_with_pending(
		as_db_qs_selectspec($memberid, 'created', 0, null, $ip, false),
		as_db_qs_selectspec($memberid, 'created', 0, null, $ip, 'Q_QUEUED'),
		as_db_qs_selectspec($memberid, 'created', 0, null, $ip, 'Q_HIDDEN', true),
		as_db_recent_a_qs_selectspec($memberid, 0, null, $ip, false),
		as_db_recent_a_qs_selectspec($memberid, 0, null, $ip, 'A_QUEUED'),
		as_db_recent_a_qs_selectspec($memberid, 0, null, $ip, 'A_HIDDEN', true),
		as_db_recent_c_qs_selectspec($memberid, 0, null, $ip, false),
		as_db_recent_c_qs_selectspec($memberid, 0, null, $ip, 'C_QUEUED'),
		as_db_recent_c_qs_selectspec($memberid, 0, null, $ip, 'C_HIDDEN', true),
		as_db_recent_edit_qs_selectspec($memberid, 0, null, $ip, false)
	);


// Check we have permission to view this page, and whether we can block or unblock IPs

if (as_member_maximum_permit_error('permit_anon_view_ips')) {
	$as_content = as_content_prepare();
	$as_content['error'] = as_lang_html('members/no_permission');
	return $as_content;
}

$blockable = as_member_level_maximum() >= AS_MEMBER_LEVEL_MODERATOR; // allow moderator in one department to block across all departments


// Perform blocking or unblocking operations as appropriate

if (as_clicked('doblock') || as_clicked('dounblock') || as_clicked('dohideall')) {
	if (!as_check_form_security_code('ip-' . $ip, as_post_text('code')))
		$pageerror = as_lang_html('misc/form_security_again');

	elseif ($blockable) {
		if (as_clicked('doblock')) {
			$oldblocked = as_opt('block_ips_write');
			as_set_option('block_ips_write', (strlen($oldblocked) ? ($oldblocked . ' , ') : '') . $ip);

			as_report_event('ip_block', $memberid, as_get_logged_in_handle(), as_cookie_get(), array(
				'ip' => $ip,
			));

			as_redirect(as_request());
		}

		if (as_clicked('dounblock')) {
			require_once AS_INCLUDE_DIR . 'app/limits.php';

			$blockipclauses = as_block_ips_explode(as_opt('block_ips_write'));

			foreach ($blockipclauses as $key => $blockipclause) {
				if (as_block_ip_match($ip, $blockipclause))
					unset($blockipclauses[$key]);
			}

			as_set_option('block_ips_write', implode(' , ', $blockipclauses));

			as_report_event('ip_unblock', $memberid, as_get_logged_in_handle(), as_cookie_get(), array(
				'ip' => $ip,
			));

			as_redirect(as_request());
		}

		if (as_clicked('dohideall') && !as_member_maximum_permit_error('permit_hide_show')) {
			// allow moderator in one department to hide posts across all departments if they are identified via IP page

			require_once AS_INCLUDE_DIR . 'db/admin.php';
			require_once AS_INCLUDE_DIR . 'app/posts.php';

			$postids = as_db_get_ip_visible_postids($ip);

			foreach ($postids as $postid)
				as_post_set_status($postid, AS_POST_STATUS_HIDDEN, $memberid);

			as_redirect(as_request());
		}
	}
}


// Combine sets of articles and get information for members

$articles = as_any_sort_by_date(array_merge($qs, $qs_queued, $qs_hidden, $a_qs, $a_queued_qs, $a_hidden_qs, $c_qs, $c_queued_qs, $c_hidden_qs, $edit_qs));

$membershtml = as_memberids_handles_html(as_any_get_memberids_handles($articles));

$hostname = gethostbyaddr($ip);


// Prepare content for theme

$as_content = as_content_prepare();

$as_content['title'] = as_lang_html_sub('main/ip_address_x', as_html($ip));
$as_content['error'] = @$pageerror;

$as_content['form'] = array(
	'tags' => 'method="post" action="' . as_self_html() . '"',

	'style' => 'wide',

	'fields' => array(
		'host' => array(
			'type' => 'static',
			'label' => as_lang_html('misc/host_name'),
			'value' => as_html($hostname),
		),
	),

	'hidden' => array(
		'code' => as_get_form_security_code('ip-' . $ip),
	),
);


if ($blockable) {
	require_once AS_INCLUDE_DIR . 'app/limits.php';

	$blockipclauses = as_block_ips_explode(as_opt('block_ips_write'));
	$matchclauses = array();

	foreach ($blockipclauses as $blockipclause) {
		if (as_block_ip_match($ip, $blockipclause))
			$matchclauses[] = $blockipclause;
	}

	if (count($matchclauses)) {
		$as_content['form']['fields']['status'] = array(
			'type' => 'static',
			'label' => as_lang_html('misc/matches_blocked_ips'),
			'value' => as_html(implode("\n", $matchclauses), true),
		);

		$as_content['form']['buttons']['unblock'] = array(
			'tags' => 'name="dounblock"',
			'label' => as_lang_html('misc/unblock_ip_button'),
		);

		if (count($articles) && !as_member_maximum_permit_error('permit_hide_show'))
			$as_content['form']['buttons']['hideall'] = array(
				'tags' => 'name="dohideall" onclick="as_show_waiting_after(this, false);"',
				'label' => as_lang_html('misc/hide_all_ip_button'),
			);

	} else {
		$as_content['form']['buttons']['block'] = array(
			'tags' => 'name="doblock"',
			'label' => as_lang_html('misc/block_ip_button'),
		);
	}
}


$as_content['q_list']['qs'] = array();

if (count($articles)) {
	$as_content['q_list']['title'] = as_lang_html_sub('misc/recent_activity_from_x', as_html($ip));

	foreach ($articles as $article) {
		$htmloptions = as_post_html_options($article);
		$htmloptions['tagsview'] = false;
		$htmloptions['voteview'] = false;
		$htmloptions['ipview'] = false;
		$htmloptions['answersview'] = false;
		$htmloptions['viewsview'] = false;
		$htmloptions['updateview'] = false;

		$htmlfields = as_any_to_q_html_fields($article, $memberid, as_cookie_get(), $membershtml, null, $htmloptions);

		if (isset($htmlfields['what_url'])) // link directly to relevant content
			$htmlfields['url'] = $htmlfields['what_url'];

		$hasother = isset($article['opostid']);

		if ($article[$hasother ? 'ohidden' : 'hidden'] && !isset($article[$hasother ? 'oupdatetype' : 'updatetype'])) {
			$htmlfields['what_2'] = as_lang_html('main/hidden');

			if (@$htmloptions['whenview']) {
				$updated = @$article[$hasother ? 'oupdated' : 'updated'];
				if (isset($updated))
					$htmlfields['when_2'] = as_when_to_html($updated, @$htmloptions['fulldatedays']);
			}
		}

		$as_content['q_list']['qs'][] = $htmlfields;
	}

} else
	$as_content['q_list']['title'] = as_lang_html_sub('misc/no_activity_from_x', as_html($ip));


return $as_content;
