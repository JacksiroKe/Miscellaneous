<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Database access functions which are specific to the admin center


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


/**
 * Return the current version of MySQL
 */
function as_db_mysql_version()
{
	return as_db_read_one_value(as_db_query_raw('SELECT VERSION()'));
}


/**
 * Return the total size in bytes of all relevant tables in the APS database
 */
function as_db_table_size()
{
	if (defined('AS_MYSQL_MEMBERS_PREFIX')) { // check if one of the prefixes is a prefix itself of the other
		if (stripos(AS_MYSQL_MEMBERS_PREFIX, AS_MYSQL_TABLE_PREFIX) === 0)
			$prefixes = array(AS_MYSQL_TABLE_PREFIX);
		elseif (stripos(AS_MYSQL_TABLE_PREFIX, AS_MYSQL_MEMBERS_PREFIX) === 0)
			$prefixes = array(AS_MYSQL_MEMBERS_PREFIX);
		else
			$prefixes = array(AS_MYSQL_TABLE_PREFIX, AS_MYSQL_MEMBERS_PREFIX);

	} else
		$prefixes = array(AS_MYSQL_TABLE_PREFIX);

	$size = 0;
	foreach ($prefixes as $prefix) {
		$statuses = as_db_read_all_assoc(as_db_query_raw(
			"SHOW TABLE STATUS LIKE '" . $prefix . "%'"
		));

		foreach ($statuses as $status)
			$size += $status['Data_length'] + $status['Index_length'];
	}

	return $size;
}


/**
 * Return a count of the number of posts of $type in database.
 * Set $frommember to true to only count non-anonymous posts, false to only count anonymous posts
 * @param $type
 * @param $frommember
 * @return mixed|null
 */
function as_db_count_posts($type = null, $frommember = null)
{
	$wheresql = '';

	if (isset($type))
		$wheresql .= ' WHERE type=' . as_db_argument_to_mysql($type, true);

	if (isset($frommember))
		$wheresql .= (strlen($wheresql) ? ' AND' : ' WHERE') . ' memberid ' . ($frommember ? 'IS NOT' : 'IS') . ' NULL';

	return as_db_read_one_value(as_db_query_sub(
		'SELECT COUNT(*) FROM ^posts' . $wheresql
	));
}


/**
 * Return number of registered members in database.
 */
function as_db_count_members()
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT COUNT(*) FROM ^members'
	));
}


/**
 * Return number of active members in database $table
 * @param $table
 * @return mixed|null
 */
function as_db_count_active_members($table)
{
	switch ($table) {
		case 'posts':
		case 'membervotes':
		case 'memberpoints':
			break;

		default:
			as_fatal_error('as_db_count_active_members() called for unknown table');
			break;
	}

	return as_db_read_one_value(as_db_query_sub(
		'SELECT COUNT(DISTINCT(memberid)) FROM ^' . $table
	));
}


/**
 * Return number of departments in the database
 */
function as_db_count_departments()
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT COUNT(*) FROM ^departments'
	));
}


/**
 * Return number of articles in the database in $departmentid exactly, and not one of its subdepartments
 * @param $departmentid
 * @return mixed|null
 */
function as_db_count_departmentid_qs($departmentid)
{
	return as_db_read_one_value(as_db_query_sub(
		"SELECT COUNT(*) FROM ^posts WHERE departmentid<=># AND type='Q'",
		$departmentid
	));
}


/**
 * Return list of postids of visible or queued posts by $memberid
 * @param $memberid
 * @return array
 */
function as_db_get_member_visible_postids($memberid)
{
	return as_db_read_all_values(as_db_query_sub(
		"SELECT postid FROM ^posts WHERE memberid=# AND type IN ('Q', 'A', 'C', 'Q_QUEUED', 'A_QUEUED', 'C_QUEUED')",
		$memberid
	));
}


/**
 * Return list of postids of visible or queued posts from $ip address
 * @param $ip
 * @return array
 */
function as_db_get_ip_visible_postids($ip)
{
	return as_db_read_all_values(as_db_query_sub(
		"SELECT postid FROM ^posts WHERE createip=UNHEX($) AND type IN ('Q', 'A', 'C', 'Q_QUEUED', 'A_QUEUED', 'C_QUEUED')",
		bin2hex(@inet_pton($ip))
	));
}


/**
 * Return an array whose keys contain the $postids which exist, and whose elements contain the number of other posts depending on each one
 * @param $postids
 * @return array
 */
function as_db_postids_count_dependents($postids)
{
	if (count($postids))
		return as_db_read_all_assoc(as_db_query_sub(
			"SELECT postid, COALESCE(childcount, 0) AS count FROM ^posts LEFT JOIN (SELECT parentid, COUNT(*) AS childcount FROM ^posts WHERE parentid IN (#) AND LEFT(type, 1) IN ('A', 'C') GROUP BY parentid) x ON postid=x.parentid WHERE postid IN (#)",
			$postids, $postids
		), 'postid', 'count');
	else
		return array();
}


/**
 * Return an array of the (up to) $count most recently created members who are awaiting approval and have not been blocked.
 * The array element for each member includes a 'profile' key whose value is an array of non-empty profile fields of the member.
 * @param $count
 * @return array
 */
function as_db_get_unapproved_members($count)
{
	$results = as_db_read_all_assoc(as_db_query_sub(
		"SELECT ^members.memberid, UNIX_TIMESTAMP(created) AS created, createip, email, handle, flags, title, content FROM ^members LEFT JOIN ^memberprofile ON ^members.memberid=^memberprofile.memberid AND LENGTH(content)>0 WHERE level<# AND NOT (flags&#) ORDER BY created DESC LIMIT #",
		AS_MEMBER_LEVEL_APPROVED, AS_MEMBER_FLAGS_MEMBER_BLOCKED, $count
	));

	$members = array();

	foreach ($results as $result) {
		$memberid = $result['memberid'];

		if (!isset($members[$memberid])) {
			$members[$result['memberid']] = $result;
			$members[$result['memberid']]['profile'] = array();
			unset($members[$memberid]['title']);
			unset($members[$memberid]['content']);
		}

		if (isset($result['title']) && isset($result['content']))
			$members[$memberid]['profile'][$result['title']] = $result['content'];
	}

	return $members;
}


/**
 * Return whether there are any blobs whose content has been stored as a file on disk
 */
function as_db_has_blobs_on_disk()
{
	return as_db_read_one_value(as_db_query_sub('SELECT blobid FROM ^blobs WHERE content IS NULL LIMIT 1'), true) != null;
}


/**
 * Return whether there are any blobs whose content has been stored in the database
 */
function as_db_has_blobs_in_db()
{
	return as_db_read_one_value(as_db_query_sub('SELECT blobid FROM ^blobs WHERE content IS NOT NULL LIMIT 1'), true) != null;
}


/**
 * Return the maximum position of the departments with $parentid
 * @param $parentid
 * @return mixed|null
 */
function as_db_department_last_pos($parentid)
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT COALESCE(MAX(position), 0) FROM ^departments WHERE parentid<=>#',
		$parentid
	));
}


/**
 * Return how many levels of subdepartment there are below $departmentid
 * @param $departmentid
 * @return int
 */
function as_db_department_child_depth($departmentid)
{
	// This is potentially a very slow query since it counts all the multi-generational offspring of a particular department
	// But it's only used for admin purposes when moving a department around so I don't think it's worth making more efficient
	// (Incidentally, this could be done by keeping a count for every department of how many generations of offspring it has.)

	$result = as_db_read_one_assoc(as_db_query_sub(
		'SELECT COUNT(child1.departmentid) AS count1, COUNT(child2.departmentid) AS count2, COUNT(child3.departmentid) AS count3 FROM ^departments AS child1 LEFT JOIN ^departments AS child2 ON child2.parentid=child1.departmentid LEFT JOIN ^departments AS child3 ON child3.parentid=child2.departmentid WHERE child1.parentid=#;', // requires AS_DEPARTMENT_DEPTH=4
		$departmentid
	));

	for ($depth = AS_DEPARTMENT_DEPTH - 1; $depth >= 1; $depth--)
		if ($result['count' . $depth])
			return $depth;

	return 0;
}


/**
 * Create a new custom page (or link) in the database
 * @param $title
 * @param $flags
 * @param $tags
 * @param $heading
 * @param $content
 * @param $permit
 * @return mixed
 */
function as_db_page_create($title, $flags, $tags, $heading, $content, $permit = null)
{
	$position = as_db_read_one_value(as_db_query_sub('SELECT 1+COALESCE(MAX(position), 0) FROM ^pages'));

	as_db_query_sub(
		'INSERT INTO ^pages (title, nav, flags, permit, tags, heading, content, position) VALUES ($, \'\', #, #, $, $, $, #)',
		$title, $flags, $permit, $tags, $heading, $content, $position
	);

	return as_db_last_insert_id();
}


/**
 * Set the fields of $pageid to the values provided in the database
 * @param $pageid
 * @param $title
 * @param $flags
 * @param $tags
 * @param $heading
 * @param $content
 * @param $permit
 */
function as_db_page_set_fields($pageid, $title, $flags, $tags, $heading, $content, $permit = null)
{
	as_db_query_sub(
		'UPDATE ^pages SET title=$, flags=#, permit=#, tags=$, heading=$, content=$ WHERE pageid=#',
		$title, $flags, $permit, $tags, $heading, $content, $pageid
	);
}


/**
 * Move the page $pageid into navigation menu $nav and position $newposition in the database
 * @param $pageid
 * @param $nav
 * @param $newposition
 */
function as_db_page_move($pageid, $nav, $newposition)
{
	as_db_query_sub(
		'UPDATE ^pages SET nav=$ WHERE pageid=#',
		$nav, $pageid
	);

	as_db_ordered_move('pages', 'pageid', $pageid, $newposition);
}


/**
 * Delete the page $pageid in the database
 * @param $pageid
 */
function as_db_page_delete($pageid)
{
	as_db_ordered_delete('pages', 'pageid', $pageid);
}


/**
 * Move the entity identified by $idcolumn=$id into position $newposition (within optional $conditionsql) in $table in the database
 * @param $table
 * @param $idcolumn
 * @param $id
 * @param $newposition
 * @param $conditionsql
 */
function as_db_ordered_move($table, $idcolumn, $id, $newposition, $conditionsql = null)
{
	$andsql = isset($conditionsql) ? (' AND ' . $conditionsql) : '';

	as_db_query_sub('LOCK TABLES ^' . $table . ' WRITE');

	$oldposition = as_db_read_one_value(as_db_query_sub('SELECT position FROM ^' . $table . ' WHERE ' . $idcolumn . '=#' . $andsql, $id));

	if ($newposition != $oldposition) {
		$lastposition = as_db_read_one_value(as_db_query_sub('SELECT MAX(position) FROM ^' . $table . ' WHERE TRUE' . $andsql));

		$newposition = max(1, min($newposition, $lastposition)); // constrain it to within range

		// move it temporarily off the top because we have a unique key on the position column
		as_db_query_sub('UPDATE ^' . $table . ' SET position=# WHERE ' . $idcolumn . '=#' . $andsql, 1 + $lastposition, $id);

		if ($newposition < $oldposition)
			as_db_query_sub('UPDATE ^' . $table . ' SET position=position+1 WHERE position BETWEEN # AND #' . $andsql . ' ORDER BY position DESC', $newposition, $oldposition);
		else
			as_db_query_sub('UPDATE ^' . $table . ' SET position=position-1 WHERE position BETWEEN # AND #' . $andsql . ' ORDER BY position', $oldposition, $newposition);

		as_db_query_sub('UPDATE ^' . $table . ' SET position=# WHERE ' . $idcolumn . '=#' . $andsql, $newposition, $id);
	}

	as_db_query_sub('UNLOCK TABLES');
}


/**
 * Delete the entity identified by $idcolumn=$id (and optional $conditionsql) in $table in the database
 * @param $table
 * @param $idcolumn
 * @param $id
 * @param $conditionsql
 */
function as_db_ordered_delete($table, $idcolumn, $id, $conditionsql = null)
{
	$andsql = isset($conditionsql) ? (' AND ' . $conditionsql) : '';

	as_db_query_sub('LOCK TABLES ^' . $table . ' WRITE');

	$oldposition = as_db_read_one_value(as_db_query_sub('SELECT position FROM ^' . $table . ' WHERE ' . $idcolumn . '=#' . $andsql, $id));

	as_db_query_sub('DELETE FROM ^' . $table . ' WHERE ' . $idcolumn . '=#' . $andsql, $id);

	as_db_query_sub('UPDATE ^' . $table . ' SET position=position-1 WHERE position>#' . $andsql . ' ORDER BY position', $oldposition);

	as_db_query_sub('UNLOCK TABLES');
}


/**
 * Create a new member field with (internal) tag $title, label $content, $flags and $permit in the database.
 * @param $title
 * @param $content
 * @param $flags
 * @param $permit
 * @return mixed
 */
function as_db_memberfield_create($title, $content, $flags, $permit = null)
{
	$position = as_db_read_one_value(as_db_query_sub('SELECT 1+COALESCE(MAX(position), 0) FROM ^memberfields'));

	as_db_query_sub(
		'INSERT INTO ^memberfields (title, content, position, flags, permit) VALUES ($, $, #, #, #)',
		$title, $content, $position, $flags, $permit
	);

	return as_db_last_insert_id();
}


/**
 * Change the member field $fieldid to have label $content, $flags and $permit in the database (the title column cannot be changed once set)
 * @param $fieldid
 * @param $content
 * @param $flags
 * @param $permit
 */
function as_db_memberfield_set_fields($fieldid, $content, $flags, $permit = null)
{
	as_db_query_sub(
		'UPDATE ^memberfields SET content=$, flags=#, permit=# WHERE fieldid=#',
		$content, $flags, $permit, $fieldid
	);
}


/**
 * Move the member field $fieldid into position $newposition in the database
 * @param $fieldid
 * @param $newposition
 */
function as_db_memberfield_move($fieldid, $newposition)
{
	as_db_ordered_move('memberfields', 'fieldid', $fieldid, $newposition);
}


/**
 * Delete the member field $fieldid in the database
 * @param $fieldid
 */
function as_db_memberfield_delete($fieldid)
{
	as_db_ordered_delete('memberfields', 'fieldid', $fieldid);
}


/**
 * Return the ID of a new widget, to be displayed by the widget module named $title on templates within $tags (comma-separated list)
 * @param $title
 * @param $tags
 * @return mixed
 */
function as_db_widget_create($title, $tags)
{
	$position = as_db_read_one_value(as_db_query_sub('SELECT 1+COALESCE(MAX(position), 0) FROM ^widgets'));

	as_db_query_sub(
		'INSERT INTO ^widgets (place, position, tags, title) VALUES (\'\', #, $, $)',
		$position, $tags, $title
	);

	return as_db_last_insert_id();
}


/**
 * Set the comma-separated list of templates for $widgetid to $tags
 * @param $widgetid
 * @param $tags
 */
function as_db_widget_set_fields($widgetid, $tags)
{
	as_db_query_sub(
		'UPDATE ^widgets SET tags=$ WHERE widgetid=#',
		$tags, $widgetid
	);
}


/**
 * Move the widget $widgetit into position $position in the database's order, and show it in $place on the page
 * @param $widgetid
 * @param $place
 * @param $newposition
 */
function as_db_widget_move($widgetid, $place, $newposition)
{
	as_db_query_sub(
		'UPDATE ^widgets SET place=$ WHERE widgetid=#',
		$place, $widgetid
	);

	as_db_ordered_move('widgets', 'widgetid', $widgetid, $newposition);
}


/**
 * Delete the widget $widgetid in the database
 * @param $widgetid
 */
function as_db_widget_delete($widgetid)
{
	as_db_ordered_delete('widgets', 'widgetid', $widgetid);
}
