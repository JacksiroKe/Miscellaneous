<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Database-level access to tables which monitor rate limits


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


/**
 * Get rate limit information for $action from the database for member $memberid and/or IP address $ip, if they're set.
 * Return as an array with the limit type in the key, and a labelled array of the period and count.
 * @param $memberid
 * @param $ip
 * @param $action
 * @return array
 */
function as_db_limits_get($memberid, $ip, $action)
{
	$selects = array();
	$arguments = array();

	if (isset($memberid)) {
		$selects[] = "(SELECT 'member' AS limitkey, period, count FROM ^memberlimits WHERE memberid=$ AND action=$)";
		$arguments[] = $memberid;
		$arguments[] = $action;
	}

	if (isset($ip)) {
		$selects[] = "(SELECT 'ip' AS limitkey, period, count FROM ^iplimits WHERE ip=UNHEX($) AND action=$)";
		$arguments[] = bin2hex(@inet_pton($ip));
		$arguments[] = $action;
	}

	if (count($selects)) {
		$query = as_db_apply_sub(implode(' UNION ALL ', $selects), $arguments);
		return as_db_read_all_assoc(as_db_query_raw($query), 'limitkey');

	} else
		return array();
}


/**
 * Increment the database rate limit count for member $memberid and $action by $count within $period
 * @param $memberid
 * @param $action
 * @param $period
 * @param $count
 */
function as_db_limits_member_add($memberid, $action, $period, $count)
{
	as_db_query_sub(
		'INSERT INTO ^memberlimits (memberid, action, period, count) VALUES ($, $, #, #) ' .
		'ON DUPLICATE KEY UPDATE count=IF(period=#, count+#, #), period=#',
		$memberid, $action, $period, $count, $period, $count, $count, $period
	);
}


/**
 * Increment the database rate limit count for IP address $ip and $action by $count within $period
 * @param $ip
 * @param $action
 * @param $period
 * @param $count
 */
function as_db_limits_ip_add($ip, $action, $period, $count)
{
	as_db_query_sub(
		'INSERT INTO ^iplimits (ip, action, period, count) VALUES (UNHEX($), $, #, #) ' .
		'ON DUPLICATE KEY UPDATE count=IF(period=#, count+#, #), period=#',
		bin2hex(@inet_pton($ip)), $action, $period, $count, $period, $count, $count, $period
	);
}
