<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Database-level access to messages table for private message history


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


/**
 * Record a message sent from $frommemberid to $tomemberid with $content in $format in the database. $public sets whether
 * public (on wall) or private. Return the messageid of the row created.
 * @param $frommemberid
 * @param $tomemberid
 * @param $content
 * @param $format
 * @param bool $public
 * @return mixed
 */
function as_db_message_create($frommemberid, $tomemberid, $content, $format, $public = false)
{
	as_db_query_sub(
		'INSERT INTO ^messages (type, frommemberid, tomemberid, content, format, created) VALUES ($, #, #, $, $, NOW())',
		$public ? 'PUBLIC' : 'PRIVATE', $frommemberid, $tomemberid, $content, $format
	);

	return as_db_last_insert_id();
}


/**
 * Hide the message with $messageid, in $box (inbox|outbox) from the member.
 * @param $messageid
 * @param $box
 */
function as_db_message_member_hide($messageid, $box)
{
	$field = ($box === 'inbox' ? 'tohidden' : 'fromhidden');

	as_db_query_sub(
		"UPDATE ^messages SET $field=1 WHERE messageid=#",
		$messageid
	);
}


/**
 * Delete the message with $messageid from the database.
 * @param $messageid
 * @param bool $public
 */
function as_db_message_delete($messageid, $public = true)
{
	// delete PM only if both sender and receiver have hidden it
	$clause = $public ? '' : ' AND fromhidden=1 AND tohidden=1';

	as_db_query_sub(
		'DELETE FROM ^messages WHERE messageid=#' . $clause,
		$messageid
	);
}


/**
 * Recalculate the cached count of wall posts for member $memberid in the database
 * @param $memberid
 */
function as_db_member_recount_posts($memberid)
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"UPDATE ^members AS x, (SELECT COUNT(*) AS wallposts FROM ^messages WHERE tomemberid=# AND type='PUBLIC') AS a SET x.wallposts=a.wallposts WHERE x.memberid=#",
			$memberid, $memberid
		);
	}
}
