<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Database functions for creating a article, answer or comment


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


/**
 * Create a new post in the database and return its ID (based on auto-incrementing)
 * @param $type
 * @param $parentid
 * @param $memberid
 * @param $cookieid
 * @param $ip
 * @param $title
 * @param $content
 * @param $format
 * @param $tagstring
 * @param $notify
 * @param $departmentid
 * @param $name
 * @return mixed
 */
function as_db_post_create($type, $parentid, $memberid, $cookieid, $ip, $title, $content, $format, $tagstring, $notify, $departmentid = null, $name = null)
{
	as_db_query_sub(
		'INSERT INTO ^posts (departmentid, type, parentid, memberid, cookieid, createip, title, content, format, tags, notify, name, created) ' .
		'VALUES (#, $, #, $, #, UNHEX($), $, $, $, $, $, $, NOW())',
		$departmentid, $type, $parentid, $memberid, $cookieid, bin2hex(@inet_pton($ip)), $title, $content, $format, $tagstring, $notify, $name
	);

	return as_db_last_insert_id();
}

function as_db_lesson_create($timetable, $group, $unit, $teacher, $code, $memberid)
{
	as_db_query_sub(
		'INSERT INTO ^lessons (timetable, groupid, unitid, teacher, code, memberid, created) ' .
		'VALUES ($, $, $, $, $, $, NOW())',
		$timetable, $group, $unit, $teacher, $code, $memberid
	);

	return as_db_last_insert_id();
}

function as_db_marks_create($examid, $paperid, $groupid, $unitid, $student)
{
	as_db_query_sub(
		'INSERT INTO ^marks (examid, paperid, groupid, unitid, student, created) ' .
		'VALUES ($, $, $, $, $, NOW())',
		$examid, $paperid, $groupid, $unitid, $student
	);

	return as_db_last_insert_id();
}

function as_db_timetable_create($state, $memberid, $cookieid, $ip, $title, $content, $count, $duration, $slots, $extravalue = null)
{
	as_db_query_sub(
		'INSERT INTO ^timetables (state, memberid, cookieid, createip, title, content, count, duration, slots, created) ' .
		'VALUES ($, $, #, UNHEX($), $, $, #, #, $, NOW())',
		$state, $memberid, $cookieid, bin2hex(@inet_pton($ip)), $title, $content, $count, $duration, $slots
	);

	return as_db_last_insert_id();
}

function as_db_examination_create($title, $code, $content, $memberid, $testfrom, $testto, $closed)
{
	as_db_query_sub(
		'INSERT INTO ^exams (title, code, content, memberid, testfrom, testto, closed, created) ' .
		'VALUES (#, #, #, $, #, #, $, NOW())',
		$title, $code, $content, $memberid, $testfrom, $testto, $closed
	);

	return as_db_last_insert_id();
}

function as_db_paper_create($exam, $group, $unit, $memberid, $type, $title, $qcount, $duration)
{
	as_db_query_sub(
		'INSERT INTO ^examspapers (examid, groupid, unitid, memberid, type, title, qcount, duration, created) ' .
		'VALUES ($, $, $, $, #, #, $, $, NOW())',
		$exam, $group, $unit, $memberid, $type, $title, $qcount, $duration
	);

	return as_db_last_insert_id();
}

function as_db_question_create($memberid, $cookieid, $ip, $paperid, $question, $format, $answera, $answerb, $answerc, $answerd, $marks, $answer)
{
	as_db_query_sub(
		'INSERT INTO ^examsquizes (paperid, memberid, cookieid, createip, question, format, answera, answerb, answerc, answerd, marks, answer, created) ' .
		'VALUES (#, #, $, UNHEX($), $, $, $, $, $, $, #, $, NOW())',
		$paperid, $memberid, $cookieid, bin2hex(@inet_pton($ip)), $question, $format, $answera, $answerb, $answerc, $answerd, $marks, $answer
	);

	return as_db_last_insert_id();
}

/**
 * Recalculate the full department path (i.e. columns deptidpath1/2/3) for posts from $firstpostid to $lastpostid (if specified)
 * @param $firstpostid
 * @param $lastpostid
 */
function as_db_posts_calc_department_path($firstpostid, $lastpostid = null)
{
	if (!isset($lastpostid))
		$lastpostid = $firstpostid;

	as_db_query_sub(
		"UPDATE ^posts AS x, (SELECT ^posts.postid, " .
		"COALESCE(parent2.parentid, parent1.parentid, parent0.parentid, parent0.departmentid) AS deptidpath1, " .
		"IF (parent2.parentid IS NOT NULL, parent1.parentid, IF (parent1.parentid IS NOT NULL, parent0.parentid, IF (parent0.parentid IS NOT NULL, parent0.departmentid, NULL))) AS deptidpath2, " .
		"IF (parent2.parentid IS NOT NULL, parent0.parentid, IF (parent1.parentid IS NOT NULL, parent0.departmentid, NULL)) AS deptidpath3 " .
		"FROM ^posts LEFT JOIN ^departments AS parent0 ON ^posts.departmentid=parent0.departmentid LEFT JOIN ^departments AS parent1 ON parent0.parentid=parent1.departmentid LEFT JOIN ^departments AS parent2 ON parent1.parentid=parent2.departmentid WHERE ^posts.postid BETWEEN # AND #) AS a SET x.deptidpath1=a.deptidpath1, x.deptidpath2=a.deptidpath2, x.deptidpath3=a.deptidpath3 WHERE x.postid=a.postid",
		$firstpostid, $lastpostid
	); // requires AS_DEPARTMENT_DEPTH=4
}


/**
 * Get the full department path (including departmentid) for $postid
 * @param $postid
 * @return array|null
 */
function as_db_post_get_department_path($postid)
{
	return as_db_read_one_assoc(as_db_query_sub(
		'SELECT departmentid, deptidpath1, deptidpath2, deptidpath3 FROM ^posts WHERE postid=#',
		$postid
	)); // requires AS_DEPARTMENT_DEPTH=4
}


/**
 * Update the cached number of answers for $articleid in the database, along with the highest netvotes of any of its answers
 * @param $articleid
 */
function as_db_post_acount_update($articleid)
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"UPDATE ^posts AS x, (SELECT COUNT(*) AS acount, COALESCE(GREATEST(MAX(netvotes), 0), 0) AS amaxvote FROM ^posts WHERE parentid=# AND type='A') AS a SET x.acount=a.acount, x.amaxvote=a.amaxvote WHERE x.postid=#",
			$articleid, $articleid
		);
	}
}


/**
 * Recalculate the number of articles for each department in $path retrieved via as_db_post_get_department_path()
 * @param $path
 */
function as_db_department_path_qcount_update($path)
{
	as_db_ifdepartment_qcount_update($path['departmentid']); // requires AS_DEPARTMENT_DEPTH=4
	as_db_ifdepartment_qcount_update($path['deptidpath1']);
	as_db_ifdepartment_qcount_update($path['deptidpath2']);
	as_db_ifdepartment_qcount_update($path['deptidpath3']);
}


/**
 * Update the cached number of articles for department $departmentid in the database, including its subdepartments
 * @param $departmentid
 */
function as_db_ifdepartment_qcount_update($departmentid)
{
	if (as_should_update_counts() && isset($departmentid)) {
		// This seemed like the most sensible approach which avoids explicitly calculating the department's depth in the hierarchy

		as_db_query_sub(
			"UPDATE ^departments SET qcount=GREATEST( (SELECT COUNT(*) FROM ^posts WHERE departmentid=# AND type='Q'), (SELECT COUNT(*) FROM ^posts WHERE deptidpath1=# AND type='Q'), (SELECT COUNT(*) FROM ^posts WHERE deptidpath2=# AND type='Q'), (SELECT COUNT(*) FROM ^posts WHERE deptidpath3=# AND type='Q') ) WHERE departmentid=#",
			$departmentid, $departmentid, $departmentid, $departmentid, $departmentid
		); // requires AS_DEPARTMENT_DEPTH=4
	}
}


/**
 * Add rows into the database title index, where $postid contains the words $wordids - this does the same sort
 * of thing as as_db_posttags_add_post_wordids() in a different way, for no particularly good reason.
 * @param $postid
 * @param $wordids
 */
function as_db_titlewords_add_post_wordids($postid, $wordids)
{
	if (count($wordids)) {
		$rowstoadd = array();
		foreach ($wordids as $wordid)
			$rowstoadd[] = array($postid, $wordid);

		as_db_query_sub(
			'INSERT INTO ^titlewords (postid, wordid) VALUES #',
			$rowstoadd
		);
	}
}


/**
 * Add rows into the database content index, where $postid (of $type, with the antecedent $articleid)
 * has words as per the keys of $wordidcounts, and the corresponding number of those words in the values.
 * @param $postid
 * @param $type
 * @param $articleid
 * @param $wordidcounts
 */
function as_db_contentwords_add_post_wordidcounts($postid, $type, $articleid, $wordidcounts)
{
	if (count($wordidcounts)) {
		$rowstoadd = array();
		foreach ($wordidcounts as $wordid => $count)
			$rowstoadd[] = array($postid, $wordid, $count, $type, $articleid);

		as_db_query_sub(
			'INSERT INTO ^contentwords (postid, wordid, count, type, articleid) VALUES #',
			$rowstoadd
		);
	}
}


/**
 * Add rows into the database index of individual tag words, where $postid contains the words $wordids
 * @param $postid
 * @param $wordids
 */
function as_db_tagwords_add_post_wordids($postid, $wordids)
{
	if (count($wordids)) {
		$rowstoadd = array();
		foreach ($wordids as $wordid)
			$rowstoadd[] = array($postid, $wordid);

		as_db_query_sub(
			'INSERT INTO ^tagwords (postid, wordid) VALUES #',
			$rowstoadd
		);
	}
}


/**
 * Add rows into the database index of whole tags, where $postid contains the tags $wordids
 * @param $postid
 * @param $wordids
 */
function as_db_posttags_add_post_wordids($postid, $wordids)
{
	if (count($wordids)) {
		as_db_query_sub(
			'INSERT INTO ^posttags (postid, wordid, postcreated) SELECT postid, wordid, created FROM ^words, ^posts WHERE postid=# AND wordid IN ($)',
			$postid, $wordids
		);
	}
}


/**
 * Return an array mapping each word in $words to its corresponding wordid in the database
 * @param $words
 * @return array
 */
function as_db_word_mapto_ids($words)
{
	if (count($words)) {
		return as_db_read_all_assoc(as_db_query_sub(
			'SELECT wordid, word FROM ^words WHERE word IN ($)', $words
		), 'word', 'wordid');
	}

	return array();
}


/**
 * Return an array mapping each word in $words to its corresponding wordid in the database, adding any that are missing
 * @param $words
 * @return array
 */
function as_db_word_mapto_ids_add($words)
{
	$wordtoid = as_db_word_mapto_ids($words);

	$wordstoadd = array();
	foreach ($words as $word) {
		if (!isset($wordtoid[$word]))
			$wordstoadd[] = $word;
	}

	if (count($wordstoadd)) {
		as_db_query_sub('LOCK TABLES ^words WRITE'); // to prevent two requests adding the same word

		$wordtoid = as_db_word_mapto_ids($words); // map it again in case table content changed before it was locked

		$rowstoadd = array();
		foreach ($words as $word) {
			if (!isset($wordtoid[$word]))
				$rowstoadd[] = array($word);
		}

		as_db_query_sub('INSERT IGNORE INTO ^words (word) VALUES $', $rowstoadd);

		as_db_query_sub('UNLOCK TABLES');

		$wordtoid = as_db_word_mapto_ids($words); // do it one last time
	}

	return $wordtoid;
}


/**
 * Update the titlecount column in the database for the words in $wordids, based on how many posts they appear in the title of
 * @param $wordids
 */
function as_db_word_titlecount_update($wordids)
{
	if (as_should_update_counts() && count($wordids)) {
		as_db_query_sub(
			'UPDATE ^words AS x, (SELECT ^words.wordid, COUNT(^titlewords.wordid) AS titlecount FROM ^words LEFT JOIN ^titlewords ON ^titlewords.wordid=^words.wordid WHERE ^words.wordid IN (#) GROUP BY wordid) AS a SET x.titlecount=a.titlecount WHERE x.wordid=a.wordid',
			$wordids
		);
	}
}


/**
 * Update the contentcount column in the database for the words in $wordids, based on how many posts they appear in the content of
 * @param $wordids
 */
function as_db_word_contentcount_update($wordids)
{
	if (as_should_update_counts() && count($wordids)) {
		as_db_query_sub(
			'UPDATE ^words AS x, (SELECT ^words.wordid, COUNT(^contentwords.wordid) AS contentcount FROM ^words LEFT JOIN ^contentwords ON ^contentwords.wordid=^words.wordid WHERE ^words.wordid IN (#) GROUP BY wordid) AS a SET x.contentcount=a.contentcount WHERE x.wordid=a.wordid',
			$wordids
		);
	}
}


/**
 * Update the tagwordcount column in the database for the individual tag words in $wordids, based on how many posts they appear in the tags of
 * @param $wordids
 */
function as_db_word_tagwordcount_update($wordids)
{
	if (as_should_update_counts() && count($wordids)) {
		as_db_query_sub(
			'UPDATE ^words AS x, (SELECT ^words.wordid, COUNT(^tagwords.wordid) AS tagwordcount FROM ^words LEFT JOIN ^tagwords ON ^tagwords.wordid=^words.wordid WHERE ^words.wordid IN (#) GROUP BY wordid) AS a SET x.tagwordcount=a.tagwordcount WHERE x.wordid=a.wordid',
			$wordids
		);
	}
}


/**
 * Update the tagcount column in the database for the whole tags in $wordids, based on how many posts they appear as tags of
 * @param $wordids
 */
function as_db_word_tagcount_update($wordids)
{
	if (as_should_update_counts() && count($wordids)) {
		as_db_query_sub(
			'UPDATE ^words AS x, (SELECT ^words.wordid, COUNT(^posttags.wordid) AS tagcount FROM ^words LEFT JOIN ^posttags ON ^posttags.wordid=^words.wordid WHERE ^words.wordid IN (#) GROUP BY wordid) AS a SET x.tagcount=a.tagcount WHERE x.wordid=a.wordid',
			$wordids
		);
	}
}


/**
 * Update the cached count in the database of the number of articles (excluding hidden/queued)
 */
function as_db_qcount_update()
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"INSERT INTO ^options (title, content) " .
			"SELECT 'cache_qcount', COUNT(*) FROM ^posts " .
			"WHERE type = 'Q' " .
			"ON DUPLICATE KEY UPDATE content = VALUES(content)"
		);
	}
}


/**
 * Update the cached count in the database of the number of answers (excluding hidden/queued)
 */
function as_db_acount_update()
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"INSERT INTO ^options (title, content) " .
			"SELECT 'cache_acount', COUNT(*) FROM ^posts " .
			"WHERE type = 'A' " .
			"ON DUPLICATE KEY UPDATE content = VALUES(content)"
		);
	}
}


/**
 * Update the cached count in the database of the number of comments (excluding hidden/queued)
 */
function as_db_ccount_update()
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"INSERT INTO ^options (title, content) " .
			"SELECT 'cache_ccount', COUNT(*) FROM ^posts " .
			"WHERE type = 'C' " .
			"ON DUPLICATE KEY UPDATE content = VALUES(content)"
		);
	}
}


/**
 * Update the cached count in the database of the number of different tags used
 */
function as_db_tagcount_update()
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"INSERT INTO ^options (title, content) " .
			"SELECT 'cache_tagcount', COUNT(*) FROM ^words " .
			"WHERE tagcount > 0 " .
			"ON DUPLICATE KEY UPDATE content = VALUES(content)"
		);
	}
}


/**
 * Update the cached count in the database of the number of unanswered articles (excluding hidden/queued)
 */
function as_db_unaqcount_update()
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"INSERT INTO ^options (title, content) " .
			"SELECT 'cache_unaqcount', COUNT(*) FROM ^posts " .
			"WHERE type = 'Q' AND acount = 0 AND closedbyid IS NULL " .
			"ON DUPLICATE KEY UPDATE content = VALUES(content)"
		);
	}
}


/**
 * Update the cached count in the database of the number of articles with no answer selected (excluding hidden/queued)
 */
function as_db_unselqcount_update()
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"INSERT INTO ^options (title, content) " .
			"SELECT 'cache_unselqcount', COUNT(*) FROM ^posts " .
			"WHERE type = 'Q' AND selchildid IS NULL AND closedbyid IS NULL " .
			"ON DUPLICATE KEY UPDATE content = VALUES(content)"
		);
	}
}


/**
 * Update the cached count in the database of the number of articles with no upvoted answers (excluding hidden/queued)
 */
function as_db_unupaqcount_update()
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"INSERT INTO ^options (title, content) " .
			"SELECT 'cache_unupaqcount', COUNT(*) FROM ^posts " .
			"WHERE type = 'Q' AND amaxvote = 0 AND closedbyid IS NULL " .
			"ON DUPLICATE KEY UPDATE content = VALUES(content)"
		);
	}
}


/**
 * Update the cached count in the database of the number of posts which are queued for moderation
 */
function as_db_queuedcount_update()
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"INSERT INTO ^options (title, content) " .
			"SELECT 'cache_queuedcount', COUNT(*) FROM ^posts " .
			"WHERE type IN ('Q_QUEUED', 'A_QUEUED', 'C_QUEUED') " .
			"ON DUPLICATE KEY UPDATE content = VALUES(content)"
		);
	}
}

/**
 * Create a new department with $parentid, $title (=name) and $tags (=slug) in the database
 * @param $parentid
 * @param $title
 * @param $tags
 * @return mixed
 */
function as_db_department_create($parentid, $title, $tags)
{
	$lastpos = as_db_department_last_pos($parentid);

	as_db_query_sub(
		'INSERT INTO ^departments (parentid, title, tags, position) VALUES (#, $, $, #)',
		$parentid, $title, $tags, 1 + $lastpos
	);

	$departmentid = as_db_last_insert_id();

	as_db_departments_recalc_backpaths($departmentid);

	return $departmentid;
}


/**
 * Recalculate the backpath columns for all departments from $firstdepartmentid to $lastdepartmentid (if specified)
 * @param $firstdepartmentid
 * @param $lastdepartmentid
 */
function as_db_departments_recalc_backpaths($firstdepartmentid, $lastdepartmentid = null)
{
	if (!isset($lastdepartmentid))
		$lastdepartmentid = $firstdepartmentid;

	as_db_query_sub(
		"UPDATE ^departments AS x, (SELECT cat1.departmentid, CONCAT_WS('/', cat1.tags, cat2.tags, cat3.tags, cat4.tags) AS backpath FROM ^departments AS cat1 LEFT JOIN ^departments AS cat2 ON cat1.parentid=cat2.departmentid LEFT JOIN ^departments AS cat3 ON cat2.parentid=cat3.departmentid LEFT JOIN ^departments AS cat4 ON cat3.parentid=cat4.departmentid WHERE cat1.departmentid BETWEEN # AND #) AS a SET x.backpath=a.backpath WHERE x.departmentid=a.departmentid",
		$firstdepartmentid, $lastdepartmentid // requires AS_DEPARTMENT_DEPTH=4
	);
}


/**
 * Set the name of $departmentid to $title and its slug to $tags in the database
 * @param $departmentid
 * @param $title
 * @param $tags
 */
function as_db_department_rename($departmentid, $title, $tags)
{
	as_db_query_sub(
		'UPDATE ^departments SET title=$, tags=$ WHERE departmentid=#',
		$title, $tags, $departmentid
	);

	as_db_departments_recalc_backpaths($departmentid); // may also require recalculation of its offspring's backpaths
}


/**
 * Set the content (=description) of $departmentid to $content
 * @param $departmentid
 * @param $content
 */
function as_db_department_set_content($departmentid, $content)
{
	as_db_query_sub(
		'UPDATE ^departments SET content=$ WHERE departmentid=#',
		$content, $departmentid
	);
}


/**
 * Return the parentid of $departmentid
 * @param $departmentid
 * @return mixed|null
 */
function as_db_department_get_parent($departmentid)
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT parentid FROM ^departments WHERE departmentid=#',
		$departmentid
	));
}


/**
 * Move the department $departmentid into position $newposition under its parent
 * @param $departmentid
 * @param $newposition
 */
function as_db_department_set_position($departmentid, $newposition)
{
	as_db_ordered_move('departments', 'departmentid', $departmentid, $newposition,
		as_db_apply_sub('parentid<=>#', array(as_db_department_get_parent($departmentid))));
}


/**
 * Set the parent of $departmentid to $newparentid, placing it in last position (doesn't do necessary recalculations)
 * @param $departmentid
 * @param $newparentid
 */
function as_db_department_set_parent($departmentid, $newparentid)
{
	$oldparentid = as_db_department_get_parent($departmentid);

	if (strcmp($oldparentid, $newparentid)) { // if we're changing parent, move to end of old parent, then end of new parent
		$lastpos = as_db_department_last_pos($oldparentid);

		as_db_ordered_move('departments', 'departmentid', $departmentid, $lastpos, as_db_apply_sub('parentid<=>#', array($oldparentid)));

		$lastpos = as_db_department_last_pos($newparentid);

		as_db_query_sub(
			'UPDATE ^departments SET parentid=#, position=# WHERE departmentid=#',
			$newparentid, 1 + $lastpos, $departmentid
		);
	}
}


/**
 * Change the departmentid of any posts with (exact) $departmentid to $reassignid
 * @param $departmentid
 * @param $reassignid
 */
function as_db_department_reassign($departmentid, $reassignid)
{
	as_db_query_sub('UPDATE ^posts SET departmentid=# WHERE departmentid<=>#', $reassignid, $departmentid);
}


/**
 * Delete the department $departmentid in the database
 * @param $departmentid
 */
function as_db_department_delete($departmentid)
{
	as_db_ordered_delete('departments', 'departmentid', $departmentid,
		as_db_apply_sub('parentid<=>#', array(as_db_department_get_parent($departmentid))));
}


/**
 * Return the departmentid for the department with parent $parentid and $slug
 * @param $parentid
 * @param $slug
 * @return mixed|null
 */
function as_db_department_slug_to_id($parentid, $slug)
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT departmentid FROM ^departments WHERE parentid<=># AND tags=$',
		$parentid, $slug
	), true);
}

/**
 * Return the maximum position of the groups with $groupid
 * @param $groupid
 * @return mixed|null
 */
function as_db_group_last_pos($groupid)
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT COALESCE(MAX(position), 0) FROM ^groups WHERE groupid<=>#',
		$groupid
	));
}


/**
 * Return how many levels of subclass there are below $groupid
 * @param $groupid
 * @return int
 */
function as_db_group_child_depth($groupid)
{
	// This is potentially a very slow query since it counts all the multi-generational offspring of a particular class
	// But it's only used for admin purposes when moving a class around so I don't think it's worth making more efficient
	// (Incidentally, this could be done by keeping a count for every class of how many generations of offspring it has.)

	$result = as_db_read_one_assoc(as_db_query_sub(
		'SELECT COUNT(child1.groupid) AS count1, COUNT(child2.groupid) AS count2, COUNT(child3.groupid) AS count3 FROM ^groups AS child1 LEFT JOIN ^groups AS child2 ON child2.groupid=child1.groupid LEFT JOIN ^groups AS child3 ON child3.groupid=child2.groupid WHERE child1.groupid=#;', // requires AS_DEPARTMENT_DEPTH=4
		$groupid
	));

	for ($depth = AS_DEPARTMENT_DEPTH - 1; $depth >= 1; $depth--)
		if ($result['count' . $depth])
			return $depth;

	return 0;
}


/**
 * Create a new class with $groupid, $title (=name) and $tags (=slug) in the database
 * @param $groupid
 * @param $title
 * @param $tags
 * @return mixed
 */
function as_db_group_create($groupid, $title, $code, $tags)
{
	$lastpos = as_db_group_last_pos($groupid);

	as_db_query_sub(
		'INSERT INTO ^groups (groupid, title, code, tags, position) VALUES (#, $, $, $, #)',
		$groupid, $title, $code, $tags, 1 + $lastpos
	);

	$groupid = as_db_last_insert_id();
	return $groupid;
}

/**
 * Set the name of $groupid to $title and its slug to $tags in the database
 * @param $groupid
 * @param $title
 * @param $tags
 */
function as_db_group_rename($groupid, $title, $code, $tags)
{
	as_db_query_sub(
		'UPDATE ^groups SET title=$, code=$, tags=$ WHERE groupid=#',
		$title, $code, $tags, $groupid
	);
}


/**
 * Set the content (=description) of $groupid to $content
 * @param $groupid
 * @param $content
 */
function as_db_group_set_content($groupid, $content)
{
	as_db_query_sub(
		'UPDATE ^groups SET content=$ WHERE groupid=#',
		$content, $groupid
	);
}


/**
 * Return the groupid of $groupid
 * @param $groupid
 * @return mixed|null
 */
function as_db_group_get_parent($groupid)
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT groupid FROM ^groups WHERE groupid=#',
		$groupid
	));
}


/**
 * Move the class $groupid into position $newposition under its parent
 * @param $groupid
 * @param $newposition
 */
function as_db_group_set_position($groupid, $newposition)
{
	as_db_ordered_move('groups', 'groupid', $groupid, $newposition,
		as_db_apply_sub('groupid<=>#', array(as_db_group_get_parent($groupid))));
}


/**
 * Set the parent of $groupid to $newgroupid, placing it in last position (doesn't do necessary recalculations)
 * @param $groupid
 * @param $newgroupid
 */
function as_db_group_set_parent($groupid, $newgroupid)
{
	$oldgroupid = as_db_group_get_parent($groupid);

	if (strcmp($oldgroupid, $newgroupid)) { // if we're changing parent, move to end of old parent, then end of new parent
		$lastpos = as_db_group_last_pos($oldgroupid);

		as_db_ordered_move('groups', 'groupid', $groupid, $lastpos, as_db_apply_sub('groupid<=>#', array($oldgroupid)));

		$lastpos = as_db_group_last_pos($newgroupid);

		as_db_query_sub(
			'UPDATE ^groups SET groupid=#, position=# WHERE groupid=#',
			$newgroupid, 1 + $lastpos, $groupid
		);
	}
}


/**
 * Change the groupid of any posts with (exact) $groupid to $reassignid
 * @param $groupid
 * @param $reassignid
 */
function as_db_group_reassign($groupid, $reassignid)
{
	as_db_query_sub('UPDATE ^posts SET groupid=# WHERE groupid<=>#', $reassignid, $groupid);
}


/**
 * Delete the class $groupid in the database
 * @param $groupid
 */
function as_db_group_delete($groupid)
{
	as_db_ordered_delete('groups', 'groupid', $groupid,
		as_db_apply_sub('groupid<=>#', array(as_db_group_get_parent($groupid))));
}


/**
 * Return the groupid for the class with parent $groupid and $slug
 * @param $groupid
 * @param $slug
 * @return mixed|null
 */
function as_db_group_slug_to_id($groupid, $slug)
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT groupid FROM ^groups WHERE groupid<=># AND tags=$',
		$groupid, $slug
	), true);
}

/**
 * Return the maximum position of the units with $unitid
 * @param $unitid
 * @return mixed|null
 */
function as_db_unit_last_pos($unitid)
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT COALESCE(MAX(position), 0) FROM ^units WHERE unitid<=>#',
		$unitid
	));
}


/**
 * Return how many levels of subunit there are below $unitid
 * @param $unitid
 * @return int
 */
function as_db_unit_child_depth($unitid)
{
	// This is potentially a very slow query since it counts all the multi-generational offspring of a particular unit
	// But it's only used for admin purposes when moving a unit around so I don't think it's worth making more efficient
	// (Incidentally, this could be done by keeping a count for every unit of how many generations of offspring it has.)

	$result = as_db_read_one_assoc(as_db_query_sub(
		'SELECT COUNT(child1.unitid) AS count1, COUNT(child2.unitid) AS count2, COUNT(child3.unitid) AS count3 FROM ^units AS child1 LEFT JOIN ^units AS child2 ON child2.unitid=child1.unitid LEFT JOIN ^units AS child3 ON child3.unitid=child2.unitid WHERE child1.unitid=#;', // requires AS_DEPARTMENT_DEPTH=4
		$unitid
	));

	for ($depth = AS_DEPARTMENT_DEPTH - 1; $depth >= 1; $depth--)
		if ($result['count' . $depth])
			return $depth;

	return 0;
}


/**
 * Create a new unit with $unitid, $title (=name) and $tags (=slug) in the database
 * @param $unitid
 * @param $title
 * @param $tags
 * @return mixed
 */
function as_db_unit_create($unitid, $title, $code, $tags)
{
	$lastpos = as_db_unit_last_pos($unitid);

	as_db_query_sub(
		'INSERT INTO ^units (unitid, title, code, tags, position) VALUES (#, $, $, $, #)',
		$unitid, $title, $code, $tags, 1 + $lastpos
	);

	$unitid = as_db_last_insert_id();
	return $unitid;
}

/**
 * Set the name of $unitid to $title and its slug to $tags in the database
 * @param $unitid
 * @param $title
 * @param $tags
 */
function as_db_unit_rename($unitid, $title, $code, $tags)
{
	as_db_query_sub(
		'UPDATE ^units SET title=$, code=$, tags=$ WHERE unitid=#',
		$title, $code, $tags, $unitid
	);
}


/**
 * Set the content (=description) of $unitid to $content
 * @param $unitid
 * @param $content
 */
function as_db_unit_set_content($unitid, $content)
{
	as_db_query_sub(
		'UPDATE ^units SET content=$ WHERE unitid=#',
		$content, $unitid
	);
}


/**
 * Return the unitid of $unitid
 * @param $unitid
 * @return mixed|null
 */
function as_db_unit_get_parent($unitid)
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT unitid FROM ^units WHERE unitid=#',
		$unitid
	));
}


/**
 * Move the unit $unitid into position $newposition under its parent
 * @param $unitid
 * @param $newposition
 */
function as_db_unit_set_position($unitid, $newposition)
{
	as_db_ordered_move('units', 'unitid', $unitid, $newposition,
		as_db_apply_sub('unitid<=>#', array(as_db_unit_get_parent($unitid))));
}


/**
 * Set the parent of $unitid to $newunitid, placing it in last position (doesn't do necessary recalculations)
 * @param $unitid
 * @param $newunitid
 */
function as_db_unit_set_parent($unitid, $newunitid)
{
	$oldunitid = as_db_unit_get_parent($unitid);

	if (strcmp($oldunitid, $newunitid)) { // if we're changing parent, move to end of old parent, then end of new parent
		$lastpos = as_db_unit_last_pos($oldunitid);

		as_db_ordered_move('units', 'unitid', $unitid, $lastpos, as_db_apply_sub('unitid<=>#', array($oldunitid)));

		$lastpos = as_db_unit_last_pos($newunitid);

		as_db_query_sub(
			'UPDATE ^units SET unitid=#, position=# WHERE unitid=#',
			$newunitid, 1 + $lastpos, $unitid
		);
	}
}


/**
 * Change the unitid of any posts with (exact) $unitid to $reassignid
 * @param $unitid
 * @param $reassignid
 */
function as_db_unit_reassign($unitid, $reassignid)
{
	as_db_query_sub('UPDATE ^posts SET unitid=# WHERE unitid<=>#', $reassignid, $unitid);
}


/**
 * Delete the unit $unitid in the database
 * @param $unitid
 */
function as_db_unit_delete($unitid)
{
	as_db_ordered_delete('units', 'unitid', $unitid,
		as_db_apply_sub('unitid<=>#', array(as_db_unit_get_parent($unitid))));
}


/**
 * Return the unitid for the unit with parent $unitid and $slug
 * @param $unitid
 * @param $slug
 * @return mixed|null
 */
function as_db_unit_slug_to_id($unitid, $slug)
{
	return as_db_read_one_value(as_db_query_sub(
		'SELECT unitid FROM ^units WHERE unitid<=># AND tags=$',
		$unitid, $slug
	), true);
}
