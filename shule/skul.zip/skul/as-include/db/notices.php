<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Database-level access to membernotices table


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


/**
 * Create a notice for $memberid with $content in $format and optional $tags (not displayed) and return its noticeid
 * @param $memberid
 * @param $content
 * @param string $format
 * @param $tags
 * @return mixed
 */
function as_db_membernotice_create($memberid, $content, $format = '', $tags = null)
{
	as_db_query_sub(
		'INSERT INTO ^membernotices (memberid, content, format, tags, created) VALUES ($, $, $, $, NOW())',
		$memberid, $content, $format, $tags
	);

	return as_db_last_insert_id();
}


/**
 * Delete the notice $notice which belongs to $memberid
 * @param $memberid
 * @param $noticeid
 */
function as_db_membernotice_delete($memberid, $noticeid)
{
	as_db_query_sub(
		'DELETE FROM ^membernotices WHERE memberid=$ AND noticeid=#',
		$memberid, $noticeid
	);
}


/**
 * Return an array summarizing the notices to be displayed for $memberid, including the tags (not displayed)
 * @param $memberid
 * @return array
 */
function as_db_membernotices_list($memberid)
{
	return as_db_read_all_assoc(as_db_query_sub(
		'SELECT noticeid, tags, UNIX_TIMESTAMP(created) AS created FROM ^membernotices WHERE memberid=$ ORDER BY created',
		$memberid
	));
}
