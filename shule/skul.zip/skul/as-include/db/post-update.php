<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description:  Database functions for changing a article, answer or comment


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'app/updates.php';

function as_db_paper_update($score, $attempts, $paperid)
{
	as_db_query_sub(
		'UPDATE ^examspapers SET score=#, attempts=#, updated=NOW() WHERE paperid=#',
		$score, $attempts, $paperid
	);
}

function as_db_marks_update($score, $grade, $remark, $memberid, $examid, $paperid, $groupid, $unitid, $student)
{
	as_db_query_sub(
		'UPDATE ^marks SET score=#, grade=$, remark=$, updated=NOW(), memberid=# WHERE examid=# AND paperid=# AND groupid=# AND unitid=# AND student=#',
		$score, $grade, $remark, $memberid, $examid, $paperid, $groupid, $unitid, $student
	);
}

function as_db_timetable_update($timetableid, $title, $content, $count, $duration, $slots, $groups, $teachers, $lessons, $lastmemberid = null, $lastip = null, $extravalue)
{
	as_db_query_sub(
		'UPDATE ^timetables SET title=$, content=$, count=$, slots=$, groups=$, teachers=$, lessons=$, updated=NOW(), lastmemberid=$, lastip=UNHEX($) WHERE timetableid=#',
		$title, $content, $count, $slots, $groups, $teachers, $lessons, $lastmemberid, bin2hex(@inet_pton($lastip)), $timetableid
	);
}

/**
	Update items count for db item.
*/
function as_db_items_update_count($table, $column, $count, $itemcolumn, $itemid)
{
	as_db_query_sub( 'UPDATE ^'.$table.' SET '.$column.'='.$count.' WHERE '.$itemcolumn.'='.$itemid );
}
 
/**
	Update papers count for exam item.
*/
function as_db_papers_update_count($examid, $papers)
{
	as_db_query_sub(
		'UPDATE ^exams SET papers=#, updated=NOW() WHERE examid=#',
		($papers + 1), $examid
	);
}
 
/**
	Update questions count for paper item.
*/
function as_db_quiz_update_count($paperid, $qcount)
{
	as_db_query_sub(
		'UPDATE ^examspapers SET qcount=# WHERE paperid=#',
		($qcount + 1), $paperid
	);
}

/**
 * Update the selected answer in the database for $articleid to $selchildid, and optionally record that $lastmemberid did it from $lastip
 * @param $articleid
 * @param $selchildid
 * @param $lastmemberid
 * @param $lastip
 */
function as_db_post_set_selchildid($articleid, $selchildid, $lastmemberid = null, $lastip = null)
{
	as_db_query_sub(
		"UPDATE ^posts AS x, (SELECT selchildid FROM ^posts WHERE postid=#) AS a " .
		"SET x.updated=NULL, x.updatetype=NULL, x.lastmemberid=NULL, x.lastip=NULL WHERE " . // if previous answer's last edit was to be selected, remove that
		"x.postid=a.selchildid AND x.updatetype=$",
		$articleid, AS_UPDATE_SELECTED
	);

	as_db_query_sub(
		'UPDATE ^posts SET selchildid=# WHERE postid=#',
		$selchildid, $articleid
	);

	if (isset($selchildid) && isset($lastmemberid) && isset($lastip)) {
		as_db_query_sub(
			"UPDATE ^posts SET updated=NOW(), updatetype=$, lastmemberid=$, lastip=UNHEX($) WHERE postid=#",
			AS_UPDATE_SELECTED, $lastmemberid, bin2hex(@inet_pton($lastip)), $selchildid
		);
	}
}


/**
 * Set $articleid to be closed by post $closedbyid (null if not closed) in the database, and optionally record that
 * $lastmemberid did it from $lastip
 * @param $articleid
 * @param $closedbyid
 * @param $lastmemberid
 * @param $lastip
 */
function as_db_post_set_closed($articleid, $closedbyid, $lastmemberid = null, $lastip = null)
{
	if (isset($lastmemberid) || isset($lastip)) {
		as_db_query_sub(
			"UPDATE ^posts SET closedbyid=#, updated=NOW(), updatetype=$, lastmemberid=$, lastip=UNHEX($) WHERE postid=#",
			$closedbyid, AS_UPDATE_CLOSED, $lastmemberid, bin2hex(@inet_pton($lastip)), $articleid
		);
	} else {
		as_db_query_sub(
			'UPDATE ^posts SET closedbyid=# WHERE postid=#',
			$closedbyid, $articleid
		);
	}
}


/**
 * Set the type in the database of $postid to $type, and optionally record that $lastmemberid did it from $lastip
 * @param $postid
 * @param $type
 * @param $lastmemberid
 * @param $lastip
 * @param string $updatetype
 */
function as_db_post_set_type($postid, $type, $lastmemberid = null, $lastip = null, $updatetype = AS_UPDATE_TYPE)
{
	if (isset($lastmemberid) || isset($lastip)) {
		as_db_query_sub(
			'UPDATE ^posts SET type=$, updated=NOW(), updatetype=$, lastmemberid=$, lastip=UNHEX($) WHERE postid=#',
			$type, $updatetype, $lastmemberid, bin2hex(@inet_pton($lastip)), $postid
		);
	} else {
		as_db_query_sub(
			'UPDATE ^posts SET type=$ WHERE postid=#',
			$type, $postid
		);
	}
}


/**
 * Set the parent in the database of $postid to $parentid, and optionally record that $lastmemberid did it from $lastip
 * (if at least one is specified)
 * @param $postid
 * @param $parentid
 * @param $lastmemberid
 * @param $lastip
 */
function as_db_post_set_parent($postid, $parentid, $lastmemberid = null, $lastip = null)
{
	if (isset($lastmemberid) || isset($lastip)) {
		as_db_query_sub(
			"UPDATE ^posts SET parentid=#, updated=NOW(), updatetype=$, lastmemberid=$, lastip=UNHEX($) WHERE postid=#",
			$parentid, AS_UPDATE_PARENT, $lastmemberid, bin2hex(@inet_pton($lastip)), $postid
		);
	} else {
		as_db_query_sub(
			'UPDATE ^posts SET parentid=# WHERE postid=#',
			$parentid, $postid
		);
	}
}


/**
 * Set the text fields in the database of $postid to $title, $content, $tagstring, $notify and $name, and record that
 * $lastmemberid did it from $lastip (if at least one is specified) with $updatetype. For backwards compatibility if $name
 * is null then the name will not be changed.
 * @param $postid
 * @param $title
 * @param $content
 * @param $format
 * @param $tagstring
 * @param $notify
 * @param $lastmemberid
 * @param $lastip
 * @param string $updatetype
 * @param $name
 */
function as_db_post_set_content($postid, $title, $content, $format, $tagstring, $notify, $lastmemberid = null, $lastip = null, $updatetype = AS_UPDATE_CONTENT, $name = null)
{
	if (isset($lastmemberid) || isset($lastip)) {
		// use COALESCE() for name since $name=null means it should not be modified (for backwards compatibility)
		as_db_query_sub(
			'UPDATE ^posts SET title=$, content=$, format=$, tags=$, name=COALESCE($, name), notify=$, updated=NOW(), updatetype=$, lastmemberid=$, lastip=UNHEX($) WHERE postid=#',
			$title, $content, $format, $tagstring, $name, $notify, $updatetype, $lastmemberid, bin2hex(@inet_pton($lastip)), $postid
		);
	} else {
		as_db_query_sub(
			'UPDATE ^posts SET title=$, content=$, format=$, tags=$, name=COALESCE($, name), notify=$ WHERE postid=#',
			$title, $content, $format, $tagstring, $name, $notify, $postid
		);
	}
}


/**
 * Set the author in the database of $postid to $memberid, and set the lastmemberid to $memberid as well if appropriate
 * @param $postid
 * @param $memberid
 */
function as_db_post_set_memberid($postid, $memberid)
{
	as_db_query_sub(
		'UPDATE ^posts SET memberid=$, lastmemberid=IF(updated IS NULL, lastmemberid, COALESCE(lastmemberid,$)) WHERE postid=#',
		$memberid, $memberid, $postid
	);
}


/**
 * Set the (exact) department in the database of $postid to $departmentid, and optionally record that $lastmemberid did it from
 * $lastip (if at least one is specified)
 * @param $postid
 * @param $departmentid
 * @param $lastmemberid
 * @param $lastip
 */
function as_db_post_set_department($postid, $departmentid, $lastmemberid = null, $lastip = null)
{
	if (isset($lastmemberid) || isset($lastip)) {
		as_db_query_sub(
			"UPDATE ^posts SET departmentid=#, updated=NOW(), updatetype=$, lastmemberid=$, lastip=UNHEX($) WHERE postid=#",
			$departmentid, AS_UPDATE_DEPARTMENT, $lastmemberid, bin2hex(@inet_pton($lastip)), $postid
		);
	} else {
		as_db_query_sub(
			'UPDATE ^posts SET departmentid=# WHERE postid=#',
			$departmentid, $postid
		);
	}
}


/**
 * Set the department path in the database of each of $postids to $path retrieved via as_db_post_get_department_path()
 * @param $postids
 * @param $path
 */
function as_db_posts_set_department_path($postids, $path)
{
	if (count($postids)) {
		// requires AS_DEPARTMENT_DEPTH=4
		as_db_query_sub(
			'UPDATE ^posts SET departmentid=#, deptidpath1=#, deptidpath2=#, deptidpath3=# WHERE postid IN (#)',
			$path['departmentid'], $path['deptidpath1'], $path['deptidpath2'], $path['deptidpath3'], $postids
		);
	}
}


/**
 * Set the created date of $postid to $created, which is a unix timestamp. If created is null, set to now.
 * @param $postid
 * @param $created
 */
function as_db_post_set_created($postid, $created)
{
	if (isset($created)) {
		as_db_query_sub(
			'UPDATE ^posts SET created=FROM_UNIXTIME(#) WHERE postid=#',
			$created, $postid
		);
	} else {
		as_db_query_sub(
			'UPDATE ^posts SET created=NOW() WHERE postid=#',
			$postid
		);
	}
}


/**
 * Set the last updated date of $postid to $updated, which is a unix timestamp. If updated is null, set to now.
 * @param $postid
 * @param $updated
 */
function as_db_post_set_updated($postid, $updated)
{
	if (isset($updated)) {
		as_db_query_sub(
			'UPDATE ^posts SET updated=FROM_UNIXTIME(#) WHERE postid=#',
			$updated, $postid
		);
	} else {
		as_db_query_sub(
			'UPDATE ^posts SET updated=NOW() WHERE postid=#',
			$postid
		);
	}
}


/**
 * Deletes post $postid from the database (will also delete any votes on the post due to foreign key cascading)
 * @param $postid
 */
function as_db_post_delete($postid)
{
	as_db_query_sub(
		'DELETE FROM ^posts WHERE postid=#',
		$postid
	);
}


/**
 * Return an array of wordids that were indexed in the database for the title of $postid
 * @param $postid
 * @return array
 */
function as_db_titlewords_get_post_wordids($postid)
{
	return as_db_read_all_values(as_db_query_sub(
		'SELECT wordid FROM ^titlewords WHERE postid=#',
		$postid
	));
}


/**
 * Remove all entries in the database index of title words for $postid
 * @param $postid
 */
function as_db_titlewords_delete_post($postid)
{
	as_db_query_sub(
		'DELETE FROM ^titlewords WHERE postid=#',
		$postid
	);
}


/**
 * Return an array of wordids that were indexed in the database for the content of $postid
 * @param $postid
 * @return array
 */
function as_db_contentwords_get_post_wordids($postid)
{
	return as_db_read_all_values(as_db_query_sub(
		'SELECT wordid FROM ^contentwords WHERE postid=#',
		$postid
	));
}


/**
 * Remove all entries in the database index of content words for $postid
 * @param $postid
 */
function as_db_contentwords_delete_post($postid)
{
	as_db_query_sub(
		'DELETE FROM ^contentwords WHERE postid=#',
		$postid
	);
}


/**
 * Return an array of wordids that were indexed in the database for the individual words in tags of $postid
 * @param $postid
 * @return array
 */
function as_db_tagwords_get_post_wordids($postid)
{
	return as_db_read_all_values(as_db_query_sub(
		'SELECT wordid FROM ^tagwords WHERE postid=#',
		$postid
	));
}


/**
 * Remove all entries in the database index of individual words in tags of $postid
 * @param $postid
 */
function as_db_tagwords_delete_post($postid)
{
	as_db_query_sub(
		'DELETE FROM ^tagwords WHERE postid=#',
		$postid
	);
}


/**
 * Return an array of wordids that were indexed in the database for the whole tags of $postid
 * @param $postid
 * @return array
 */
function as_db_posttags_get_post_wordids($postid)
{
	return as_db_read_all_values(as_db_query_sub(
		'SELECT wordid FROM ^posttags WHERE postid=#',
		$postid
	));
}


/**
 * Remove all entries in the database index of whole tags for $postid
 * @param $postid
 */
function as_db_posttags_delete_post($postid)
{
	as_db_query_sub(
		'DELETE FROM ^posttags WHERE postid=#',
		$postid
	);
}


/**
 * Return the array $postids containing only those elements which are the postid of a article in the database
 * @param $postids
 * @return array
 */
function as_db_posts_filter_q_postids($postids)
{
	if (count($postids)) {
		return as_db_read_all_values(as_db_query_sub(
			"SELECT postid FROM ^posts WHERE type='Q' AND postid IN (#)",
			$postids
		));
	}

	return array();
}


/**
 * Return an array of all the memberids of authors of posts in the array $postids
 * @param $postids
 * @return array
 */
function as_db_posts_get_memberids($postids)
{
	if (count($postids)) {
		return as_db_read_all_values(as_db_query_sub(
			"SELECT DISTINCT memberid FROM ^posts WHERE postid IN (#) AND memberid IS NOT NULL",
			$postids
		));
	}

	return array();
}


/**
 * Update the cached count of the number of flagged posts in the database
 */
function as_db_flaggedcount_update()
{
	if (as_should_update_counts()) {
		as_db_query_sub(
			"INSERT INTO ^options (title, content) " .
			"SELECT 'cache_flaggedcount', COUNT(*) FROM ^posts " .
			"WHERE flagcount > 0 AND type IN ('Q', 'A', 'C') " .
			"ON DUPLICATE KEY UPDATE content = VALUES(content)"
		);
	}
}
