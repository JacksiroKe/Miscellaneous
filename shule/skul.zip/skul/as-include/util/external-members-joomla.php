<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: External member functions for basic Joomla integration


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


function as_get_mysql_member_column_type()
{
	return "INT";
}

function as_get_login_links($relative_url_prefix, $redirect_back_to_url)
{
	$jhelper = new as_joomla_helper();
	$config_urls = $jhelper->trigger_get_urls_event();

	return array(
		'login' => $config_urls['login'],
		'register' => $config_urls['reg'],
		'logout' => $config_urls['logout']
	);
}

function as_get_logged_in_member()
{
	$jhelper = new as_joomla_helper();
	$member = $jhelper->get_member();
	$config_urls = $jhelper->trigger_get_urls_event();

	if ($member && !$member->guest) {
		$access = $jhelper->trigger_access_event($member);
		$level = AS_MEMBER_LEVEL_BASIC;

		if ($access['post']) {
			$level = AS_MEMBER_LEVEL_APPROVED;
		}
		if ($access['edit']) {
			$level = AS_MEMBER_LEVEL_EDITOR;
		}
		if ($access['mod']) {
			$level = AS_MEMBER_LEVEL_MODERATOR;
		}
		if ($access['admin']) {
			$level = AS_MEMBER_LEVEL_ADMIN;
		}
		if ($access['super'] || $member->get('isRoot')) {
			$level = AS_MEMBER_LEVEL_SUPER;
		}

		$teamGroup = $jhelper->trigger_team_group_event($member);

		$as_member = array(
			'memberid' => $member->id,
			'publicusername' => $member->username,
			'email' => $member->email,
			'level' => $level,
		);

		if ($member->block) {
			$as_member['blocked'] = true;
		}

		return $as_member;
	}

	return null;
}

function as_get_member_email($memberid)
{
	$jhelper = new as_joomla_helper();
	$member = $jhelper->get_member($memberid);

	if ($member) {
		return $member->email;
	}

	return null;
}

function as_get_memberids_from_public($publicusernames)
{
	$output = array();
	if (count($publicusernames)) {
		$jhelper = new as_joomla_helper();
		foreach ($publicusernames as $username) {
			$output[$username] = $jhelper->get_memberid($username);
		}
	}
	return $output;
}

function as_get_public_from_memberids($memberids)
{
	$output = array();
	if (count($memberids)) {
		$jhelper = new as_joomla_helper();
		foreach ($memberids as $memberID) {
			$member = $jhelper->get_member($memberID);
			$output[$memberID] = $member->username;
		}
	}
	return $output;
}

function as_get_logged_in_member_html($logged_in_member, $relative_url_prefix)
{
	$publicusername = $logged_in_member['publicusername'];
	return '<a href="' . as_path_html('member/' . $publicusername) . '" class="as-member-link">' . htmlspecialchars($publicusername) . '</a>';
}

function as_get_members_html($memberids, $should_include_link, $relative_url_prefix)
{
	$memberidtopublic = as_get_public_from_memberids($memberids);
	$membershtml = array();

	foreach ($memberids as $memberid) {
		$publicusername = $memberidtopublic[$memberid];
		$membershtml[$memberid] = htmlspecialchars($publicusername);

		if ($should_include_link) {
			$membershtml[$memberid] = '<a href="' . as_path_html('member/' . $publicusername) . '" class="as-member-link">' . $membershtml[$memberid] . '</a>';
		}
	}

	return $membershtml;
}

function as_avatar_html_from_memberid($memberid, $size, $padding)
{
	$jhelper = new as_joomla_helper();
	$avatarURL = $jhelper->trigger_get_avatar_event($memberid, $size);

	$avatarHTML = $avatarURL ? "<img src='{$avatarURL}' class='as-avatar-image' alt=''/>" : '';
	if ($padding) {
		// If $padding is true, the HTML you return should render to a square of $size x $size pixels, even if the avatar is not square.
		$avatarHTML = "<span style='display:inline-block; width:{$size}px; height:{$size}px; overflow:hidden;'>{$avatarHTML}</span>";
	}
	return $avatarHTML;
}

function as_member_report_action($memberid, $action)
{
	$jhelper = new as_joomla_helper();
	$jhelper->trigger_log_event($memberid, $action);
}


/**
 * Link to Joomla app.
 */
class as_joomla_helper
{
	private $app;

	public function __construct()
	{
		$this->find_joomla_path();
		$this->load_joomla_app();
	}

	private function find_joomla_path()
	{
		// JPATH_BASE must be defined for Joomla to work
		if (!defined('JPATH_BASE')) {
			define('JPATH_BASE', AS_FINAL_JOOMLA_INTEGRATE_PATH);
		}
	}

	private function load_joomla_app()
	{
		// This will define the _JEXEC constant that will allow us to access the rest of the Joomla framework
		if (!defined('_JEXEC')) {
			define('_JEXEC', 1);
		}

		require_once(JPATH_BASE . '/includes/defines.php');
		require_once(JPATH_BASE . '/includes/framework.php');
		// Instantiate the application.
		$this->app = JFactory::getApplication('site');
		// Initialise the application.
		$this->app->initialise();
	}

	public function get_app()
	{
		return $this->app;
	}

	public function get_member($memberid = null)
	{
		return JFactory::getMember($memberid);
	}

	public function get_memberid($username)
	{
		return JMemberHelper::getMemberId($username);
	}

	public function trigger_access_event($member)
	{
		return $this->trigger_joomla_event('onQnaAccess', array($member));
	}

	public function trigger_team_group_event($member)
	{
		return $this->trigger_joomla_event('onTeamGroup', array($member));
	}

	public function trigger_get_urls_event()
	{
		return $this->trigger_joomla_event('onGetURLs', array());
	}

	public function trigger_get_avatar_event($memberid, $size)
	{
		return $this->trigger_joomla_event('onGetAvatar', array($memberid, $size));
	}

	public function trigger_log_event($memberid, $action)
	{
		return $this->trigger_joomla_event('onWriteLog', array($memberid, $action), false);
	}

	private function trigger_joomla_event($event, $args = array(), $expectResponse = true)
	{
		JPluginHelper::importPlugin('aps');
		$dispatcher = JEventDispatcher::getInstance();
		$results = $dispatcher->trigger($event, $args);

		if ($expectResponse && (!is_array($results) || count($results) < 1)) {
			// no APS plugins installed in Joomla, so we'll have to resort to defaults
			$results = $this->default_response($event, $args);
		}
		return array_pop($results);
	}

	private function default_response($event, $args)
	{
		return array(as_joomla_default_integration::$event($args));
	}
}

/**
 * Implements the same methods as a Joomla plugin would implement, but called locally within APS.
 * This is intended as a set of default actions in case no Joomla plugin has been installed. It's
 * recommended to install the Joomla QAIntegration plugin for additional member-access control.
 */
class as_joomla_default_integration
{
	/**
	 * If you're relying on the defaults, you must make sure that your Joomla instance has the following pages configured.
	 */
	public static function onGetURLs()
	{
		$login = 'index.php?option=com_members&view=login';
		$logout = 'index.php?option=com_members&twrite=member.logout&' . JSession::getFormToken() . '=1&return=' . urlencode(base64_encode('index.php'));
		$reg = 'index.php?option=com_members&view=registration';

		return array(
			// undo Joomla's escaping of characters since APS also escapes
			'login' => htmlspecialchars_decode(JRoute::_($login)),
			'logout' => htmlspecialchars_decode(JRoute::_($logout)),
			'reg' => htmlspecialchars_decode(JRoute::_($reg)),
			'denied' => htmlspecialchars_decode(JRoute::_('index.php')),
		);
	}

	/**
	 * Return the access levels available to the member. A proper Joomla plugin would allow you to fine tune this in as much
	 * detail as you needed, but this default method can only look at the core Joomla system permissions and try to map
	 * those to the APS perms. Not ideal; enough to get started, but recommend switching to the Joomla plugin if possible.
	 */
	public static function onQnaAccess(array $args)
	{
		list($member) = $args;

		return array(
			'view' => true,
			'post' => !($member->guest || $member->block),
			'edit' => $member->authorise('core.edit'),
			'mod' => $member->authorise('core.edit.state'),
			'admin' => $member->authorise('core.manage'),
			'super' => $member->authorise('core.admin') || $member->get('isRoot'),
		);
	}

	/**
	 * Return the group name (if any) that was responsible for granting the member access to the given view level.
	 * For this default method, we just won't return anything.
	 */
	public static function onTeamGroup($args)
	{
		list($member) = $args;
		return null;
	}

	/**
	 * This method would be used to write Joomla to supply an avatar for a member.
	 * For this default method, we just won't do anything.
	 */
	public static function onGetAvatar($args)
	{
		list($memberid, $size) = $args;
		return null;
	}

	/**
	 * This method would be used to notify Joomla of a APS action, eg so it could write a log entry.
	 * For this default method, we just won't do anything.
	 */
	public static function onWriteLog($args)
	{
		list($memberid, $action) = $args;
		return null;
	}
}
