<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Event module for maintaining events tables


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

class as_event_updates
{
	public function process_event($event, $memberid, $handle, $cookieid, $params)
	{
		if (@$params['silent']) // don't create updates about silent edits, and possibly other silent events in future
			return;

		require_once AS_INCLUDE_DIR . 'db/events.php';
		require_once AS_INCLUDE_DIR . 'app/events.php';

		switch ($event) {
			case 'q_post':
				if (isset($params['parent'])) // article is following an answer
					as_create_event_for_q_member($params['parent']['parentid'], $params['postid'], AS_UPDATE_FOLLOWS, $memberid, $params['parent']['memberid']);

				as_create_event_for_q_member($params['postid'], $params['postid'], null, $memberid);
				as_create_event_for_tags($params['tags'], $params['postid'], null, $memberid);
				as_create_event_for_department($params['departmentid'], $params['postid'], null, $memberid);
				break;


			case 'a_post':
				as_create_event_for_q_member($params['parentid'], $params['postid'], null, $memberid, $params['parent']['memberid']);
				break;


			case 'c_post':
				$keymemberids = array();

				foreach ($params['thread'] as $comment) // previous comments in thread (but not author of parent again)
				{
					if (isset($comment['memberid']))
						$keymemberids[$comment['memberid']] = true;
				}

				foreach ($keymemberids as $keymemberid => $dummy) {
					if ($keymemberid != $memberid)
						as_db_event_create_not_entity($keymemberid, $params['articleid'], $params['postid'], AS_UPDATE_FOLLOWS, $memberid);
				}

				switch ($params['parent']['basetype']) {
					case 'Q':
						$updatetype = AS_UPDATE_C_FOR_Q;
						break;

					case 'A':
						$updatetype = AS_UPDATE_C_FOR_A;
						break;

					default:
						$updatetype = null;
						break;
				}

				// give precedence to 'your comment followed' rather than 'your Q/A commented' if both are true
				as_create_event_for_q_member($params['articleid'], $params['postid'], $updatetype, $memberid,
					@$keymemberids[$params['parent']['memberid']] ? null : $params['parent']['memberid']);
				break;


			case 'q_edit':
				if ($params['titlechanged'] || $params['contentchanged'])
					$updatetype = AS_UPDATE_CONTENT;
				elseif ($params['tagschanged'])
					$updatetype = AS_UPDATE_TAGS;
				else
					$updatetype = null;

				if (isset($updatetype)) {
					as_create_event_for_q_member($params['postid'], $params['postid'], $updatetype, $memberid, $params['oldarticle']['memberid']);

					if ($params['tagschanged'])
						as_create_event_for_tags($params['tags'], $params['postid'], AS_UPDATE_TAGS, $memberid);
				}
				break;


			case 'a_select':
				as_create_event_for_q_member($params['parentid'], $params['postid'], AS_UPDATE_SELECTED, $memberid, $params['answer']['memberid']);
				break;


			case 'q_reopen':
			case 'q_close':
				as_create_event_for_q_member($params['postid'], $params['postid'], AS_UPDATE_CLOSED, $memberid, $params['oldarticle']['memberid']);
				break;


			case 'q_hide':
				if (isset($params['oldarticle']['memberid']))
					as_db_event_create_not_entity($params['oldarticle']['memberid'], $params['postid'], $params['postid'], AS_UPDATE_VISIBLE, $memberid);
				break;


			case 'q_reshow':
				as_create_event_for_q_member($params['postid'], $params['postid'], AS_UPDATE_VISIBLE, $memberid, $params['oldarticle']['memberid']);
				break;


			case 'q_move':
				as_create_event_for_q_member($params['postid'], $params['postid'], AS_UPDATE_DEPARTMENT, $memberid, $params['oldarticle']['memberid']);
				as_create_event_for_department($params['departmentid'], $params['postid'], AS_UPDATE_DEPARTMENT, $memberid);
				break;


			case 'a_edit':
				if ($params['contentchanged'])
					as_create_event_for_q_member($params['parentid'], $params['postid'], AS_UPDATE_CONTENT, $memberid, $params['oldanswer']['memberid']);
				break;


			case 'a_hide':
				if (isset($params['oldanswer']['memberid']))
					as_db_event_create_not_entity($params['oldanswer']['memberid'], $params['parentid'], $params['postid'], AS_UPDATE_VISIBLE, $memberid);
				break;


			case 'a_reshow':
				as_create_event_for_q_member($params['parentid'], $params['postid'], AS_UPDATE_VISIBLE, $memberid, $params['oldanswer']['memberid']);
				break;


			case 'c_edit':
				if ($params['contentchanged'])
					as_create_event_for_q_member($params['articleid'], $params['postid'], AS_UPDATE_CONTENT, $memberid, $params['oldcomment']['memberid']);
				break;


			case 'a_to_c':
				if ($params['contentchanged'])
					as_create_event_for_q_member($params['articleid'], $params['postid'], AS_UPDATE_CONTENT, $memberid, $params['oldanswer']['memberid']);
				else
					as_create_event_for_q_member($params['articleid'], $params['postid'], AS_UPDATE_TYPE, $memberid, $params['oldanswer']['memberid']);
				break;


			case 'c_hide':
				if (isset($params['oldcomment']['memberid']))
					as_db_event_create_not_entity($params['oldcomment']['memberid'], $params['articleid'], $params['postid'], AS_UPDATE_VISIBLE, $memberid);
				break;


			case 'c_reshow':
				as_create_event_for_q_member($params['articleid'], $params['postid'], AS_UPDATE_VISIBLE, $memberid, $params['oldcomment']['memberid']);
				break;
		}
	}
}
