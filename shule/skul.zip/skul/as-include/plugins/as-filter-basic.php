<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Basic module for validating form inputs


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

require_once AS_INCLUDE_DIR.'db/maxima.php';
require_once AS_INCLUDE_DIR.'util/string.php';

class as_filter_basic
{
	
	public function filter_email(&$email, $oldmember)
	{
		if (!strlen($email)) {
			return as_lang('members/email_required');
		}
		if (!as_email_validate($email)) {
			return as_lang('members/email_invalid');
		}
		if (as_strlen($email) > AS_DB_MAX_EMAIL_LENGTH) {
			return as_lang_sub('main/max_length_x', AS_DB_MAX_EMAIL_LENGTH);
		}
	}

	public function filter_handle(&$handle, $oldmember)
	{
		if (!strlen($handle)) {
			return as_lang('members/handle_empty');
		}
		if (in_array($handle, array('.', '..'))) {
			return as_lang_sub('members/handle_has_bad', '. ..');
		}
		if (preg_match('/[\\@\\+\\/]/', $handle)) {
			return as_lang_sub('members/handle_has_bad', '@ + /');
		}
		if (as_strlen($handle) > AS_DB_MAX_HANDLE_LENGTH) {
			return as_lang_sub('main/max_length_x', AS_DB_MAX_HANDLE_LENGTH);
		}
		// check for banned usernames (e.g. "anonymous")
		$wordspreg = as_block_words_to_preg(as_opt('block_bad_usernames'));
		$blocked = as_block_words_match_all($handle, $wordspreg);
		if (!empty($blocked)) {
			return as_lang('members/handle_blocked');
		}
	}

	public function filter_timetable(&$timetable, &$errors, $oldtimetable)
	{
		if ($oldtimetable === null) {
			// a new post requires these fields be set
			$timetable['title'] = isset($timetable['title']) ? $timetable['title'] : '';
			$timetable['duration'] = isset($timetable['duration']) ? $timetable['duration'] : '';
			$timetable['slots'] = isset($timetable['slots']) ? $timetable['slots'] : array();
		}

		$qminlength = as_opt('min_len_q_title');
		$qmaxlength = max($qminlength, min(as_opt('max_len_q_title'), AS_DB_MAX_TITLE_LENGTH));
		$this->validate_field_length($errors, $timetable, 'title', $qminlength, $qmaxlength);
		$this->validate_field_length($errors, $timetable, 'duration', 20, 120, null, true, 
		' ' . as_lang_html('options/minutes_suffix'));
					
		if (isset($timetable['slots'])) {
			$countslots = count($timetable['slots']);
			$maxslots = 20;
			$minslots = min(5, $maxslots);

			if ($countslots < $minslots) {
				$errors['slots'] = as_lang_sub('article/min_slots_x', $minslots);
			} elseif ($countslots > $maxslots) {
				$errors['slots'] = as_lang_sub('article/max_slots_x', $maxslots);
			} 
		}

		$this->validate_post_email($errors, $timetable);
	}
	
	public function filter_article(&$article, &$errors, $oldarticle)
	{
		if ($oldarticle === null) {
			// a new post requires these fields be set
			$article['title'] = isset($article['title']) ? $article['title'] : '';
			$article['content'] = isset($article['content']) ? $article['content'] : '';
			$article['text'] = isset($article['text']) ? $article['text'] : '';
			$article['tags'] = isset($article['tags']) ? $article['tags'] : array();
		}

		$qminlength = as_opt('min_len_q_title');
		$qmaxlength = max($qminlength, min(as_opt('max_len_q_title'), AS_DB_MAX_TITLE_LENGTH));
		$this->validate_field_length($errors, $article, 'title', $qminlength, $qmaxlength);

		$this->validate_field_length($errors, $article, 'content', 0, AS_DB_MAX_CONTENT_LENGTH); // for storage
		$this->validate_field_length($errors, $article, 'text', as_opt('min_len_q_content'), null); // for display
		// ensure content error is shown
		if (isset($errors['text'])) {
			$errors['content'] = $errors['text'];
		}

		if (isset($article['tags'])) {
			$counttags = count($article['tags']);
			$maxtags = as_opt('max_num_q_tags');
			$mintags = min(as_opt('min_num_q_tags'), $maxtags);

			if ($counttags < $mintags) {
				$errors['tags'] = as_lang_sub('article/min_tags_x', $mintags);
			} elseif ($counttags > $maxtags) {
				$errors['tags'] = as_lang_sub('article/max_tags_x', $maxtags);
			} else {
				$tagstring = as_tags_to_tagstring($article['tags']);
				if (as_strlen($tagstring) > AS_DB_MAX_TAGS_LENGTH) { // for storage
					$errors['tags'] = as_lang_sub('main/max_length_x', AS_DB_MAX_TAGS_LENGTH);
				}
			}
		}

		$this->validate_post_email($errors, $article);
	}

	public function filter_answer(&$answer, &$errors, $article, $oldanswer)
	{
		$this->validate_field_length($errors, $answer, 'content', 0, AS_DB_MAX_CONTENT_LENGTH); // for storage
		$this->validate_field_length($errors, $answer, 'text', as_opt('min_len_a_content'), null, 'content'); // for display
		$this->validate_post_email($errors, $answer);
	}

	public function filter_comment(&$comment, &$errors, $article, $parent, $oldcomment)
	{
		$this->validate_field_length($errors, $comment, 'content', 0, AS_DB_MAX_CONTENT_LENGTH); // for storage
		$this->validate_field_length($errors, $comment, 'text', as_opt('min_len_c_content'), null, 'content'); // for display
		$this->validate_post_email($errors, $comment);
	}

	public function filter_profile(&$profile, &$errors, $member, $oldprofile)
	{
		foreach (array_keys($profile) as $field) {
			// ensure fields are not NULL
			$profile[$field] = (string)$profile[$field];
			$this->validate_field_length($errors, $profile, $field, 0, AS_DB_MAX_CONTENT_LENGTH);
		}
	}


	// The definitions below are not part of a standard filter module, but just used within this one

	/**
	 * Add textual element $field to $errors if length of $input is not between $minlength and $maxlength.
	 *
	 * @deprecated This function is no longer used and will removed in the future.
	 */
	public function validate_length(&$errors, $field, $input, $minlength, $maxlength)
	{
		$length = isset($input) ? as_strlen($input) : 0;

		if ($length < $minlength)
			$errors[$field] = ($minlength == 1) ? as_lang('main/field_required') : as_lang_sub('main/min_length_x', $minlength);
		elseif (isset($maxlength) && ($length > $maxlength))
			$errors[$field] = as_lang_sub('main/max_length_x', $maxlength);
	}

	/**
	 * Check that a field meets the length requirements. If we're editing the post we can ignore missing fields.
	 *
	 * @param array $errors Array of errors, with keys matching $post
	 * @param array $post The post containing the field we want to validate
	 * @param string $key The element of $post to validate
	 * @param int $minlength
	 * @param int $maxlength
	 */
	private function validate_field_length(&$errors, &$post, $key, $minlength, $maxlength, $errorKey = null, $isnumeric = false, $itemstr = '')
	{
		if (!$errorKey) {
			$errorKey = $key;
		}

		// skip the field if key not set (for example, 'title' when recategorizing articles)
		if (array_key_exists($key, $post)) {
			if ($isnumeric) {
				$number = (int)$post[$key];
				if ($number < $minlength) {
					$errors[$errorKey] = $minlength == 1 ? as_lang('main/field_required') . $itemstr : as_lang_sub('main/min_number_x', $minlength) . $itemstr;
				} elseif (isset($maxlength) && ($number > $maxlength)) {
					$errors[$errorKey] = as_lang_sub('main/max_number_x', $maxlength) . $itemstr;
				}
			} else {
				$length = as_strlen($post[$key]);
				if ($length < $minlength) {
					$errors[$errorKey] = $minlength == 1 ? as_lang('main/field_required') : as_lang_sub('main/min_length_x', $minlength);
				} elseif (isset($maxlength) && ($length > $maxlength)) {
					$errors[$errorKey] = as_lang_sub('main/max_length_x', $maxlength);
				}
			}
		}
	}
	
	/**
	 * Wrapper function for validating a post's email address.
	 *
	 * @deprecated This function will become private in APS 1.8. It is specific to this plugin and
	 * should not be used by outside code.
	 */
	public function validate_post_email(&$errors, $post)
	{
		if (@$post['notify'] && strlen(@$post['email'])) {
			$error = $this->filter_email($post['email'], null);
			if (isset($error)) {
				$errors['email'] = $error;
			}
		}
	}
}
