<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Widget module class for write a article box


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

class as_write_box
{
	public function allow_template($template)
	{
		$allowed = array(
			'activity', 'departments', 'custom', 'feedback', 'as', 'articles',
			'hot', 'search', 'tag', 'tags', 'unanswered',
		);
		return in_array($template, $allowed);
	}

	public function allow_region($region)
	{
		return in_array($region, array('main', 'side', 'full'));
	}

	public function output_widget($region, $place, $themeobject, $template, $request, $as_content)
	{
		if (isset($as_content['departmentids']))
			$params = array('cat' => end($as_content['departmentids']));
		else
			$params = null;

?>
<div class="as-write-box">
	<form method="post" action="<?php echo as_path_html('write', $params); ?>">
		<table class="as-form-tall-table" style="width:100%">
			<tr style="vertical-align:middle;">
				<td class="as-form-tall-label" style="width: 1px; padding:8px; white-space:nowrap; <?php echo ($region=='side') ? 'padding-bottom:0;' : 'text-align:right;'?>">
					<?php echo strtr(as_lang_html('article/write_title'), array(' ' => '&nbsp;'))?>:
				</td>
<?php if ($region=='side') : ?>
			</tr>
			<tr>
<?php endif; ?>
				<td class="as-form-tall-data" style="padding:8px;">
					<input name="title" type="text" class="as-form-tall-text" style="width:95%;">
				</td>
			</tr>
		</table>
		<input type="hidden" name="dowrite1" value="1">
	</form>
</div>
<?php
	}
}
