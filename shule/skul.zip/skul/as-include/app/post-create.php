<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Creating articles, answers and comments (application level)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/maxima.php';
require_once AS_INCLUDE_DIR . 'db/post-create.php';
require_once AS_INCLUDE_DIR . 'db/points.php';
require_once AS_INCLUDE_DIR . 'db/hotness.php';
require_once AS_INCLUDE_DIR . 'util/string.php';


/**
 * Return value to store in database combining $notify and $email values entered by member $memberid (or null for anonymous)
 * @param $memberid
 * @param $notify
 * @param $email
 * @return null|string
 */
function as_combine_notify_email($memberid, $notify, $email)
{
	return $notify ? (empty($email) ? (isset($memberid) ? '@' : null) : $email) : null;
}


/**
 * Add a article (application level) - create record, update appropriate counts, index it, send notifications.
 * If article is follow-on from an answer, $followanswer should contain answer database record, otherwise null.
 * See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $followanswer
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $title
 * @param $content
 * @param $format
 * @param $text
 * @param $tagstring
 * @param $notify
 * @param $email
 * @param $departmentid
 * @param $extravalue
 * @param bool $queued
 * @param $name
 * @return mixed
 */
function as_article_create($followanswer, $memberid, $handle, $cookieid, $title, $content, $format, $text, $tagstring, $notify, $email,
	$departmentid = null, $extravalue = null, $queued = false, $name = null)
{
	require_once AS_INCLUDE_DIR . 'db/selects.php';

	$postid = as_db_post_create($queued ? 'Q_QUEUED' : 'Q', @$followanswer['postid'], $memberid, isset($memberid) ? null : $cookieid,
		as_remote_ip_address(), $title, $content, $format, $tagstring, as_combine_notify_email($memberid, $notify, $email),
		$departmentid, isset($memberid) ? null : $name);

	if (isset($extravalue)) {
		require_once AS_INCLUDE_DIR . 'db/metas.php';
		as_db_postmeta_set($postid, 'as_q_extra', $extravalue);
	}

	as_db_posts_calc_department_path($postid);
	as_db_hotness_update($postid);

	if ($queued) {
		as_db_queuedcount_update();

	} else {
		as_post_index($postid, 'Q', $postid, @$followanswer['postid'], $title, $content, $format, $text, $tagstring, $departmentid);
		as_update_counts_for_q($postid);
		as_db_points_update_ifmember($memberid, 'qposts');
	}

	as_report_event($queued ? 'q_queue' : 'q_post', $memberid, $handle, $cookieid, array(
		'postid' => $postid,
		'parentid' => @$followanswer['postid'],
		'parent' => $followanswer,
		'title' => $title,
		'content' => $content,
		'format' => $format,
		'text' => $text,
		'tags' => $tagstring,
		'departmentid' => $departmentid,
		'fullname' => as_get_member_name($handle),
		'extra' => $extravalue,
		'name' => $name,
		'notify' => $notify,
		'email' => $email,
	));

	return $postid;
}


/**
 * Perform various common cached count updating operations to reflect changes in the article whose id is $postid
 * @param $postid
 */
function as_update_counts_for_q($postid)
{
	if (isset($postid)) // post might no longer exist
		as_db_department_path_qcount_update(as_db_post_get_department_path($postid));

	as_db_qcount_update();
	as_db_unaqcount_update();
	as_db_unselqcount_update();
	as_db_unupaqcount_update();
}

function as_timetable_create($memberid, $handle, $email, $cookieid, $title, $content, $lessons, $duration, $slots, $extravalue = null)
{
	require_once AS_INCLUDE_DIR . 'db/selects.php';
	$timetableid = as_db_timetable_create('1', $memberid, isset($memberid) ? null : $cookieid,
		as_remote_ip_address(), $title, $content, $lessons, $duration, $slots, isset($extravalue) ? null : $extravalue);
	/*
	if (isset($extravalue)) {
		require_once AS_INCLUDE_DIR . 'db/metas.php';
		as_db_postmeta_set($postid, 'as_q_extra', $extravalue);
	}*/

	/*as_db_posts_calc_department_path($postid);
	as_db_hotness_update($postid);

	if ($queued) {
		as_db_queuedcount_update();

	} else {
		as_post_index($postid, 'Q', $postid, @$followanswer['postid'], $title, $content, $format, $text, $tagstring, $departmentid);
		as_update_counts_for_q($postid);
		as_db_points_update_ifmember($memberid, 'qposts');
	}*/

	as_report_event('t_draft', $memberid, $handle, $cookieid, array(
		'timetableid' => $timetableid,
		'title' => $title,
		'content' => $content,
		'fullname' => as_get_member_name($handle),
		'email' => $email,
	));

	return $timetableid;
}

function as_examination_create($memberid, $handle, $email, $cookieid, $title, $code, $content, $testfrom, $testto)
{
	require_once AS_INCLUDE_DIR . 'db/selects.php';
	$examinationid = as_db_examination_create($title, $code, $content, $memberid, $testfrom, $testto, '0');
	
	as_report_event('exam_on', $memberid, $handle, $cookieid, array(
		'examinationid' => $examinationid,
		'title' => $title,
		'content' => $content,
		'fullname' => as_get_member_name($handle),
		'email' => $email,
	));

	return $examinationid;
}

function as_paper_create($memberid, $handle, $email, $cookieid, $exam, $class, $unit, $type, $title, $scount, $duration, $papers)
{
	require_once AS_INCLUDE_DIR . 'db/selects.php';
	require_once AS_INCLUDE_DIR . 'db/post-update.php';
	$paperid = as_db_paper_create($exam, $class, $unit, $memberid, $type, $title, $scount, $duration);
	
	as_db_papers_update_count($exam, $papers);

	as_report_event('n_paper', $memberid, $handle, $cookieid, array(
		'examinationid' => $paperid,
		'parent' => $paperid,
		'title' => $title,
		'fullname' => as_get_member_name($handle),
		'email' => $email,
	));

	return $paperid;
}

function as_question_create($memberid, $handle, $email, $cookieid, $paperid, $question, $format, $text, $answera, $answerb, $answerc, $answerd, $marks, $answer, $qcount)
{
	require_once AS_INCLUDE_DIR . 'db/post-update.php';
	$quizid = as_db_question_create($memberid, $cookieid, as_remote_ip_address(), $paperid, $question, $format, $answera, $answerb, $answerc, $answerd, $marks, $answer);
	
	as_db_quiz_update_count($paperid, $qcount);

	as_report_event('quez', $memberid, $handle, $cookieid, array(
		'quizid' => $quizid,
		'question' => $question,
		'format' => $format,
		'text' => $text,
		'paperid' => $paperid,
		'fullname' => as_get_member_name($handle),
		'email' => $email,
	));

	return $quizid;
}

/**
 * Return an array containing the elements of $inarray whose key is in $keys
 * @param $inarray
 * @param $keys
 * @return array
 */
function as_array_filter_by_keys($inarray, $keys)
{
	$outarray = array();

	foreach ($keys as $key) {
		if (isset($inarray[$key]))
			$outarray[$key] = $inarray[$key];
	}

	return $outarray;
}


/**
 * Suspend the indexing (and unindexing) of posts via as_post_index(...) and as_post_unindex(...)
 * if $suspend is true, otherwise reinstate it. A counter is kept to allow multiple calls.
 * @param bool $suspend
 */
function as_suspend_post_indexing($suspend = true)
{
	global $as_post_indexing_suspended;

	$as_post_indexing_suspended += ($suspend ? 1 : -1);
}


/**
 * Add post $postid (which comes under $articleid) of $type (Q/A/C) to the database index, with $title, $text,
 * $tagstring and $departmentid. Calls through to all installed search modules.
 * @param $postid
 * @param $type
 * @param $articleid
 * @param $parentid
 * @param $title
 * @param $content
 * @param $format
 * @param $text
 * @param $tagstring
 * @param $departmentid
 */
function as_post_index($postid, $type, $articleid, $parentid, $title, $content, $format, $text, $tagstring, $departmentid)
{
	global $as_post_indexing_suspended;

	if ($as_post_indexing_suspended > 0)
		return;

	// Send through to any search modules for indexing

	$searches = as_load_modules_with('search', 'index_post');
	foreach ($searches as $search)
		$search->index_post($postid, $type, $articleid, $parentid, $title, $content, $format, $text, $tagstring, $departmentid);
}


/**
 * Add an answer (application level) - create record, update appropriate counts, index it, send notifications.
 * $article should contain database record for the article this is an answer to.
 * See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $content
 * @param $format
 * @param $text
 * @param $notify
 * @param $email
 * @param $article
 * @param bool $queued
 * @param $name
 * @return mixed
 */
function as_answer_create($memberid, $handle, $cookieid, $content, $format, $text, $notify, $email, $article, $queued = false, $name = null)
{
	$postid = as_db_post_create($queued ? 'A_QUEUED' : 'A', $article['postid'], $memberid, isset($memberid) ? null : $cookieid,
		as_remote_ip_address(), null, $content, $format, null, as_combine_notify_email($memberid, $notify, $email),
		$article['departmentid'], isset($memberid) ? null : $name);

	as_db_posts_calc_department_path($postid);

	if ($queued) {
		as_db_queuedcount_update();

	} else {
		if ($article['type'] == 'Q') // don't index answer if parent article is hidden or queued
			as_post_index($postid, 'A', $article['postid'], $article['postid'], null, $content, $format, $text, null, $article['departmentid']);

		as_update_q_counts_for_a($article['postid']);
		as_db_points_update_ifmember($memberid, 'aposts');
	}

	as_report_event($queued ? 'a_queue' : 'a_post', $memberid, $handle, $cookieid, array(
		'postid' => $postid,
		'parentid' => $article['postid'],
		'parent' => $article,
		'content' => $content,
		'format' => $format,
		'text' => $text,
		'departmentid' => $article['departmentid'],
		'fullname' => as_get_member_name($handle),
		'name' => $name,
		'notify' => $notify,
		'email' => $email,
	));

	return $postid;
}


/**
 * Perform various common cached count updating operations to reflect changes in an answer of article $articleid
 * @param $articleid
 */
function as_update_q_counts_for_a($articleid)
{
	as_db_post_acount_update($articleid);
	as_db_hotness_update($articleid);
	as_db_acount_update();
	as_db_unaqcount_update();
	as_db_unupaqcount_update();
}


/**
 * Add a comment (application level) - create record, update appropriate counts, index it, send notifications.
 * $article should contain database record for the article this is part of (as direct or comment on Q's answer).
 * If this is a comment on an answer, $answer should contain database record for the answer, otherwise null.
 * $commentsfollows should contain database records for all previous comments on the same article or answer,
 * but it can also contain other records that are ignored.
 * See /as-include/app/posts.php for a higher-level function which is easier to use.
 * @param $memberid
 * @param $handle
 * @param $cookieid
 * @param $content
 * @param $format
 * @param $text
 * @param $notify
 * @param $email
 * @param $article
 * @param $parent
 * @param $commentsfollows
 * @param bool $queued
 * @param $name
 * @return mixed
 */
function as_comment_create($memberid, $handle, $cookieid, $content, $format, $text, $notify, $email, $article, $parent, $commentsfollows, $queued = false, $name = null)
{
	require_once AS_INCLUDE_DIR . 'app/emails.php';
	require_once AS_INCLUDE_DIR . 'app/options.php';
	require_once AS_INCLUDE_DIR . 'app/format.php';
	require_once AS_INCLUDE_DIR . 'util/string.php';

	if (!isset($parent))
		$parent = $article; // for backwards compatibility with old answer parameter

	$postid = as_db_post_create($queued ? 'C_QUEUED' : 'C', $parent['postid'], $memberid, isset($memberid) ? null : $cookieid,
		as_remote_ip_address(), null, $content, $format, null, as_combine_notify_email($memberid, $notify, $email),
		$article['departmentid'], isset($memberid) ? null : $name);

	as_db_posts_calc_department_path($postid);

	if ($queued) {
		as_db_queuedcount_update();

	} else {
		if ($article['type'] == 'Q' && ($parent['type'] == 'Q' || $parent['type'] == 'A')) { // only index if antecedents fully visible
			as_post_index($postid, 'C', $article['postid'], $parent['postid'], null, $content, $format, $text, null, $article['departmentid']);
		}

		as_db_points_update_ifmember($memberid, 'cposts');
		as_db_ccount_update();
	}

	$thread = array();

	foreach ($commentsfollows as $comment) {
		if ($comment['type'] == 'C' && $comment['parentid'] == $parent['postid']) // find just those for this parent, fully visible
			$thread[] = $comment;
	}

	as_report_event($queued ? 'c_queue' : 'c_post', $memberid, $handle, $cookieid, array(
		'postid' => $postid,
		'parentid' => $parent['postid'],
		'parenttype' => $parent['basetype'],
		'parent' => $parent,
		'articleid' => $article['postid'],
		'article' => $article,
		'thread' => $thread,
		'content' => $content,
		'format' => $format,
		'text' => $text,
		'departmentid' => $article['departmentid'],
		'fullname' => as_get_member_name($handle),
		'name' => $name,
		'notify' => $notify,
		'email' => $email,
	));

	return $postid;
}
