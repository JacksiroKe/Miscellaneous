<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Controller for most article listing pages, plus custom pages and plugin pages


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


/**
 * Returns the $as_content structure for a article list page showing $articles retrieved from the
 * database. If $pagesize is not null, it sets the max number of articles to display. If $count is
 * not null, pagination is determined by $start and $count. The page title is $sometitle unless
 * there are no articles shown, in which case it's $nonetitle. $navdepartments should contain the
 * departments retrived from the database using as_db_department_nav_selectspec(...) for $departmentid,
 * which is the current department shown. If $departmentpathprefix is set, department navigation will be
 * shown, with per-department article counts if $departmentqcount is true. The nav links will have the
 * prefix $departmentpathprefix and possible extra $departmentparams. If $feedpathprefix is set, the
 * page has an RSS feed whose URL uses that prefix. If there are no links to other pages, $suggest
 * is used to suggest what the member should do. The $pagelinkparams are passed through to
 * as_html_page_links(...) which creates links for page 2, 3, etc..
 * @param $articles
 * @param $pagesize
 * @param $start
 * @param $count
 * @param $sometitle
 * @param $nonetitle
 * @param $navdepartments
 * @param $departmentid
 * @param $departmentqcount
 * @param $departmentpathprefix
 * @param $feedpathprefix
 * @param $suggest
 * @param $pagelinkparams
 * @param $departmentparams
 * @param $dummy
 * @return array
 */
function as_q_list_page_content($articles, $pagesize, $start, $count, $sometitle, $nonetitle,
	$navdepartments, $departmentid, $departmentqcount, $departmentpathprefix, $feedpathprefix, $suggest,
	$pagelinkparams = null, $departmentparams = null, $dummy = null)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'app/format.php';
	require_once AS_INCLUDE_DIR . 'app/updates.php';

	$memberid = as_get_logged_in_memberid();


	// Chop down to size, get member information for display

	if (isset($pagesize)) {
		$articles = array_slice($articles, 0, $pagesize);
	}

	$membershtml = as_memberids_handles_html(as_any_get_memberids_handles($articles));


	// Prepare content for theme

	$as_content = as_content_prepare(true, array_keys(as_department_path($navdepartments, $departmentid)));

	$as_content['q_list']['form'] = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',

		'hidden' => array(
			'code' => as_get_form_security_code('vote'),
		),
	);

	$as_content['q_list']['qs'] = array();

	if (count($articles)) {
		$as_content['title'] = $sometitle;

		$defaults = as_post_html_defaults('Q');
		if (isset($departmentpathprefix)) {
			$defaults['departmentpathprefix'] = $departmentpathprefix;
		}

		foreach ($articles as $article) {
			$fields = as_any_to_q_html_fields($article, $memberid, as_cookie_get(), $membershtml, null, as_post_html_options($article, $defaults));

			if (!empty($fields['raw']['closedbyid'])) {
				$fields['closed'] = array(
					'state' => as_lang_html('main/closed'),
				);
			}

			$as_content['q_list']['qs'][] = $fields;
		}
	} else {
		$as_content['title'] = $nonetitle;
	}

	if (isset($memberid) && isset($departmentid)) {
		$favoritemap = as_get_favorite_non_qs_map();
		$departmentisfavorite = @$favoritemap['department'][$navdepartments[$departmentid]['backpath']];

		$as_content['favorite'] = as_favorite_form(AS_ENTITY_DEPARTMENT, $departmentid, $departmentisfavorite,
			as_lang_sub($departmentisfavorite ? 'main/remove_x_favorites' : 'main/add_department_x_favorites', $navdepartments[$departmentid]['title']));
	}

	if (isset($count) && isset($pagesize)) {
		$as_content['page_links'] = as_html_page_links(as_request(), $start, $pagesize, $count, as_opt('pages_prev_next'), $pagelinkparams);
	}

	$as_content['canonical'] = as_get_canonical();

	if (empty($as_content['page_links'])) {
		$as_content['suggest_next'] = $suggest;
	}

	if (as_using_departments() && count($navdepartments) && isset($departmentpathprefix)) {
		$as_content['navigation']['cat'] = as_department_navigation($navdepartments, $departmentid, $departmentpathprefix, $departmentqcount, $departmentparams);
	}

	// set meta description on department pages
	if (!empty($navdepartments[$departmentid]['content'])) {
		$as_content['description'] = as_html($navdepartments[$departmentid]['content']);
	}

	if (isset($feedpathprefix) && (as_opt('feed_per_department') || !isset($departmentid))) {
		$as_content['feed'] = array(
			'url' => as_path_html(as_feed_request($feedpathprefix . (isset($departmentid) ? ('/' . as_department_path_request($navdepartments, $departmentid)) : ''))),
			'label' => strip_tags($sometitle),
		);
	}

	return $as_content;
}


/**
 * Return the sub navigation structure common to article listing pages
 * @param $sort
 * @param $departmentslugs
 * @return array
 */
function as_qs_sub_navigation($sort, $departmentslugs)
{
	$request = 'articles';

	if (isset($departmentslugs)) {
		foreach ($departmentslugs as $slug) {
			$request .= '/' . $slug;
		}
	}

	$navigation = array(
		'recent' => array(
			'label' => as_lang('main/nav_most_recent'),
			'url' => as_path_html($request),
		),

		'hot' => array(
			'label' => as_lang('main/nav_hot'),
			'url' => as_path_html($request, array('sort' => 'hot')),
		),

		'votes' => array(
			'label' => as_lang('main/nav_most_votes'),
			'url' => as_path_html($request, array('sort' => 'votes')),
		),

		'answers' => array(
			'label' => as_lang('main/nav_most_answers'),
			'url' => as_path_html($request, array('sort' => 'answers')),
		),

		'views' => array(
			'label' => as_lang('main/nav_most_views'),
			'url' => as_path_html($request, array('sort' => 'views')),
		),
	);

	if (isset($navigation[$sort])) {
		$navigation[$sort]['selected'] = true;
	} else {
		$navigation['recent']['selected'] = true;
	}

	if (!as_opt('do_count_q_views')) {
		unset($navigation['views']);
	}

	return $navigation;
}


/**
 * Return the sub navigation structure common to unanswered pages
 * @param $by
 * @param $departmentslugs
 * @return array
 */
function as_unanswered_sub_navigation($by, $departmentslugs)
{
	$request = 'unanswered';

	if (isset($departmentslugs)) {
		foreach ($departmentslugs as $slug) {
			$request .= '/' . $slug;
		}
	}

	$navigation = array(
		'by-answers' => array(
			'label' => as_lang('main/nav_no_answer'),
			'url' => as_path_html($request),
		),

		'by-selected' => array(
			'label' => as_lang('main/nav_no_selected_answer'),
			'url' => as_path_html($request, array('by' => 'selected')),
		),

		'by-upvotes' => array(
			'label' => as_lang('main/nav_no_upvoted_answer'),
			'url' => as_path_html($request, array('by' => 'upvotes')),
		),
	);

	if (isset($navigation['by-' . $by])) {
		$navigation['by-' . $by]['selected'] = true;
	} else {
		$navigation['by-answers']['selected'] = true;
	}

	if (!as_opt('voting_on_as')) {
		unset($navigation['by-upvotes']);
	}

	return $navigation;
}
