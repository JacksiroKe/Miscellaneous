<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Definitions relating to favorites and updates in the database tables


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


// Character codes for the different types of entity that can be followed (entitytype columns)

define('AS_ENTITY_ARTICLE', 'Q');
define('AS_ENTITY_MEMBER', 'U');
define('AS_ENTITY_TAG', 'T');
define('AS_ENTITY_DEPARTMENT', 'C');
define('AS_ENTITY_NONE', '-');


// Character codes for the different types of updates on a post (updatetype columns)

define('AS_UPDATE_DEPARTMENT', 'A'); // articles only, department changed
define('AS_UPDATE_CLOSED', 'C'); // articles only, closed or reopened
define('AS_UPDATE_CONTENT', 'E'); // title or content edited
define('AS_UPDATE_PARENT', 'M'); // e.g. comment moved when converting its parent answer to a comment
define('AS_UPDATE_SELECTED', 'S'); // answers only, removed if unselected
define('AS_UPDATE_TAGS', 'T'); // articles only
define('AS_UPDATE_TYPE', 'Y'); // e.g. answer to comment
define('AS_UPDATE_VISIBLE', 'H'); // hidden or reshown


// Character codes for types of update that only appear in the streams tables, not on the posts themselves

define('AS_UPDATE_FOLLOWS', 'F'); // if a new article was published related to one of its answers, or for a comment that follows another
define('AS_UPDATE_C_FOR_Q', 'U'); // if comment created was on a article of the member whose stream this appears in
define('AS_UPDATE_C_FOR_A', 'N'); // if comment created was on an answer of the member whose stream this appears in
