<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Member management (application level) for basic member operations


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

define('AS_MEMBER_LEVEL_BASIC', 0);
define('AS_MEMBER_LEVEL_APPROVED', 10);
define('AS_MEMBER_LEVEL_WRITER', 20);
define('AS_MEMBER_LEVEL_EDITOR', 50);
define('AS_MEMBER_LEVEL_MODERATOR', 80);
define('AS_MEMBER_LEVEL_ADMIN', 100);
define('AS_MEMBER_LEVEL_SUPER', 120);

define('AS_MEMBER_FLAGS_EMAIL_CONFIRMED', 1);
define('AS_MEMBER_FLAGS_MEMBER_BLOCKED', 2);
define('AS_MEMBER_FLAGS_SHOW_AVATAR', 4);
define('AS_MEMBER_FLAGS_SHOW_GRAVATAR', 8);
define('AS_MEMBER_FLAGS_NO_MESSAGES', 16);
define('AS_MEMBER_FLAGS_NO_MAILINGS', 32);
define('AS_MEMBER_FLAGS_WELCOME_NOTICE', 64);
define('AS_MEMBER_FLAGS_MUST_CONFIRM', 128);
define('AS_MEMBER_FLAGS_NO_WALL_POSTS', 256);
define('AS_MEMBER_FLAGS_MUST_APPROVE', 512); // @deprecated

define('AS_FIELD_FLAGS_MULTI_LINE', 1);
define('AS_FIELD_FLAGS_LINK_URL', 2);
define('AS_FIELD_FLAGS_ON_REGISTER', 4);

if (!defined('AS_FORM_EXPIRY_SECS')) {
	// how many seconds a form is valid for submission
	define('AS_FORM_EXPIRY_SECS', 86400);
}
if (!defined('AS_FORM_KEY_LENGTH')) {
	define('AS_FORM_KEY_LENGTH', 32);
}


if (AS_FINAL_EXTERNAL_MEMBERS) {
	// If we're using single sign-on integration (WordPress or otherwise), load PHP file for that

	if (defined('AS_FINAL_WORDPRESS_INTEGRATE_PATH')) {
		require_once AS_INCLUDE_DIR . 'util/external-members-wp.php';
	} elseif (defined('AS_FINAL_JOOMLA_INTEGRATE_PATH')) {
		require_once AS_INCLUDE_DIR . 'util/external-members-joomla.php';
	} else {
		require_once AS_EXTERNAL_DIR . 'as-external-members.php';
	}

	// Access functions for member information

	/**
	 * Return array of information about the currently logged in member, cache to ensure only one call to external code
	 */
	function as_get_logged_in_member_cache()
	{
		global $as_cached_logged_in_member;

		if (!isset($as_cached_logged_in_member)) {
			$member = as_get_logged_in_member();

			if (isset($member)) {
				$member['flags'] = isset($member['blocked']) ? AS_MEMBER_FLAGS_MEMBER_BLOCKED : 0;
				$as_cached_logged_in_member = $member;
			} else
				$as_cached_logged_in_member = false;
		}

		return @$as_cached_logged_in_member;
	}


	/**
	 * Return $field of the currently logged in member, or null if not available
	 * @param $field
	 * @return null
	 */
	function as_get_logged_in_member_field($field)
	{
		$member = as_get_logged_in_member_cache();

		return isset($member[$field]) ? $member[$field] : null;
	}


	/**
	 * Return the memberid of the currently logged in member, or null if none
	 */
	function as_get_logged_in_memberid()
	{
		return as_get_logged_in_member_field('memberid');
	}


	/**
	 * Return the number of points of the currently logged in member, or null if none is logged in
	 */
	function as_get_logged_in_points()
	{
		global $as_cached_logged_in_points;

		if (!isset($as_cached_logged_in_points)) {
			require_once AS_INCLUDE_DIR . 'db/selects.php';

			$as_cached_logged_in_points = as_db_select_with_pending(as_db_member_points_selectspec(as_get_logged_in_memberid(), true));
		}

		return $as_cached_logged_in_points['points'];
	}


	/**
	 * Return HTML to display for the avatar of $memberid, constrained to $size pixels, with optional $padding to that size
	 * @param $memberid
	 * @param $size
	 * @param bool $padding
	 * @return mixed|null|string
	 */
	function as_get_external_avatar_html($memberid, $size, $padding = false)
	{
		if (function_exists('as_avatar_html_from_memberid'))
			return as_avatar_html_from_memberid($memberid, $size, $padding);
		else
			return null;
	}


} else {

	/**
	 * Open a PHP session if one isn't opened already
	 */
	function as_start_session()
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		@ini_set('session.gc_maxlifetime', 86400); // worth a try, but won't help in shared hosting environment
		@ini_set('session.use_trans_sid', false); // sessions need cookies to work, since we redirect after login
		@ini_set('session.cookie_domain', AS_COOKIE_DOMAIN);

		if (!isset($_SESSION))
			session_start();
	}


	/**
	 * Returns a suffix to be used for names of session variables to prevent them being shared between multiple APS sites on the same server
	 */
	function as_session_var_suffix()
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		global $as_session_suffix;

		if (!$as_session_suffix) {
			$prefix = defined('AS_MYSQL_MEMBERS_PREFIX') ? AS_MYSQL_MEMBERS_PREFIX : AS_MYSQL_TABLE_PREFIX;
			$as_session_suffix = md5(AS_FINAL_MYSQL_HOSTNAME . '/' . AS_FINAL_MYSQL_MEMBERNAME . '/' . AS_FINAL_MYSQL_PASSWORD . '/' . AS_FINAL_MYSQL_DATABASE . '/' . $prefix);
		}

		return $as_session_suffix;
	}


	/**
	 * Returns a verification code used to ensure that a member session can't be generated by another PHP script running on the same server
	 * @param $memberid
	 * @return mixed|string
	 */
	function as_session_verify_code($memberid)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		return sha1($memberid . '/' . AS_MYSQL_TABLE_PREFIX . '/' . AS_FINAL_MYSQL_DATABASE . '/' . AS_FINAL_MYSQL_PASSWORD . '/' . AS_FINAL_MYSQL_MEMBERNAME . '/' . AS_FINAL_MYSQL_HOSTNAME);
	}


	/**
	 * Set cookie in browser for username $handle with $sessioncode (in database).
	 * Pass true if member checked 'Remember me' (either now or previously, as learned from cookie).
	 * @param $handle
	 * @param $sessioncode
	 * @param $remember
	 * @return mixed
	 */
	function as_set_session_cookie($handle, $sessioncode, $remember)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		// if $remember is true, store in browser for a month, otherwise store only until browser is closed
		setcookie('as_session', $handle . '/' . $sessioncode . '/' . ($remember ? 1 : 0), $remember ? (time() + 2592000) : 0, '/', AS_COOKIE_DOMAIN, (bool)ini_get('session.cookie_secure'), true);
	}


	/**
	 * Remove session cookie from browser
	 */
	function as_clear_session_cookie()
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		setcookie('as_session', false, 0, '/', AS_COOKIE_DOMAIN, (bool)ini_get('session.cookie_secure'), true);
	}


	/**
	 * Set the session variables to indicate that $memberid is logged in from $source
	 * @param $memberid
	 * @param $source
	 * @return mixed
	 */
	function as_set_session_member($memberid, $source)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		$suffix = as_session_var_suffix();

		$_SESSION['as_session_memberid_' . $suffix] = $memberid;
		$_SESSION['as_session_source_' . $suffix] = $source;
		// prevents one account on a shared server being able to create a log in a member to APS on another account on same server
		$_SESSION['as_session_verify_' . $suffix] = as_session_verify_code($memberid);
	}


	/**
	 * Clear the session variables indicating that a member is logged in
	 */
	function as_clear_session_member()
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		$suffix = as_session_var_suffix();

		unset($_SESSION['as_session_memberid_' . $suffix]);
		unset($_SESSION['as_session_source_' . $suffix]);
		unset($_SESSION['as_session_verify_' . $suffix]);
	}


	/**
	 * Call for successful log in by $memberid and $handle or successful log out with $memberid=null.
	 * $remember states if 'Remember me' was checked in the login form.
	 * @param $memberid
	 * @param string $handle
	 * @param bool $remember
	 * @param $source
	 * @return mixed
	 */
	function as_set_logged_in_member($memberid, $handle = '', $remember = false, $source = null)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		require_once AS_INCLUDE_DIR . 'app/cookies.php';

		as_start_session();

		if (isset($memberid)) {
			as_set_session_member($memberid, $source);

			// PHP sessions time out too quickly on the server side, so we also set a cookie as backup.
			// Logging in from a second browser will make the previous browser's 'Remember me' no longer
			// work - I'm not sure if this is the right behavior - could see it either way.

			require_once AS_INCLUDE_DIR . 'db/selects.php';

			$memberinfo = as_db_single_select(as_db_member_account_selectspec($memberid, true));

			// if we have logged in before, and are logging in the same way as before, we don't need to change the sessioncode/source
			// this means it will be possible to automatically log in (via cookies) to the same account from more than one browser

			if (empty($memberinfo['sessioncode']) || ($source !== $memberinfo['sessionsource'])) {
				$sessioncode = as_db_member_rand_sessioncode();
				as_db_member_set($memberid, 'sessioncode', $sessioncode);
				as_db_member_set($memberid, 'sessionsource', $source);
			} else
				$sessioncode = $memberinfo['sessioncode'];

			as_db_member_logged_in($memberid, as_remote_ip_address());
			as_set_session_cookie($handle, $sessioncode, $remember);

			as_report_event('u_login', $memberid, $memberinfo['handle'], as_cookie_get());

		} else {
			$oldmemberid = as_get_logged_in_memberid();
			$oldhandle = as_get_logged_in_handle();

			as_clear_session_cookie();
			as_clear_session_member();

			as_report_event('u_logout', $oldmemberid, $oldhandle, as_cookie_get());
		}
	}


	/**
	 * Call to log in a member based on an external identity provider $source with external $identifier
	 * A new member is created based on $fields if it's a new combination of $source and $identifier
	 * @param $source
	 * @param $identifier
	 * @param $fields
	 * @return mixed
	 */
	function as_log_in_external_member($source, $identifier, $fields)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		require_once AS_INCLUDE_DIR . 'db/members.php';

		$members = as_db_member_login_find($source, $identifier);
		$countmembers = count($members);

		if ($countmembers > 1)
			as_fatal_error('External login mapped to more than one member'); // should never happen

		if ($countmembers) // member exists so log them in
			as_set_logged_in_member($members[0]['memberid'], $members[0]['handle'], false, $source);

		else { // create and log in member
			require_once AS_INCLUDE_DIR . 'app/members-edit.php';

			as_db_member_login_sync(true);

			$members = as_db_member_login_find($source, $identifier); // check again after table is locked

			if (count($members) == 1) {
				as_db_member_login_sync(false);
				as_set_logged_in_member($members[0]['memberid'], $members[0]['handle'], false, $source);

			} else {
				$handle = as_handle_make_valid(@$fields['handle']);

				if (strlen(@$fields['email'])) { // remove email address if it will cause a duplicate
					$emailmembers = as_db_member_find_by_email($fields['email']);
					if (count($emailmembers)) {
						as_redirect('login', array('e' => $fields['email'], 'ee' => '1'));
						unset($fields['email']);
						unset($fields['confirmed']);
					}
				}

				$memberid = as_create_new_member((string)@$fields['email'], null /* no password */, $handle,
					isset($fields['level']) ? $fields['level'] : AS_MEMBER_LEVEL_BASIC, @$fields['confirmed']);

				as_db_member_login_add($memberid, $source, $identifier);
				as_db_member_login_sync(false);

				$profilefields = array('name', 'location', 'website', 'about');

				foreach ($profilefields as $fieldname) {
					if (strlen(@$fields[$fieldname]))
						as_db_member_profile_set($memberid, $fieldname, $fields[$fieldname]);
				}

				if (strlen(@$fields['avatar']))
					as_set_member_avatar($memberid, $fields['avatar']);

				as_set_logged_in_member($memberid, $handle, false, $source);
			}
		}
	}


	/**
	 * Return the memberid of the currently logged in member, or null if none logged in
	 */
	function as_get_logged_in_memberid()
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		global $as_logged_in_memberid_checked;

		$suffix = as_session_var_suffix();

		if (!$as_logged_in_memberid_checked) { // only check once
			as_start_session(); // this will load logged in memberid from the native PHP session, but that's not enough

			$sessionmemberid = @$_SESSION['as_session_memberid_' . $suffix];

			if (isset($sessionmemberid)) // check verify code matches
				if (!hash_equals(as_session_verify_code($sessionmemberid), @$_SESSION['as_session_verify_' . $suffix]))
					as_clear_session_member();

			if (!empty($_COOKIE['as_session'])) {
				@list($handle, $sessioncode, $remember) = explode('/', $_COOKIE['as_session']);

				if ($remember)
					as_set_session_cookie($handle, $sessioncode, $remember); // extend 'remember me' cookies each time

				$sessioncode = trim($sessioncode); // trim to prevent passing in blank values to match uninitiated DB rows

				// Try to recover session from the database if PHP session has timed out
				if (!isset($_SESSION['as_session_memberid_' . $suffix]) && !empty($handle) && !empty($sessioncode)) {
					require_once AS_INCLUDE_DIR . 'db/selects.php';

					$memberinfo = as_db_single_select(as_db_member_account_selectspec($handle, false)); // don't get any pending

					if (strtolower(trim($memberinfo['sessioncode'])) == strtolower($sessioncode))
						as_set_session_member($memberinfo['memberid'], $memberinfo['sessionsource']);
					else
						as_clear_session_cookie(); // if cookie not valid, remove it to save future checks
				}
			}

			$as_logged_in_memberid_checked = true;
		}

		return @$_SESSION['as_session_memberid_' . $suffix];
	}


	/**
	 * Get the source of the currently logged in member, from call to as_log_in_external_member() or null if logged in normally
	 */
	function as_get_logged_in_source()
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		$memberid = as_get_logged_in_memberid();
		$suffix = as_session_var_suffix();

		if (isset($memberid))
			return @$_SESSION['as_session_source_' . $suffix];
	}


	/**
	 * Return array of information about the currently logged in member, cache to ensure only one call to external code
	 */
	function as_get_logged_in_member_cache()
	{
		global $as_cached_logged_in_member;

		if (!isset($as_cached_logged_in_member)) {
			$memberid = as_get_logged_in_memberid();

			if (isset($memberid)) {
				require_once AS_INCLUDE_DIR . 'db/selects.php';
				$as_cached_logged_in_member = as_db_get_pending_result('loggedinmember', as_db_member_account_selectspec($memberid, true));

				if (!isset($as_cached_logged_in_member)) {
					// the member can no longer be found (should only apply to deleted members)
					as_clear_session_member();
					as_redirect(''); // implicit exit;
				}
			}
		}

		return $as_cached_logged_in_member;
	}


	/**
	 * Return $field of the currently logged in member
	 * @param $field
	 * @return mixed|null
	 */
	function as_get_logged_in_member_field($field)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		$membercache = as_get_logged_in_member_cache();

		return isset($membercache[$field]) ? $membercache[$field] : null;
	}


	/**
	 * Return the number of points of the currently logged in member, or null if none is logged in
	 */
	function as_get_logged_in_points()
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		return as_get_logged_in_member_field('points');
	}


	/**
	 * Return column type to use for members (if not using single sign-on integration)
	 */
	function as_get_mysql_member_column_type()
	{
		return 'INT UNSIGNED';
	}


	/**
	 * Return the URL to the $blobId with a stored size of $width and $height.
	 * Constrain the image to $size (width AND height)
	 *
	 * @param string $blobId The blob ID from the image
	 * @param int|null $size The resulting image's size. If omitted the original image size will be used. If the
	 * size is present it must be greater than 0
	 * @param bool $absolute Whether the link returned should be absolute or relative
	 * @return string|null The URL to the avatar or null if the $blobId was empty or the $size not valid
	 */
	function as_get_avatar_blob_url($blobId, $size = null, $absolute = false)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		require_once AS_INCLUDE_DIR . 'util/image.php';

		if (strlen($blobId) == 0 || (isset($size) && (int)$size <= 0)) {
			return null;
		}

		$params = array('as_blobid' => $blobId);
		if (isset($size)) {
			$params['as_size'] = $size;
		}

		$rootUrl = $absolute ? as_opt('site_url') : null;

		return as_path('image', $params, $rootUrl, AS_URL_FORMAT_PARAMS);
	}


	/**
	 * Get HTML to display a username, linked to their member page.
	 *
	 * @param string $handle  The username.
	 * @param bool $microdata  Whether to include microdata.
	 * @param bool $favorited  Show the member as favorited.
	 * @return string  The member HTML.
	 */
	function as_get_one_member_html($handle, $microdata = false, $favorited = false)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		if (strlen($handle) === 0) {
			return as_lang('main/anonymous');
		}

		$url = as_path_html($handle);
		$favclass = $favorited ? ' as-member-favorited' : '';
		$mfAttr = $microdata ? ' itemprop="url"' : '';

		$memberName = as_html(as_get_member_name($handle));
		$memberHandle = $microdata ? '<span itemprop="name">' . $memberName . '</span>' : $memberName;
		$memberHtml = '<a href="' . $url . '" class="as-member-link' . $favclass . '"' . $mfAttr . '>' . $memberHandle . '</a>';

		if ($microdata) {
			$memberHtml = '<span itemprop="author" itemscope itemtype="http://schema.org/Person">' . $memberHtml . '</span>';
		}

		return $memberHtml;
	}


	/**
	 * Return where the avatar will be fetched from for the given member flags. The possible return values are
	 * 'gravatar' for an avatar that will be fetched from Gravatar, 'local-member' for an avatar fetched locally from
	 * the member's profile, 'local-default' for an avatar fetched locally from the default avatar blob ID, and NULL
	 * if the avatar could not be fetched from any of these sources
	 *
	 * @param int $flags The member's flags
	 * @param string|null $email The member's email
	 * @param string|null $blobId The blob ID for a locally stored avatar.
	 * @return string|null The source of the avatar: 'gravatar', 'local-member', 'local-default' and null
	 */
	function as_get_member_avatar_source($flags, $email, $blobId)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		if (as_opt('avatar_allow_gravatar') && (($flags & AS_MEMBER_FLAGS_SHOW_GRAVATAR) > 0) && isset($email)) {
			return 'gravatar';
		} elseif (as_opt('avatar_allow_upload') && (($flags & AS_MEMBER_FLAGS_SHOW_AVATAR) > 0) && isset($blobId)) {
			return 'local-member';
		} elseif ((as_opt('avatar_allow_gravatar') || as_opt('avatar_allow_upload')) && as_opt('avatar_default_show') && strlen(as_opt('avatar_default_blobid') > 0)) {
			return 'local-default';
		} else {
			return null;
		}
	}


	/**
	 * Return the avatar URL, either Gravatar or from a blob ID, constrained to $size pixels.
	 *
	 * @param int $flags The member's flags
	 * @param string $email The member's email. Only needed to return the Gravatar link
	 * @param string $blobId The blob ID. Only needed to return the locally stored avatar
	 * @param int $size The size to constrain the final image
	 * @param bool $absolute Whether the link returned should be absolute or relative
	 * @return null|string The URL to the member's avatar or null if none could be found (not even as a default site avatar)
	 */
	function as_get_member_avatar_url($flags, $email, $blobId, $size = null, $absolute = false)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		$avatarSource = as_get_member_avatar_source($flags, $email, $blobId);

		switch ($avatarSource) {
			case 'gravatar':
				return as_get_gravatar_url($email, $size);
			case 'local-member':
				return as_get_avatar_blob_url($blobId, $size, $absolute);
			case 'local-default':
				return as_get_avatar_blob_url(as_opt('avatar_default_blobid'), $size, $absolute);
			default: // NULL
				return null;
		}
	}


	/**
	 * Return HTML to display for the member's avatar, constrained to $size pixels, with optional $padding to that size
	 *
	 * @param int $flags The member's flags
	 * @param string $email The member's email. Only needed to return the Gravatar HTML
	 * @param string $blobId The blob ID. Only needed to return the locally stored avatar HTML
	 * @param string $handle The handle of the member that the avatar will link to
	 * @param int $width The width to constrain the image
	 * @param int $height The height to constrain the image
	 * @param int $size The size to constrain the final image
	 * @param bool $padding HTML padding to add to the image
	 * @return string|null The HTML to the member's avatar or null if no valid source for the avatar could be found
	 */
	function as_get_member_avatar_html($flags, $email, $handle, $blobId, $width, $height, $size, $padding = false)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		require_once AS_INCLUDE_DIR . 'app/format.php';
		if (strlen($handle) == 0) {
			return null;
		}

		$avatarSource = as_get_member_avatar_source($flags, $email, $blobId);

		switch ($avatarSource) {
			case 'gravatar':
				$html = as_get_gravatar_html($email, $size);
				break;
			case 'local-member':
				$html = as_get_avatar_blob_html($blobId, $width, $height, $size, $padding);
				break;
			case 'local-default':
				$html = as_get_avatar_blob_html(as_opt('avatar_default_blobid'), as_opt('avatar_default_width'), as_opt('avatar_default_height'), $size, $padding);
				break;
			default: // NULL
				return null;
		}

		return sprintf('<a href="%s" class="as-avatar-link">%s</a>', as_path_html($handle), $html);
	}


	/**
	 * Return email address for member $memberid (if not using single sign-on integration)
	 * @param $memberid
	 * @return string
	 */
	function as_get_member_email($memberid)
	{
		$memberinfo = as_db_select_with_pending(as_db_member_account_selectspec($memberid, true));

		return $memberinfo['email'];
	}


	/**
	 * Return full name for member $memberid (if not using single sign-on integration)
	 * @param $memberid
	 * @return string
	 */
	function as_get_member_name($handle)
	{
		$memberid = as_handle_to_memberid($handle);
		$memberinfo = as_db_select_with_pending(as_db_member_account_selectspec($memberid, true));
		return $memberinfo['firstname'] . ' ' . $memberinfo['lastname'];
	}

	/**
	 * Return first name for member $memberid (if not using single sign-on integration)
	 * @param $memberid
	 * @return string
	 */
	function as_get_first_name($handle)
	{
		$memberid = as_handle_to_memberid($handle);
		$memberinfo = as_db_select_with_pending(as_db_member_account_selectspec($memberid, true));
		return $memberinfo['firstname'];
	}

	/**
	 * Called after a database write $action performed by a member $memberid
	 * @param $memberid
	 * @param $action
	 * @return mixed
	 */
	function as_member_report_action($memberid, $action)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		require_once AS_INCLUDE_DIR . 'db/members.php';

		as_db_member_written($memberid, as_remote_ip_address());
	}


	/**
	 * Return textual representation of the member $level
	 * @param $level
	 * @return mixed|string
	 */
	function as_member_level_string($level)
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

		if ($level >= AS_MEMBER_LEVEL_SUPER)
			$string = 'members/level_super';
		elseif ($level >= AS_MEMBER_LEVEL_ADMIN)
			$string = 'members/level_admin';
		elseif ($level >= AS_MEMBER_LEVEL_MODERATOR)
			$string = 'members/level_moderator';
		elseif ($level >= AS_MEMBER_LEVEL_EDITOR)
			$string = 'members/level_editor';
		elseif ($level >= AS_MEMBER_LEVEL_WRITER)
			$string = 'members/level_writer';
		elseif ($level >= AS_MEMBER_LEVEL_APPROVED)
			$string = 'members/approved_member';
		else
			$string = 'members/registered_member';

		return as_lang($string);
	}


	/**
	 * Return an array of links to login, register, email confirm and logout pages (if not using single sign-on integration)
	 * @param $rooturl
	 * @param $tourl
	 * @return array
	 */
	function as_get_login_links($rooturl, $tourl)
	{
		return array(
			'login' => as_path('login', isset($tourl) ? array('to' => $tourl) : null, $rooturl),
			'register' => as_path('register', isset($tourl) ? array('to' => $tourl) : null, $rooturl),
			'confirm' => as_path('confirm', null, $rooturl),
			'logout' => as_path('logout', null, $rooturl),
		);
	}

} // end of: if (AS_FINAL_EXTERNAL_MEMBERS) { ... } else { ... }


/**
 * Return whether someone is logged in at the moment
 */
function as_is_logged_in()
{
	$memberid = as_get_logged_in_memberid();
	return isset($memberid);
}


/**
 * Return displayable handle/username of currently logged in member, or null if none
 */
function as_get_logged_in_handle()
{
	return as_get_logged_in_member_field(AS_FINAL_EXTERNAL_MEMBERS ? 'publicusername' : 'handle');
}


/**
 * Return email of currently logged in member, or null if none
 */
function as_get_logged_in_email()
{
	return as_get_logged_in_member_field('email');
}

/**
 * Return level of currently logged in member, or null if none
 */
function as_get_logged_in_level()
{
	return as_get_logged_in_member_field('level');
}


/**
 * Return level of currently logged in member, or null if none
 */
function as_get_logged_in_type()
{
	return as_get_logged_in_member_field('type');
}


/**
 * Return flags (see AS_MEMBER_FLAGS_*) of currently logged in member, or null if none
 */
function as_get_logged_in_flags()
{
	if (AS_FINAL_EXTERNAL_MEMBERS)
		return as_get_logged_in_member_field('blocked') ? AS_MEMBER_FLAGS_MEMBER_BLOCKED : 0;
	else
		return as_get_logged_in_member_field('flags');
}


/**
 * Return an array of all the specific (e.g. per department) level privileges for the logged in member, retrieving from the database if necessary
 */
function as_get_logged_in_levels()
{
	require_once AS_INCLUDE_DIR . 'db/selects.php';

	return as_db_get_pending_result('memberlevels', as_db_member_levels_selectspec(as_get_logged_in_memberid(), true));
}


/**
 * Return an array mapping each memberid in $memberids to that member's handle (public username), or to null if not found
 * @param $memberids
 * @return array
 */
function as_memberids_to_handles($memberids)
{
	if (AS_FINAL_EXTERNAL_MEMBERS)
		$rawmemberidhandles = as_get_public_from_memberids($memberids);

	else {
		require_once AS_INCLUDE_DIR . 'db/members.php';
		$rawmemberidhandles = as_db_member_get_memberid_handles($memberids);
	}

	$gotmemberidhandles = array();
	foreach ($memberids as $memberid)
		$gotmemberidhandles[$memberid] = @$rawmemberidhandles[$memberid];

	return $gotmemberidhandles;
}


/**
 * Return an string mapping the received memberid to that member's handle (public username), or to null if not found
 * @param $memberid
 * @return mixed|null
 */
function as_memberid_to_handle($memberid)
{
	$handles = as_memberids_to_handles(array($memberid));
	return empty($handles) ? null : $handles[$memberid];
}


/**
 * Return an array mapping each handle in $handles the member's memberid, or null if not found. If $exactonly is true then
 * $handles must have the correct case and accents. Otherwise, handles are case- and accent-insensitive, and the keys
 * of the returned array will match the $handles provided, not necessary those in the DB.
 * @param $handles
 * @param bool $exactonly
 * @return array
 */
function as_handles_to_memberids($handles, $exactonly = false)
{
	require_once AS_INCLUDE_DIR . 'util/string.php';

	if (AS_FINAL_EXTERNAL_MEMBERS)
		$rawhandlememberids = as_get_memberids_from_public($handles);

	else {
		require_once AS_INCLUDE_DIR . 'db/members.php';
		$rawhandlememberids = as_db_member_get_handle_memberids($handles);
	}

	$gothandlememberids = array();

	if ($exactonly) { // only take the exact matches
		foreach ($handles as $handle)
			$gothandlememberids[$handle] = @$rawhandlememberids[$handle];

	} else { // normalize to lowercase without accents, and then find matches
		$normhandlememberids = array();
		foreach ($rawhandlememberids as $handle => $memberid)
			$normhandlememberids[as_string_remove_accents(as_strtolower($handle))] = $memberid;

		foreach ($handles as $handle)
			$gothandlememberids[$handle] = @$normhandlememberids[as_string_remove_accents(as_strtolower($handle))];
	}

	return $gothandlememberids;
}


/**
 * Return the memberid corresponding to $handle (not case- or accent-sensitive)
 * @param $handle
 * @return mixed|null
 */
function as_handle_to_memberid($handle)
{
	if (AS_FINAL_EXTERNAL_MEMBERS)
		$handlememberids = as_get_memberids_from_public(array($handle));

	else {
		require_once AS_INCLUDE_DIR . 'db/members.php';
		$handlememberids = as_db_member_get_handle_memberids(array($handle));
	}

	if (count($handlememberids) == 1)
		return reset($handlememberids); // don't use $handlememberids[$handle] since capitalization might be different

	return null;
}


/**
 * Return the level of the logged in member for a post with $departmentids (expressing the full hierarchy to the final department)
 * @param $departmentids
 * @return mixed|null
 */
function as_member_level_for_departments($departmentids)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'app/updates.php';

	$level = as_get_logged_in_level();

	if (count($departmentids)) {
		$memberlevels = as_get_logged_in_levels();

		$departmentlevels = array(); // create a map
		foreach ($memberlevels as $memberlevel) {
			if ($memberlevel['entitytype'] == AS_ENTITY_DEPARTMENT)
				$departmentlevels[$memberlevel['entityid']] = $memberlevel['level'];
		}

		foreach ($departmentids as $departmentid) {
			$level = max($level, @$departmentlevels[$departmentid]);
		}
	}

	return $level;
}


/**
 * Return the level of the logged in member for $post, as retrieved from the database
 * @param $post
 * @return mixed|null
 */
function as_member_level_for_post($post)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	if (strlen(@$post['departmentids']))
		return as_member_level_for_departments(explode(',', $post['departmentids']));

	return null;
}


/**
 * Return the maximum possible level of the logged in member in any context (i.e. for any department)
 */
function as_member_level_maximum()
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	$level = as_get_logged_in_level();

	$memberlevels = as_get_logged_in_levels();
	foreach ($memberlevels as $memberlevel) {
		$level = max($level, $memberlevel['level']);
	}

	return $level;
}


/**
 * Check whether the logged in member has permission to perform $permitoption on post $post (from the database)
 * Other parameters and the return value are as for as_member_permit_error(...)
 * @param $permitoption
 * @param $post
 * @param $limitaction
 * @param bool $checkblocks
 * @return bool|string
 */
function as_member_post_permit_error($permitoption, $post, $limitaction = null, $checkblocks = true)
{
	return as_member_permit_error($permitoption, $limitaction, as_member_level_for_post($post), $checkblocks);
}


/**
 * Check whether the logged in member would have permittion to perform $permitoption in any context (i.e. for any department)
 * Other parameters and the return value are as for as_member_permit_error(...)
 * @param $permitoption
 * @param $limitaction
 * @param bool $checkblocks
 * @return bool|string
 */
function as_member_maximum_permit_error($permitoption, $limitaction = null, $checkblocks = true)
{
	return as_member_permit_error($permitoption, $limitaction, as_member_level_maximum(), $checkblocks);
}


/**
 * Check whether the logged in member has permission to perform an action.
 *
 * @param string $permitoption The permission to check (if null, this simply checks whether the member is blocked).
 * @param string $limitaction Constant from /as-include/app/limits.php to check against member or IP rate limits.
 * @param int $memberlevel A AS_MEMBER_LEVEL_* constant to consider the member at a different level to usual (e.g. if
 *   they are performing this action in a department for which they have elevated privileges).
 * @param bool $checkblocks Whether to check the member's blocked status.
 * @param array $memberfields Cache for logged in member, containing keys 'memberid', 'level' (optional), 'flags'.
 *
 * @return bool|string The permission error, or false if no error. Possible errors, in order of priority:
 *   'login' => the member should login or register
 *   'level' => a special privilege level (e.g. writer) or minimum number of points is required
 *   'memberblock' => the member has been blocked
 *   'ipblock' => the ip address has been blocked
 *   'confirm' => the member should confirm their email address
 *   'approve' => the member needs to be approved by the site admins (no longer used as global permission)
 *   'limit' => the member or IP address has reached a rate limit (if $limitaction specified)
 *   false => the operation can go ahead
 */
function as_member_permit_error($permitoption = null, $limitaction = null, $memberlevel = null, $checkblocks = true, $memberfields = null)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	require_once AS_INCLUDE_DIR . 'app/limits.php';

	if (!isset($memberfields))
		$memberfields = as_get_logged_in_member_cache();

	$memberid = isset($memberfields['memberid']) ? $memberfields['memberid'] : null;

	if (!isset($memberlevel))
		$memberlevel = isset($memberfields['level']) ? $memberfields['level'] : null;

	$flags = isset($memberfields['flags']) ? $memberfields['flags'] : null;
	if (!$checkblocks)
		$flags &= ~AS_MEMBER_FLAGS_MEMBER_BLOCKED;

	$error = as_permit_error($permitoption, $memberid, $memberlevel, $flags);

	if ($checkblocks && !$error && as_is_ip_blocked())
		$error = 'ipblock';

	if (!$error && isset($memberid) && ($flags & AS_MEMBER_FLAGS_MUST_CONFIRM) && as_opt('confirm_member_emails'))
		$error = 'confirm';

	if (isset($limitaction) && !$error) {
		if (as_member_limits_remaining($limitaction) <= 0)
			$error = 'limit';
	}

	return $error;
}


/**
 * Check whether member can perform $permitoption. Result as for as_member_permit_error(...).
 *
 * @param string $permitoption Permission option name (from database) for action.
 * @param int $memberid ID of member (null for no member).
 * @param int $memberlevel Level to check against.
 * @param int $memberflags Flags for this member.
 * @param int $memberpoints Member's points: if $memberid is currently logged in, you can set $memberpoints=null to retrieve them only if necessary.
 *
 * @return string|bool Reason the member is not permitted, or false if the operation can go ahead.
 */
function as_permit_error($permitoption, $memberid, $memberlevel, $memberflags, $memberpoints = null)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	$permit = isset($permitoption) ? as_opt($permitoption) : AS_PERMIT_ALL;

	if (isset($memberid) && ($permit == AS_PERMIT_POINTS || $permit == AS_PERMIT_POINTS_CONFIRMED || $permit == AS_PERMIT_APPROVED_POINTS)) {
		// deal with points threshold by converting as appropriate

		if (!isset($memberpoints) && $memberid == as_get_logged_in_memberid())
			$memberpoints = as_get_logged_in_points(); // allow late retrieval of points (to avoid unnecessary DB query when using external members)

		if ($memberpoints >= as_opt($permitoption . '_points')) {
			$permit = $permit == AS_PERMIT_APPROVED_POINTS
				? AS_PERMIT_APPROVED
				: ($permit == AS_PERMIT_POINTS_CONFIRMED ? AS_PERMIT_CONFIRMED : AS_PERMIT_MEMBERS); // convert if member has enough points
		} else
			$permit = AS_PERMIT_WRITERS; // otherwise show a generic message so they're not tempted to collect points just for this
	}

	return as_permit_value_error($permit, $memberid, $memberlevel, $memberflags);
}


/**
 * Check whether member can reach the permission level. Result as for as_member_permit_error(...).
 *
 * @param int $permit Permission constant.
 * @param int $memberid ID of member (null for no member).
 * @param int $memberlevel Level to check against.
 * @param int $memberflags Flags for this member.
 *
 * @return string|bool Reason the member is not permitted, or false if the operation can go ahead
 */
function as_permit_value_error($permit, $memberid, $memberlevel, $memberflags)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	if (!isset($memberid) && $permit < AS_PERMIT_ALL)
		return 'login';

	$levelError =
		($permit <= AS_PERMIT_SUPERS && $memberlevel < AS_MEMBER_LEVEL_SUPER) ||
		($permit <= AS_PERMIT_ADMINS && $memberlevel < AS_MEMBER_LEVEL_ADMIN) ||
		($permit <= AS_PERMIT_MODERATORS && $memberlevel < AS_MEMBER_LEVEL_MODERATOR) ||
		($permit <= AS_PERMIT_EDITORS && $memberlevel < AS_MEMBER_LEVEL_EDITOR) ||
		($permit <= AS_PERMIT_WRITERS && $memberlevel < AS_MEMBER_LEVEL_WRITER);

	if ($levelError)
		return 'level';

	if (isset($memberid) && ($memberflags & AS_MEMBER_FLAGS_MEMBER_BLOCKED))
		return 'memberblock';

	if ($permit >= AS_PERMIT_MEMBERS)
		return false;

	if ($permit >= AS_PERMIT_CONFIRMED) {
		$confirmed = ($memberflags & AS_MEMBER_FLAGS_EMAIL_CONFIRMED);
		// not currently supported by single sign-on integration; approved members and above don't need confirmation
		if (!AS_FINAL_EXTERNAL_MEMBERS && as_opt('confirm_member_emails') && $memberlevel < AS_MEMBER_LEVEL_APPROVED && !$confirmed) {
			return 'confirm';
		}
	} elseif ($permit >= AS_PERMIT_APPROVED) {
		// check member is approved, only if we require it
		if (as_opt('moderate_members') && $memberlevel < AS_MEMBER_LEVEL_APPROVED) {
			return 'approve';
		}
	}

	return false;
}


/**
 * Return whether a captcha is required for posts submitted by the current member. You can pass in a AS_MEMBER_LEVEL_*
 * constant in $memberlevel to consider the member at a different level to usual (e.g. if they are performing this action
 * in a department for which they have elevated privileges).
 *
 * Possible results:
 * 'login' => captcha required because the member is not logged in
 * 'approve' => captcha required because the member has not been approved
 * 'confirm' => captcha required because the member has not confirmed their email address
 * false => captcha is not required
 * @param $memberlevel
 * @return bool|mixed|string
 */
function as_member_captcha_reason($memberlevel = null)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	$reason = false;
	if (!isset($memberlevel))
		$memberlevel = as_get_logged_in_level();

	if ($memberlevel < AS_MEMBER_LEVEL_APPROVED) { // approved members and above aren't shown captchas
		$memberid = as_get_logged_in_memberid();

		if (as_opt('captcha_on_anon_post') && !isset($memberid))
			$reason = 'login';
		elseif (as_opt('moderate_members') && as_opt('captcha_on_unapproved'))
			$reason = 'approve';
		elseif (as_opt('confirm_member_emails') && as_opt('captcha_on_unconfirmed') && !(as_get_logged_in_flags() & AS_MEMBER_FLAGS_EMAIL_CONFIRMED))
			$reason = 'confirm';
	}

	return $reason;
}


/**
 * Return whether a captcha should be presented to the logged in member for writing posts. You can pass in a
 * AS_MEMBER_LEVEL_* constant in $memberlevel to consider the member at a different level to usual.
 * @param $memberlevel
 * @return bool|mixed
 */
function as_member_use_captcha($memberlevel = null)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	return as_member_captcha_reason($memberlevel) != false;
}


/**
 * Return whether moderation is required for posts submitted by the current member. You can pass in a AS_MEMBER_LEVEL_*
 * constant in $memberlevel to consider the member at a different level to usual (e.g. if they are performing this action
 * in a department for which they have elevated privileges).
 *
 * Possible results:
 * 'login' => moderation required because the member is not logged in
 * 'approve' => moderation required because the member has not been approved
 * 'confirm' => moderation required because the member has not confirmed their email address
 * 'points' => moderation required because the member has insufficient points
 * false => moderation is not required
 * @param $memberlevel
 * @return bool|string
 */
function as_member_moderation_reason($memberlevel = null)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	$reason = false;
	if (!isset($memberlevel))
		$memberlevel = as_get_logged_in_level();

	if ($memberlevel < AS_MEMBER_LEVEL_WRITER && as_member_permit_error('permit_moderate')) {
		// writers and above aren't moderated; if the member can approve posts, no point in moderating theirs
		$memberid = as_get_logged_in_memberid();

		if (isset($memberid)) {
			if (as_opt('moderate_members') && as_opt('moderate_unapproved') && ($memberlevel < AS_MEMBER_LEVEL_APPROVED))
				$reason = 'approve';
			elseif (as_opt('confirm_member_emails') && as_opt('moderate_unconfirmed') && !(as_get_logged_in_flags() & AS_MEMBER_FLAGS_EMAIL_CONFIRMED))
				$reason = 'confirm';
			elseif (as_opt('moderate_by_points') && (as_get_logged_in_points() < as_opt('moderate_points_limit')))
				$reason = 'points';

		} elseif (as_opt('moderate_anon_post'))
			$reason = 'login';
	}

	return $reason;
}


/**
 * Return the label to display for $memberfield as retrieved from the database, using default if no name set
 * @param $memberfield
 * @return string
 */
function as_member_memberfield_label($memberfield)
{
	if (isset($memberfield['content']))
		return $memberfield['content'];

	else {
		$defaultlabels = array(
			'name' => 'members/full_name',
			'about' => 'members/about',
			'location' => 'members/location',
			'website' => 'members/website',
		);

		if (isset($defaultlabels[$memberfield['title']]))
			return as_lang($defaultlabels[$memberfield['title']]);
	}

	return '';
}


/**
 * Set or extend the cookie in browser of non logged-in members which identifies them for the purposes of form security (anti-CSRF protection)
 */
function as_set_form_security_key()
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	global $as_form_key_cookie_set;

	if (!as_is_logged_in() && !@$as_form_key_cookie_set) {
		$as_form_key_cookie_set = true;

		if (strlen(@$_COOKIE['as_key']) != AS_FORM_KEY_LENGTH) {
			require_once AS_INCLUDE_DIR . 'util/string.php';
			$_COOKIE['as_key'] = as_random_alphanum(AS_FORM_KEY_LENGTH);
		}

		setcookie('as_key', $_COOKIE['as_key'], time() + 2 * AS_FORM_EXPIRY_SECS, '/', AS_COOKIE_DOMAIN, (bool)ini_get('session.cookie_secure'), true); // extend on every page request
	}
}


/**
 * Return the form security (anti-CSRF protection) hash for an $action (any string), that can be performed within
 * AS_FORM_EXPIRY_SECS of $timestamp (in unix seconds) by the current member.
 * @param $action
 * @param $timestamp
 * @return mixed|string
 */
function as_calc_form_security_hash($action, $timestamp)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	$salt = as_opt('form_security_salt');

	if (as_is_logged_in())
		return sha1($salt . '/' . $action . '/' . $timestamp . '/' . as_get_logged_in_memberid() . '/' . as_get_logged_in_member_field('passsalt'));
	else
		return sha1($salt . '/' . $action . '/' . $timestamp . '/' . @$_COOKIE['as_key']); // lower security for non logged in members - code+cookie can be transferred
}


/**
 * Return the full form security (anti-CSRF protection) code for an $action (any string) performed within
 * AS_FORM_EXPIRY_SECS of now by the current member.
 * @param $action
 * @return mixed|string
 */
function as_get_form_security_code($action)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	as_set_form_security_key();

	$timestamp = as_opt('db_time');

	return (int)as_is_logged_in() . '-' . $timestamp . '-' . as_calc_form_security_hash($action, $timestamp);
}


/**
 * Return whether $value matches the expected form security (anti-CSRF protection) code for $action (any string) and
 * that the code has not expired (if more than AS_FORM_EXPIRY_SECS have passed). Logs causes for suspicion.
 * @param $action
 * @param $value
 * @return bool
 */
function as_check_form_security_code($action, $value)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	$reportproblems = array();
	$silentproblems = array();

	if (!isset($value)) {
		$silentproblems[] = 'code missing';

	} elseif (!strlen($value)) {
		$silentproblems[] = 'code empty';

	} else {
		$parts = explode('-', $value);

		if (count($parts) == 3) {
			$loggedin = $parts[0];
			$timestamp = $parts[1];
			$hash = $parts[2];
			$timenow = as_opt('db_time');

			if ($timestamp > $timenow) {
				$reportproblems[] = 'time ' . ($timestamp - $timenow) . 's in future';
			} elseif ($timestamp < ($timenow - AS_FORM_EXPIRY_SECS)) {
				$silentproblems[] = 'timeout after ' . ($timenow - $timestamp) . 's';
			}

			if (as_is_logged_in()) {
				if (!$loggedin) {
					$silentproblems[] = 'now logged in';
				}
			} else {
				if ($loggedin) {
					$silentproblems[] = 'now logged out';
				} else {
					$key = @$_COOKIE['as_key'];

					if (!isset($key)) {
						$silentproblems[] = 'key cookie missing';
					} elseif (!strlen($key)) {
						$silentproblems[] = 'key cookie empty';
					} elseif (strlen($key) != AS_FORM_KEY_LENGTH) {
						$reportproblems[] = 'key cookie ' . $key . ' invalid';
					}
				}
			}

			if (empty($silentproblems) && empty($reportproblems)) {
				if (!hash_equals(strtolower(as_calc_form_security_hash($action, $timestamp)), strtolower($hash))) {
					$reportproblems[] = 'code mismatch';
				}
			}

		} else {
			$reportproblems[] = 'code ' . $value . ' malformed';
		}
	}

	if (!empty($reportproblems) && AS_DEBUG_PERFORMANCE) {
		@error_log(
			'PHP Osam form security violation for ' . $action .
			' by ' . (as_is_logged_in() ? ('memberid ' . as_get_logged_in_memberid()) : 'anonymous') .
			' (' . implode(', ', array_merge($reportproblems, $silentproblems)) . ')' .
			' on ' . @$_SERVER['REQUEST_URI'] .
			' via ' . @$_SERVER['HTTP_REFERER']
		);
	}

	return (empty($silentproblems) && empty($reportproblems));
}


/**
 * Return the URL for the Gravatar corresponding to $email, constrained to $size
 *
 * @param string $email The email of the Gravatar to return
 * @param int|null $size The size of the Gravatar to return. If omitted the default size will be used
 * @return string The URL to the Gravatar of the member
 */
function as_get_gravatar_url($email, $size = null)
{
	if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }

	$link = 'https://www.gravatar.com/avatar/%s';

	$params = array(md5(strtolower(trim($email))));

	$size = (int)$size;
	if ($size > 0) {
		$link .= '?s=%d';
		$params[] = $size;
	}

	return vsprintf($link, $params);
}
