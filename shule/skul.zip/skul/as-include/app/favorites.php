<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Handles favoriting and unfavoriting (application level)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


/**
 * Set an entity to be favorited or removed from favorites. Handles event reporting.
 *
 * @param int $memberid ID of member assigned to the favorite
 * @param string $handle Username of member
 * @param string $cookieid Cookie ID of member
 * @param string $entitytype Entity type code (one of AS_ENTITY_* constants)
 * @param string $entityid ID of the entity being favorited (e.g. postid for articles)
 * @param bool $favorite Whether to add favorite (true) or remove favorite (false)
 */
function as_member_favorite_set($memberid, $handle, $cookieid, $entitytype, $entityid, $favorite)
{
	require_once AS_INCLUDE_DIR . 'db/favorites.php';
	require_once AS_INCLUDE_DIR . 'app/limits.php';
	require_once AS_INCLUDE_DIR . 'app/updates.php';

	// Make sure the member is not favoriting themselves
	if ($entitytype == AS_ENTITY_MEMBER && $memberid == $entityid) {
		return;
	}

	$params = array('fullname' => as_get_member_name($handle));
	
	if ($favorite)
		as_db_favorite_create($memberid, $entitytype, $entityid);
	else
		as_db_favorite_delete($memberid, $entitytype, $entityid);

	switch ($entitytype) {
		case AS_ENTITY_ARTICLE:
			$action = $favorite ? 'q_favorite' : 'q_unfavorite';
			$params = array_push($params, 'postid' => $entityid);
			break;

		case AS_ENTITY_MEMBER:
			$action = $favorite ? 'u_favorite' : 'u_unfavorite';
			$params = array_push($params, 'memberid' => $entityid);
			break;

		case AS_ENTITY_TAG:
			$action = $favorite ? 'tag_favorite' : 'tag_unfavorite';
			$params = array_push($params, 'wordid' => $entityid);
			break;

		case AS_ENTITY_DEPARTMENT:
			$action = $favorite ? 'cat_favorite' : 'cat_unfavorite';
			$params = array_push($params, 'departmentid' => $entityid);
			break;

		default:
			as_fatal_error('Favorite type not recognized');
			break;
	}

	as_report_event($action, $memberid, $handle, $cookieid, $params);
}


/**
 * Returns content to set in $as_content['q_list'] for a member's favorite $articles. Pre-generated
 * member HTML in $membershtml.
 * @param $articles
 * @param $membershtml
 * @return array
 */
function as_favorite_q_list_view($articles, $membershtml)
{
	$q_list = array(
		'qs' => array(),
	);

	if (count($articles) === 0)
		return $q_list;

	$q_list['form'] = array(
		'tags' => 'method="post" action="' . as_self_html() . '"',
		'hidden' => array(
			'code' => as_get_form_security_code('vote'),
		),
	);

	$defaults = as_post_html_defaults('Q');

	foreach ($articles as $article) {
		$q_list['qs'][] = as_post_html_fields($article, as_get_logged_in_memberid(), as_cookie_get(),
			$membershtml, null, as_post_html_options($article, $defaults));
	}

	return $q_list;
}


/**
 * Returns content to set in $as_content['ranking_members'] for a member's favorite $members. Pre-generated
 * member HTML in $membershtml.
 * @param $members
 * @param $membershtml
 * @return array|null
 */
function as_favorite_members_view($members, $membershtml)
{
	if (AS_FINAL_EXTERNAL_MEMBERS)
		return null;

	require_once AS_INCLUDE_DIR . 'app/members.php';
	require_once AS_INCLUDE_DIR . 'app/format.php';

	$ranking = array(
		'items' => array(),
		'rows' => ceil(count($members) / as_opt('columns_members')),
		'type' => 'members',
	);

	foreach ($members as $member) {
		$avatarhtml = as_get_member_avatar_html($member['flags'], $member['email'], $member['handle'],
			$member['avatarblobid'], $member['avatarwidth'], $member['avatarheight'], as_opt('avatar_members_size'), true);

		$ranking['items'][] = array(
			'avatar' => $avatarhtml,
			'label' => $membershtml[$member['memberid']],
			'score' => as_html(as_format_number($member['points'], 0, true)),
			'raw' => $member,
		);
	}

	return $ranking;
}


/**
 * Returns content to set in $as_content['ranking_tags'] for a member's favorite $tags.
 * @param $tags
 * @return array
 */
function as_favorite_tags_view($tags)
{
	require_once AS_INCLUDE_DIR . 'app/format.php';

	$ranking = array(
		'items' => array(),
		'rows' => ceil(count($tags) / as_opt('columns_tags')),
		'type' => 'tags',
	);

	foreach ($tags as $tag) {
		$ranking['items'][] = array(
			'label' => as_tag_html($tag['word'], false, true),
			'count' => as_html(as_format_number($tag['tagcount'], 0, true)),
		);
	}

	return $ranking;
}


/**
 * Returns content to set in $as_content['nav_list_departments'] for a member's favorite $departments.
 * @param $departments
 * @return array
 */
function as_favorite_departments_view($departments)
{
	require_once AS_INCLUDE_DIR . 'app/format.php';

	$nav_list_departments = array(
		'nav' => array(),
		'type' => 'browse-cat',
	);

	foreach ($departments as $department) {
		$cat_url = as_path_html('articles/' . implode('/', array_reverse(explode('/', $department['backpath']))));
		$cat_anchor = $department['qcount'] == 1
			? as_lang_html_sub('main/1_article', '1', '1')
			: as_lang_html_sub('main/x_articles', as_format_number($department['qcount'], 0, true));
		$cat_descr = strlen($department['content']) ? as_html(' - ' . $department['content']) : '';

		$nav_list_departments['nav'][$department['departmentid']] = array(
			'label' => as_html($department['title']),
			'state' => 'open',
			'favorited' => true,
			'note' => ' - <a href="' . $cat_url . '">' . $cat_anchor . '</a>' . $cat_descr,
		);
	}

	return $nav_list_departments;
}
