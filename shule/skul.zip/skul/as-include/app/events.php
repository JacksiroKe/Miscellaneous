<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Handles the submission of events to the database (application level)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

if (!defined('AS_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}

require_once AS_INCLUDE_DIR . 'db/events.php';
require_once AS_INCLUDE_DIR . 'app/updates.php';


/**
 * Add appropriate events to the database for an action performed on a article. The event of type $updatetype relates
 * to $lastpostid whose antecedent article is $articleid, and was caused by $lastmemberid. Pass a unix $timestamp for
 * the event time or leave as null to use now. This will add an event to $articleid's and $lastmemberid's streams. If
 * $othermemberid is set, it will also add an notification-style event for that member, unless they are the one who did it.
 * @param $articleid
 * @param $lastpostid
 * @param $updatetype
 * @param $lastmemberid
 * @param $othermemberid
 * @param $timestamp
 */
function as_create_event_for_q_member($articleid, $lastpostid, $updatetype, $lastmemberid, $othermemberid = null, $timestamp = null)
{
	as_db_event_create_for_entity(AS_ENTITY_ARTICLE, $articleid, $articleid, $lastpostid, $updatetype, $lastmemberid, $timestamp); // anyone who favorited the article

	if (isset($lastmemberid) && !AS_FINAL_EXTERNAL_MEMBERS)
		as_db_event_create_for_entity(AS_ENTITY_MEMBER, $lastmemberid, $articleid, $lastpostid, $updatetype, $lastmemberid, $timestamp); // anyone who favorited the member who did it

	if (isset($othermemberid) && ($othermemberid != $lastmemberid))
		as_db_event_create_not_entity($othermemberid, $articleid, $lastpostid, $updatetype, $lastmemberid, $timestamp); // possible other member to be informed
}


/**
 * Add appropriate events to the database for an action performed on a set of tags in $tagstring (namely, a article
 * being created with those tags or having one of those tags added afterwards). The event of type $updatetype relates
 * to the article $articleid, and was caused by $lastmemberid. Pass a unix $timestamp for the event time or leave as
 * null to use now.
 * @param $tagstring
 * @param $articleid
 * @param $updatetype
 * @param $lastmemberid
 * @param $timestamp
 */
function as_create_event_for_tags($tagstring, $articleid, $updatetype, $lastmemberid, $timestamp = null)
{
	require_once AS_INCLUDE_DIR . 'util/string.php';
	require_once AS_INCLUDE_DIR . 'db/post-create.php';

	$tagwordids = as_db_word_mapto_ids(array_unique(as_tagstring_to_tags($tagstring)));
	foreach ($tagwordids as $wordid) {
		as_db_event_create_for_entity(AS_ENTITY_TAG, $wordid, $articleid, $articleid, $updatetype, $lastmemberid, $timestamp);
	}
}


/**
 * Add appropriate events to the database for an action performed on $departmentid (namely, a article being created in
 * that department or being moved to it later on), along with all of its ancestor departments. The event of type
 * $updatetype relates to the article $articleid, and was caused by $lastmemberid. Pass a unix $timestamp for the event
 * time or leave as null to use now.
 * @param $departmentid
 * @param $articleid
 * @param $updatetype
 * @param $lastmemberid
 * @param $timestamp
 */
function as_create_event_for_department($departmentid, $articleid, $updatetype, $lastmemberid, $timestamp = null)
{
	if (isset($departmentid)) {
		require_once AS_INCLUDE_DIR . 'db/selects.php';
		require_once AS_INCLUDE_DIR . 'app/format.php';

		$departments = as_department_path(as_db_single_select(as_db_department_nav_selectspec($departmentid, true)), $departmentid);
		foreach ($departments as $department) {
			as_db_event_create_for_entity(AS_ENTITY_DEPARTMENT, $department['departmentid'], $articleid, $articleid, $updatetype, $lastmemberid, $timestamp);
		}
	}
}
