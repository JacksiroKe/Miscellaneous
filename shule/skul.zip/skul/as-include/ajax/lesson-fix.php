<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Server-side response to Ajax request to view table information


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

require_once AS_INCLUDE_DIR . 'app/members.php';
require_once AS_INCLUDE_DIR . 'app/limits.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'db/post-create.php';

$finalcontent = '';
$tablecontent = array();
$unitscontent = array();
$memberid = as_get_logged_in_memberid();

function as_lesson_slots($as_slots, $day, $group, $data = '', $lessons = '')
{
	$grp_lessons = array();
	$grp_finals = array();
	$items = count($as_slots) - 1;
	for ($i = 0; $i <= ($items - 1); $i++)
	{
		$grp_lessons[] = (!strpos($as_slots[$i], '#')) ? $day.'_'.$group.'_'.($i + 1) : '';
	}
	$grp_lessons[] = (!strpos($as_slots[$items], '#')) ? $day.'_'.$group.'_'.($items + 1) : '';
	shuffle($grp_lessons);
	return implode(',', $grp_lessons);
}

function as_daily_slots($day, $as_slots, $as_groups, $periods = '')
{	
	$grp_count = count($as_groups);
	for ($g = 0; $g < $grp_count; $g++) {
		$grouparr = as_array_filter( explode('_', $as_groups[$g]) );
		$periods .= as_lesson_slots($as_slots, $day, $grouparr[1]);
		$periods .= '#';
	}	
	return $periods;
}

$as_count = as_post_text('txtcount');
$timetable = as_post_text('timetable');

$as_slots = as_array_filter( explode(',', as_post_text('txtslots')) );
$as_unit = as_array_filter( explode('_', as_post_text('txtunit')) );
$as_group = as_array_filter( explode('_', as_post_text('txtgroup')) );
$as_teacher = as_array_filter( explode('_', as_post_text('txteacher')) );

$position = $time = '';

if ($as_slots && $as_unit && $as_group && $as_teacher && $as_count && $timetable) {
	$code = $as_unit[1].'_'.$as_group[1].'_'.$as_teacher[1];
	$lessonid = as_db_lesson_create($timetable, $as_group[0], $as_unit[0], $as_teacher[0], $code, $memberid);
	$finalcontent .= $lessonid;
}
/*$slot_count = count($as_slots) - 1;
if (!$as_groups) $as_groups = array('0-DC-Default Class');

$unt_count = count($as_units);
for ($u = 0; $u < $unt_count; $u++) {
	$unitarr = as_array_filter( explode('_', $as_units[$u]) );
	$finalcontent .= $unitarr[1];
}*/

/*$groupings = as_array_filter( explode('#', as_daily_slots(1, $as_slots, $as_groups)) );

foreach ($groupings as $grouping) {
	$grp_content = as_array_filter( explode('|', $grouping) );
	$finalcontent .= implode(',', $grp_content).',';
}*/

echo "AS_AJAX_RESPONSE\n1\n";
echo $finalcontent;
