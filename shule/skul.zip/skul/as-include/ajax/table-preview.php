<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Server-side response to Ajax request to view table information


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

function as_get_breaks($string)
{
	if (strpos($string, '#')) {
		$strings = explode('#', trim($string));
		return $strings[0];
	} else return trim($string);
}

function as_end_time($string)
{
	if (strpos($string, '#')) {
		$strings = explode('#', $string);
		$timestr = $strings[0];
	} else $timestr = $string;
	if (strpos($string, ':')) {
		$timefinal = explode(':', $timestr);
		return ($timefinal[0] + 1) . ':' . $timefinal[1];
	} else return '';
}

function as_set_lesson($day, $id, $break)
{
	if (strpos($break, '#')) {
		$breaks = explode('#', $break);
		$breakcount = count($breaks);
		if ($breakcount = 5)
			return '<td class="td-titles">'.$breaks[$day].'</td>';
		else return '<td class="td-titles">'.$breaks[1].'</td>';
	} else return '<td id="'.$day. '#'. $id.'" >Free</td>';
}

function as_lesson_slots($slots, $day, $breaks = '')
{
	$items = count($slots) - 1;
	for ($i = 0; $i <= ($items - 1); $i++)
	{
		$breaks .= as_set_lesson( $day, $i + 1, $slots[$i]);
	}
	$breaks .= as_set_lesson( $day, $items + 1, $slots[$items]);
	return $breaks;
}

function as_daily_slots($day, $slots, $html = '')
{	
	$timeslots = as_lesson_slots( $slots, $day );
	switch ($day) {
		case 1:
			$daystr = 'MON';
			break;
		case 2:
			$daystr = 'TUE';
			break;
		case 3:
			$daystr = 'WED';
			break;
		case 4:
			$daystr = 'THU';
			break;
		case 5:
			$daystr = 'FRI';
			break;
		case 6:
			$daystr = 'SAT';
			break;
	}
	
	return '<tr><td><b>'.$daystr.'</b></td><td><b>Null</b></td>'.$timeslots.'</tr>';
}

$headers = array();
$tablecontent = array();

$slots = explode(',', as_post_text('txtslots'));
$items = count($slots) - 1;
for ($i = 0; $i <= ($items - 1); $i++) 
	$headers[$i] = as_get_breaks($slots[$i]) . ' -' . as_get_breaks($slots[$i + 1]);

$headers[$items] = as_get_breaks($slots[$items]) . ' -' . as_end_time($slots[$items]);
	
$tablecontent[] = '<table id="as-table"><thead><tr class="as-table-top"><th>DAY</th>';
$tablecontent[] = '<th>Class</th>';
foreach ($headers as $thlabel) $tablecontent[] = '<th>'.$thlabel.'</th>';
$tablecontent[] = '</tr>';
$tablecontent[] = '</thead>';
$tablecontent[] = '<tbody>';

$tablecontent[] = as_daily_slots(1, $slots);
$tablecontent[] = as_daily_slots(2, $slots);
$tablecontent[] = as_daily_slots(3, $slots);
$tablecontent[] = as_daily_slots(4, $slots);
$tablecontent[] = as_daily_slots(5, $slots);

$tablecontent[] = '</tbody>';
$tablecontent[] = '</table>';

echo "AS_AJAX_RESPONSE\n1\n";
echo implode('', $tablecontent);
