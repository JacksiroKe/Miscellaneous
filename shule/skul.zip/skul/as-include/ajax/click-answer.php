<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Server-side response to Ajax single clicks on answer


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

require_once AS_INCLUDE_DIR . 'app/cookies.php';
require_once AS_INCLUDE_DIR . 'app/format.php';
require_once AS_INCLUDE_DIR . 'app/members.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';
require_once AS_INCLUDE_DIR . 'pages/article-view.php';
require_once AS_INCLUDE_DIR . 'pages/article-submit.php';
require_once AS_INCLUDE_DIR . 'util/sort.php';


// Load relevant information about this answer

$answerid = as_post_text('answerid');
$articleid = as_post_text('articleid');

$memberid = as_get_logged_in_memberid();

list($answer, $article, $qchildposts, $achildposts) = as_db_select_with_pending(
	as_db_full_post_selectspec($memberid, $answerid),
	as_db_full_post_selectspec($memberid, $articleid),
	as_db_full_child_posts_selectspec($memberid, $articleid),
	as_db_full_child_posts_selectspec($memberid, $answerid)
);


// Check if there was an operation that succeeded

if (@$answer['basetype'] == 'A' && @$article['basetype'] == 'Q') {
	$answers = as_page_q_load_as($article, $qchildposts);

	$article = $article + as_page_q_post_rules($article, null, null, $qchildposts); // array union
	$answer = $answer + as_page_q_post_rules($answer, $article, $qchildposts, $achildposts);

	if (as_page_q_single_click_a($answer, $article, $answers, $achildposts, false, $error)) {
		list($answer, $article) = as_db_select_with_pending(
			as_db_full_post_selectspec($memberid, $answerid),
			as_db_full_post_selectspec($memberid, $articleid)
		);


		// If so, page content to be updated via Ajax

		echo "AS_AJAX_RESPONSE\n1\n";


		// Send back new count of answers

		$countanswers = $article['acount'];

		if ($countanswers == 1)
			echo as_lang_html('article/1_answer_title');
		else
			echo as_lang_html_sub('article/x_answers_title', $countanswers);


		// If the answer was not deleted....

		if (isset($answer)) {
			$article = $article + as_page_q_post_rules($article, null, null, $qchildposts); // array union
			$answer = $answer + as_page_q_post_rules($answer, $article, $qchildposts, $achildposts);

			$commentsfollows = as_page_q_load_c_follows($article, $qchildposts, $achildposts);

			foreach ($commentsfollows as $key => $commentfollow) {
				$commentsfollows[$key] = $commentfollow + as_page_q_post_rules($commentfollow, $answer, $commentsfollows, null);
			}

			$membershtml = as_memberids_handles_html(array_merge(array($answer), $commentsfollows), true);
			as_sort_by($commentsfollows, 'created');

			$a_view = as_page_q_answer_view($article, $answer, ($answer['postid'] == $article['selchildid'] && $answer['type'] == 'A'),
				$membershtml, false);

			$a_view['c_list'] = as_page_q_comment_follow_list($article, $answer, $commentsfollows, false, $membershtml, false, null);

			$themeclass = as_load_theme_group(as_get_site_theme(), 'ajax-answer', null, null);
			$themeclass->initialize();


			// ... send back the HTML for it

			echo "\n";

			$themeclass->a_list_item($a_view);
		}

		return;
	}
}


echo "AS_AJAX_RESPONSE\n0\n"; // fall back to non-Ajax submission if something failed
