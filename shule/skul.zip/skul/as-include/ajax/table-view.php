<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Server-side response to Ajax request to view table information


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

$headers = array();
$tablecontent = array();

$slots = as_array_filter( explode(',', as_post_text('txtslots')) );
$teachers = as_array_filter( explode(',', as_post_text('txteacher')) );
$groups = as_array_filter( explode(',', as_post_text('txtgroup')) );
$units = as_array_filter( explode(',', as_post_text('txtunit')) );
$count = as_array_filter( explode(',', as_post_text('txtcount')) );

function as_get_breaks($string)
{
	if (strpos($string, '#')) {
		$strings = explode('#', trim($string));
		return $strings[0];
	} else return trim($string);
}

function as_end_time($string)
{
	if (strpos($string, '#')) {
		$strings = explode('#', $string);
		$timestr = $strings[0];
	} else $timestr = $string;
	if (strpos($string, ':')) {
		$timefinal = explode(':', $timestr);
		return ($timefinal[0] + 1) . ':' . $timefinal[1];
	} else return '';
}

function as_day( $day, $grp_count )
{
	$linebr = $grp_count > 1 ? '<br>' : '';
	switch ($day) {
		case 1: return 'M'.$linebr.'O'.$linebr.'N';
		case 2: return 'T'.$linebr.'U'.$linebr.'E';
		case 3: return 'W'.$linebr.'E'.$linebr.'D';
		case 4: return 'T'.$linebr.'H'.$linebr.'U';
		case 5: return 'F'.$linebr.'R'.$linebr.'I';
		case 5: return 'S'.$linebr.'A'.$linebr.'T';
		case 5: return 'S'.$linebr.'U'.$linebr.'N';
	}
}

function as_set_break($day, $id, $break, $grp_count, $data)
{
	$id = $day.'_'.$id;
	if (strpos($break, '#')) {
		$breaks = explode('#', $break);
		$breakcount = count($breaks);
		if ($breakcount = 5)
			return '<td rowspan="'.$grp_count.'" class="td-titles">'.$breaks[$day].'</td>';
		else return '<td rowspan="'.$grp_count.'" class="td-titles">'.$breaks[1].'</td>';
	} else return '<td id="'.$id.'">'.$id.'</td>';
}

function as_break_slots($slots, $day, $group, $groups, $grp_count, $data = '', $breaks = '')
{
	$items = count($slots) - 1;
	for ($i = 0; $i <= ($items - 1); $i++)
	{
		$breaks .= as_set_break( $day, $group.'_'.($i + 1), $slots[$i], $grp_count, $data);
	}
	$breaks .= as_set_break( $day, $group.'_'.($items + 1), $slots[$items], $grp_count, $data);
	return $breaks;
}

function as_lesson_slots($slots, $day, $group, $data = '', $lessons = '')
{
	$items = count($slots) - 1;
	for ($i = 0; $i <= ($items - 1); $i++)
	{
		$id = $day.'_'.$group.'_'.($i + 1);
		$lessons .= (!strpos($slots[$i], '#')) ? '<td id="'.$id.'">'.$id.'</td>' : '';
	}
	$id = $day.'_'.$group.'_'.($items + 1);
	$lessons .= (!strpos($slots[$items], '#')) ? '<td id="'.$id.'">'.$id.'</td>' : '';
	return $lessons;
}

function as_daily_slots($day, $slots, $groups, $teachers, $units, $html = '')
{	
	$grp_count = count($groups);
	$daystr = as_day( $day, $grp_count );
	for ($g = 0; $g < $grp_count; $g++) {
		$grouparr = as_array_filter( explode('|', $groups[$g]) );
		$html .= '<tr>';
		if ($g == 0) {
			$html .= '<td rowspan="'.$grp_count.'" class="td-titles">'.$daystr.'</td>';
			$html .= '<td><b>'.$grouparr[1].'</b></td>';
			$html .= as_break_slots($slots, $day, $grouparr[1], $groups, $grp_count);
		} else {
			$html .= '<td><b>'.$grouparr[1].'</b></td>';
			$html .= as_lesson_slots($slots, $day, $grouparr[1]);
		}
		$html .= '</tr>';
	}	
	return $html;
}

$slot_count = count($slots) - 1;
for ($i = 0; $i <= ($slot_count - 1); $i++) 
	$headers[$i] = as_get_breaks($slots[$i]) . ' -' . as_get_breaks($slots[$i + 1]);

$headers[$slot_count] = as_get_breaks($slots[$slot_count]) . ' -' . as_end_time($slots[$slot_count]);
if (!$groups) $groups = array('X|DC|Default Class');
	
$tablecontent[] = '<table id="as-table"><thead><tr class="as-table-top"><th>DAY</th>';
$tablecontent[] = '<th>Class</th>';
foreach ($headers as $thlabel) $tablecontent[] = '<th>'.$thlabel.'</th>';
$tablecontent[] = '</tr>';
$tablecontent[] = '</thead>';
$tablecontent[] = '<tbody>';

$tablecontent[] = as_daily_slots(1, $slots, $groups, $teachers, $units);
$tablecontent[] = as_daily_slots(2, $slots, $groups, $teachers, $units);
$tablecontent[] = as_daily_slots(3, $slots, $groups, $teachers, $units);
$tablecontent[] = as_daily_slots(4, $slots, $groups, $teachers, $units);
$tablecontent[] = as_daily_slots(5, $slots, $groups, $teachers, $units);

$tablecontent[] = '</tbody>';
$tablecontent[] = '</table>';

echo "AS_AJAX_RESPONSE\n1\n";
echo implode('', $tablecontent);
