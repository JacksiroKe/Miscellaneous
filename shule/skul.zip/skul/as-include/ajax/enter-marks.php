<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Server-side response to Ajax request to submit marks information


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

require_once AS_INCLUDE_DIR . 'app/members.php';
require_once AS_INCLUDE_DIR . 'db/post-update.php';

$student = trim(as_post_text('studentid'));
$exam = trim(as_post_text('examid'));
$paper = trim(as_post_text('paperid'));
$group = trim(as_post_text('groupid'));
$unit = trim(as_post_text('unitid'));
$score = trim(as_post_text('score'));
$remark = trim(as_post_text('remark'));
$memberid = as_get_logged_in_memberid();

$grade = as_grading($score);

as_db_marks_update($score, $grade, $remark, $memberid, $exam, $paper, $group, $unit, $student);

echo "AS_AJAX_RESPONSE\n1\n";
echo "successfully";
