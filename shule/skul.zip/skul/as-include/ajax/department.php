<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Server-side response to Ajax department information requests


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

require_once AS_INCLUDE_DIR . 'db/selects.php';


$departmentid = as_post_text('departmentid');
if (!strlen($departmentid))
	$departmentid = null;

list($fulldepartment, $departments) = as_db_select_with_pending(
	as_db_full_department_selectspec($departmentid, true),
	as_db_department_sub_selectspec($departmentid)
);

echo "AS_AJAX_RESPONSE\n1\n";

echo as_html(strtr(@$fulldepartment['content'], "\r\n", '  ')); // department description

foreach ($departments as $department) {
	// subdepartment information
	echo "\n" . $department['departmentid'] . '/' . $department['title'];
}
