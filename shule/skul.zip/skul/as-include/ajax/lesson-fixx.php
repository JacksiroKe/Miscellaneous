<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Server-side response to Ajax request to view table information


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

$finalcontent = '';
$tablecontent = array();
$unitscontent = array();

function as_lesson_slots($as_slots, $day, $group, $data = '', $lessons = '')
{
	$grp_lessons = array();
	$grp_finals = array();
	$items = count($as_slots) - 1;
	for ($i = 0; $i <= ($items - 1); $i++)
	{
		$grp_lessons[] = (!strpos($as_slots[$i], '#')) ? $day.'-'.$group.'-'.($i + 1) : '';
	}
	$grp_lessons[] = (!strpos($as_slots[$items], '#')) ? $day.'-'.$group.'-'.($items + 1) : '';
	shuffle($grp_lessons);
	return implode(',', $grp_lessons);
}

function as_daily_slots($day, $as_slots, $as_groups, $periods = '')
{	
	$grp_count = count($as_groups);
	for ($g = 0; $g < $grp_count; $g++) {
		$grouparr = as_array_filter( explode('-', $as_groups[$g]) );
		$periods .= as_lesson_slots($as_slots, $day, $grouparr[1]);
		$periods .= '#';
	}	
	return $periods;
}

$as_slots = as_array_filter( explode(',', as_post_text('txtslots')) );
$as_groups = as_array_filter( explode(',', as_post_text('txtgroup')) );
$as_units = as_array_filter( explode(',', as_post_text('txtunit')) );
$as_count = as_array_filter( explode(',', as_post_text('txtcount')) );
$as_teachers = as_array_filter( explode(',', as_post_text('txteacher')) );

$slot_count = count($as_slots) - 1;
if (!$as_groups) $as_groups = array('0-DC-Default Class');

$unt_count = count($as_units);
for ($u = 0; $u < $unt_count; $u++) {
	$unitarr = as_array_filter( explode('-', $as_units[$u]) );
	$finalcontent .= $unitarr[1];
}

/*$groupings = as_array_filter( explode('#', as_daily_slots(1, $as_slots, $as_groups)) );

foreach ($groupings as $grouping) {
	$grp_content = as_array_filter( explode('|', $grouping) );
	$finalcontent .= implode(',', $grp_content).',';
}*/

echo "AS_AJAX_RESPONSE\n1\n";
echo $finalcontent;
