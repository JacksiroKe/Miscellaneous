<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Server-side response to Ajax request to view table information


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

function as_set_lesson($string)
{ 
	if (!strpos($string, '#')) return 1;
}

$slots = explode(',', as_post_text('tt_slots'));

$lesson_count = 0;
$items = count($slots) - 1;
for ($i = 0; $i <= ($items - 1); $i++)
{
	$lesson_count = $lesson_count + as_set_lesson( $slots[$i] );
}
$lesson_count = $lesson_count + as_set_lesson( $slots[$items] );

echo "AS_AJAX_RESPONSE\n1\n";
echo $lesson_count;
