<?php
/*
	Osam by Jackson Siro
	https://www.github.com/AppSmata/Osam/

	Description: Server-side response to Ajax wall post requests


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: https://www.github.com/AppSmata/Osam/license.php
*/

require_once AS_INCLUDE_DIR . 'app/messages.php';
require_once AS_INCLUDE_DIR . 'app/members.php';
require_once AS_INCLUDE_DIR . 'app/cookies.php';
require_once AS_INCLUDE_DIR . 'db/selects.php';


$message = as_post_text('message');
$tohandle = as_post_text('handle');
$morelink = as_post_text('morelink');

$tomemberaccount = as_db_select_with_pending(as_db_member_account_selectspec($tohandle, false));
$loginmemberid = as_get_logged_in_memberid();

$errorhtml = as_wall_error_html($loginmemberid, $tomemberaccount['memberid'], $tomemberaccount['flags']);

if ($errorhtml || !strlen($message) || !as_check_form_security_code('wall-' . $tohandle, as_post_text('code'))) {
	echo "AS_AJAX_RESPONSE\n0"; // if there's an error, process in non-Ajax way
} else {
	$messageid = as_wall_add_post($loginmemberid, as_get_logged_in_handle(), as_cookie_get(),
		$tomemberaccount['memberid'], $tomemberaccount['handle'], $message, '');
	$tomemberaccount['wallposts']++; // won't have been updated

	$membermessages = as_db_select_with_pending(as_db_recent_messages_selectspec(null, null, $tomemberaccount['memberid'], true, as_opt('page_size_wall')));
	$membermessages = as_wall_posts_add_rules($membermessages, 0);

	$themeclass = as_load_theme_group(as_get_site_theme(), 'wall', null, null);
	$themeclass->initialize();

	echo "AS_AJAX_RESPONSE\n1\n";

	echo 'm' . $messageid . "\n"; // element in list to be revealed

	foreach ($membermessages as $message) {
		$themeclass->message_item(as_wall_post_view($message));
	}

	if ($morelink && ($tomemberaccount['wallposts'] > count($membermessages)))
		$themeclass->message_item(as_wall_view_more_link($tohandle, count($membermessages)));
}
